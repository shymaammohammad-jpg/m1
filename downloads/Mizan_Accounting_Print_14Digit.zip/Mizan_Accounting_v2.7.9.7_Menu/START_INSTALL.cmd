@echo off
chcp 65001 >NUL
cd /d "%~dp0"
title Mizan Accounting Setup 2.7.9.7

if not exist "Application\ifrs_accounting\index.php" (
  echo.
  echo ERROR: The ZIP package was not extracted completely.
  echo Use Extract All, then run this file from the extracted folder.
  echo.
  pause
  exit /b 1
)
if not exist "Install_Mizan_2.7.9_Clean.cmd" (
  echo ERROR: Install_Mizan_2.7.9_Clean.cmd is missing.
  pause
  exit /b 2
)

rem The installer asks for administrator permission by itself, and falls back
rem to a per-user installation if that permission is refused. No EXE is used.
call "%~dp0Install_Mizan_2.7.9_Clean.cmd"
exit /b %errorlevel%
