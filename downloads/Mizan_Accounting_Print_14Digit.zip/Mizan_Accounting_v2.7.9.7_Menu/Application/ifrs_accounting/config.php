<?php
declare(strict_types=1);

return [
    'installed' => false,
    'db_host' => '127.0.0.1',
    'db_port' => '3306',
    'db_name' => 'ifrs_accounting',
    'db_user' => 'root',
    'db_pass' => '',
    'app_name' => 'نظام الميزان المحاسبي',
    'timezone' => 'Asia/Baghdad',
    'app_key' => '',
    'version' => '2.7.9.7',
];
