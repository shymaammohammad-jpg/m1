<?php
declare(strict_types=1);
require_once __DIR__ . '/app/core.php';
require_once __DIR__ . '/app/layout.php';

$error='';$success=false;$backupName='';
try{$pdo=db();}catch(Throwable $e){$pdo=null;$error='تعذر الاتصال بقاعدة البيانات الحالية: '.$e->getMessage();}

function upgrade_add_column(PDO $pdo,string $table,string $column,string $definition):void{
    if(table_exists($table)&&!column_exists($table,$column))$pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
}
function upgrade_index_exists(PDO $pdo,string $table,string $index):bool{
    $stmt=$pdo->prepare('SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=? AND table_name=? AND index_name=?');
    $stmt->execute([(string)app_config('db_name'),$table,$index]);
    return (int)$stmt->fetchColumn()>0;
}
function upgrade_exec_script(PDO $pdo,string $sql):void{
    $statement='';$quote=null;$escape=false;
    for($i=0,$n=strlen($sql);$i<$n;$i++){$ch=$sql[$i];if($escape){$statement.=$ch;$escape=false;continue;}if($ch==='\\'&&$quote!==null){$statement.=$ch;$escape=true;continue;}if(in_array($ch,["'",'"','`'],true)){if($quote===null)$quote=$ch;elseif($quote===$ch)$quote=null;$statement.=$ch;continue;}if($ch===';'&&$quote===null){$q=trim($statement);if($q!==''&&!str_starts_with($q,'--'))$pdo->exec($q);$statement='';continue;}$statement.=$ch;}if(trim($statement)!=='')$pdo->exec(trim($statement));
}
function upgrade_sync_account_names(PDO $pdo,int $companyId):int{
    $file=__DIR__.'/database/accounts.csv';
    $h=fopen($file,'rb');
    if(!$h)throw new RuntimeException('تعذر فتح دليل الحسابات العربي المدقق.');
    $head=fgetcsv($h);if(!$head)throw new RuntimeException('ملف دليل الحسابات المدقق فارغ.');
    $head[0]=preg_replace('/^\xEF\xBB\xBF/','',(string)$head[0]);
    $stmt=$pdo->prepare('UPDATE accounts SET name_ar=? WHERE company_id=? AND code=?');
    $n=0;
    while(($r=fgetcsv($h))!==false){
        if(count($r)!==count($head))continue;
        $d=array_combine($head,$r);
        if(!$d||trim((string)$d['code'])==='')continue;
        $stmt->execute([trim((string)$d['name_ar']),$companyId,trim((string)$d['code'])]);
        if($stmt->rowCount()>0)$n++;
    }
    fclose($h);
    return $n;
}

function upgrade_import_standards(PDO $pdo):int{
    $file=__DIR__.'/database/standards.csv';$h=fopen($file,'rb');if(!$h)throw new RuntimeException('تعذر فتح مكتبة المعايير.');$head=fgetcsv($h);$head[0]=preg_replace('/^\xEF\xBB\xBF/','',(string)$head[0]);$stmt=$pdo->prepare('INSERT INTO standards_library(code,title_ar,standard_type,standard_no,guide_order,guide_page) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE title_ar=VALUES(title_ar),guide_order=VALUES(guide_order),guide_page=VALUES(guide_page)');$n=0;while(($r=fgetcsv($h))!==false){if(count($r)!==count($head))continue;$d=array_combine($head,$r);if(!$d||$d['code']==='')continue;$stmt->execute([$d['code'],$d['title_ar'],$d['standard_type'],$d['standard_no'],(int)$d['guide_order'],$d['guide_page']]);$n++;}fclose($h);return $n;
}

if($_SERVER['REQUEST_METHOD']==='POST'&&$pdo instanceof PDO){
    try{
        verify_csrf();
        $username=trim((string)($_POST['username']??''));$password=(string)($_POST['password']??'');
        $stmt=$pdo->prepare("SELECT * FROM users WHERE username=? AND role='admin' AND is_active=1 ORDER BY id LIMIT 1");$stmt->execute([$username]);$admin=$stmt->fetch();
        if(!$admin||!password_verify($password,(string)$admin['password_hash']))throw new RuntimeException('بيانات مدير النظام غير صحيحة.');
        $_SESSION['user']=['id'=>(int)$admin['id'],'company_id'=>(int)$admin['company_id'],'full_name'=>$admin['full_name'],'username'=>$admin['username'],'role'=>$admin['role']];
        if(!is_dir(__DIR__.'/storage/backups'))mkdir(__DIR__.'/storage/backups',0775,true);$backup=create_backup_file();$backupName=$backup['filename'];

        $pdo->exec("CREATE TABLE IF NOT EXISTS schema_migrations (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,version VARCHAR(30) NOT NULL UNIQUE,applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS document_sequences (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,company_id INT UNSIGNED NOT NULL,prefix VARCHAR(12) NOT NULL,sequence_year SMALLINT UNSIGNED NOT NULL,last_number INT UNSIGNED NOT NULL DEFAULT 0,updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY uq_document_sequence(company_id,prefix,sequence_year)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voucher_details (journal_entry_id BIGINT UNSIGNED PRIMARY KEY,sheet_no VARCHAR(100) NULL,check_no VARCHAR(100) NULL,check_date DATE NULL,payee_name VARCHAR(255) NULL,recipient_name VARCHAR(255) NULL,updated_by INT UNSIGNED NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,CONSTRAINT fk_voucher_details_entry FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,CONSTRAINT fk_voucher_details_user FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        foreach([
          ['companies','ministry_name_ar','VARCHAR(190) NULL AFTER name_en'],['companies','formation_name_ar','VARCHAR(190) NULL AFTER ministry_name_ar'],['companies','reporting_basis',"ENUM('going_concern','other') NOT NULL DEFAULT 'going_concern' AFTER fiscal_year_start_month"],['companies','statement_scope',"ENUM('separate','consolidated') NOT NULL DEFAULT 'separate' AFTER reporting_basis"],['companies','expense_presentation',"ENUM('functional','natural','summary') NOT NULL DEFAULT 'functional' AFTER statement_scope"],['companies','rounding_level',"VARCHAR(50) NOT NULL DEFAULT 'دينار' AFTER expense_presentation"],['companies','ifrs_transition_date','DATE NULL AFTER rounding_level'],['companies','previous_gaap_name','VARCHAR(190) NULL AFTER ifrs_transition_date'],
          ['journal_entries','period_id','INT UNSIGNED NULL AFTER company_id'],['journal_entries','document_series',"VARCHAR(12) NOT NULL DEFAULT 'JOURNAL' AFTER period_id"],['journal_entries','origin_standard','VARCHAR(30) NULL AFTER source_type'],['journal_entries','equity_movement_type',"ENUM('none','profit','dividend','reserve','capital','accumulated_loss_amortization','policy_change','nci','oci','other') NOT NULL DEFAULT 'none' AFTER origin_standard"],['journal_entries','approval_status',"ENUM('not_required','pending','approved','rejected') NOT NULL DEFAULT 'not_required' AFTER status"],['journal_entries','version_no','INT UNSIGNED NOT NULL DEFAULT 1 AFTER reversal_of'],['journal_entries','last_modified_by','INT UNSIGNED NULL AFTER created_by'],['journal_entries','submitted_by','INT UNSIGNED NULL AFTER last_modified_by'],['journal_entries','submitted_at','DATETIME NULL AFTER submitted_by'],['journal_entries','approved_by','INT UNSIGNED NULL AFTER submitted_at'],['journal_entries','approved_at','DATETIME NULL AFTER approved_by'],['journal_entries','approval_notes','VARCHAR(500) NULL AFTER approved_at'],['journal_entries','unposted_by','INT UNSIGNED NULL AFTER posted_at'],['journal_entries','unposted_at','DATETIME NULL AFTER unposted_by'],['journal_entries','cancelled_by','INT UNSIGNED NULL AFTER unposted_at'],['journal_entries','cancelled_at','DATETIME NULL AFTER cancelled_by'],
          ['journal_lines','currency_code','VARCHAR(10) NULL AFTER party_id'],['journal_lines','exchange_rate','DECIMAL(20,8) NOT NULL DEFAULT 1 AFTER currency_code'],['journal_lines','foreign_amount','DECIMAL(20,3) NOT NULL DEFAULT 0 AFTER exchange_rate'],['journal_lines','cash_flow_line_code','VARCHAR(40) NULL AFTER foreign_amount'],
          ['cost_centers','functional_report_code',"ENUM('none','5','6','7','8') NOT NULL DEFAULT 'none' AFTER name_ar"],
          ['cash_flow_overrides','allocated_amount','DECIMAL(20,3) NULL AFTER line_code'],
          ['audit_logs','before_json','LONGTEXT NULL AFTER entity_id'],['audit_logs','after_json','LONGTEXT NULL AFTER before_json'],['audit_logs','user_agent','VARCHAR(255) NULL AFTER ip_address']
        ] as [$t,$c,$d])upgrade_add_column($pdo,$t,$c,$d);
        $pdo->exec("ALTER TABLE journal_entries MODIFY status ENUM('draft','posted','reversed','cancelled') NOT NULL DEFAULT 'draft'");
        if(column_exists('journal_entries','document_series')){
            $pdo->exec("UPDATE journal_entries SET document_series=CASE WHEN source_type='payment' THEN 'PAYMENT' WHEN source_type='receipt' THEN 'RECEIPT' ELSE 'JOURNAL' END");
            if(upgrade_index_exists($pdo,'journal_entries','uq_voucher'))$pdo->exec("ALTER TABLE journal_entries DROP INDEX uq_voucher");
            if(!upgrade_index_exists($pdo,'journal_entries','uq_voucher_series'))$pdo->exec("ALTER TABLE journal_entries ADD UNIQUE KEY uq_voucher_series(company_id,document_series,voucher_no)");
        }

        $schema=file_get_contents(__DIR__.'/database/schema.sql');if($schema===false)throw new RuntimeException('تعذر قراءة مخطط الإصدار الجديد.');$pos=strpos($schema,'CREATE TABLE IF NOT EXISTS standards_library');if($pos===false)throw new RuntimeException('مخطط وحدات المطابقة غير مكتمل.');upgrade_exec_script($pdo,substr($schema,$pos));
        $standardCount=upgrade_import_standards($pdo);
        $companyId=(int)$admin['company_id'];
        $accountNamesUpdated=upgrade_sync_account_names($pdo,$companyId);
        $pdo->exec("UPDATE journal_entries je JOIN fiscal_periods fp ON fp.company_id=je.company_id AND je.entry_date BETWEEN fp.start_date AND fp.end_date SET je.period_id=fp.id WHERE je.period_id IS NULL");
        $periods=$pdo->prepare('SELECT id FROM fiscal_periods WHERE company_id=?');$periods->execute([$companyId]);$check=$pdo->prepare("INSERT IGNORE INTO compliance_checklist(company_id,period_id,checklist_code,title_ar,category,status) VALUES(?,?,?,?,?,'not_started')");$items=[['FRAME-01','الإطار والعرض العادل','توثيق الاستمرارية والاستحقاق والأهمية النسبية وعدم المقاصة.'],['IFRS1-01','التحول إلى IFRS','قائمة افتتاحية ومطابقات التحول.'],['IAS1-01','العرض والمقارنة','القوائم الحالية والمقارنة وبداية السابقة.'],['IAS7-01','التدفقات النقدية','الطريقة المباشرة والتصنيف الكامل.'],['NOTES-01','الإيضاحات','السياسات والإيضاحات والمقارنات.'],['CONTROL-01','الرقابة','الاعتماد والتدقيق والإقفال والنسخ الاحتياطية.']];foreach($periods->fetchAll(PDO::FETCH_COLUMN) as $pid)foreach($items as [$code,$cat,$title])$check->execute([$companyId,(int)$pid,$code,$title,$cat]);
        $setting=$pdo->prepare('INSERT INTO app_settings(company_id,setting_key,setting_value) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');foreach([['schema_version','2.3.0'],['application_version','2.7.9.7'],['excel_forms_version','2026-08-05'],['payment_voucher_template','official-photo-2026-08-05'],['account_names_proofread_version','2026-08-04-final'],['account_names_source_hash','c770e536806e96b1784365914a0ede632097ca3bd1d6f31b5f4ff6921140e256'],['installed_standards_count',(string)$standardCount],['posting_requires_approval','0'],['guide_compliance_profile','Iraqi Unified Accounting System IFRS Guide 2026']] as [$k,$v])$setting->execute([$companyId,$k,$v]);
        audit('system_upgrade','application','2.7.9.7',null,null,['backup'=>$backupName,'standards'=>$standardCount,'account_names_updated'=>$accountNamesUpdated]);
        $cfg=app_config();$cfg['installed']=true;$cfg['version']='2.7.9.7';$cfg['app_key']=!empty($cfg['app_key'])?$cfg['app_key']:bin2hex(random_bytes(32));$text="<?php\ndeclare(strict_types=1);\n\nreturn ".var_export($cfg,true).";\n";if(file_put_contents(__DIR__.'/config.php',$text,LOCK_EX)===false)throw new RuntimeException('تمت ترقية قاعدة البيانات، لكن تعذر تحديث config.php.');file_put_contents(__DIR__.'/storage/installed.lock',json_encode(['upgraded_at'=>date('c'),'version'=>'2.7.9.7'],JSON_UNESCAPED_UNICODE),LOCK_EX);$success=true;
    }catch(Throwable $e){$error=$e->getMessage();log_exception($e);}
}
render_public_header('ترقية نظام الميزان المحاسبي إلى الإصدار 2.7.9.7');
?>
<div class="install-card"><div class="install-header"><img class="install-brand-logo" src="assets/branding/app_icon.png" alt="شعار نظام الميزان المحاسبي"><div><h1>ترقية نظام الميزان المحاسبي إلى الإصدار 2.7.9.7</h1><p>ترقية آمنة مع نسخة احتياطية تلقائية، وتطبيق أسماء دليل الحسابات العربية المدققة دون حذف القيود أو الأرصدة.</p></div></div>
<?php if($success):?><div class="alert alert-success">اكتملت الترقية بنجاح. النسخة الاحتياطية: <?=e($backupName)?>.</div><a class="btn btn-primary" href="index.php?page=login">الانتقال إلى تسجيل الدخول</a><?php else:?><?php if($error!==''):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?><div class="grid grid-2"><div class="card"><h3>محتوى الترقية</h3><div class="step-list"><div>تحديث أسماء دليل الحسابات إلى النسخة العربية المدققة.</div><div>إضافة نماذج القوائم المطابقة للدليل.</div><div>إضافة التحول IFRS 1 والسياسات والإيضاحات.</div><div>إضافة سجلات الأصول والمخزون والعقود والمعايير.</div><div>إضافة العملات والتدفقات والاعتماد وسجل المطابقة.</div></div></div><form method="post" class="card"><?=csrf_field()?><h3>تأكيد مدير النظام</h3><div class="field"><label>اسم المستخدم</label><input name="username" required></div><div class="field"><label>كلمة المرور</label><input type="password" name="password" required></div><button class="btn btn-primary" data-confirm="بدء الترقية بعد إنشاء نسخة احتياطية؟">بدء الترقية</button></form></div><?php endif;?></div><?php render_public_footer(); ?>
