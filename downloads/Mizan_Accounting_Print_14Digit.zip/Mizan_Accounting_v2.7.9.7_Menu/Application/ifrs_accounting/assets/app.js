(() => {
  'use strict';
  const sidebar = document.getElementById('sidebar');
  const menuButton = document.getElementById('menuBtn');
  menuButton?.addEventListener('click', () => sidebar?.classList.toggle('open'));
  document.addEventListener('click', (event) => {
    if (window.innerWidth <= 1050 && sidebar?.classList.contains('open') && !sidebar.contains(event.target) && event.target !== menuButton) {
      sidebar.classList.remove('open');
    }
  });

  const modernNavigation = (() => {
    const menu = document.getElementById('modernSidebarMenu');
    if (!menu) return null;
    const groups = Array.from(menu.querySelectorAll('.nav-modern-group'));
    const searchInput = document.getElementById('navMenuSearch');
    const clearButton = document.getElementById('navMenuClear');
    const expandAllButton = document.getElementById('navExpandAll');
    const collapseAllButton = document.getElementById('navCollapseAll');
    const emptyState = document.getElementById('navEmptyState');
    const storageKey = 'mizan.sidebar.groups.v2.7.9.1.cairo-flat';

    const normalize = (value) => String(value || '')
      .toLocaleLowerCase('ar')
      .replace(/[أإآ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/\s+/g, ' ')
      .trim();

    const saveState = () => {
      try {
        const state = {};
        groups.forEach((group) => { state[group.dataset.navGroup || ''] = group.classList.contains('is-open'); });
        localStorage.setItem(storageKey, JSON.stringify(state));
      } catch (_) {}
    };

    const setOpen = (group, open, persist = true) => {
      group.classList.toggle('is-open', open);
      group.querySelector('.nav-modern-trigger')?.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (persist) saveState();
    };

    const restoreState = () => {
      let state = null;
      try { state = JSON.parse(localStorage.getItem(storageKey) || 'null'); } catch (_) {}
      groups.forEach((group) => {
        const key = group.dataset.navGroup || '';
        const hasActive = group.classList.contains('has-active');
        const defaultOpen = group.dataset.defaultOpen === '1';
        const shouldOpen = hasActive || (state && Object.prototype.hasOwnProperty.call(state, key) ? state[key] === true : defaultOpen);
        setOpen(group, shouldOpen, false);
      });
    };

    groups.forEach((group) => {
      group.querySelector('.nav-modern-trigger')?.addEventListener('click', () => {
        setOpen(group, !group.classList.contains('is-open'));
      });
    });

    expandAllButton?.addEventListener('click', () => {
      groups.filter((group) => !group.classList.contains('search-hidden')).forEach((group) => setOpen(group, true, false));
      saveState();
    });
    collapseAllButton?.addEventListener('click', () => {
      groups.filter((group) => !group.classList.contains('has-active')).forEach((group) => setOpen(group, false, false));
      saveState();
    });

    const applySearch = () => {
      const query = normalize(searchInput?.value);
      let visibleGroups = 0;
      groups.forEach((group) => {
        const items = Array.from(group.querySelectorAll('.nav-modern-item'));
        let visibleItems = 0;
        items.forEach((item) => {
          const label = normalize(item.dataset.navLabel || item.textContent);
          const visible = !query || label.includes(query);
          item.hidden = !visible;
          if (visible) visibleItems++;
        });
        const groupVisible = visibleItems > 0;
        group.classList.toggle('search-hidden', !groupVisible);
        if (groupVisible) {
          visibleGroups++;
          if (query) setOpen(group, true, false);
        }
      });
      if (clearButton) clearButton.hidden = !query;
      if (emptyState) emptyState.hidden = visibleGroups !== 0;
    };

    searchInput?.addEventListener('input', applySearch);
    searchInput?.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        searchInput.value = '';
        applySearch();
        searchInput.blur();
      }
    });
    clearButton?.addEventListener('click', () => {
      if (!searchInput) return;
      searchInput.value = '';
      applySearch();
      searchInput.focus();
    });

    restoreState();
    applySearch();
    menu.querySelector('.nav-link.active')?.scrollIntoView({ block: 'nearest' });
    return { setOpen, applySearch };
  })();

  document.querySelectorAll('[data-confirm]').forEach((element) => {
    element.addEventListener('click', (event) => {
      const message = element.dataset.confirm || 'هل أنت متأكد من تنفيذ العملية؟';
      if (!window.confirm(message)) event.preventDefault();
    });
  });

  document.querySelectorAll('.print-btn').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      if (window.IFRSPrintDesigner?.open) window.IFRSPrintDesigner.open();
      else window.print();
    });
  });

  const lineTable = document.getElementById('journal-lines');
  if (lineTable) {
    const body = document.getElementById('voucher-line-body') || lineTable.querySelector('tbody');
    const template = document.getElementById('voucher-line-template') || document.getElementById('journal-row-template');
    const addButton = document.getElementById('add-voucher-line') || document.getElementById('add-line');
    const currencyDecimals = Number(lineTable.dataset.decimals || 3);
    const isExcelVoucher = lineTable.classList.contains('excel-voucher-table');

    const parse = (value) => {
      const normalized = String(value || '').replace(/[٬,\s]/g, '').replace('٫', '.');
      const number = Number.parseFloat(normalized);
      return Number.isFinite(number) ? number : 0;
    };
    const format = (value) => Number(value || 0).toLocaleString('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: currencyDecimals,
    });

    const arabicUnderThousand = (number) => {
      const units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
      const tens = {20:'عشرون',30:'ثلاثون',40:'أربعون',50:'خمسون',60:'ستون',70:'سبعون',80:'ثمانون',90:'تسعون'};
      const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];
      const parts = [];
      let n = Math.floor(number);
      if (n >= 100) {
        parts.push(hundreds[Math.floor(n / 100)]);
        n %= 100;
      }
      if (n > 0) {
        if (n < 20) parts.push(units[n]);
        else {
          const u = n % 10;
          const t = n - u;
          parts.push(u ? `${units[u]} و${tens[t]}` : tens[t]);
        }
      }
      return parts.filter(Boolean).join(' و');
    };
    const arabicIntegerWords = (number) => {
      let n = Math.floor(Math.abs(Number(number) || 0));
      if (n === 0) return 'صفر';
      const scales = [
        [1000000000000, 'تريليون', 'تريليونان', 'تريليونات'],
        [1000000000, 'مليار', 'ملياران', 'مليارات'],
        [1000000, 'مليون', 'مليونان', 'ملايين'],
        [1000, 'ألف', 'ألفان', 'آلاف'],
      ];
      const parts = [];
      scales.forEach(([value, one, two, plural]) => {
        if (n < value) return;
        const count = Math.floor(n / value);
        n %= value;
        if (count === 1) parts.push(one);
        else if (count === 2) parts.push(two);
        else if (count >= 3 && count <= 10) parts.push(`${arabicUnderThousand(count)} ${plural}`);
        else parts.push(`${arabicUnderThousand(count)} ${one}`);
      });
      if (n > 0) parts.push(arabicUnderThousand(n));
      return parts.filter(Boolean).join(' و');
    };

    if (isExcelVoucher) {
      const detailRows = () => Array.from(body?.querySelectorAll('.voucher-line') || []);
      const placeCode = (row, selector, code, prefix, min, max) => {
        row?.querySelectorAll(selector).forEach((cell) => { cell.textContent = ''; });
        const digits = String(code || '').replace(/\D+/g, '');
        if (!digits) return;
        const level = Math.max(min, Math.min(max, digits.length));
        const target = row?.querySelector(`${selector}.${prefix}-level-${level}`);
        if (target) target.textContent = code || '';
      };
      const applyAccount = (detailRow, option) => {
        const codeInput = detailRow.querySelector('.voucher-account-code-input');
        const printName = detailRow.querySelector('.voucher-account-print-name');
        const code = option?.dataset.code || '';
        const name = option?.dataset.name || '';
        if (codeInput && document.activeElement !== codeInput) codeInput.value = code;
        if (printName) printName.textContent = name;
        placeCode(detailRow, '.voucher-detail-code', code, 'code', 3, 5);
      };
      const applyCostCenter = (row) => {
        const select = row.querySelector('.voucher-cc-select');
        const code = select?.selectedOptions?.[0]?.dataset.code || '';
        placeCode(row, '.voucher-cc-code', code, 'cc', 5, 9);
      };
      const applySide = (row) => {
        const side = row.querySelector('.voucher-line-side');
        if (!side) return;
        const debit = parse(row.querySelector('.voucher-debit')?.value) || parse(row.querySelector('.voucher-debit-fils')?.value);
        const credit = parse(row.querySelector('.voucher-credit')?.value) || parse(row.querySelector('.voucher-credit-fils')?.value);
        side.textContent = debit > 0 ? 'من ح/ ' : (credit > 0 ? 'الى ح/ ' : '');
      };
      const applyNote = (row) => {
        const note = row.querySelector('.voucher-line-note');
        const value = row.querySelector('.voucher-line-note-input')?.value || '';
        if (note) note.textContent = value ? ` — ${value}` : '';
      };
      const selectFromCode = (detailRow, force = false) => {
        const input = detailRow.querySelector('.voucher-account-code-input');
        const select = detailRow.querySelector('.voucher-account-select');
        if (!input || !select) return;
        const code = String(input.value || '').trim();
        const options = Array.from(select.options);
        const exact = options.find((option) => option.dataset.code === code);
        const prefixMatches = options.filter((option) => option.dataset.code?.startsWith(code));
        const matched = exact || (force && prefixMatches.length === 1 ? prefixMatches[0] : null);
        if (matched) {
          select.value = matched.value;
          input.value = matched.dataset.code || code;
          applyAccount(detailRow, matched);
          input.setCustomValidity('');
        } else if (!code) {
          select.value = '';
          applyAccount(detailRow, null);
          input.setCustomValidity('');
        } else if (force) {
          input.setCustomValidity('رقم الحساب غير موجود في الدليل.');
          input.reportValidity();
        }
      };
      const filsOf = (input) => {
        const digits = String(input?.value || '').replace(/\D+/g, '').slice(0, 3);
        return digits ? Number(digits.padEnd(3, '0')) / 1000 : 0;
      };
      const calculate = () => {
        let debit = 0;
        let credit = 0;
        detailRows().forEach((row) => {
          debit += parse(row.querySelector('.voucher-debit')?.value) + filsOf(row.querySelector('.voucher-debit-fils'));
          credit += parse(row.querySelector('.voucher-credit')?.value) + filsOf(row.querySelector('.voucher-credit-fils'));
          applySide(row);
        });
        const difference = debit - credit;
        const totalDebit = document.getElementById('voucher-total-debit');
        const totalCredit = document.getElementById('voucher-total-credit');
        const totalDiff = document.getElementById('voucher-total-diff');
        const words = document.getElementById('voucher-amount-words');
        const debitFilsCell = document.getElementById('voucher-total-debit-fils');
        const creditFilsCell = document.getElementById('voucher-total-credit-fils');
        const filsText = (value) => {
          const fils = Math.round((value - Math.floor(value)) * 1000);
          return fils > 0 ? String(fils).padStart(3, '0') : '';
        };
        if (debitFilsCell) debitFilsCell.textContent = filsText(debit);
        if (creditFilsCell) creditFilsCell.textContent = filsText(credit);
        if (totalDebit) totalDebit.textContent = format(Math.floor(debit));
        if (totalCredit) totalCredit.textContent = format(Math.floor(credit));
        if (totalDiff) {
          totalDiff.textContent = format(difference);
          totalDiff.className = Math.abs(difference) < 0.0005 ? 'balanced' : 'unbalanced';
        }
        if (words) {
          const currency = words.dataset.currency || document.documentElement.dataset.currency || 'دينار عراقي';
          const wholePart = Math.floor(debit);
          const filsPart = Math.round((debit - wholePart) * 1000);
          const filsPhrase = filsPart > 0 ? ` و${arabicIntegerWords(filsPart)} فلساً` : '';
          words.textContent = `فقط ${arabicIntegerWords(wholePart)} ${currency}${filsPhrase} لا غير`;
        }
      };
      const updateDateParts = () => {
        const input = document.querySelector('input[name="entry_date"]');
        if (!input?.value) return;
        const [year, month, day] = input.value.split('-');
        const dayCell = lineTable.querySelector('.voucher-date-day');
        const monthCell = lineTable.querySelector('.voucher-date-month');
        const yearCell = lineTable.querySelector('.voucher-date-year');
        if (dayCell) dayCell.textContent = day || '';
        if (monthCell) monthCell.textContent = month || '';
        if (yearCell) yearCell.textContent = year || '';
      };
      const initializeRow = (detailRow) => {
        const select = detailRow.querySelector('.voucher-account-select');
        const option = select?.selectedOptions?.[0];
        if (option?.value) applyAccount(detailRow, option);
        applyCostCenter(detailRow);
        applyNote(detailRow);
      };

      detailRows().forEach(initializeRow);
      body?.addEventListener('change', (event) => {
        const select = event.target.closest('.voucher-account-select');
        if (select) {
          const detailRow = select.closest('.voucher-line');
          const option = select.selectedOptions?.[0];
          if (detailRow) applyAccount(detailRow, option?.value ? option : null);
        }
        if (event.target.matches('.voucher-account-code-input')) selectFromCode(event.target.closest('.voucher-line'), true);
        if (event.target.matches('.voucher-cc-select')) applyCostCenter(event.target.closest('.voucher-line'));
      });
      body?.addEventListener('input', (event) => {
        const input = event.target;
        if (input.matches('.voucher-account-code-input')) selectFromCode(input.closest('.voucher-line'), false);
        const row = input.closest('.voucher-line');
        if (row && input.matches('.voucher-debit, .voucher-debit-fils') && parse(input.value) > 0) {
          row.querySelectorAll('.voucher-credit, .voucher-credit-fils').forEach((other) => { other.value = ''; });
        }
        if (row && input.matches('.voucher-credit, .voucher-credit-fils') && parse(input.value) > 0) {
          row.querySelectorAll('.voucher-debit, .voucher-debit-fils').forEach((other) => { other.value = ''; });
        }
        if (row && input.matches('.voucher-line-note-input')) applyNote(row);
        calculate();
      });
      body?.addEventListener('focusout', (event) => {
        if (event.target.matches('.voucher-account-code-input')) selectFromCode(event.target.closest('.voucher-line'), true);
      });
      body?.addEventListener('click', (event) => {
        const remove = event.target.closest('.voucher-remove-line');
        if (!remove) return;
        const detailRow = remove.closest('.voucher-line');
        if (!detailRow) return;
        if (detailRows().length > 2) {
          detailRow.remove();
        } else {
          detailRow.querySelectorAll('input').forEach((input) => {
            if (input.name === 'currency_code[]') return;
            if (input.name === 'exchange_rate[]') input.value = '1';
            else if (input.name === 'foreign_amount[]') input.value = '0';
            else input.value = '';
          });
          detailRow.querySelectorAll('select').forEach((select) => { select.value = ''; });
          applyAccount(detailRow, null);
          applyCostCenter(detailRow);
          applyNote(detailRow);
        }
        calculate();
      });
      addButton?.addEventListener('click', () => {
        if (!template || !body) return;
        const indices = detailRows().map((row) => Number(row.dataset.lineIndex || 0));
        const index = (indices.length ? Math.max(...indices) : -1) + 1;
        body.insertAdjacentHTML('beforeend', template.innerHTML.replaceAll('__INDEX__', String(index)));
        const row = body.querySelector(`.voucher-line[data-line-index="${index}"]`);
        row?.querySelector('.voucher-account-code-input')?.focus();
        calculate();
      });
      document.querySelector('input[name="entry_date"]')?.addEventListener('change', updateDateParts);
      const wordsCell = document.getElementById('voucher-amount-words');
      if (wordsCell && !wordsCell.dataset.currency) {
        const initialText = wordsCell.textContent || '';
        const currencyMatch = initialText.match(/(?:صفر|\d+)\s+(.+?)\s+لا غير/);
        wordsCell.dataset.currency = currencyMatch?.[1] || 'دينار عراقي';
      }
      updateDateParts();
      calculate();
    } else {
      const renumber = () => body?.querySelectorAll('tr').forEach((row, index) => {
        const cell = row.querySelector('.row-no');
        if (cell) cell.textContent = String(index + 1);
      });
      const calculate = () => {
        let debit = 0;
        let credit = 0;
        body?.querySelectorAll('input[name="debit[]"]').forEach((input) => debit += parse(input.value));
        body?.querySelectorAll('input[name="credit[]"]').forEach((input) => credit += parse(input.value));
        const difference = debit - credit;
        const d = document.getElementById('total-debit');
        const c = document.getElementById('total-credit');
        const diff = document.getElementById('total-diff');
        if (d) d.textContent = format(debit);
        if (c) c.textContent = format(credit);
        if (diff) {
          diff.textContent = format(difference);
          diff.className = Math.abs(difference) < 0.0005 ? 'balanced' : 'unbalanced';
        }
      };
      addButton?.addEventListener('click', () => {
        if (template && body) body.insertAdjacentHTML('beforeend', template.innerHTML);
        renumber();
        calculate();
      });
      lineTable.addEventListener('click', (event) => {
        const remove = event.target.closest('.remove-line');
        if (!remove) return;
        const rows = body?.querySelectorAll('tr') || [];
        if (rows.length <= 2) return;
        remove.closest('tr')?.remove();
        renumber();
        calculate();
      });
      lineTable.addEventListener('input', (event) => {
        const input = event.target;
        if (input.matches('input[name="debit[]"]') && parse(input.value) > 0) {
          const other = input.closest('tr')?.querySelector('input[name="credit[]"]');
          if (other) other.value = '';
        }
        if (input.matches('input[name="credit[]"]') && parse(input.value) > 0) {
          const other = input.closest('tr')?.querySelector('input[name="debit[]"]');
          if (other) other.value = '';
        }
        calculate();
      });
      renumber();
      calculate();
    }
  }

  document.querySelectorAll('[data-assistant-question]').forEach((button) => {
    button.addEventListener('click', () => {
      const input = document.getElementById('assistantQuestion');
      if (!input) return;
      input.value = button.dataset.assistantQuestion || '';
      input.focus();
      input.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  });


  const excelExport = (() => {
    const toast = (message, isError = false) => {
      const el = document.getElementById('toast');
      if (!el) return;
      el.textContent = message;
      el.classList.toggle('toast-error', isError);
      el.classList.add('show');
      setTimeout(() => el.classList.remove('show'), 2600);
    };

    const normalizeText = (value) => String(value ?? '').replace(/\s+/g, ' ').trim();
    const numericValue = (text) => {
      const normalized = String(text).replace(/[٬,\s]/g, '').replace('٫', '.').replace(/^\((.*)\)$/, '-$1');
      return /^-?\d+(?:\.\d+)?$/.test(normalized) ? Number(normalized) : null;
    };
    const cellValue = (cell) => {
      const clone = cell.cloneNode(true);
      clone.querySelectorAll('.no-print,button,.btn,script,style').forEach((node) => node.remove());
      clone.querySelectorAll('input,select,textarea').forEach((field) => {
        let text = '';
        if (field.tagName === 'SELECT') text = field.selectedOptions?.[0]?.textContent || field.value || '';
        else if (field.type === 'checkbox' || field.type === 'radio') text = field.checked ? 'نعم' : 'لا';
        else text = field.value || '';
        field.replaceWith(document.createTextNode(text));
      });
      return normalizeText(clone.textContent);
    };
    const isExcludedCell = (cell) => cell.classList.contains('no-print') || cell.classList.contains('no-excel') || getComputedStyle(cell).display === 'none';
    const rowStyle = (row) => {
      if (row.closest('thead')) return 'header';
      if (row.matches('.grand-total,.subtotal,.gj-total-row,.balance-grand-total,.guide-total,.guide-grand,.total-row') || row.closest('tfoot')) return 'total';
      return 'body';
    };

    const tableToSheet = (table, index) => {
      const grid = [];
      const merges = [];
      let headerRows = 0;
      const rows = Array.from(table.rows);
      rows.forEach((row, rowIndex) => {
        if (row.closest('thead')) headerRows++;
        if (!grid[rowIndex]) grid[rowIndex] = [];
        let colIndex = 0;
        Array.from(row.cells).forEach((cell) => {
          if (isExcludedCell(cell)) return;
          while (grid[rowIndex][colIndex] !== undefined) colIndex++;
          const rowSpan = Math.max(1, Number(cell.rowSpan || 1));
          const colSpan = Math.max(1, Number(cell.colSpan || 1));
          const text = cellValue(cell);
          const num = cell.classList.contains('num') ? numericValue(text) : null;
          grid[rowIndex][colIndex] = { value: num === null ? text : num, type: num === null ? 'string' : 'number', style: rowStyle(row) };
          for (let rr = rowIndex; rr < rowIndex + rowSpan; rr++) {
            if (!grid[rr]) grid[rr] = [];
            for (let cc = colIndex; cc < colIndex + colSpan; cc++) {
              if (rr === rowIndex && cc === colIndex) continue;
              grid[rr][cc] = { value: '', type: 'string', style: rowStyle(row) };
            }
          }
          if (rowSpan > 1 || colSpan > 1) {
            merges.push({ startRow: rowIndex, startCol: colIndex, endRow: rowIndex + rowSpan - 1, endCol: colIndex + colSpan - 1 });
          }
          colIndex += colSpan;
        });
      });
      const maxCols = grid.reduce((max, row) => Math.max(max, row.length), 0);
      grid.forEach((row) => { while (row.length < maxCols) row.push({ value: '', type: 'string', style: 'body' }); });
      const pageTitle = normalizeText(document.querySelector('.page-heading h1')?.textContent || document.querySelector('.topbar-title')?.textContent || 'تقرير');
      const cardTitle = normalizeText(table.dataset.excelSheet || table.closest('.card')?.querySelector('.report-head h2:last-of-type,.report-section-title,h2,h3')?.textContent || '');
      return { name: cardTitle || (index === 0 ? pageTitle : `${pageTitle} ${index + 1}`), rows: grid, merges, headerRows };
    };

    const exportTables = async (button) => {
      const tables = Array.from(document.querySelectorAll('.content table:not(.no-excel)')).filter((table) => table.rows.length > 0 && getComputedStyle(table).display !== 'none');
      if (!tables.length) {
        toast('لا يوجد جدول ظاهر قابل للتصدير.', true);
        return;
      }
      const pageTitle = normalizeText(document.querySelector('.page-heading h1')?.textContent || document.title || 'تقرير');
      const payload = { filename: `${pageTitle}_${new Date().toISOString().slice(0, 10)}`, sheets: tables.map(tableToSheet) };
      const token = document.querySelector('meta[name="csrf-token"]')?.content || document.querySelector('input[name="csrf"]')?.value || '';
      if (!token) {
        toast('تعذر قراءة رمز الحماية. أعد تحميل الصفحة ثم حاول مرة أخرى.', true);
        return;
      }
      const body = new FormData();
      body.append('csrf', token);
      body.append('payload', JSON.stringify(payload));
      const original = button.textContent;
      button.disabled = true;
      button.textContent = 'جاري إنشاء Excel...';
      try {
        const response = await fetch('index.php?page=excel_export', { method: 'POST', body, credentials: 'same-origin' });
        if (!response.ok) {
          const message = await response.text();
          throw new Error(message || 'تعذر إنشاء ملف Excel.');
        }
        const blob = await response.blob();
        const disposition = response.headers.get('Content-Disposition') || '';
        const match = disposition.match(/filename\*=UTF-8''([^;]+)/i);
        const filename = match ? decodeURIComponent(match[1]) : `${pageTitle}.xlsx`;
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1500);
        toast('تم إنشاء ملف Excel بنجاح.');
      } catch (error) {
        toast(error.message || 'تعذر إنشاء ملف Excel.', true);
      } finally {
        button.disabled = false;
        button.textContent = original;
      }
    };

    const bind = () => {
      const tables = document.querySelectorAll('.content table:not(.no-excel)');
      if (!tables.length) return;
      let buttons = Array.from(document.querySelectorAll('.excel-export-btn'));
      if (!buttons.length) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'btn btn-outline excel-export-btn no-print';
        button.textContent = 'تصدير Excel';
        const actions = document.querySelector('.page-actions');
        if (actions) actions.appendChild(button);
        else {
          const toolbar = document.createElement('div');
          toolbar.className = 'excel-export-toolbar no-print';
          toolbar.appendChild(button);
          document.querySelector('.page-heading')?.insertAdjacentElement('afterend', toolbar);
        }
        buttons = [button];
      }
      buttons.forEach((button) => button.addEventListener('click', () => exportTables(button)));
    };
    return { bind };
  })();
  excelExport.bind();

  document.querySelectorAll('[data-copy]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(button.dataset.copy || '');
        const toast = document.getElementById('toast');
        if (toast) {
          toast.textContent = 'تم النسخ';
          toast.classList.add('show');
          setTimeout(() => toast.classList.remove('show'), 1600);
        }
      } catch (_) {}
    });
  });
})();

/* v2.7.9.3 — التاريخ في المستندات: ثلاثة حقول يوم/شهر/سنة بترتيب من اليمين إلى اليسار */
(function () {
  const westernDigits = (value) => String(value || '')
    .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[\u06f0-\u06f9]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/\D+/g, '');

  const bind = (wrap) => {
    const day = wrap.querySelector('.doc-date-day');
    const month = wrap.querySelector('.doc-date-month');
    const year = wrap.querySelector('.doc-date-year');
    const hidden = wrap.querySelector('.doc-date-value');
    if (!day || !month || !year || !hidden) return;

    const sync = () => {
      const d = westernDigits(day.value);
      const m = westernDigits(month.value);
      const y = westernDigits(year.value);
      let valid = d !== '' && m !== '' && y.length === 4;
      if (valid) {
        const probe = new Date(`${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}T00:00:00`);
        valid = probe.getFullYear() === Number(y)
          && probe.getMonth() + 1 === Number(m)
          && probe.getDate() === Number(d);
      }
      hidden.value = valid ? `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}` : '';
      const message = valid ? '' : 'أدخل تاريخاً صحيحاً: يوم / شهر / سنة.';
      [day, month, year].forEach((field) => field.setCustomValidity(message));
      document.dispatchEvent(new CustomEvent('doc-date-change', { detail: hidden.value }));
    };

    [day, month, year].forEach((field) => {
      field.addEventListener('input', () => {
        field.value = westernDigits(field.value);
        sync();
        const limit = field === year ? 4 : 2;
        if (field.value.length >= limit && field !== year) {
          (field === day ? month : year).focus();
        }
      });
      field.addEventListener('blur', () => {
        const limit = field === year ? 4 : 2;
        if (field.value && field.value.length < limit && field !== year) {
          field.value = field.value.padStart(2, '0');
        }
        sync();
      });
    });
    sync();
  };

  document.querySelectorAll('.doc-date-field').forEach(bind);
})();
