<?php
declare(strict_types=1);
require_once __DIR__ . '/app/core.php';
require_once __DIR__ . '/app/layout.php';

$lockFile = __DIR__ . '/storage/installed.lock';
if (is_file($lockFile) && (bool)app_config('installed', false)) {
    redirect('index.php');
}

function execute_sql_script(PDO $pdo, string $sql): void
{
    $statement = '';
    $quote = null;
    $escape = false;
    $length = strlen($sql);
    for ($i = 0; $i < $length; $i++) {
        $char = $sql[$i];
        if ($escape) {
            $statement .= $char;
            $escape = false;
            continue;
        }
        if ($char === '\\' && $quote !== null) {
            $statement .= $char;
            $escape = true;
            continue;
        }
        if (($char === "'" || $char === '"' || $char === '`')) {
            if ($quote === null) {
                $quote = $char;
            } elseif ($quote === $char) {
                $quote = null;
            }
            $statement .= $char;
            continue;
        }
        if ($char === ';' && $quote === null) {
            $trimmed = trim($statement);
            if ($trimmed !== '' && !str_starts_with($trimmed, '--')) {
                $pdo->exec($trimmed);
            }
            $statement = '';
            continue;
        }
        $statement .= $char;
    }
    $trimmed = trim($statement);
    if ($trimmed !== '') {
        $pdo->exec($trimmed);
    }
}

$error = '';
$success = false;
$pdo = null;
$targetDbName = '';
$targetDbExisted = false;
$schemaCreated = false;
$diagnostics = [
    'PHP 8.1 أو أحدث' => version_compare(PHP_VERSION, '8.1.0', '>='),
    'PDO MySQL' => extension_loaded('pdo_mysql'),
    'امتداد mbstring' => extension_loaded('mbstring'),
    'مجلد النظام قابل للكتابة' => is_writable(__DIR__),
    'مجلد التخزين قابل للكتابة' => is_writable(__DIR__ . '/storage'),
    'ملف دليل الحسابات المدقق موجود' => is_file(__DIR__ . '/database/accounts.csv'),
    'بصمة دليل الحسابات المدقق موجودة' => is_file(__DIR__ . '/database/accounts_proofread.sha256'),
    'ملف مكتبة المعايير موجود' => is_file(__DIR__ . '/database/standards.csv'),
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf();
        foreach ($diagnostics as $label => $ok) {
            if (!$ok) {
                throw new RuntimeException('فشل متطلب التثبيت: ' . $label);
            }
        }
        $host = trim((string)($_POST['db_host'] ?? '127.0.0.1'));
        $port = trim((string)($_POST['db_port'] ?? '3306'));
        $dbName = trim((string)($_POST['db_name'] ?? 'ifrs_accounting'));
        $targetDbName = $dbName;
        $dbUser = trim((string)($_POST['db_user'] ?? 'root'));
        $dbPass = (string)($_POST['db_pass'] ?? '');
        $companyName = trim((string)($_POST['company_name'] ?? ''));
        $currencyCode = strtoupper(trim((string)($_POST['currency_code'] ?? 'IQD')));
        $currencyName = trim((string)($_POST['currency_name'] ?? 'دينار عراقي'));
        $adminName = trim((string)($_POST['admin_name'] ?? ''));
        $adminUser = trim((string)($_POST['admin_user'] ?? 'admin'));
        $adminPass = (string)($_POST['admin_pass'] ?? '');

        if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $dbName)) {
            throw new RuntimeException('اسم قاعدة البيانات يجب أن يتكون من أحرف إنجليزية وأرقام وشرطة سفلية فقط.');
        }
        if (!preg_match('/^[A-Za-z0-9_.-]{3,100}$/', $adminUser)) {
            throw new RuntimeException('اسم مستخدم المدير غير صالح. استخدم أحرفاً إنجليزية وأرقاماً فقط.');
        }
        if ($companyName === '' || $adminName === '') {
            throw new RuntimeException('يرجى إدخال اسم المنشأة واسم مدير النظام.');
        }
        if (mb_strlen($adminPass) < 8) {
            throw new RuntimeException('كلمة مرور مدير النظام يجب ألا تقل عن 8 أحرف.');
        }
        if (!preg_match('/^[A-Z]{3,5}$/', $currencyCode)) {
            throw new RuntimeException('رمز العملة غير صالح.');
        }

        $pdo = new PDO("mysql:host={$host};port={$port};charset=utf8mb4", $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $existsStmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name=?');
        $existsStmt->execute([$dbName]);
        $targetDbExisted = (int)$existsStmt->fetchColumn() > 0;
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `{$dbName}`");
        $existing = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=" . $pdo->quote($dbName))->fetchColumn();
        if ($existing > 0) {
            throw new RuntimeException('قاعدة البيانات تحتوي على جداول. استخدم قاعدة بيانات فارغة للتثبيت الجديد أو شغّل upgrade.php لترقية النظام السابق.');
        }
        $schema = file_get_contents(__DIR__ . '/database/schema.sql');
        if ($schema === false) {
            throw new RuntimeException('تعذر قراءة مخطط قاعدة البيانات.');
        }
        $schemaCreated = true;
        execute_sql_script($pdo, $schema);

        $pdo->beginTransaction();
        $decimalPlaces = $currencyCode === 'IQD' ? 0 : 2;
        $stmt = $pdo->prepare('INSERT INTO companies(name_ar,currency_code,currency_name_ar,decimal_places) VALUES(?,?,?,?)');
        $stmt->execute([$companyName, $currencyCode, $currencyName, $decimalPlaces]);
        $companyId = (int)$pdo->lastInsertId();

        $stmt = $pdo->prepare(
            "INSERT INTO users(company_id,full_name,username,password_hash,role,is_active,must_change_password)
             VALUES(?,?,?,?, 'admin',1,0)"
        );
        $stmt->execute([$companyId, $adminName, $adminUser, password_hash($adminPass, PASSWORD_DEFAULT)]);
        $adminId = (int)$pdo->lastInsertId();

        $handle = fopen(__DIR__ . '/database/accounts.csv', 'rb');
        if (!$handle) {
            throw new RuntimeException('تعذر فتح ملف دليل الحسابات.');
        }
        $header = fgetcsv($handle);
        if (!$header) {
            throw new RuntimeException('ملف دليل الحسابات فارغ.');
        }
        $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string)$header[0]);
        $accountIds = [];
        $insertAccount = $pdo->prepare(
            'INSERT INTO accounts(company_id,code,name_ar,parent_id,level_no,account_type,normal_balance,statement_section,
             cash_flow_category,is_cash_account,is_postable,is_active,source_reference)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,1,?)'
        );
        $imported = 0;
        while (($row = fgetcsv($handle)) !== false) {
            if (count($row) !== count($header)) {
                continue;
            }
            $data = array_combine($header, $row);
            if (!$data || trim((string)$data['code']) === '') {
                continue;
            }
            $parentId = $data['parent_code'] !== '' ? ($accountIds[$data['parent_code']] ?? null) : null;
            $postable = (int)$data['is_postable'];
            $name = trim((string)$data['name_ar']);
            $isCash = $postable === 1 && (
                str_starts_with((string)$data['code'], '134')
                || str_contains($name, 'نقدية لدى')
                || str_contains($name, 'نقدية بالصندوق')
            );
            $insertAccount->execute([
                $companyId, $data['code'], $name, $parentId, (int)$data['level'],
                $data['account_type'], $data['normal_balance'], $data['statement_section'],
                $data['cash_flow_category'], $isCash ? 1 : 0, $postable,
                'دليل تطبيق النظام المحاسبي الموحد وفق IFRS - صفحة ' . $data['source_page'],
            ]);
            $accountIds[$data['code']] = (int)$pdo->lastInsertId();
            $imported++;
        }
        fclose($handle);
        if ($imported !== 1163) {
            throw new RuntimeException('لم يكتمل استيراد دليل الحسابات المدقق؛ العدد المتوقع 1163 حساباً.');
        }

        $stdHandle = fopen(__DIR__ . '/database/standards.csv', 'rb');
        if (!$stdHandle) throw new RuntimeException('تعذر فتح ملف مكتبة المعايير.');
        $stdHeader = fgetcsv($stdHandle); $stdHeader[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string)$stdHeader[0]);
        $stdInsert = $pdo->prepare('INSERT INTO standards_library(code,title_ar,standard_type,standard_no,guide_order,guide_page) VALUES(?,?,?,?,?,?)');
        $standardCount=0;
        while(($row=fgetcsv($stdHandle))!==false){ if(count($row)!==count($stdHeader))continue; $d=array_combine($stdHeader,$row); if(!$d||$d['code']==='')continue; $stdInsert->execute([$d['code'],$d['title_ar'],$d['standard_type'],$d['standard_no'],(int)$d['guide_order'],$d['guide_page']]); $standardCount++; }
        fclose($stdHandle);
        if($standardCount < 40) throw new RuntimeException('لم يكتمل استيراد مكتبة المعايير.');

        $year = (int)date('Y');
        $stmt = $pdo->prepare("INSERT INTO fiscal_periods(company_id,name_ar,start_date,end_date,status) VALUES(?,?,?,?, 'open')");
        $stmt->execute([$companyId, 'السنة المالية ' . $year, $year . '-01-01', $year . '-12-31']);
        $periodId=(int)$pdo->lastInsertId();
        $checkItems = [
          ['FRAME-01','الإطار والعرض العادل','توثيق الاستمرارية والاستحقاق والأهمية النسبية وعدم المقاصة.'],
          ['IFRS1-01','تطبيق IFRS لأول مرة','إعداد قائمة المركز المالي الافتتاحية ومطابقات حقوق الملكية والدخل الشامل.'],
          ['IAS1-01','العرض والمقارنة','عرض السنة الحالية والسنة السابقة وبداية السنة السابقة عند اللزوم.'],
          ['IAS7-01','التدفقات النقدية','تصنيف التدفقات بالطريقة المباشرة إلى تشغيلية واستثمارية وتمويلية.'],
          ['NOTES-01','الإيضاحات','إعداد السياسات والإيضاحات والمعلومات المقارنة ذات الصلة.'],
          ['CONTROL-01','الرقابة','اعتماد القيود وسجل التدقيق وإقفال الفترات والنسخ الاحتياطية.'],
          ['IAS2-01','المخزون','قياس المخزون بالتكلفة أو صافي القيمة القابلة للتحقق أيهما أقل.'],
          ['IAS16-01','الأصول الثابتة','توثيق الكلفة والعمر والاندثار والانخفاض وإعادة التقييم.'],
          ['IFRS9-01','الأدوات المالية','توثيق التصنيف والقياس وخسائر الائتمان المتوقعة.'],
          ['IFRS15-01','الإيرادات','توثيق العقود والتزامات الأداء وتوقيت الاعتراف بالإيراد.'],
          ['IFRS16-01','الإيجار','توثيق أصل حق الاستخدام والتزام الإيجار.'],
          ['IAS37-01','المخصصات','توثيق المخصصات والالتزامات والأصول المحتملة.']
        ];
        $check=$pdo->prepare("INSERT INTO compliance_checklist(company_id,period_id,checklist_code,title_ar,category,status) VALUES(?,?,?,?,?,'not_started')");
        foreach($checkItems as [$ccode,$cat,$title])$check->execute([$companyId,$periodId,$ccode,$title,$cat]);
        $stmt = $pdo->prepare('INSERT INTO cost_centers(company_id,code,name_ar,is_active) VALUES(?,?,?,1)');
        $stmt->execute([$companyId, 'CC-001', 'المركز الرئيسي']);
        $setting = $pdo->prepare('INSERT INTO app_settings(company_id,setting_key,setting_value) VALUES(?,?,?)');
        $setting->execute([$companyId, 'programmer_credit', 'م. أرشد حميد حسن']);
        $setting->execute([$companyId, 'programmer_whatsapp', '07735882844']);
        $setting->execute([$companyId, 'schema_version', '2.3.0']);
        $setting->execute([$companyId, 'application_version', '2.7.9.7']);
        $setting->execute([$companyId, 'excel_forms_version', '2026-08-05']);
        $setting->execute([$companyId, 'payment_voucher_template', 'official-photo-2026-08-05']);
        $setting->execute([$companyId, 'installed_accounts_count', (string)$imported]);
        $setting->execute([$companyId, 'account_names_proofread_version', '2026-08-04-final']);
        $setting->execute([$companyId, 'account_names_source_hash', 'c770e536806e96b1784365914a0ede632097ca3bd1d6f31b5f4ff6921140e256']);
        $setting->execute([$companyId, 'installed_standards_count', (string)$standardCount]);
        $setting->execute([$companyId, 'posting_requires_approval', '0']);
        $setting->execute([$companyId, 'guide_compliance_profile', 'Iraqi Unified Accounting System IFRS Guide 2026']);
        $pdo->commit();

        $newConfig = [
            'installed' => true,
            'db_host' => $host,
            'db_port' => $port,
            'db_name' => $dbName,
            'db_user' => $dbUser,
            'db_pass' => $dbPass,
            'app_name' => 'نظام الميزان المحاسبي',
            'timezone' => 'Asia/Baghdad',
            'app_key' => bin2hex(random_bytes(32)),
            'version' => '2.7.9.7',
        ];
        $configText = "<?php\ndeclare(strict_types=1);\n\nreturn " . var_export($newConfig, true) . ";\n";
        if (file_put_contents(__DIR__ . '/config.php', $configText, LOCK_EX) === false) {
            throw new RuntimeException('تم إنشاء قاعدة البيانات، لكن تعذر كتابة config.php. امنح مجلد النظام صلاحية الكتابة ثم أعد المحاولة.');
        }
        if (!is_dir(__DIR__ . '/storage/backups')) {
            mkdir(__DIR__ . '/storage/backups', 0775, true);
        }
        file_put_contents($lockFile, json_encode([
            'installed_at' => date('c'),
            'version' => '2.7.9.7',
            'company_id' => $companyId,
            'admin_id' => $adminId,
        ], JSON_UNESCAPED_UNICODE), LOCK_EX);
        $success = true;
    } catch (Throwable $e) {
        if ($pdo instanceof PDO && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        if ($schemaCreated && $pdo instanceof PDO && $targetDbName !== '') {
            try {
                if ($targetDbExisted) {
                    $pdo->exec("USE `{$targetDbName}`");
                    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
                    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
                    foreach ($tables as $table) {
                        $safeTable = str_replace('`', '``', (string)$table);
                        $pdo->exec("DROP TABLE IF EXISTS `{$safeTable}`");
                    }
                    $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
                } else {
                    $pdo->exec("DROP DATABASE IF EXISTS `{$targetDbName}`");
                }
            } catch (Throwable $cleanupError) {
                log_exception($cleanupError);
            }
            @unlink($lockFile);
            $defaultConfig = [
                'installed' => false,
                'db_host' => '127.0.0.1',
                'db_port' => '3306',
                'db_name' => 'ifrs_accounting',
                'db_user' => 'root',
                'db_pass' => '',
                'app_name' => 'نظام الميزان المحاسبي',
                'timezone' => 'Asia/Baghdad',
                'app_key' => '',
                'version' => '2.7.9.7',
            ];
            @file_put_contents(__DIR__ . '/config.php', "<?php\ndeclare(strict_types=1);\n\nreturn " . var_export($defaultConfig, true) . ";\n", LOCK_EX);
        }
        log_exception($e);
        $error = $e->getMessage();
    }
}

render_public_header('تثبيت نظام الميزان المحاسبي - الإصدار 2.7.9.7');
?>
<div class="install-card">
    <div class="install-header">
        <img class="install-brand-logo" src="assets/branding/app_icon.png" alt="شعار نظام الميزان المحاسبي">
        <div><h1>تثبيت نظام الميزان المحاسبي</h1><p>الإصدار 2.7.9.7 • دليل حسابات عربي مدقق • ترخيص سنوي آمن • PHP / MySQL / XAMPP</p></div>
    </div>
    <?php if ($success): ?>
        <div class="alert alert-success">تم تثبيت النظام بنجاح واستيراد دليل الحسابات ومكتبة المعايير ووحدات المطابقة وإنشاء الفترة المالية وحساب المدير.</div>
        <div class="card" style="margin-bottom:16px">
            <h3 class="card-title">اكتمل التثبيت</h3>
            <div class="step-list"><div>شغّل Apache وMySQL دائماً قبل فتح النظام.</div><div>سجّل الدخول باسم المستخدم الذي أدخلته.</div><div>أنشئ نسخة احتياطية بعد إدخال البيانات الأساسية.</div></div>
        </div>
        <a class="btn btn-primary" href="index.php?page=license">الانتقال إلى التفعيل السنوي</a>
    <?php else: ?>
        <?php if ($error !== ''): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
        <div class="grid grid-2" style="margin-bottom:18px">
            <div class="card">
                <h3 class="card-title">فحص المتطلبات</h3>
                <?php foreach ($diagnostics as $label => $ok): ?>
                    <div class="health-item"><span><?= e($label) ?></span><strong class="<?= $ok ? 'health-ok' : 'health-bad' ?>"><?= $ok ? 'جاهز' : 'غير جاهز' ?></strong></div>
                <?php endforeach; ?>
            </div>
            <div class="card">
                <h3 class="card-title">ملاحظة قبل التثبيت</h3>
                <div class="notice-box">استخدم قاعدة بيانات فارغة. عند وجود نسخة سابقة من النظام لا تحذف بياناتها؛ استبدل الملفات ثم افتح <span class="code">upgrade.php</span>.</div>
            </div>
        </div>
        <form method="post">
            <?= csrf_field() ?>
            <div class="grid grid-2">
                <div class="card">
                    <h3 class="card-title">اتصال قاعدة البيانات</h3>
                    <div class="form-grid">
                        <div class="field col-8"><label>الخادم</label><input name="db_host" value="<?= e($_POST['db_host'] ?? '127.0.0.1') ?>" required></div>
                        <div class="field col-4"><label>المنفذ</label><input name="db_port" value="<?= e($_POST['db_port'] ?? '3306') ?>" required></div>
                        <div class="field col-12"><label>اسم قاعدة البيانات</label><input name="db_name" value="<?= e($_POST['db_name'] ?? 'ifrs_accounting') ?>" required></div>
                        <div class="field col-6"><label>مستخدم MySQL</label><input name="db_user" value="<?= e($_POST['db_user'] ?? 'root') ?>" required></div>
                        <div class="field col-6"><label>كلمة مرور MySQL</label><input type="password" name="db_pass" placeholder="تترك فارغة غالباً في XAMPP"></div>
                    </div>
                </div>
                <div class="card">
                    <h3 class="card-title">المنشأة ومدير النظام</h3>
                    <div class="form-grid">
                        <div class="field col-12"><label>اسم المنشأة</label><input name="company_name" value="<?= e($_POST['company_name'] ?? '') ?>" required></div>
                        <div class="field col-4"><label>رمز العملة</label><input name="currency_code" value="<?= e($_POST['currency_code'] ?? 'IQD') ?>" required></div>
                        <div class="field col-8"><label>اسم العملة</label><input name="currency_name" value="<?= e($_POST['currency_name'] ?? 'دينار عراقي') ?>" required></div>
                        <div class="field col-12"><label>اسم مدير النظام</label><input name="admin_name" value="<?= e($_POST['admin_name'] ?? '') ?>" required></div>
                        <div class="field col-6"><label>اسم المستخدم</label><input name="admin_user" value="<?= e($_POST['admin_user'] ?? 'admin') ?>" required></div>
                        <div class="field col-6"><label>كلمة المرور</label><input type="password" name="admin_pass" minlength="8" required></div>
                    </div>
                </div>
            </div>
            <div class="form-actions"><button class="btn btn-primary" type="submit">تثبيت النظام واستيراد دليل الحسابات ومكتبة المعايير</button></div>
        </form>
    <?php endif; ?>
</div>
<?php render_public_footer(); ?>
