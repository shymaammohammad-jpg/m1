<?php
declare(strict_types=1);

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    header('Location: install.php');
    exit;
}
$configCheck = require $configFile;
$lockFile = __DIR__ . '/storage/installed.lock';
if (!is_file($lockFile)) {
    header('Location: install.php');
    exit;
}
if (!(bool)($configCheck['installed'] ?? false)) {
    header('Location: upgrade.php');
    exit;
}
if (version_compare((string)($configCheck['version'] ?? '0'), '2.7.9.7', '<')) {
    header('Location: upgrade.php');
    exit;
}

require_once __DIR__ . '/app/institutions.php';
institution_session_start();
$institutionRegistry = institution_bootstrap_registry($configCheck);
$prePage = (string)($_GET['page'] ?? '');

if ($prePage === 'institution_switch') {
    institution_clear_selection();
    header('Location: index.php?page=institution_select');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string)($_POST['pre_action'] ?? '') === 'institution_choose') {
    $postedCsrf = (string)($_POST['csrf'] ?? '');
    $storedCsrf = (string)($_SESSION['csrf'] ?? '');
    if ($storedCsrf === '' || !hash_equals($storedCsrf, $postedCsrf)) {
        http_response_code(419);
        exit('انتهت صلاحية الجلسة. أعد تحميل الصفحة.');
    }
    try {
        $selectedKey = (string)($_POST['institution_key'] ?? '');
        $selectedInstitution = institution_find($institutionRegistry, $selectedKey);
        if (!$selectedInstitution) {
            throw new RuntimeException('المؤسسة المختارة غير موجودة.');
        }
        $selectorServer = institution_server_pdo($configCheck);
        if (!institution_database_is_mizan($selectorServer, (string)($selectedInstitution['db_name'] ?? ''))) {
            throw new RuntimeException('قاعدة بيانات المؤسسة المختارة غير متاحة أو غير مكتملة. شغّل MySQL ثم أعد المحاولة.');
        }
        institution_select($institutionRegistry, $selectedKey);
        header('Location: index.php?page=login');
        exit;
    } catch (Throwable $institutionError) {
        $_SESSION['institution_error'] = $institutionError->getMessage();
        header('Location: index.php?page=institution_select');
        exit;
    }
}

$currentInstitution = institution_current($institutionRegistry);
if ($prePage === 'institution_select' || !$currentInstitution) {
    if (empty($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    $institutionError = (string)($_SESSION['institution_error'] ?? '');
    unset($_SESSION['institution_error']);
    $institutions = (array)($institutionRegistry['institutions'] ?? []);
    $warning = trim((string)($institutionRegistry['bootstrap_warning'] ?? ''));
    ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>اختيار المؤسسة | نظام الميزان المحاسبي</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/app.css?v=2.7.9.7-ai-agent-ollama-r1">
<style>
body.institution-select-body{font-family:'Cairo',Tahoma,Arial,sans-serif;background:#f3f5f7;margin:0;min-height:100vh;color:#1f2933;display:grid;place-items:center;padding:28px;box-sizing:border-box}
.institution-select-shell{width:min(960px,100%)}
.institution-select-head{text-align:center;margin-bottom:22px}.institution-select-head img{width:74px;height:74px;object-fit:contain;margin-bottom:8px}.institution-select-head h1{margin:0;font-size:30px}.institution-select-head p{margin:8px auto 0;color:#667085;max-width:660px;line-height:1.8}
.institution-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}
.institution-card{background:#fff;border:1px solid #dfe5eb;border-radius:18px;padding:22px;box-shadow:0 10px 28px rgba(31,41,51,.07);display:flex;flex-direction:column;gap:14px}.institution-card:hover{border-color:#9db0c1;box-shadow:0 14px 34px rgba(31,41,51,.10)}
.institution-kind{width:48px;height:48px;border-radius:14px;background:#eef2f5;display:grid;place-items:center;font-size:23px}.institution-card h2{font-size:19px;margin:0;line-height:1.6}.institution-card small{color:#667085;direction:ltr;text-align:right}.institution-card button{margin-top:auto;border:0;border-radius:12px;background:#263746;color:#fff;font:700 15px 'Cairo',sans-serif;padding:12px 16px;cursor:pointer}.institution-card button:hover{background:#1d2a35}
.institution-note{margin-top:16px;background:#fff;border:1px solid #e2e7ec;border-radius:14px;padding:13px 16px;color:#596675;text-align:center;font-size:13px}.institution-alert{margin-bottom:16px;border-radius:12px;padding:12px 14px;background:#fff4e5;border:1px solid #f1c27d;color:#7a4d0b}.institution-error{background:#fff0f0;border-color:#efb4b4;color:#8b1f1f}.institution-footer{text-align:center;color:#8a96a3;font-size:12px;margin-top:18px}
</style>
</head>
<body class="institution-select-body">
<div class="institution-select-shell">
  <div class="institution-select-head">
    <img src="assets/branding/brand_icon.png" alt="شعار نظام الميزان المحاسبي">
    <h1>اختر المؤسسة التي تريد العمل عليها</h1>
    <p>كل مؤسسة تعمل بقاعدة بيانات مستقلة تماماً. القيود والسندات والأرصدة والحسابات البنكية وشهادة مطابقة البنك لا تختلط بين المؤسسات.</p>
  </div>
  <?php if ($institutionError !== ''): ?><div class="institution-alert institution-error"><?= htmlspecialchars($institutionError, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
  <?php if ($warning !== ''): ?><div class="institution-alert">تعذر إنشاء المؤسسة الثانية تلقائياً: <?= htmlspecialchars($warning, ENT_QUOTES, 'UTF-8') ?>. يمكن للمدير إضافتها لاحقاً من إدارة المؤسسات.</div><?php endif; ?>
  <div class="institution-grid">
    <?php foreach ($institutions as $inst): if (!is_array($inst)) continue; ?>
      <form class="institution-card" method="post" action="index.php?page=institution_select">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars((string)$_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="pre_action" value="institution_choose">
        <input type="hidden" name="institution_key" value="<?= htmlspecialchars((string)($inst['key'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        <div class="institution-kind"><?= (($inst['kind'] ?? '') === 'evening') ? '🌙' : ((($inst['kind'] ?? '') === 'morning') ? '☀️' : '🏛️') ?></div>
        <h2><?= htmlspecialchars((string)($inst['name'] ?? 'مؤسسة'), ENT_QUOTES, 'UTF-8') ?></h2>
        <small>Database: <?= htmlspecialchars((string)($inst['db_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></small>
        <button type="submit">فتح هذه المؤسسة</button>
      </form>
    <?php endforeach; ?>
  </div>
  <div class="institution-note">بعد الدخول يمكنك استخدام زر <strong>تبديل المؤسسة</strong> في أعلى البرنامج للانتقال بين الصباحي والمسائي دون إعادة التثبيت.</div>
  <div class="institution-footer">نظام الميزان المحاسبي 2.7.9.7 • قواعد بيانات منفصلة لكل مؤسسة</div>
</div>
</body>
</html>
    <?php
    exit;
}

require_once __DIR__ . '/app/core.php';
require_once __DIR__ . '/app/layout.php';
require_once __DIR__ . '/app/compliance.php';
require_once __DIR__ . '/app/bank_reconciliation.php';
require_once __DIR__ . '/app/guide_reports.php';
require_once __DIR__ . '/app/compliance_actions.php';
require_once __DIR__ . '/app/smart_assistant.php';
require_once __DIR__ . '/app/xlsx_export.php';
require_once __DIR__ . '/app/license.php';

$page = (string)($_GET['page'] ?? (user() ? 'dashboard' : 'login'));
$licenseError = '';

// شاشة التفعيل متاحة قبل تسجيل الدخول حتى عند انتهاء الترخيص.
if ($page === 'license') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        try {
            verify_csrf();
            if ((string)($_POST['license_action'] ?? '') !== 'activate') {
                throw new RuntimeException('إجراء الترخيص غير معروف.');
            }
            $licenseKey = trim((string)($_POST['license_key'] ?? ''));
            if (isset($_FILES['license_file']) && is_array($_FILES['license_file'])
                && (int)($_FILES['license_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                if ((int)($_FILES['license_file']['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
                    throw new RuntimeException('تعذر رفع ملف الترخيص.');
                }
                if ((int)($_FILES['license_file']['size'] ?? 0) > 64 * 1024) {
                    throw new RuntimeException('ملف الترخيص يتجاوز الحجم المسموح.');
                }
                $uploaded = (string)@file_get_contents((string)$_FILES['license_file']['tmp_name']);
                if (trim($uploaded) !== '') {
                    $licenseKey = trim($uploaded);
                }
            }
            if ($licenseKey === '') {
                throw new RuntimeException('أدخل رقم الترخيص أو اختر ملف License.');
            }
            license_activate($licenseKey);
            redirect(url('license', ['activated' => '1']));
        } catch (Throwable $error) {
            log_exception($error);
            $licenseError = $error->getMessage();
        }
    }
    require __DIR__ . '/pages/license.php';
    exit;
}

$licenseState = license_status();
if (!$licenseState['valid'] && $page !== 'logout') {
    redirect(url('license'));
}

if ($page === 'login') {
    if (user()) {
        redirect(url('dashboard'));
    }
    $error = '';
    $restoreSuccess = isset($_GET['restored']) && (string)$_GET['restored'] === '1';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        try {
            verify_csrf();
            $attempts = (int)($_SESSION['login_attempts'] ?? 0);
            $lastAttempt = (int)($_SESSION['login_last_attempt'] ?? 0);
            if ($attempts >= 6 && time() - $lastAttempt < 60) {
                throw new RuntimeException('تم إيقاف المحاولات مؤقتاً. انتظر دقيقة ثم أعد المحاولة.');
            }
            $username = trim((string)($_POST['username'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $stmt = db()->prepare('SELECT * FROM users WHERE username=? AND is_active=1 ORDER BY id LIMIT 1');
            $stmt->execute([$username]);
            $account = $stmt->fetch();
            if (!$account || !password_verify($password, (string)$account['password_hash'])) {
                $_SESSION['login_attempts'] = $attempts + 1;
                $_SESSION['login_last_attempt'] = time();
                throw new RuntimeException('اسم المستخدم أو كلمة المرور غير صحيحة.');
            }
            session_regenerate_id(true);
            $_SESSION['login_attempts'] = 0;
            $_SESSION['user'] = [
                'id' => (int)$account['id'],
                'company_id' => (int)$account['company_id'],
                'full_name' => $account['full_name'],
                'username' => $account['username'],
                'role' => $account['role'],
            ];
            db()->prepare('UPDATE users SET last_login_at=NOW() WHERE id=?')->execute([$account['id']]);
            audit('login', 'user', $account['id'], null, null, ['username' => $username]);
            redirect(url('dashboard'));
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
    }
    render_public_header('تسجيل الدخول');
    ?>
    <div class="public-card login-card">
        <div class="login-visual">
            <span class="login-pill">الإصدار 2.7.9.7 • ترخيص سنوي آمن وتقارير احترافية</span>
            <div class="login-institution-badge"><strong><?= e((string)($_SESSION['institution_name'] ?? '')) ?></strong><a href="index.php?page=institution_switch">تبديل المؤسسة</a></div>
            <img class="login-brand-logo" src="assets/branding/logo_full.png" alt="شعار نظام الميزان المحاسبي"><h1>نظام الميزان المحاسبي</h1>
            <p>إدارة القيود الافتتاحية واليومية والإقفالات، وسندات القبض والصرف، والتقارير المالية، مع إلغاء الترحيل والتعديل وإعادة الترحيل وسجل تدقيق متكامل.</p>
        </div>
        <form class="login-form" method="post">
            <?= csrf_field() ?>
            <h2>تسجيل الدخول</h2>
            <p>أدخل بيانات حسابك للوصول إلى النظام.</p>
            <?php if ($restoreSuccess): ?><div class="alert alert-success">تمت استعادة النسخة الاحتياطية بنجاح. سجل الدخول ببيانات المستخدم الموجودة داخل النسخة المستعادة.</div><?php endif; ?>
            <?php if ($error !== ''): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
            <div class="field"><label>اسم المستخدم</label><input name="username" autocomplete="username" required autofocus></div>
            <div class="field"><label>كلمة المرور</label><input type="password" name="password" autocomplete="current-password" required></div>
            <button class="btn btn-primary btn-block" type="submit">دخول إلى النظام</button>
        </form>
    </div>
    <?php
    render_public_footer();
    exit;
}

if ($page === 'logout') {
    if (user()) {
        audit('logout', 'user', user()['id']);
    }
    // Logout from the user account while keeping the selected institution.
    unset($_SESSION['user'], $_SESSION['company_cache'], $_SESSION['login_attempts'], $_SESSION['login_last_attempt']);
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    session_regenerate_id(true);
    redirect(url('login'));
}

require_auth();
$restoreLock = __DIR__ . '/storage/restore.lock';
if (is_file($restoreLock) && $page !== 'backups') {
    http_response_code(503);
    render_header('النظام في وضع الصيانة', '');
    page_heading('جاري استعادة نسخة احتياطية', 'انتظر حتى تنتهي العملية ثم أعد تحميل الصفحة.');
    echo '<div class="alert alert-warning">قاعدة البيانات في وضع الصيانة المؤقت لحمايتها أثناء الاستعادة.</div>';
    render_footer();
    exit;
}
if (!schema_is_current()) {
    redirect('upgrade.php');
}

if ($page === 'excel_export') {
    try {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            exit('Method Not Allowed');
        }
        // Compatibility with the first 2.5.0 JavaScript build, which used csrf_token.
        if (!isset($_POST['csrf']) && isset($_POST['csrf_token'])) {
            $_POST['csrf'] = $_POST['csrf_token'];
        }
        verify_csrf();
        $payloadJson = (string)($_POST['payload'] ?? '');
        if ($payloadJson === '' || strlen($payloadJson) > 12 * 1024 * 1024) {
            throw new RuntimeException('بيانات التصدير فارغة أو تتجاوز الحجم المسموح.');
        }
        $payload = json_decode($payloadJson, true, 512, JSON_THROW_ON_ERROR);
        export_visible_tables_to_xlsx(is_array($payload) ? $payload : []);
    } catch (Throwable $error) {
        log_exception($error);
        if (http_response_code() < 400) {
            http_response_code($error instanceof RuntimeException ? 400 : 500);
        }
        header('Content-Type: text/plain; charset=UTF-8');
        echo $error->getMessage();
        exit;
    }
}

if ($page === 'backup_download') {
    require_role('admin');
    $path = safe_backup_path((string)($_GET['file'] ?? ''));
    audit('backup_download', 'database_backup', basename($path));
    header('Content-Type: application/sql; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . basename($path) . '"');
    header('Content-Length: ' . filesize($path));
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

function redirect_after_error(string $fallback): never
{
    old_input_store($_POST);
    $referer = (string)($_SERVER['HTTP_REFERER'] ?? '');
    if ($referer !== '' && str_contains($referer, 'index.php')) {
        $parts = parse_url($referer);
        $target = 'index.php' . (isset($parts['query']) ? '?' . $parts['query'] : '');
        redirect($target);
    }
    redirect($fallback);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    try {
        verify_csrf();
        compliance_action($action);

        if ($action === 'institution_add') {
            require_role('admin');
            $name = trim((string)($_POST['institution_name'] ?? ''));
            $suffix = trim((string)($_POST['db_suffix'] ?? 'unit'));
            if ($suffix !== '' && !preg_match('/^[A-Za-z0-9_]{2,24}$/', $suffix)) {
                throw new RuntimeException('رمز قاعدة البيانات يجب أن يتكون من أحرف إنجليزية أو أرقام فقط.');
            }
            $created = institution_add_from_current(app_config(), $name, $suffix);
            flash('success', 'تم إنشاء المؤسسة وقاعدة بياناتها المستقلة بنجاح: ' . (string)$created['name']);
            redirect(url('institutions'));
        }

        if ($action === 'institution_rename') {
            require_role('admin');
            $key = trim((string)($_POST['institution_key'] ?? ''));
            $name = trim((string)($_POST['institution_name'] ?? ''));
            institution_rename(app_config(), $key, $name);
            if ((string)($_SESSION['institution_key'] ?? '') === $key) {
                company(true);
            }
            flash('success', 'تم تحديث اسم المؤسسة في القائمة وقاعدة البيانات.');
            redirect(url('institutions'));
        }

        if ($action === 'bank_reconciliation_save') {
            require_role(['admin','accountant']);
            $saved = br_save_statement($_POST);
            flash('success', 'تم حفظ كشف البنك وإعادة احتساب شهادة المطابقة تلقائياً.');
            redirect(url('bank_reconciliation', ['account_id'=>$saved['account_id'], 'month'=>$saved['month']]));
        }

        if ($action === 'bank_reconciliation_clear') {
            require_role(['admin','accountant']);
            $accountId = (int)($_POST['account_id'] ?? 0);
            $month = trim((string)($_POST['month'] ?? ''));
            br_clear_statement($accountId, $month);
            flash('success', 'تم مسح كشف البنك المدخل لهذا الشهر.');
            redirect(url('bank_reconciliation', ['account_id'=>$accountId, 'month'=>$month]));
        }

        if ($action === 'assistant_ask') {
            require_role(['admin','accountant','viewer']);
            $question = trim((string)($_POST['question'] ?? ''));
            $answer = sa_answer($question);
            sa_history_add($answer);
            audit('ask', 'smart_assistant', null, null, null, ['question' => mb_substr($question, 0, 700)]);
            redirect(url('smart_assistant'));
        }

        if ($action === 'assistant_clear') {
            require_role(['admin','accountant','viewer']);
            sa_history_clear();
            flash('success', 'تم مسح سجل محادثة المساعد من الجلسة الحالية.');
            redirect(url('smart_assistant'));
        }

        if ($action === 'assistant_ai_settings_save') {
            require_role('admin');
            $saved = sa_ai_save_settings($_POST);
            $label = trim((string)$saved['model']) !== '' ? (string)$saved['model'] : 'gemma4:26b';
            flash('success', !empty($saved['enabled']) ? 'تم حفظ إعدادات Gemma 4 المحلي. النموذج المعتمد: ' . $label : 'تم تعطيل Gemma 4 المحلي، وسيبقى البحث المعرفي المحلي متاحاً.');
            redirect(url('smart_assistant'));
        }

        if ($action === 'account_save') {
            require_role(['admin','accountant']);
            $id = (int)($_POST['id'] ?? 0);
            $code = trim((string)($_POST['code'] ?? ''));
            $name = trim((string)($_POST['name_ar'] ?? ''));
            $parentId = ($_POST['parent_id'] ?? '') !== '' ? (int)$_POST['parent_id'] : null;
            $type = (string)($_POST['account_type'] ?? 'asset');
            $normal = (string)($_POST['normal_balance'] ?? 'debit');
            $section = trim((string)($_POST['statement_section'] ?? 'other'));
            $cashFlow = (string)($_POST['cash_flow_category'] ?? 'operating');
            $isCash = isset($_POST['is_cash_account']) ? 1 : 0;
            $isPostable = isset($_POST['is_postable']) ? 1 : 0;
            $isActive = isset($_POST['is_active']) ? 1 : 0;
            if (!preg_match('/^[0-9A-Za-z._-]{1,30}$/', $code) || $name === '') {
                throw new RuntimeException('رمز الحساب أو اسمه غير صالح.');
            }
            if (!in_array($type, ['asset','contra_asset','liability','equity','revenue','expense','oci','off_balance'], true)
                || !in_array($normal, ['debit','credit'], true)
                || !in_array($cashFlow, ['none','operating','investing','financing'], true)) {
                throw new RuntimeException('تصنيف الحساب غير صالح.');
            }
            $dupStmt = db()->prepare('SELECT COUNT(*) FROM accounts WHERE company_id=? AND code=? AND id<>?');
            $dupStmt->execute([company_id(), $code, $id]);
            if ((int)$dupStmt->fetchColumn() > 0) throw new RuntimeException('رمز الحساب مستخدم مسبقاً.');
            if ($id > 0 && $parentId === $id) {
                throw new RuntimeException('لا يمكن جعل الحساب أباً لنفسه.');
            }
            $level = 1;
            if ($parentId !== null) {
                $stmt = db()->prepare('SELECT id,parent_id,level_no FROM accounts WHERE id=? AND company_id=?');
                $stmt->execute([$parentId, company_id()]);
                $parent = $stmt->fetch();
                if (!$parent) {
                    throw new RuntimeException('الحساب الأب غير صالح.');
                }
                $cursor = $parent;
                while ($id > 0 && $cursor) {
                    if ((int)$cursor['id'] === $id) {
                        throw new RuntimeException('لا يمكن نقل الحساب تحت أحد حساباته الفرعية.');
                    }
                    if (empty($cursor['parent_id'])) {
                        break;
                    }
                    $stmt->execute([(int)$cursor['parent_id'], company_id()]);
                    $cursor = $stmt->fetch();
                }
                $level = (int)$parent['level_no'] + 1;
            }
            if ($id > 0) {
                $beforeStmt = db()->prepare('SELECT * FROM accounts WHERE id=? AND company_id=?');
                $beforeStmt->execute([$id, company_id()]);
                $before = $beforeStmt->fetch();
                if (!$before) {
                    throw new RuntimeException('الحساب غير موجود.');
                }
                $stmt = db()->prepare(
                    'UPDATE accounts SET code=?,name_ar=?,parent_id=?,level_no=?,account_type=?,normal_balance=?,statement_section=?,
                     cash_flow_category=?,is_cash_account=?,is_postable=?,is_active=? WHERE id=? AND company_id=?'
                );
                $stmt->execute([$code,$name,$parentId,$level,$type,$normal,$section,$cashFlow,$isCash,$isPostable,$isActive,$id,company_id()]);
                recalculate_account_levels($id, $level);
                $afterStmt = db()->prepare('SELECT * FROM accounts WHERE id=? AND company_id=?');
                $afterStmt->execute([$id, company_id()]);
                audit('update', 'account', $id, $before, $afterStmt->fetch());
            } else {
                $stmt = db()->prepare(
                    'INSERT INTO accounts(company_id,code,name_ar,parent_id,level_no,account_type,normal_balance,statement_section,cash_flow_category,
                     is_cash_account,is_postable,is_active,source_reference) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)'
                );
                $stmt->execute([company_id(),$code,$name,$parentId,$level,$type,$normal,$section,$cashFlow,$isCash,$isPostable,$isActive,'إضافة يدوية']);
                $id = (int)db()->lastInsertId();
                $afterStmt = db()->prepare('SELECT * FROM accounts WHERE id=?');
                $afterStmt->execute([$id]);
                audit('create', 'account', $id, null, $afterStmt->fetch());
            }
            flash('success', 'تم حفظ الحساب بنجاح.');
            redirect(url('accounts'));
        }

        if ($action === 'account_delete') {
            require_role('admin');
            $id = (int)($_POST['id'] ?? 0);
            $stmt = db()->prepare('SELECT * FROM accounts WHERE id=? AND company_id=?');
            $stmt->execute([$id, company_id()]);
            $before = $stmt->fetch();
            if (!$before) throw new RuntimeException('الحساب غير موجود.');
            $stmt = db()->prepare('SELECT COUNT(*) FROM journal_lines WHERE account_id=?');
            $stmt->execute([$id]);
            if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException('لا يمكن حذف حساب مستخدم في القيود؛ يمكن تعطيله بدلاً من ذلك.');
            $stmt = db()->prepare('SELECT COUNT(*) FROM accounts WHERE parent_id=?');
            $stmt->execute([$id]);
            if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException('لا يمكن حذف حساب له حسابات فرعية.');
            db()->prepare('DELETE FROM accounts WHERE id=? AND company_id=?')->execute([$id, company_id()]);
            audit('delete', 'account', $id, $before, null);
            flash('success', 'تم حذف الحساب.');
            redirect(url('accounts'));
        }

        if ($action === 'journal_save') {
            require_role(['admin','accountant']);
            $accounts = (array)($_POST['account_id'] ?? []);
            $debits = (array)($_POST['debit'] ?? []);
            $credits = (array)($_POST['credit'] ?? []);
            $debitFils = (array)($_POST['debit_fils'] ?? []);
            $creditFils = (array)($_POST['credit_fils'] ?? []);
            $descriptions = (array)($_POST['line_description'] ?? []);
            $costCenters = (array)($_POST['cost_center_id'] ?? []);
            $parties = (array)($_POST['party_id'] ?? []);
            $currencies = (array)($_POST['currency_code'] ?? []);
            $rates = (array)($_POST['exchange_rate'] ?? []);
            $foreignAmounts = (array)($_POST['foreign_amount'] ?? []);
            $cashFlowCodes = (array)($_POST['cash_flow_line_code'] ?? []);
            $lines = [];
            foreach ($accounts as $i => $accountId) {
                $lines[] = [
                    'account_id' => $accountId,
                    'debit' => voucher_amount_join($debits[$i] ?? '', $debitFils[$i] ?? ''),
                    'credit' => voucher_amount_join($credits[$i] ?? '', $creditFils[$i] ?? ''),
                    'line_description' => $descriptions[$i] ?? '',
                    'cost_center_id' => $costCenters[$i] ?? null,
                    'party_id' => $parties[$i] ?? null,
                    'currency_code' => $currencies[$i] ?? (company()['currency_code'] ?? 'IQD'),
                    'exchange_rate' => $rates[$i] ?? 1,
                    'foreign_amount' => $foreignAmounts[$i] ?? 0,
                    'cash_flow_line_code' => $cashFlowCodes[$i] ?? null,
                ];
            }
            foreach (['organizer','auditor','accounts_manager','department_head','accountant','general_manager'] as $sigKey) {
                if (array_key_exists('signature_' . $sigKey, $_POST)) {
                    setting_set('voucher_sign_' . $sigKey, trim((string)$_POST['signature_' . $sigKey]));
                }
            }
            $result = save_journal_document([
                'entry_date' => $_POST['entry_date'] ?? '',
                'voucher_no' => $_POST['voucher_no'] ?? '',
                'reference_no' => $_POST['reference_no'] ?? '',
                'description' => $_POST['description'] ?? '',
                'source_type' => $_POST['source_type'] ?? 'manual',
                'origin_standard' => $_POST['origin_standard'] ?? '',
                'equity_movement_type' => $_POST['equity_movement_type'] ?? 'none',
            ], $lines, (int)($_POST['id'] ?? 0) ?: null, isset($_POST['version_no']) ? (int)$_POST['version_no'] : null, ($_POST['submit_mode'] ?? '') === 'post');
            flash('success', 'تم حفظ المستند ' . $result['voucher_no'] . ($result['posted'] ? ' وترحيله.' : (!empty($result['pending_approval']) ? ' وإرساله للاعتماد.' : ' كمسودة.')));
            redirect(url('journal_view', ['id' => $result['id']]));
        }

        if ($action === 'voucher_save') {
            require_role(['admin','accountant']);
            foreach (['organizer','accountant','auditor','accounts_manager','general_manager'] as $sigKey) {
                if (array_key_exists('signature_' . $sigKey, $_POST)) {
                    setting_set('voucher_sign_' . $sigKey, trim((string)$_POST['signature_' . $sigKey]));
                }
            }
            $source = (string)($_POST['source_type'] ?? 'receipt');
            if (!in_array($source, ['receipt','payment'], true)) throw new RuntimeException('نوع السند غير صالح.');

            // v2.7.9.7: مستند الصرف/القبض أصبح قيداً عاماً بالكامل.
            // لا يوجد حساب نقدي إلزامي؛ كل صف يختار أي حساب فعال وقابل للترحيل
            // ويحدد مبلغه في المدين أو الدائن، مع السماح بتقسيم أي طرف على عدة حسابات.
            $rawAccounts = $_POST['line_account_id'] ?? [];
            $rawDebits = $_POST['line_debit'] ?? [];
            $rawCredits = $_POST['line_credit'] ?? [];
            $rawDescriptions = $_POST['line_description'] ?? [];
            $rawCostCenters = $_POST['line_cost_center_id'] ?? [];
            $rawParties = $_POST['line_party_id'] ?? [];
            $lineAccounts = is_array($rawAccounts) ? array_values($rawAccounts) : [$rawAccounts];
            $lineDebits = is_array($rawDebits) ? array_values($rawDebits) : [$rawDebits];
            $lineCredits = is_array($rawCredits) ? array_values($rawCredits) : [$rawCredits];
            $lineDescriptions = is_array($rawDescriptions) ? array_values($rawDescriptions) : [$rawDescriptions];
            $lineCostCenters = is_array($rawCostCenters) ? array_values($rawCostCenters) : [$rawCostCenters];
            $lineParties = is_array($rawParties) ? array_values($rawParties) : [$rawParties];

            $lines = [];
            $totalDebit = 0.0;
            $totalCredit = 0.0;
            $headerDescription = '';
            foreach ($lineAccounts as $i => $accountValue) {
                $accountId = (int)$accountValue;
                $debit = parse_amount($lineDebits[$i] ?? 0);
                $credit = parse_amount($lineCredits[$i] ?? 0);
                $lineDescription = trim((string)($lineDescriptions[$i] ?? ''));
                $costCenterId = (int)($lineCostCenters[$i] ?? 0) ?: null;
                $partyId = (int)($lineParties[$i] ?? 0) ?: null;

                if ($accountId === 0 && $debit <= 0 && $credit <= 0 && $lineDescription === '') continue;
                if ($accountId <= 0) throw new RuntimeException('يجب اختيار حساب صحيح لكل صف مستخدم في المستند.');
                if (($debit > 0 && $credit > 0) || ($debit <= 0 && $credit <= 0)) {
                    throw new RuntimeException('كل صف في مستند الصرف يجب أن يحتوي مبلغاً في المدين أو الدائن فقط.');
                }

                $accountCheck = db()->prepare('SELECT id FROM accounts WHERE id=? AND company_id=? AND is_postable=1 AND is_active=1');
                $accountCheck->execute([$accountId, company_id()]);
                if (!$accountCheck->fetchColumn()) throw new RuntimeException('أحد الحسابات غير صالح أو غير قابل للترحيل.');

                if ($lineDescription === '') $lineDescription = trim((string)($_POST['description'] ?? ''));
                if ($headerDescription === '' && $lineDescription !== '') $headerDescription = $lineDescription;
                $totalDebit += $debit;
                $totalCredit += $credit;
                $lines[] = [
                    'account_id' => $accountId,
                    'debit' => $debit,
                    'credit' => $credit,
                    'cost_center_id' => $costCenterId,
                    'party_id' => $partyId,
                    'line_description' => $lineDescription,
                    'currency_code' => $_POST['currency_code'] ?? (company()['currency_code'] ?? 'IQD'),
                    'exchange_rate' => $_POST['exchange_rate'] ?? 1,
                    'foreign_amount' => 0,
                    'cash_flow_line_code' => $_POST['cash_flow_line_code'] ?? null,
                ];
            }
            if (count($lines) < 2) throw new RuntimeException('يجب إدخال حسابين على الأقل في المستند.');
            if ($totalDebit <= 0 || $totalCredit <= 0) throw new RuntimeException('يجب أن يحتوي المستند على طرف مدين وطرف دائن.');
            if (abs($totalDebit - $totalCredit) > 0.0005) {
                throw new RuntimeException('مستند الصرف غير متوازن؛ يجب أن يساوي إجمالي المدين إجمالي الدائن.');
            }

            $result = save_journal_document([
                'entry_date' => $_POST['entry_date'] ?? '',
                'reference_no' => $_POST['reference_no'] ?? '',
                'description' => $headerDescription,
                'source_type' => $source,
                'origin_standard' => $_POST['origin_standard'] ?? '',
                'equity_movement_type' => $_POST['equity_movement_type'] ?? 'none',
            ], $lines, (int)($_POST['id'] ?? 0) ?: null, isset($_POST['version_no']) ? (int)$_POST['version_no'] : null, ($_POST['submit_mode'] ?? '') === 'post');
            $detailsStmt = db()->prepare(
                'INSERT INTO voucher_details(journal_entry_id,sheet_no,check_no,check_date,payee_name,recipient_name,updated_by) VALUES(?,?,?,?,?,?,?) '
                . 'ON DUPLICATE KEY UPDATE sheet_no=VALUES(sheet_no),check_no=VALUES(check_no),check_date=VALUES(check_date),payee_name=VALUES(payee_name),recipient_name=VALUES(recipient_name),updated_by=VALUES(updated_by)'
            );
            $checkDatePosted = trim((string)($_POST['check_date'] ?? ''));
            $detailsStmt->execute([
                (int)$result['id'],
                trim((string)($_POST['sheet_no'] ?? $_POST['reference_no'] ?? '')) ?: null,
                trim((string)($_POST['check_no'] ?? '')) ?: null,
                valid_date($checkDatePosted) ? $checkDatePosted : null,
                trim((string)($_POST['payee_name'] ?? '')) ?: null,
                trim((string)($_POST['recipient_name'] ?? '')) ?: null,
                (int)user()['id'],
            ]);
            flash('success', 'تم حفظ ' . source_label($source) . ' رقم ' . $result['voucher_no'] . ($result['posted'] ? ' وترحيله.' : (!empty($result['pending_approval']) ? ' وإرساله للاعتماد.' : ' كمسودة.')));
            redirect(url('journal_view', ['id' => $result['id']]));
        }

        if ($action === 'journal_post') {
            require_role(['admin','accountant']);
            $id = (int)($_POST['id'] ?? 0);
            post_journal($id);
            flash('success', 'تم ترحيل المستند بنجاح وإدراجه في التقارير.');
            redirect(url('journal_view', ['id' => $id]));
        }

        if ($action === 'journal_unpost') {
            require_role(['admin','accountant']);
            $id = (int)($_POST['id'] ?? 0);
            $entry = unpost_journal($id);
            flash('success', 'تم إلغاء الترحيل وإعادة المستند إلى حالة مسودة.');
            if ((int)($_POST['edit_after'] ?? 0) === 1) {
                $target = in_array($entry['source_type'], ['receipt','payment'], true)
                    ? url('cash_voucher', ['id' => $id]) : url('journal_new', ['id' => $id]);
                redirect($target);
            }
            redirect(url('journal_view', ['id' => $id]));
        }

        if ($action === 'journal_reverse') {
            require_role(['admin','accountant']);
            $id = (int)($_POST['id'] ?? 0);
            $date = (string)($_POST['reversal_date'] ?? date('Y-m-d'));
            $newId = reverse_journal($id, $date);
            flash('success', 'تم إنشاء قيد العكس وترحيله بنجاح.');
            redirect(url('journal_view', ['id' => $newId]));
        }

        if ($action === 'journal_delete') {
            require_role(['admin','accountant']);
            $id = (int)($_POST['id'] ?? 0);
            delete_journal_permanently($id);
            flash('success', 'تم حذف المستند نهائياً من النظام، وحُذف أثره من التسلسل وأعيد احتساب الرقم التالي من المستندات الموجودة فعلياً.');
            redirect(url('journal_list'));
        }

        if ($action === 'party_save') {
            require_role(['admin','accountant']);
            $id = (int)($_POST['id'] ?? 0);
            $type = (string)($_POST['party_type'] ?? 'other');
            $code = trim((string)($_POST['code'] ?? ''));
            $name = trim((string)($_POST['name_ar'] ?? ''));
            $accountId = ($_POST['account_id'] ?? '') !== '' ? (int)$_POST['account_id'] : null;
            if ($name === '' || !in_array($type, ['customer','supplier','employee','other'], true)) throw new RuntimeException('بيانات الجهة غير صالحة.');
            if ($code !== '') {
                $dupStmt = db()->prepare('SELECT COUNT(*) FROM parties WHERE company_id=? AND code=? AND id<>?');
                $dupStmt->execute([company_id(), $code, $id]);
                if ((int)$dupStmt->fetchColumn() > 0) throw new RuntimeException('رمز الجهة مستخدم مسبقاً.');
            }
            if ($accountId !== null) {
                $stmt = db()->prepare('SELECT id FROM accounts WHERE id=? AND company_id=? AND is_postable=1');
                $stmt->execute([$accountId, company_id()]);
                if (!$stmt->fetchColumn()) throw new RuntimeException('الحساب المرتبط بالجهة غير صالح.');
            }
            $values = [
                $type, $code !== '' ? $code : null, $name, trim((string)($_POST['tax_no'] ?? '')) ?: null,
                trim((string)($_POST['phone'] ?? '')) ?: null, trim((string)($_POST['email'] ?? '')) ?: null,
                trim((string)($_POST['address_ar'] ?? '')) ?: null, $accountId, isset($_POST['is_active']) ? 1 : 0,
            ];
            if ($id > 0) {
                $stmt = db()->prepare('SELECT * FROM parties WHERE id=? AND company_id=?');
                $stmt->execute([$id, company_id()]); $before = $stmt->fetch();
                if (!$before) throw new RuntimeException('الجهة غير موجودة.');
                $stmt = db()->prepare('UPDATE parties SET party_type=?,code=?,name_ar=?,tax_no=?,phone=?,email=?,address_ar=?,account_id=?,is_active=? WHERE id=? AND company_id=?');
                $stmt->execute([...$values, $id, company_id()]);
                $stmt = db()->prepare('SELECT * FROM parties WHERE id=?'); $stmt->execute([$id]);
                audit('update', 'party', $id, $before, $stmt->fetch());
            } else {
                $stmt = db()->prepare('INSERT INTO parties(company_id,party_type,code,name_ar,tax_no,phone,email,address_ar,account_id,is_active) VALUES(?,?,?,?,?,?,?,?,?,?)');
                $stmt->execute([company_id(), ...$values]);
                $id = (int)db()->lastInsertId();
                $stmt = db()->prepare('SELECT * FROM parties WHERE id=?'); $stmt->execute([$id]);
                audit('create', 'party', $id, null, $stmt->fetch());
            }
            flash('success', 'تم حفظ بيانات الجهة.');
            redirect(url('parties'));
        }

        if ($action === 'party_delete') {
            require_role('admin');
            $id = (int)($_POST['id'] ?? 0);
            $stmt = db()->prepare('SELECT COUNT(*) FROM journal_lines WHERE party_id=?'); $stmt->execute([$id]);
            if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException('لا يمكن حذف جهة مرتبطة بقيود؛ يمكن إيقافها بدلاً من ذلك.');
            $stmt = db()->prepare('SELECT * FROM parties WHERE id=? AND company_id=?'); $stmt->execute([$id, company_id()]); $before = $stmt->fetch();
            db()->prepare('DELETE FROM parties WHERE id=? AND company_id=?')->execute([$id, company_id()]);
            audit('delete', 'party', $id, $before, null);
            flash('success', 'تم حذف الجهة.');
            redirect(url('parties'));
        }

        if ($action === 'cost_center_save') {
            require_role(['admin','accountant']);
            $id = (int)($_POST['id'] ?? 0);
            $code = trim((string)($_POST['code'] ?? ''));
            $name = trim((string)($_POST['name_ar'] ?? ''));
            if (!preg_match('/^[A-Za-z0-9._-]{1,30}$/', $code) || $name === '') throw new RuntimeException('رمز مركز الكلفة أو اسمه غير صالح.');
            $dupStmt = db()->prepare('SELECT COUNT(*) FROM cost_centers WHERE company_id=? AND code=? AND id<>?');
            $dupStmt->execute([company_id(), $code, $id]);
            if ((int)$dupStmt->fetchColumn() > 0) throw new RuntimeException('رمز مركز الكلفة مستخدم مسبقاً.');
            $active = isset($_POST['is_active']) ? 1 : 0;
            if ($id > 0) {
                $stmt = db()->prepare('SELECT * FROM cost_centers WHERE id=? AND company_id=?'); $stmt->execute([$id, company_id()]); $before = $stmt->fetch();
                if (!$before) throw new RuntimeException('مركز الكلفة غير موجود.');
                db()->prepare('UPDATE cost_centers SET code=?,name_ar=?,is_active=? WHERE id=? AND company_id=?')->execute([$code,$name,$active,$id,company_id()]);
                $stmt = db()->prepare('SELECT * FROM cost_centers WHERE id=?'); $stmt->execute([$id]); audit('update','cost_center',$id,$before,$stmt->fetch());
            } else {
                db()->prepare('INSERT INTO cost_centers(company_id,code,name_ar,is_active) VALUES(?,?,?,?)')->execute([company_id(),$code,$name,$active]);
                $id = (int)db()->lastInsertId(); $stmt = db()->prepare('SELECT * FROM cost_centers WHERE id=?'); $stmt->execute([$id]); audit('create','cost_center',$id,null,$stmt->fetch());
            }
            flash('success', 'تم حفظ مركز الكلفة.');
            redirect(url('cost_centers'));
        }

        if ($action === 'period_save') {
            require_role('admin');
            $name = trim((string)($_POST['name_ar'] ?? ''));
            $start = (string)($_POST['start_date'] ?? '');
            $end = (string)($_POST['end_date'] ?? '');
            if ($name === '' || !valid_date($start) || !valid_date($end) || $start > $end) throw new RuntimeException('بيانات الفترة المالية غير صالحة.');
            $stmt = db()->prepare('SELECT COUNT(*) FROM fiscal_periods WHERE company_id=? AND NOT(end_date<? OR start_date>?)');
            $stmt->execute([company_id(), $start, $end]);
            if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException('الفترة الجديدة تتداخل مع فترة مالية موجودة.');
            db()->prepare("INSERT INTO fiscal_periods(company_id,name_ar,start_date,end_date,status) VALUES(?,?,?,?, 'open')")->execute([company_id(),$name,$start,$end]);
            $id = (int)db()->lastInsertId(); audit('create','fiscal_period',$id,null,['name'=>$name,'start'=>$start,'end'=>$end]);
            flash('success','تم إنشاء الفترة المالية.'); redirect(url('periods'));
        }

        if ($action === 'period_toggle') {
            require_role('admin');
            $id = (int)($_POST['id'] ?? 0);
            $target = (string)($_POST['status'] ?? 'closed');
            $stmt = db()->prepare('SELECT * FROM fiscal_periods WHERE id=? AND company_id=?'); $stmt->execute([$id,company_id()]); $period = $stmt->fetch();
            if (!$period) throw new RuntimeException('الفترة المالية غير موجودة.');
            if ($target === 'closed') {
                $stmt = db()->prepare("SELECT COUNT(*) FROM journal_entries WHERE company_id=? AND entry_date BETWEEN ? AND ? AND status='draft'");
                $stmt->execute([company_id(),$period['start_date'],$period['end_date']]);
                if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException('لا يمكن إغلاق الفترة لوجود مستندات مسودة. رحّلها أو احذفها أولاً.');
                $unclosed = 0.0;
                foreach (report_balances($period['end_date'],$period['start_date']) as $row) {
                    if (in_array($row['account_type'],['revenue','expense'],true)) $unclosed += abs((float)$row['debit']-(float)$row['credit']);
                }
                if ($unclosed > 0.0005) throw new RuntimeException('لا يمكن إغلاق الفترة قبل إقفال حسابات الإيرادات والمصروفات. استخدم مساعد الإقفال.');
                db()->prepare("UPDATE fiscal_periods SET status='closed',closed_at=NOW(),closed_by=? WHERE id=? AND company_id=?")->execute([user()['id'],$id,company_id()]);
            } elseif ($target === 'open') {
                db()->prepare("UPDATE fiscal_periods SET status='open',closed_at=NULL,closed_by=NULL WHERE id=? AND company_id=?")->execute([$id,company_id()]);
            } else throw new RuntimeException('حالة الفترة غير صالحة.');
            audit('status_change','fiscal_period',$id,$period,['status'=>$target]);
            flash('success','تم تحديث حالة الفترة المالية.'); redirect(url('periods'));
        }

        if ($action === 'closing_generate') {
            require_role(['admin','accountant']);
            $result = create_closing_entry((int)($_POST['period_id'] ?? 0),(int)($_POST['result_account_id'] ?? 0),($_POST['submit_mode'] ?? '') === 'post');
            flash('success','تم إنشاء قيد الإقفال ' . $result['voucher_no'] . ($result['posted'] ? ' وترحيله.' : ' كمسودة.'));
            redirect(url('journal_view',['id'=>$result['id']]));
        }

        if ($action === 'user_save') {
            require_role('admin');
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['full_name'] ?? ''));
            $username = trim((string)($_POST['username'] ?? ''));
            $role = (string)($_POST['role'] ?? 'accountant');
            $password = (string)($_POST['password'] ?? '');
            $active = isset($_POST['is_active']) ? 1 : 0;
            if ($name === '' || !preg_match('/^[A-Za-z0-9_.-]{3,100}$/',$username) || !in_array($role,['admin','accountant','viewer'],true)) throw new RuntimeException('بيانات المستخدم غير صالحة.');
            $dupStmt = db()->prepare('SELECT COUNT(*) FROM users WHERE company_id=? AND username=? AND id<>?');
            $dupStmt->execute([company_id(), $username, $id]);
            if ((int)$dupStmt->fetchColumn() > 0) throw new RuntimeException('اسم المستخدم مستخدم مسبقاً.');
            if ($id === (int)user()['id'] && $active === 0) throw new RuntimeException('لا يمكن إيقاف حسابك الحالي.');
            if ($id > 0) {
                $stmt = db()->prepare('SELECT id,full_name,username,role,is_active FROM users WHERE id=? AND company_id=?'); $stmt->execute([$id,company_id()]); $before = $stmt->fetch();
                if (!$before) throw new RuntimeException('المستخدم غير موجود.');
                if ($before['role'] === 'admin' && ($role !== 'admin' || $active === 0)) {
                    $countStmt = db()->prepare("SELECT COUNT(*) FROM users WHERE company_id=? AND role='admin' AND is_active=1 AND id<>?");
                    $countStmt->execute([company_id(), $id]);
                    if ((int)$countStmt->fetchColumn() === 0) throw new RuntimeException('لا يمكن إلغاء صلاحية آخر مدير فعال في النظام.');
                }
                if ($password !== '' && mb_strlen($password) < 8) throw new RuntimeException('كلمة المرور يجب ألا تقل عن 8 أحرف.');
                if ($password !== '') {
                    db()->prepare('UPDATE users SET full_name=?,username=?,role=?,is_active=?,password_hash=? WHERE id=? AND company_id=?')->execute([$name,$username,$role,$active,password_hash($password,PASSWORD_DEFAULT),$id,company_id()]);
                } else {
                    db()->prepare('UPDATE users SET full_name=?,username=?,role=?,is_active=? WHERE id=? AND company_id=?')->execute([$name,$username,$role,$active,$id,company_id()]);
                }
                $stmt = db()->prepare('SELECT id,full_name,username,role,is_active FROM users WHERE id=?'); $stmt->execute([$id]); audit('update','user',$id,$before,$stmt->fetch());
            } else {
                if (mb_strlen($password) < 8) throw new RuntimeException('كلمة المرور يجب ألا تقل عن 8 أحرف.');
                db()->prepare('INSERT INTO users(company_id,full_name,username,password_hash,role,is_active) VALUES(?,?,?,?,?,?)')->execute([company_id(),$name,$username,password_hash($password,PASSWORD_DEFAULT),$role,$active]);
                $id=(int)db()->lastInsertId(); $stmt=db()->prepare('SELECT id,full_name,username,role,is_active FROM users WHERE id=?');$stmt->execute([$id]);audit('create','user',$id,null,$stmt->fetch());
            }
            flash('success','تم حفظ المستخدم.');redirect(url('users'));
        }

        if ($action === 'settings_save') {
            require_role('admin');
            $before = company();
            $name = trim((string)($_POST['name_ar'] ?? ''));
            if ($name === '') throw new RuntimeException('اسم المنشأة مطلوب.');
            $email = trim((string)($_POST['email'] ?? ''));
            if ($email !== '' && !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('البريد الإلكتروني غير صالح.');
            $decimalPlaces = (int)($_POST['decimal_places'] ?? 0);
            $startMonth = (int)($_POST['fiscal_year_start_month'] ?? 1);
            if ($decimalPlaces < 0 || $decimalPlaces > 3 || $startMonth < 1 || $startMonth > 12) throw new RuntimeException('إعدادات العملة أو بداية السنة المالية غير صالحة.');
            db()->prepare('UPDATE companies SET name_ar=?,name_en=?,registration_no=?,tax_no=?,address_ar=?,phone=?,email=?,currency_code=?,currency_name_ar=?,decimal_places=?,fiscal_year_start_month=? WHERE id=?')->execute([
                $name,trim((string)($_POST['name_en']??''))?:null,trim((string)($_POST['registration_no']??''))?:null,trim((string)($_POST['tax_no']??''))?:null,
                trim((string)($_POST['address_ar']??''))?:null,trim((string)($_POST['phone']??''))?:null,$email?:null,strtoupper(trim((string)($_POST['currency_code']??'IQD'))),
                trim((string)($_POST['currency_name_ar']??'دينار عراقي')),$decimalPlaces,$startMonth,company_id()
            ]);
            $after=company(true);
            $currentInstitutionKey = (string)($_SESSION['institution_key'] ?? '');
            if ($currentInstitutionKey !== '') {
                institution_rename(app_config(), $currentInstitutionKey, $name);
                $after = company(true);
            }
            audit('update','company',company_id(),$before,$after);flash('success','تم حفظ إعدادات المنشأة.');redirect(url('settings'));
        }

        if ($action === 'backup_create') {
            require_role('admin');
            $backup = create_backup_file();
            flash('success','تم إنشاء النسخة الاحتياطية ' . $backup['filename'] . ' بحجم ' . format_bytes((int)$backup['size']) . '.');
            redirect(url('backups'));
        }

        if ($action === 'backup_delete') {
            require_role('admin');
            $path = safe_backup_path((string)($_POST['filename'] ?? ''));
            $filename = basename($path);
            if (!unlink($path)) throw new RuntimeException('تعذر حذف ملف النسخة الاحتياطية.');
            audit('backup_delete','database_backup',$filename);flash('success','تم حذف النسخة الاحتياطية.');redirect(url('backups'));
        }


        if ($action === 'backup_restore_upload') {
            require_role('admin');
            verify_admin_restore_authorization(
                (string)($_POST['admin_password'] ?? ''),
                (string)($_POST['restore_confirmation'] ?? '')
            );
            $uploaded = save_uploaded_backup($_FILES['backup_file'] ?? []);
            try {
                restore_database_from_backup((string)$uploaded['path'], 'ملف مرفوع: ' . (string)$uploaded['filename']);
            } catch (Throwable $restoreError) {
                throw $restoreError;
            }
            try { audit('logout_after_restore', 'database_backup', (string)$uploaded['filename']); } catch (Throwable $auditError) { log_exception($auditError); }
            $institutionSnapshot = institution_session_snapshot();
            $_SESSION = [];
            institution_restore_session_snapshot($institutionSnapshot);
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            session_regenerate_id(true);
            redirect(url('login', ['restored' => '1']));
        }

        if ($action === 'backup_restore_saved') {
            require_role('admin');
            verify_admin_restore_authorization(
                (string)($_POST['admin_password'] ?? ''),
                (string)($_POST['restore_confirmation'] ?? '')
            );
            $path = safe_backup_path((string)($_POST['filename'] ?? ''));
            $filename = basename($path);
            restore_database_from_backup($path, 'نسخة محفوظة: ' . $filename);
            try { audit('logout_after_restore', 'database_backup', $filename); } catch (Throwable $auditError) { log_exception($auditError); }
            $institutionSnapshot = institution_session_snapshot();
            $_SESSION = [];
            institution_restore_session_snapshot($institutionSnapshot);
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            session_regenerate_id(true);
            redirect(url('login', ['restored' => '1']));
        }

        throw new RuntimeException('الإجراء المطلوب غير معروف.');
    } catch (Throwable $e) {
        log_exception($e);
        $message = ($e instanceof PDOException && !in_array($action, ['institution_add','institution_rename'], true))
            ? 'تعذر حفظ العملية بسبب قيد في قاعدة البيانات. تحقق من عدم تكرار الرموز ومن صحة البيانات.'
            : $e->getMessage();
        flash('danger', $message);
        redirect_after_error(url('dashboard'));
    }
}

$routes = [
    'dashboard','accounts','journal_list','journal_new','journal_view','cash_voucher','parties','cost_centers',
    'trial_balance','trial_balance_balances','general_journal','general_journal_assistant','ledger','bank_reconciliation','financial_position','income_statement','cash_flow','equity_changes','periods','closing',
    'users','settings','institutions','audit','backups','diagnostics','license','compliance_dashboard','standards_library','accounting_policies','disclosures','ifrs_transition','fixed_assets','inventory','ifrs_registers','cash_flow_register','report_settings','analytical_schedules','financial_package','smart_assistant'
];
if (!in_array($page, $routes, true)) {
    http_response_code(404);
    $page = 'not_found';
}
try {
    require __DIR__ . '/pages/' . $page . '.php';
} catch (Throwable $e) {
    log_exception($e);
    http_response_code($e instanceof RuntimeException ? 400 : 500);
    render_header('تعذر إكمال العملية', '');
    page_heading('تعذر إكمال العملية', 'راجع الرسالة أدناه ثم عد إلى الشاشة السابقة.');
    echo '<div class="alert alert-danger">' . e($e->getMessage()) . '</div>';
    echo '<a class="btn btn-primary" href="' . e(url('dashboard')) . '">العودة إلى لوحة المؤشرات</a>';
    render_footer();
}
