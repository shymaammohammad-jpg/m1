<?php
declare(strict_types=1);

/**
 * نظام ترخيص سنوي محلي باستخدام توقيع RSA-SHA256.
 * المفتاح الخاص غير موجود داخل التطبيق؛ التطبيق يحتوي المفتاح العام فقط.
 */

const BALANCE_LICENSE_PRODUCT = 'BALANCE-ACCOUNTING';
const BALANCE_LICENSE_PREFIX = 'BAL1';

function license_storage_dir(): string
{
    $dir = __DIR__ . '/../storage/license';
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('تعذر إنشاء مجلد الترخيص داخل storage.');
    }
    return $dir;
}

function license_base64url_encode(string $value): string
{
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function license_base64url_decode(string $value): string|false
{
    $padding = strlen($value) % 4;
    if ($padding > 0) {
        $value .= str_repeat('=', 4 - $padding);
    }
    return base64_decode(strtr($value, '-_', '+/'), true);
}

function license_installation_id(): string
{
    $path = license_storage_dir() . '/installation.id';
    if (is_file($path)) {
        $value = trim((string)@file_get_contents($path));
        if (preg_match('/^[A-F0-9-]{20,64}$/i', $value)) {
            return strtoupper($value);
        }
    }
    $raw = strtoupper(bin2hex(random_bytes(16)));
    $value = implode('-', str_split($raw, 8));
    if (@file_put_contents($path, $value, LOCK_EX) === false) {
        throw new RuntimeException('تعذر إنشاء رقم تثبيت ثابت. تحقق من صلاحيات مجلد storage/license.');
    }
    return $value;
}

function license_os_machine_id(): string
{
    $parts = [];
    $host = trim((string)(getenv('COMPUTERNAME') ?: gethostname() ?: php_uname('n')));
    if ($host !== '') {
        $parts[] = 'HOST=' . strtoupper($host);
    }

    if (PHP_OS_FAMILY === 'Windows' && function_exists('exec')) {
        $output = [];
        $code = 1;
        @exec('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid 2>NUL', $output, $code);
        if ($code === 0) {
            foreach ($output as $line) {
                if (preg_match('/MachineGuid\s+REG_\w+\s+(.+)$/i', trim((string)$line), $match)) {
                    $parts[] = 'GUID=' . strtoupper(trim($match[1]));
                    break;
                }
            }
        }
        $uuidOutput = [];
        $uuidCode = 1;
        @exec('wmic csproduct get uuid 2>NUL', $uuidOutput, $uuidCode);
        if ($uuidCode === 0) {
            foreach ($uuidOutput as $line) {
                $candidate = trim((string)$line);
                if (preg_match('/^[A-F0-9-]{20,}$/i', $candidate) && !preg_match('/^0+-0+-0+-0+-0+$/', $candidate)) {
                    $parts[] = 'UUID=' . strtoupper($candidate);
                    break;
                }
            }
        }
    } elseif (is_file('/etc/machine-id')) {
        $linuxId = trim((string)@file_get_contents('/etc/machine-id'));
        if ($linuxId !== '') {
            $parts[] = 'MID=' . strtoupper($linuxId);
        }
    }

    $parts[] = 'OS=' . strtoupper(PHP_OS_FAMILY);
    return implode('|', $parts);
}

function license_machine_code(): string
{
    $material = BALANCE_LICENSE_PRODUCT . '|' . license_os_machine_id() . '|INSTALL=' . license_installation_id();
    $hash = strtoupper(hash('sha256', $material));
    return implode('-', str_split(substr($hash, 0, 32), 4));
}

function license_key_path(): string
{
    return license_storage_dir() . '/license.key';
}

function license_public_key_text(): string
{
    $path = __DIR__ . '/license_public.pem';
    if (!is_file($path)) {
        throw new RuntimeException('ملف المفتاح العام للترخيص غير موجود.');
    }
    $key = (string)file_get_contents($path);
    if (trim($key) === '') {
        throw new RuntimeException('ملف المفتاح العام للترخيص فارغ.');
    }
    return $key;
}

function license_clock_state(bool $update, ?DateTimeImmutable $now = null): array
{
    $now ??= new DateTimeImmutable('now', new DateTimeZone('UTC'));
    $path = license_storage_dir() . '/clock.state';
    $appKey = (string)app_config('app_key', '');
    $secret = hash('sha256', BALANCE_LICENSE_PRODUCT . '|CLOCK|' . $appKey . '|' . license_installation_id(), true);
    $lastSeen = null;

    if (is_file($path)) {
        $decoded = json_decode((string)@file_get_contents($path), true);
        if (is_array($decoded) && isset($decoded['last_seen'], $decoded['mac'])) {
            $expected = hash_hmac('sha256', (string)$decoded['last_seen'], $secret);
            if (hash_equals($expected, (string)$decoded['mac'])) {
                try {
                    $lastSeen = new DateTimeImmutable((string)$decoded['last_seen'], new DateTimeZone('UTC'));
                } catch (Throwable) {
                    $lastSeen = null;
                }
            }
        }
    }

    $rollback = false;
    if ($lastSeen instanceof DateTimeImmutable) {
        $tolerance = $lastSeen->modify('-3 days');
        $rollback = $now < $tolerance;
    }

    if ($update && !$rollback && (!$lastSeen || $now > $lastSeen)) {
        $stamp = $now->format(DateTimeInterface::ATOM);
        $payload = json_encode([
            'last_seen' => $stamp,
            'mac' => hash_hmac('sha256', $stamp, $secret),
        ], JSON_UNESCAPED_SLASHES);
        @file_put_contents($path, $payload, LOCK_EX);
    }

    return ['rollback' => $rollback, 'last_seen' => $lastSeen?->format(DateTimeInterface::ATOM)];
}

function license_verify_key(string $key, bool $checkTime = true): array
{
    $key = preg_replace('/\s+/', '', trim($key)) ?? '';
    $machineCode = license_machine_code();
    $invalid = static fn(string $reason, string $code = 'invalid'): array => [
        'valid' => false,
        'code' => $code,
        'reason' => $reason,
        'payload' => null,
        'machine_code' => $machineCode,
        'days_remaining' => null,
    ];

    if ($key === '') {
        return $invalid('لم يتم تفعيل النظام بعد.', 'missing');
    }
    if (!extension_loaded('openssl') || !function_exists('openssl_verify')) {
        return $invalid('امتداد OpenSSL غير مفعّل في PHP، لذلك لا يمكن التحقق من الترخيص.', 'openssl_missing');
    }

    $parts = explode('.', $key);
    if (count($parts) !== 3 || $parts[0] !== BALANCE_LICENSE_PREFIX) {
        return $invalid('صيغة رقم الترخيص غير صحيحة.', 'format');
    }
    $payloadJson = license_base64url_decode($parts[1]);
    $signature = license_base64url_decode($parts[2]);
    if ($payloadJson === false || $signature === false) {
        return $invalid('تعذر قراءة بيانات الترخيص.', 'decode');
    }

    $publicKey = openssl_pkey_get_public(license_public_key_text());
    if ($publicKey === false) {
        return $invalid('تعذر تحميل المفتاح العام للترخيص.', 'public_key');
    }
    $verified = openssl_verify($payloadJson, $signature, $publicKey, OPENSSL_ALGO_SHA256);
    if ($verified !== 1) {
        return $invalid('التوقيع الرقمي للترخيص غير صحيح أو تم تعديل الرقم.', 'signature');
    }

    try {
        $payload = json_decode($payloadJson, true, 32, JSON_THROW_ON_ERROR);
    } catch (Throwable) {
        return $invalid('محتوى الترخيص غير صالح.', 'payload');
    }
    if (!is_array($payload)
        || ($payload['product'] ?? '') !== BALANCE_LICENSE_PRODUCT
        || (int)($payload['version'] ?? 0) !== 1
        || empty($payload['license_id'])
        || empty($payload['machine_code'])
        || empty($payload['valid_from'])
        || empty($payload['expires_at'])) {
        return $invalid('بيانات الترخيص ناقصة أو تخص منتجاً آخر.', 'product');
    }
    if (!hash_equals(strtoupper($machineCode), strtoupper((string)$payload['machine_code']))) {
        return $invalid('الترخيص غير مخصص لهذا الجهاز أو لهذا التثبيت.', 'machine');
    }

    try {
        $tz = new DateTimeZone('UTC');
        $from = new DateTimeImmutable((string)$payload['valid_from'] . ' 00:00:00', $tz);
        $expires = new DateTimeImmutable((string)$payload['expires_at'] . ' 23:59:59', $tz);
        $now = new DateTimeImmutable('now', $tz);
    } catch (Throwable) {
        return $invalid('تواريخ الترخيص غير صالحة.', 'date');
    }
    if ($expires < $from) {
        return $invalid('تاريخ انتهاء الترخيص يسبق تاريخ بدايته.', 'date_order');
    }

    if ($checkTime) {
        $clock = license_clock_state(false, $now);
        if ($clock['rollback']) {
            return $invalid('اكتشف النظام إرجاعاً غير طبيعي لتاريخ الجهاز. صحح التاريخ وتواصل مع المبرمج.', 'clock_rollback');
        }
        if ($now < $from) {
            return $invalid('الترخيص لم يبدأ بعد. تاريخ البداية: ' . $from->format('Y-m-d'), 'not_started');
        }
        if ($now > $expires) {
            return $invalid('انتهت صلاحية الترخيص بتاريخ ' . $expires->format('Y-m-d') . '.', 'expired');
        }
    }

    $days = max(0, (int)$now->diff($expires)->format('%a'));
    return [
        'valid' => true,
        'code' => 'valid',
        'reason' => 'الترخيص صالح.',
        'payload' => $payload,
        'machine_code' => $machineCode,
        'days_remaining' => $days,
        'expires_at' => $expires->format('Y-m-d'),
        'valid_from' => $from->format('Y-m-d'),
        'license_key' => $key,
    ];
}

function license_current_key(): string
{
    $path = license_key_path();
    return is_file($path) ? trim((string)@file_get_contents($path)) : '';
}

function license_status(bool $refresh = false): array
{
    static $cached = null;
    if (!$refresh && is_array($cached)) {
        return $cached;
    }
    try {
        $cached = license_verify_key(license_current_key(), true);
        if ($cached['valid']) {
            license_clock_state(true);
        }
    } catch (Throwable $error) {
        $cached = [
            'valid' => false,
            'code' => 'system_error',
            'reason' => $error->getMessage(),
            'payload' => null,
            'machine_code' => 'غير متاح',
            'days_remaining' => null,
        ];
    }
    return $cached;
}

function license_activate(string $key): array
{
    $status = license_verify_key($key, true);
    if (!$status['valid']) {
        throw new RuntimeException((string)$status['reason']);
    }
    $normalized = preg_replace('/\s+/', '', trim($key)) ?? '';
    $path = license_key_path();
    $tmp = $path . '.tmp-' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $normalized, LOCK_EX) === false || !@rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('تعذر حفظ ملف الترخيص. تحقق من صلاحيات مجلد storage/license.');
    }
    @file_put_contents(license_storage_dir() . '/activation.log', sprintf(
        "[%s] Activated %s for %s, expires %s\n",
        date('c'),
        (string)($status['payload']['license_id'] ?? ''),
        (string)($status['payload']['organization'] ?? $status['payload']['customer_name'] ?? ''),
        (string)($status['expires_at'] ?? '')
    ), FILE_APPEND | LOCK_EX);
    license_clock_state(true);
    return license_status(true);
}

function license_remove(): void
{
    $path = license_key_path();
    if (is_file($path) && !@unlink($path)) {
        throw new RuntimeException('تعذر حذف الترخيص الحالي.');
    }
}
