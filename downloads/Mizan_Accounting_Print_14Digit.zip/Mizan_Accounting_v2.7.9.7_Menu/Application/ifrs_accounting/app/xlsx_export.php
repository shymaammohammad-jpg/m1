<?php
declare(strict_types=1);

/**
 * Lightweight native XLSX exporter for XAMPP.
 * It uses ZipArchive and OOXML directly, so no Composer package is required.
 */
final class NativeXlsxExporter
{
    private array $sheets = [];

    public function addSheet(string $name, array $rows, array $merges = [], int $headerRows = 1): void
    {
        if (count($this->sheets) >= 30) {
            throw new RuntimeException('لا يمكن تصدير أكثر من 30 ورقة في ملف واحد.');
        }
        $cleanName = $this->uniqueSheetName($name);
        $this->sheets[] = [
            'name' => $cleanName,
            'rows' => array_slice($rows, 0, 20000),
            'merges' => array_slice($merges, 0, 5000),
            'header_rows' => max(0, min($headerRows, 20)),
        ];
    }

    public function save(string $path): void
    {
        if ($this->sheets === []) {
            throw new RuntimeException('لا توجد جداول قابلة للتصدير إلى Excel.');
        }
        $files = [
            '[Content_Types].xml' => $this->contentTypesXml(),
            '_rels/.rels' => $this->rootRelationshipsXml(),
            'docProps/app.xml' => $this->appPropertiesXml(),
            'docProps/core.xml' => $this->corePropertiesXml(),
            'xl/workbook.xml' => $this->workbookXml(),
            'xl/_rels/workbook.xml.rels' => $this->workbookRelationshipsXml(),
            'xl/styles.xml' => $this->stylesXml(),
        ];
        foreach ($this->sheets as $index => $sheet) {
            $files['xl/worksheets/sheet' . ($index + 1) . '.xml'] = $this->worksheetXml($sheet);
        }

        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
                throw new RuntimeException('تعذر إنشاء ملف Excel المؤقت.');
            }
            foreach ($files as $name => $content) {
                $zip->addFromString($name, $content);
            }
            $zip->close();
            return;
        }

        // XAMPP usually provides ZipArchive, but PharData is kept as a native fallback.
        if (class_exists('PharData')) {
            $zipPath = $path . '.zip';
            @unlink($zipPath);
            try {
                $archive = new PharData($zipPath, 0, null, Phar::ZIP);
                foreach ($files as $name => $content) {
                    $archive->addFromString($name, $content);
                }
                unset($archive);
                if (!@rename($zipPath, $path)) {
                    throw new RuntimeException('تعذر اعتماد ملف Excel بعد إنشائه.');
                }
                return;
            } catch (Throwable $error) {
                @unlink($zipPath);
                throw new RuntimeException('تعذر إنشاء ملف Excel بواسطة مكونات PHP المتاحة: ' . $error->getMessage());
            }
        }

        throw new RuntimeException('لا تتوفر آلية ZIP في PHP. فعّل extension=zip أو extension=phar ثم أعد تشغيل Apache.');
    }

    private function uniqueSheetName(string $name): string
    {
        $name = trim(preg_replace('~[\\/:?*\[\]]+~u', ' ', $name) ?? '');
        $name = trim(preg_replace('/\s+/u', ' ', $name) ?? '');
        if ($name === '') {
            $name = 'جدول';
        }
        $name = self::uSubstr($name, 0, 31);
        $base = $name;
        $used = array_column($this->sheets, 'name');
        $counter = 2;
        while (in_array($name, $used, true)) {
            $suffix = ' ' . $counter++;
            $name = self::uSubstr($base, 0, 31 - self::uStrlen($suffix)) . $suffix;
        }
        return $name;
    }

    private function worksheetXml(array $sheet): string
    {
        $rows = is_array($sheet['rows'] ?? null) ? $sheet['rows'] : [];
        $maxCols = 0;
        $widths = [];
        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $maxCols = max($maxCols, count($row));
            foreach ($row as $colIndex => $cell) {
                $value = is_array($cell) ? ($cell['value'] ?? '') : $cell;
                $length = self::uStrlen(trim((string)$value));
                $widths[$colIndex] = max((int)($widths[$colIndex] ?? 0), min($length + 2, 45));
            }
        }
        $maxCols = max(1, min($maxCols, 400));

        $colsXml = '';
        for ($i = 0; $i < $maxCols; $i++) {
            $width = max(8, min((float)($widths[$i] ?? 12), 42));
            $colsXml .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . $width . '" customWidth="1"/>';
        }

        $sheetData = '';
        foreach ($rows as $rowIndex => $row) {
            if (!is_array($row)) continue;
            $excelRow = $rowIndex + 1;
            $cellsXml = '';
            foreach (array_slice($row, 0, $maxCols) as $colIndex => $cell) {
                $cell = is_array($cell) ? $cell : ['value' => $cell];
                $value = $cell['value'] ?? '';
                $type = (string)($cell['type'] ?? 'string');
                $rowStyle = (string)($cell['style'] ?? 'body');
                $coordinate = self::columnName($colIndex + 1) . $excelRow;
                $isNumeric = $type === 'number' && is_numeric($value);
                $styleId = match (true) {
                    $rowStyle === 'header' => 1,
                    $rowStyle === 'total' && $isNumeric => 5,
                    $rowStyle === 'total' => 4,
                    $isNumeric => 3,
                    default => 2,
                };
                if ($isNumeric) {
                    $cellsXml .= '<c r="' . $coordinate . '" s="' . $styleId . '" t="n"><v>' . self::xml((string)(0 + $value)) . '</v></c>';
                } else {
                    $text = self::sanitizeText((string)$value);
                    $cellsXml .= '<c r="' . $coordinate . '" s="' . $styleId . '" t="inlineStr"><is><t xml:space="preserve">' . self::xml($text) . '</t></is></c>';
                }
            }
            $sheetData .= '<row r="' . $excelRow . '">' . $cellsXml . '</row>';
        }

        $mergeRefs = [];
        foreach ((array)($sheet['merges'] ?? []) as $merge) {
            if (!is_array($merge)) continue;
            $sr = max(0, (int)($merge['startRow'] ?? 0));
            $sc = max(0, (int)($merge['startCol'] ?? 0));
            $er = max($sr, (int)($merge['endRow'] ?? $sr));
            $ec = max($sc, (int)($merge['endCol'] ?? $sc));
            if ($er >= count($rows) || $ec >= $maxCols || ($sr === $er && $sc === $ec)) continue;
            $mergeRefs[] = self::columnName($sc + 1) . ($sr + 1) . ':' . self::columnName($ec + 1) . ($er + 1);
        }
        $mergesXml = '';
        if ($mergeRefs !== []) {
            $mergesXml = '<mergeCells count="' . count($mergeRefs) . '">';
            foreach ($mergeRefs as $ref) $mergesXml .= '<mergeCell ref="' . $ref . '"/>';
            $mergesXml .= '</mergeCells>';
        }

        $headerRows = (int)($sheet['header_rows'] ?? 1);
        $paneXml = $headerRows > 0
            ? '<pane ySplit="' . $headerRows . '" topLeftCell="A' . ($headerRows + 1) . '" activePane="bottomLeft" state="frozen"/>'
            : '';
        $dimension = 'A1:' . self::columnName($maxCols) . max(1, count($rows));

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<dimension ref="' . $dimension . '"/>'
            . '<sheetViews><sheetView workbookViewId="0" rightToLeft="1">' . $paneXml . '</sheetView></sheetViews>'
            . '<sheetFormatPr defaultRowHeight="18"/>'
            . '<cols>' . $colsXml . '</cols>'
            . '<sheetData>' . $sheetData . '</sheetData>'
            . $mergesXml
            . '<pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.2" footer="0.2"/>'
            . '<pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0" paperSize="9"/>'
            . '</worksheet>';
    }

    private function contentTypesXml(): string
    {
        $sheets = '';
        foreach ($this->sheets as $index => $_) {
            $sheets .= '<Override PartName="/xl/worksheets/sheet' . ($index + 1) . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            . '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            . $sheets . '</Types>';
    }

    private function rootRelationshipsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
            . '</Relationships>';
    }

    private function workbookXml(): string
    {
        $sheets = '';
        foreach ($this->sheets as $index => $sheet) {
            $sheets .= '<sheet name="' . self::xml((string)$sheet['name']) . '" sheetId="' . ($index + 1) . '" r:id="rId' . ($index + 1) . '"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<workbookPr date1904="0"/>'
            . '<bookViews><workbookView activeTab="0"/></bookViews>'
            . '<sheets>' . $sheets . '</sheets>'
            . '<calcPr calcId="191029" fullCalcOnLoad="1"/>'
            . '</workbook>';
    }

    private function workbookRelationshipsXml(): string
    {
        $rels = '';
        foreach ($this->sheets as $index => $_) {
            $rels .= '<Relationship Id="rId' . ($index + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . ($index + 1) . '.xml"/>';
        }
        $rels .= '<Relationship Id="rId' . (count($this->sheets) + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $rels . '</Relationships>';
    }

    private function stylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.###"/></numFmts>'
            . '<fonts count="3">'
            . '<font><sz val="10"/><name val="Arial"/></font>'
            . '<font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Arial"/></font>'
            . '<font><b/><color rgb="FF17324D"/><sz val="10"/><name val="Arial"/></font>'
            . '</fonts>'
            . '<fills count="4">'
            . '<fill><patternFill patternType="none"/></fill>'
            . '<fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FFDCE6F1"/><bgColor indexed="64"/></patternFill></fill>'
            . '</fills>'
            . '<borders count="2">'
            . '<border><left/><right/><top/><bottom/><diagonal/></border>'
            . '<border><left style="thin"><color rgb="FFB8C6D1"/></left><right style="thin"><color rgb="FFB8C6D1"/></right><top style="thin"><color rgb="FFB8C6D1"/></top><bottom style="thin"><color rgb="FFB8C6D1"/></bottom><diagonal/></border>'
            . '</borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="6">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>'
            . '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
            . '<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="right" vertical="center" wrapText="1"/></xf>'
            . '<xf numFmtId="164" fontId="2" fillId="3" borderId="1" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
            . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }

    private function appPropertiesXml(): string
    {
        $titles = '';
        foreach ($this->sheets as $sheet) {
            $titles .= '<vt:lpstr>' . self::xml((string)$sheet['name']) . '</vt:lpstr>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
            . '<Application>نظام الميزان المحاسبي</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop>'
            . '<HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant><vt:variant><vt:i4>' . count($this->sheets) . '</vt:i4></vt:variant></vt:vector></HeadingPairs>'
            . '<TitlesOfParts><vt:vector size="' . count($this->sheets) . '" baseType="lpstr">' . $titles . '</vt:vector></TitlesOfParts>'
            . '<Company>' . self::xml((string)(company()['name_ar'] ?? '')) . '</Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>2.5</AppVersion>'
            . '</Properties>';
    }

    private function corePropertiesXml(): string
    {
        $now = gmdate('Y-m-d\TH:i:s\Z');
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            . '<dc:creator>نظام الميزان المحاسبي</dc:creator><cp:lastModifiedBy>' . self::xml((string)(user()['full_name'] ?? '')) . '</cp:lastModifiedBy>'
            . '<dcterms:created xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' . $now . '</dcterms:modified>'
            . '</cp:coreProperties>';
    }

    private static function columnName(int $number): string
    {
        $name = '';
        while ($number > 0) {
            $number--;
            $name = chr(65 + ($number % 26)) . $name;
            $number = intdiv($number, 26);
        }
        return $name;
    }

    private static function uStrlen(string $value): int
    {
        return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
    }

    private static function uSubstr(string $value, int $start, int $length): string
    {
        return function_exists('mb_substr') ? mb_substr($value, $start, $length, 'UTF-8') : substr($value, $start, $length);
    }

    private static function sanitizeText(string $value): string
    {
        return preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', '', $value) ?? '';
    }

    private static function xml(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }
}

function export_visible_tables_to_xlsx(array $payload): never
{
    $sheets = $payload['sheets'] ?? null;
    if (!is_array($sheets) || $sheets === []) {
        throw new RuntimeException('لا توجد جداول قابلة للتصدير في الصفحة الحالية.');
    }

    $exporter = new NativeXlsxExporter();
    foreach ($sheets as $sheet) {
        if (!is_array($sheet)) continue;
        $rows = $sheet['rows'] ?? [];
        if (!is_array($rows) || $rows === []) continue;
        $exporter->addSheet(
            (string)($sheet['name'] ?? 'جدول'),
            $rows,
            is_array($sheet['merges'] ?? null) ? $sheet['merges'] : [],
            (int)($sheet['headerRows'] ?? 1)
        );
    }

    $filename = trim((string)($payload['filename'] ?? 'accounting_export'));
    $filename = preg_replace('/[^\p{L}\p{N}._-]+/u', '_', $filename) ?? 'accounting_export';
    $filename = trim($filename, '._-');
    if ($filename === '') $filename = 'accounting_export';
    $filename = mb_substr($filename, 0, 100) . '.xlsx';

    $tmpDir = __DIR__ . '/../storage/tmp';
    if (!is_dir($tmpDir) && !@mkdir($tmpDir, 0775, true) && !is_dir($tmpDir)) {
        throw new RuntimeException('تعذر إنشاء مجلد ملفات التصدير المؤقتة.');
    }
    $tmpPath = $tmpDir . '/xlsx_' . bin2hex(random_bytes(8)) . '.xlsx';
    $exporter->save($tmpPath);
    audit('export_xlsx', 'visible_tables', null, null, null, ['filename' => $filename, 'sheets' => count($sheets)]);

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Length: ' . filesize($tmpPath));
    header('Content-Disposition: attachment; filename="accounting_export.xlsx"; filename*=UTF-8\'\'' . rawurlencode($filename));
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('X-Content-Type-Options: nosniff');
    readfile($tmpPath);
    @unlink($tmpPath);
    exit;
}
