<?php
declare(strict_types=1);

/**
 * Exact financial-statement templates based on the Iraqi Unified Accounting
 * System IFRS implementation guide (statement models on guide pages 47-64).
 *
 * The functions in this file deliberately separate the code printed in the
 * guide from the source account code used by the database. This is necessary
 * because the guide's illustrative statement templates contain a small number
 * of code inconsistencies with its own chart of accounts (for example 226 vs
 * 228 for accumulated amortisation of intangible assets, and 256 vs 25115 for
 * investment impairment). The printed code remains faithful to the template,
 * while the source code follows the imported chart of accounts.
 */

function gr_vec_zero(): array
{
    return [0.0, 0.0, 0.0];
}

function gr_vec_add(array ...$vectors): array
{
    $out = gr_vec_zero();
    foreach ($vectors as $vector) {
        for ($i = 0; $i < 3; $i++) {
            $out[$i] += (float)($vector[$i] ?? 0);
        }
    }
    return array_map(static fn(float $v): float => round($v, 3), $out);
}

function gr_vec_sub(array $base, array ...$vectors): array
{
    foreach ($vectors as $vector) {
        for ($i = 0; $i < 3; $i++) {
            $base[$i] -= (float)($vector[$i] ?? 0);
        }
    }
    return array_map(static fn(float $v): float => round($v, 3), $base);
}

function gr_vec_scale(array $vector, float $factor): array
{
    return array_map(static fn(float $v): float => round($v * $factor, 3), $vector);
}

function gr_row(
    string $label,
    string|int|float|null $displayCode = '',
    ?array $values = null,
    string $kind = 'detail',
    string $formula = '',
    string $sourceCode = ''
): array {
    return [
        'label' => $label,
        'code' => $displayCode === null ? '' : trim((string)$displayCode),
        'values' => $values,
        'kind' => $kind,
        'formula' => $formula,
        'source_code' => $sourceCode,
    ];
}

function gr_account_prefix_exists(string $prefix): bool
{
    static $cache = [];
    $key = company_id() . ':' . $prefix;
    if (!array_key_exists($key, $cache)) {
        $stmt = db()->prepare('SELECT COUNT(*) FROM accounts WHERE company_id=? AND (code=? OR code LIKE ?)');
        $stmt->execute([company_id(), $prefix, $prefix . '%']);
        $cache[$key] = (int)$stmt->fetchColumn() > 0;
    }
    return $cache[$key];
}

/** Select the first chart-of-accounts prefix that exists in this installation. */
function gr_source_prefix(array|string|int $candidates): string|array
{
    if (!is_array($candidates)) {
        return (string)$candidates;
    }
    foreach ($candidates as $candidate) {
        $prefix = trim((string)$candidate);
        if ($prefix !== '' && gr_account_prefix_exists($prefix)) {
            return $prefix;
        }
    }
    return trim((string)($candidates[0] ?? ''));
}

function gr_balance_triplet(array $ctx, array|string|int $include, string $orientation = 'debit', array|string|int $exclude = []): array
{
    return report_triplet($include, $ctx, $orientation, $exclude);
}

function gr_movement_triplet(array $ctx, array|string|int $include, string $orientation = 'debit', array|string|int $exclude = []): array
{
    return movement_triplet($include, $ctx, $orientation, $exclude);
}

function gr_balance_on_dates(array|string|int $include, array $dates, string $orientation = 'debit', array|string|int $exclude = []): array
{
    $out = [];
    foreach ($dates as $date) {
        $out[] = guide_amount($include, (string)$date, null, $orientation, $exclude);
    }
    return array_map(static fn(float $v): float => round($v, 3), $out);
}

function gr_period_opening_triplet(array $ctx, array|string|int $include, string $orientation = 'debit', array|string|int $exclude = []): array
{
    $dates = [
        (new DateTimeImmutable($ctx['from']))->modify('-1 day')->format('Y-m-d'),
        (new DateTimeImmutable($ctx['prior_from']))->modify('-1 day')->format('Y-m-d'),
        (new DateTimeImmutable($ctx['earlier_from']))->modify('-1 day')->format('Y-m-d'),
    ];
    return gr_balance_on_dates($include, $dates, $orientation, $exclude);
}

function gr_period_closing_triplet(array $ctx, array|string|int $include, string $orientation = 'debit', array|string|int $exclude = []): array
{
    return gr_balance_on_dates($include, [$ctx['to'], $ctx['prior_to'], $ctx['earlier_to']], $orientation, $exclude);
}

function gr_period_value(string $periodEnd, string $valueCode, float $default = 0.0): float
{
    if (!table_exists('report_period_values')) {
        return $default;
    }
    $stmt = db()->prepare('SELECT amount FROM report_period_values WHERE company_id=? AND period_end=? AND value_code=?');
    $stmt->execute([company_id(), $periodEnd, $valueCode]);
    $value = $stmt->fetchColumn();
    return $value === false ? $default : round((float)$value, 3);
}

function gr_period_value_triplet(array $ctx, string $valueCode): array
{
    return [
        gr_period_value($ctx['to'], $valueCode),
        gr_period_value($ctx['prior_to'], $valueCode),
        gr_period_value($ctx['earlier_to'], $valueCode),
    ];
}

function gr_report_money(float|int|string|null $amount): string
{
    $value = round((float)$amount, 3);
    $formatted = money(abs($value));
    return $value < -0.0005 ? '(' . $formatted . ')' : $formatted;
}

function gr_parse_signed_amount(mixed $value): float
{
    $text = trim((string)$value);
    if ($text === '') return 0.0;
    $negativeParentheses = str_starts_with($text, '(') && str_ends_with($text, ')');
    if ($negativeParentheses) $text = substr($text, 1, -1);
    $text = str_replace([',', ' ', '٬'], '', $text);
    $text = str_replace('٫', '.', $text);
    if (!is_numeric($text)) throw new RuntimeException('توجد قيمة تقريرية غير صالحة.');
    $number = round((float)$text, 3);
    return $negativeParentheses ? -abs($number) : $number;
}

/**
 * Financial position statement - exact row order and calculations of the guide
 * model. Totals are derived from the visible net components and therefore do
 * not include regulatory/off-setting accounts 18, 19, 28 or 29.
 */
function gr_financial_position_rows(array $ctx): array
{
    $v = static fn(array|string|int $c, string $o = 'debit', array|string|int $x = []): array => gr_balance_triplet($ctx, $c, $o, $x);
    $rows = [];

    $rows[] = gr_row('الأصول غير المتداولة', '11', null, 'section');

    $ppe = $v('111');
    $ppeDep = $v('221', 'credit');
    $ppeImp = $v('25111', 'credit');
    $ppeNet = gr_vec_sub($ppe, $ppeDep, $ppeImp);
    $rows[] = gr_row('الممتلكات والآلات والمعدات', '111', $ppe);
    $rows[] = gr_row('ينزل: متراكم اندثار الممتلكات والآلات والمعدات', '221', $ppeDep, 'deduction');
    $rows[] = gr_row('ينزل: مخصص انخفاض الممتلكات والآلات والمعدات', '25111', $ppeImp, 'deduction');
    $rows[] = gr_row('صافي الممتلكات والآلات والمعدات', '', $ppeNet, 'subtotal', '111 - 221 - 25111');

    $property = $v('112');
    $propertyDep = $v('222', 'credit');
    $propertyImp = $v('25112', 'credit');
    $propertyNet = gr_vec_sub($property, $propertyDep, $propertyImp);
    $rows[] = gr_row('العقارات الاستثمارية', '112', $property);
    $rows[] = gr_row('ينزل: متراكم اندثار العقارات الاستثمارية', '222', $propertyDep, 'deduction');
    $rows[] = gr_row('ينزل: مخصص انخفاض العقارات الاستثمارية', '25112', $propertyImp, 'deduction');
    $rows[] = gr_row('صافي العقارات الاستثمارية', '', $propertyNet, 'subtotal', '112 - 222 - 25112');

    $lease = $v('113');
    $leaseImp = $v('25113', 'credit');
    $leaseDep = $v('223', 'credit');
    $leaseNet = gr_vec_sub($lease, $leaseImp, $leaseDep);
    $rows[] = gr_row('الأصول غير المتداولة المستأجرة (إيجار تمويلي)', '113', $lease);
    $rows[] = gr_row('ينزل: مخصص انخفاض الأصول غير المتداولة المستأجرة', '25113', $leaseImp, 'deduction');
    $rows[] = gr_row('ينزل: متراكم اندثار الأصول غير المتداولة المستأجرة', '223', $leaseDep, 'deduction');
    $rows[] = gr_row('صافي الأصول غير المتداولة المستأجرة (إيجار تمويلي)', '', $leaseNet, 'subtotal', '113 - 25113 - 223');

    $bio = $v('114');
    $bioImp = $v('25114', 'credit');
    $bioNet = gr_vec_sub($bio, $bioImp);
    $rows[] = gr_row('أصول حية لأغراض العرض والإنتاج والحراسة', '114', $bio);
    $rows[] = gr_row('ينزل: مخصص انخفاض أصول حية لأغراض العرض والإنتاج والحراسة', '25114', $bioImp, 'deduction');
    $rows[] = gr_row('صافي أصول حية لأغراض العرض والإنتاج والحراسة', '', $bioNet, 'subtotal', '114 - 25114');

    $loansLong = $v('1151');
    $investLong = $v('1152');
    $investImpairSource = gr_source_prefix(['256', '25115']);
    $investImpair = $v($investImpairSource, 'credit');
    $investNet = gr_vec_sub($investLong, $investImpair);
    $loansInvestNet = gr_vec_add($loansLong, $investNet);
    $rows[] = gr_row('القروض والاستثمارات طويلة الأجل', '115', null, 'section');
    $rows[] = gr_row('القروض الممنوحة طويلة الأجل', '1151', $loansLong);
    $rows[] = gr_row('الاستثمارات المالية', '1152', $investLong);
    $rows[] = gr_row('ينزل: مخصص انخفاض الاستثمارات المالية', '256', $investImpair, 'deduction', '', (string)$investImpairSource);
    $rows[] = gr_row('صافي الاستثمارات في أدوات حقوق الملكية', '', $investNet, 'subtotal', '1152 - مخصص الانخفاض');
    $rows[] = gr_row('مجموع القروض وصافي الاستثمارات في أدوات حقوق الملكية', '', $loansInvestNet, 'subtotal');

    $mining = $v('116');
    $miningDep = $v('226', 'credit');
    $miningAmort = $v('229', 'credit');
    $miningImp = $v('25116', 'credit');
    $miningNet = gr_vec_sub($mining, $miningDep, $miningAmort, $miningImp);
    $rows[] = gr_row('عقود التعدين', '116', null, 'section');
    $rows[] = gr_row('عقود التعدين', '116', $mining);
    $rows[] = gr_row('ينزل: متراكم اندثار عقود التعدين الملموسة', '226', $miningDep, 'deduction');
    $rows[] = gr_row('ينزل: متراكم إطفاء عقود التعدين غير الملموسة', '229', $miningAmort, 'deduction');
    $rows[] = gr_row('ينزل: مخصص انخفاض عقود التعدين', '25116', $miningImp, 'deduction');
    $rows[] = gr_row('صافي عقود التعدين', '', $miningNet, 'subtotal');

    $joint = $v('117');
    $jointDep = $v('227', 'credit');
    $jointImp = $v('25117', 'credit');
    $jointNet = gr_vec_sub($joint, $jointDep, $jointImp);
    $rows[] = gr_row('الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة', '117', $joint);
    $rows[] = gr_row('ينزل: متراكم اندثار الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة', '227', $jointDep, 'deduction');
    $rows[] = gr_row('ينزل: مخصص انخفاض الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة', '25117', $jointImp, 'deduction');
    $rows[] = gr_row('صافي الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة', '', $jointNet, 'subtotal');

    $nonCurrentTotal = gr_vec_add($ppeNet, $propertyNet, $leaseNet, $bioNet, $loansInvestNet, $miningNet, $jointNet);
    $rows[] = gr_row('مجموع الأصول غير المتداولة', '', $nonCurrentTotal, 'total');

    $rows[] = gr_row('الإنفاق الرأسمالي', '12', null, 'section');
    $capexParts = [];
    foreach ([
        '121' => 'الإنفاق الرأسمالي على الممتلكات والآلات والمعدات',
        '122' => 'الإنفاق الرأسمالي على العقارات الاستثمارية',
        '123' => 'الإنفاق الرأسمالي على الأصول غير المتداولة المستأجرة',
        '124' => 'الإنفاق الرأسمالي على الأصول الحية لأغراض العرض والإنتاج',
        '125' => 'إنفاق استثماري',
        '126' => 'عقود التعدين',
        '127' => 'الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة',
    ] as $code => $label) {
        $amount = $v($code);
        $capexParts[] = $amount;
        $rows[] = gr_row($label, $code, $amount);
    }
    $capexTotal = gr_vec_add(...$capexParts);
    $rows[] = gr_row('مجموع الإنفاق الرأسمالي', '', $capexTotal, 'total');

    $rows[] = gr_row('الأصول المتداولة', '13', null, 'section');
    $inventory = $v('131', 'debit', ['1318']);
    $inventoryProvision = $v('25121', 'credit');
    $inventoryNrv = gr_vec_sub($inventory, $inventoryProvision);
    $letters = $v('1318');
    $inventoryTotal = gr_vec_add($inventoryNrv, $letters);
    $rows[] = gr_row('المخزون (عدا حـ/1318)', '131', $inventory);
    $rows[] = gr_row('ينزل: مخصص هبوط أسعار المخزون', '25121', $inventoryProvision, 'deduction');
    $rows[] = gr_row('المخزون بالقيمة التحصيلية الصافية', '', $inventoryNrv, 'subtotal');
    $rows[] = gr_row('اعتمادات مستندية لشراء مواد', '1318', $letters);
    $rows[] = gr_row('إجمالي المخزون', '', $inventoryTotal, 'subtotal');

    $receivables = $v('132');
    $badDebts = $v('224', 'credit');
    $receivablesNet = gr_vec_sub($receivables, $badDebts);
    $rows[] = gr_row('الذمم المدينة', '132', $receivables);
    $rows[] = gr_row('ينزل: الديون المشكوك في تحصيلها', '224', $badDebts, 'deduction');
    $rows[] = gr_row('صافي الذمم المدينة', '', $receivablesNet, 'subtotal');

    $heldForSale = $v('133');
    $heldForSaleImp = $v('2581', 'credit');
    $heldForSaleNet = gr_vec_sub($heldForSale, $heldForSaleImp);
    $rows[] = gr_row('الأصول غير المتداولة المعروضة للبيع أو المحتفظ بها للتوزيع على الملاك', '133', $heldForSale);
    $rows[] = gr_row('ينزل: مخصص انخفاض الأصول غير المتداولة المعروضة للبيع أو المحتفظ بها للتوزيع على الملاك', '2581', $heldForSaleImp, 'deduction');
    $rows[] = gr_row('صافي الأصول غير المتداولة المعروضة للبيع أو المحتفظ بها للتوزيع على الملاك', '', $heldForSaleNet, 'subtotal');

    $cash = $v('134');
    $fxProvision = $v('257', 'credit');
    $cashNet = gr_vec_sub($cash, $fxProvision);
    $rows[] = gr_row('النقود', '134', $cash);
    $rows[] = gr_row('ينزل: مخصص فروقات أسعار الصرف', '257', $fxProvision, 'deduction');
    $rows[] = gr_row('صافي النقود', '', $cashNet, 'subtotal');

    $shortLoans = $v('1351');
    $shortInvestments = $v('1352');
    $shortTotal = gr_vec_add($shortLoans, $shortInvestments);
    $rows[] = gr_row('القروض والاستثمارات قصيرة الأجل', '135', null, 'section');
    $rows[] = gr_row('قروض ممنوحة قصيرة الأجل', '1351', $shortLoans);
    $rows[] = gr_row('الاستثمارات في الأسهم والسندات والأوراق التجارية', '1352', $shortInvestments);
    $rows[] = gr_row('مجموع القروض والاستثمارات قصيرة الأجل', '', $shortTotal, 'subtotal');

    $currentTotal = gr_vec_add($inventoryTotal, $receivablesNet, $heldForSaleNet, $cashNet, $shortTotal);
    $rows[] = gr_row('مجموع الأصول المتداولة', '', $currentTotal, 'total');

    $rows[] = gr_row('الأصول الأخرى', '14', null, 'section');
    $taxAssets = $v('141');
    $compensation = $v('142');
    $longLeaseRights = $v('143');
    $fairValueInvestments = $v('145');
    $fairValueAdjustment = $v('225', 'credit');
    $fairValueNet = gr_vec_sub($fairValueInvestments, $fairValueAdjustment);
    $repurchaseRights = $v('146');
    $contractAssets = $v('148');
    $rows[] = gr_row('أصول ضريبية مؤجلة', '141', $taxAssets);
    $rows[] = gr_row('تعويضات وغرامات مؤجلة', '142', $compensation);
    $rows[] = gr_row('حقوق التأجير طويلة الأجل', '143', $longLeaseRights);
    $rows[] = gr_row('استثمارات بالقيمة العادلة من خلال الدخل الشامل الآخر', '145', $fairValueInvestments);
    $rows[] = gr_row('تعديلات القيمة العادلة للاستثمارات المقيمة من خلال الدخل الشامل الآخر', '225', $fairValueAdjustment, 'deduction');
    $rows[] = gr_row('الاستثمارات بالقيمة العادلة', '', $fairValueNet, 'subtotal');
    $rows[] = gr_row('حقوق بيع البضائع وإعادة الشراء', '146', $repurchaseRights);
    $rows[] = gr_row('الحقوق الناشئة عن العقود', '148', $contractAssets);
    $otherAssetsTotal = gr_vec_add($taxAssets, $compensation, $longLeaseRights, $fairValueNet, $repurchaseRights, $contractAssets);
    $rows[] = gr_row('مجموع الأصول الأخرى', '', $otherAssetsTotal, 'total');

    $rows[] = gr_row('الأصول غير الملموسة', '15', null, 'section');
    $intangibleParts = [];
    foreach ([
        '151' => 'شهرة المحل',
        '152' => 'حقوق اختراع',
        '153' => 'حقوق الامتياز والتراخيص',
        '154' => 'العلامة التجارية',
        '155' => 'الأبحاث والتجارب',
        '156' => 'حقوق النشر والطبع والتأليف',
        '157' => 'حقوق عقود التأجير طويلة الأجل',
        '158' => 'أصول غير ملموسة أخرى',
    ] as $code => $label) {
        $amount = $v($code);
        $intangibleParts[] = $amount;
        $rows[] = gr_row($label, $code, $amount);
    }
    $intangibleGross = gr_vec_add(...$intangibleParts);
    $intangibleAmortSource = gr_source_prefix(['228', '226']);
    $intangibleAmort = $v($intangibleAmortSource, 'credit');
    $intangibleNet = gr_vec_sub($intangibleGross, $intangibleAmort);
    $rows[] = gr_row('مجموع الأصول غير الملموسة', '', $intangibleGross, 'subtotal');
    $rows[] = gr_row('ينزل: متراكم إطفاء الأصول غير الملموسة', '226', $intangibleAmort, 'deduction', '', (string)$intangibleAmortSource);
    $rows[] = gr_row('صافي الأصول غير الملموسة', '', $intangibleNet, 'subtotal');

    $assetsTotal = gr_vec_add($nonCurrentTotal, $capexTotal, $currentTotal, $otherAssetsTotal, $intangibleNet);
    $rows[] = gr_row('مجموع الأصول', '', $assetsTotal, 'grand');
    $rows[] = gr_row('الحسابات التنظيمية المؤجلة المدينة', '18', $v('18'));
    $rows[] = gr_row('الحسابات المتقابلة المدينة', '19', $v('19'));

    $rows[] = gr_row('الالتزامات غير المتداولة', '21', null, 'section');
    $nonCurrentLiabilityParts = [];
    foreach ([
        '211' => 'التزامات تمويل الممتلكات والآلات والمعدات',
        '212' => 'التزامات تمويل العقارات الاستثمارية',
        '213' => 'التزامات تمويل عقود الإيجار',
        '214' => 'التزامات تمويل أصول حية لأغراض العرض والإنتاج والحراسة',
        '215' => 'الالتزامات طويلة الأجل',
    ] as $code => $label) {
        $amount = $v($code, 'credit');
        $nonCurrentLiabilityParts[] = $amount;
        $rows[] = gr_row($label, $code, $amount);
    }
    $nonCurrentLiabilityTotal = gr_vec_add(...$nonCurrentLiabilityParts);
    $rows[] = gr_row('مجموع الالتزامات غير المتداولة', '', $nonCurrentLiabilityTotal, 'total');

    $rows[] = gr_row('الالتزامات المتداولة', '23', null, 'section');
    $currentLiabilityParts = [];
    foreach ([
        '232' => 'الذمم الدائنة',
        '234' => 'المصارف الدائنة (جاري مكشوف)',
        '235' => 'الالتزامات قصيرة الأجل',
    ] as $code => $label) {
        $amount = $v($code, 'credit');
        $currentLiabilityParts[] = $amount;
        $rows[] = gr_row($label, $code, $amount);
    }
    $currentLiabilityTotal = gr_vec_add(...$currentLiabilityParts);
    $rows[] = gr_row('مجموع الالتزامات المتداولة', '', $currentLiabilityTotal, 'total');

    $rows[] = gr_row('الالتزامات الأخرى', '24', null, 'section');
    $otherLiabilityParts = [];
    foreach ([
        '241' => 'التزامات ضريبية مؤجلة',
        '242' => 'التزامات وغرامات مؤجلة',
        '243' => 'التزامات عقود إيجار',
    ] as $code => $label) {
        $amount = $v($code, 'credit');
        $otherLiabilityParts[] = $amount;
        $rows[] = gr_row($label, $code, $amount);
    }
    // The statement model prints deferred revenue as 244 while the imported
    // chart places it under 245. Print the guide code and read the chart code.
    $deferredSource = gr_source_prefix(['244', '245']);
    $deferredRevenue = $v($deferredSource, 'credit');
    $otherLiabilityParts[] = $deferredRevenue;
    $rows[] = gr_row('إيرادات مؤجلة', '244', $deferredRevenue, 'detail', '', (string)$deferredSource);
    // If a separately configured 245 account exists alongside 244, report it;
    // otherwise keep the duplicated guide row at zero to avoid double counting.
    $secondLease = (gr_account_prefix_exists('244') && gr_account_prefix_exists('245')) ? $v('245', 'credit') : gr_vec_zero();
    $otherLiabilityParts[] = $secondLease;
    $rows[] = gr_row('التزامات عقود إيجار', '245', $secondLease, 'detail', '', gr_account_prefix_exists('244') ? '245' : 'غير معرف مستقلاً في الدليل المستورد');
    foreach ([
        '246' => 'التزامات بيع البضائع وعقود الصرف المؤجلة',
        '247' => 'التزام منح حق استخدام الأصول غير الملموسة',
        '248' => 'الالتزامات الناشئة عن العقود',
    ] as $code => $label) {
        $amount = $v($code, 'credit');
        $otherLiabilityParts[] = $amount;
        $rows[] = gr_row($label, $code, $amount);
    }
    $otherLiabilityTotal = gr_vec_add(...$otherLiabilityParts);
    $rows[] = gr_row('مجموع الالتزامات الأخرى', '', $otherLiabilityTotal, 'total');

    $rows[] = gr_row('التخصيصات', '25', null, 'section');
    $provisionParts = [];
    foreach ([
        '251' => 'مخصص مصروفات الشراء',
        '252' => 'مخصص الخسائر المتوقعة لمشاريع قيد الإنجاز',
        '253' => 'مخصص مصاريف الصيانة المحتملة وخدمات ما بعد البيع',
        '255' => 'مخصص الالتزامات والمطالبات والغرامات',
        '258' => 'مخصصات متنوعة',
    ] as $code => $label) {
        $amount = $v($code, 'credit');
        $provisionParts[] = $amount;
        $rows[] = gr_row($label, $code, $amount);
    }
    $provisionsTotal = gr_vec_add(...$provisionParts);
    $rows[] = gr_row('مجموع المخصصات', '', $provisionsTotal, 'total');

    $rows[] = gr_row('حقوق الملكية', '26', null, 'section');
    $capital = $v('261', 'credit');
    $additionalCapital = $v('262', 'credit');
    $retained = $v('263', 'credit');
    $surplus = $v('2631', 'credit');
    $deficit = $v('2632', 'credit');
    $oci = $v('264', 'credit');
    $policySource = gr_source_prefix(['265', '2633']);
    $policy = $v($policySource, 'credit');
    $rows[] = gr_row('رأس المال', '261', $capital);
    $rows[] = gr_row('رأس المال الإضافي (الاحتياطيات)', '262', $additionalCapital);
    $rows[] = gr_row('الأرباح المحتجزة', '263', $retained);
    $rows[] = gr_row('الفائض المتراكم', '2631', $surplus);
    $rows[] = gr_row('العجز المتراكم', '2632', $deficit);
    $rows[] = gr_row('الدخل الشامل الآخر', '264', $oci);
    $rows[] = gr_row('التغير بالسياسات المحاسبية والتقديرات وتصحيح الأخطاء', '265', $policy, 'detail', '', (string)$policySource);
    // Use the top-level account to prevent double counting the detail rows.
    $equityTotal = $v('26', 'credit');
    $rows[] = gr_row('مجموع حقوق الملكية', '', $equityTotal, 'total');

    $liabilitiesEquityTotal = gr_vec_add(
        $nonCurrentLiabilityTotal,
        $currentLiabilityTotal,
        $otherLiabilityTotal,
        $provisionsTotal,
        $equityTotal
    );
    $rows[] = gr_row('مجموع الالتزامات وحقوق الملكية', '', $liabilitiesEquityTotal, 'grand');
    $rows[] = gr_row('الحسابات التنظيمية المؤجلة الدائنة', '28', $v('28', 'credit'));
    $rows[] = gr_row('الحسابات المتقابلة الدائنة', '29', $v('29', 'credit'));

    return [
        'rows' => $rows,
        'assets_total' => $assetsTotal,
        'liabilities_equity_total' => $liabilitiesEquityTotal,
        'balance_difference' => gr_vec_sub($assetsTotal, $liabilitiesEquityTotal),
    ];
}

function gr_functional_account_map(): array
{
    if (!table_exists('report_account_function_map')) {
        return [];
    }
    $stmt = db()->prepare('SELECT account_id,function_code FROM report_account_function_map WHERE company_id=?');
    $stmt->execute([company_id()]);
    $map = [];
    foreach ($stmt->fetchAll() as $row) {
        $map[(int)$row['account_id']] = (string)$row['function_code'];
    }
    return $map;
}

/**
 * Sum expenses assigned to functional rows 5, 6, 7 or 8. Cost-centre mapping
 * takes precedence; account-level mapping is the fallback.
 */
function gr_functional_expense(string $functionCode, string $from, string $to): float
{
    if (!in_array($functionCode, ['5', '6', '7', '8'], true)) {
        throw new InvalidArgumentException('Functional report code must be 5, 6, 7 or 8.');
    }
    $sql = "SELECT COALESCE(SUM(jl.debit-jl.credit),0)
            FROM journal_lines jl
            JOIN journal_entries je ON je.id=jl.journal_entry_id
            JOIN accounts a ON a.id=jl.account_id
            LEFT JOIN cost_centers cc ON cc.id=jl.cost_center_id
            LEFT JOIN report_account_function_map fm ON fm.company_id=je.company_id AND fm.account_id=jl.account_id
            WHERE je.company_id=? AND " . posted_status_condition('je') . "
              AND je.entry_date BETWEEN ? AND ?
              AND a.account_type='expense'
              AND COALESCE(NULLIF(cc.functional_report_code,'none'),fm.function_code)=?";
    $stmt = db()->prepare($sql);
    $stmt->execute([company_id(), $from, $to, $functionCode]);
    return round((float)$stmt->fetchColumn(), 3);
}

function gr_functional_expense_triplet(string $functionCode, array $ctx): array
{
    return [
        gr_functional_expense($functionCode, $ctx['from'], $ctx['to']),
        gr_functional_expense($functionCode, $ctx['prior_from'], $ctx['prior_to']),
        gr_functional_expense($functionCode, $ctx['earlier_from'], $ctx['earlier_to']),
    ];
}

function gr_unclassified_functional_expense(string $from, string $to): float
{
    $sql = "SELECT COALESCE(SUM(jl.debit-jl.credit),0)
            FROM journal_lines jl
            JOIN journal_entries je ON je.id=jl.journal_entry_id
            JOIN accounts a ON a.id=jl.account_id
            LEFT JOIN cost_centers cc ON cc.id=jl.cost_center_id
            LEFT JOIN report_account_function_map fm ON fm.company_id=je.company_id AND fm.account_id=jl.account_id
            WHERE je.company_id=? AND " . posted_status_condition('je') . "
              AND je.entry_date BETWEEN ? AND ?
              AND (a.code LIKE '31%' OR a.code LIKE '32%' OR a.code LIKE '33%' OR a.code LIKE '34%' OR a.code LIKE '37%' OR a.code LIKE '3842%')
              AND COALESCE(NULLIF(cc.functional_report_code,'none'),fm.function_code) IS NULL";
    $stmt = db()->prepare($sql);
    $stmt->execute([company_id(), $from, $to]);
    return round((float)$stmt->fetchColumn(), 3);
}

function gr_income_statement_rows(array $ctx, string $mode = 'functional'): array
{
    if (!in_array($mode, ['functional', 'natural', 'summary'], true)) {
        throw new InvalidArgumentException('Income statement mode is invalid.');
    }
    $m = static fn(array|string|int $c, string $o = 'debit', array|string|int $x = []): array => gr_movement_triplet($ctx, $c, $o, $x);
    $rows = [];

    $revenue = $m(['41', '42', '43', '44', '45', '46'], 'credit');
    $rows[] = gr_row('إيرادات النشاط الجاري', '46 - 41', $revenue);
    $rows[] = gr_row('تنزل: كلفة البضاعة المباعة', '', null, 'section');

    $openingWip = gr_period_opening_triplet($ctx, '13162');
    $closingWip = gr_period_closing_triplet($ctx, '13162');
    $byproductRevenue = $m('417', 'credit');
    $openingFinished = gr_period_opening_triplet($ctx, '13161');
    $closingFinished = gr_period_closing_triplet($ctx, '13161');
    $openingGoods = gr_period_opening_triplet($ctx, '1317');
    $closingGoods = gr_period_closing_triplet($ctx, '1317');
    $purchases = $m('35');

    if ($mode === 'functional') {
        $cost5 = gr_functional_expense_triplet('5', $ctx);
        $cost6 = gr_functional_expense_triplet('6', $ctx);
        $marketing = gr_functional_expense_triplet('7', $ctx);
        $adminFinance = gr_functional_expense_triplet('8', $ctx);
        $rows[] = gr_row('كلفة الإنتاج', '5', $cost5);
        $rows[] = gr_row('كلفة الإنتاج', '6', $cost6);
        $rows[] = gr_row('مخزون إنتاج غير تام أول المدة', '', $openingWip);
        $rows[] = gr_row('ينزل: إيراد بيع المخلفات والمنتجات العرضية', '417', $byproductRevenue, 'deduction');
        $rows[] = gr_row('ينزل: مخزون إنتاج غير تام آخر المدة', '', $closingWip, 'deduction');
        $netProduction = gr_vec_sub(gr_vec_add($cost5, $cost6, $openingWip), $byproductRevenue, $closingWip);
        $rows[] = gr_row('صافي كلفة الإنتاج خلال الفترة', '', $netProduction, 'subtotal');
        $rows[] = gr_row('مخزون إنتاج تام أول المدة', '', $openingFinished);
        $productionAvailable = gr_vec_add($netProduction, $openingFinished);
        $rows[] = gr_row('كلفة الإنتاج المعد للبيع', '', $productionAvailable, 'subtotal');
        $rows[] = gr_row('مشتريات بضائع وأراضٍ بغرض البيع خلال الفترة', '35', $purchases);
        $rows[] = gr_row('مخزون بضائع وأراضٍ بغرض البيع أول المدة', '', $openingGoods);
        $goodsAvailable = gr_vec_add($purchases, $openingGoods);
        $rows[] = gr_row('كلفة البضاعة المعدة للبيع', '', $goodsAvailable, 'subtotal');
        $allAvailable = gr_vec_add($productionAvailable, $goodsAvailable);
        $rows[] = gr_row('كلفة الإنتاج والبضائع والأراضي المعدة للبيع', '', $allAvailable, 'subtotal');
        $rows[] = gr_row('ينزل: مخزون إنتاج تام آخر المدة', '', $closingFinished, 'deduction');
        $rows[] = gr_row('ينزل: مخزون بضائع وأراضٍ بغرض البيع آخر المدة', '', $closingGoods, 'deduction');
        $productionAndGoodsSold = gr_vec_sub($allAvailable, $closingFinished, $closingGoods);
        $rows[] = gr_row('كلفة الإنتاج والبضاعة المباعة', '', $productionAndGoodsSold, 'subtotal');
        $rows[] = gr_row('يضاف: كلفة الخدمات التسويقية', '7', $marketing);
        $currentActivityCost = gr_vec_add($productionAndGoodsSold, $marketing);
        $rows[] = gr_row('كلفة النشاط الجاري', '', $currentActivityCost, 'subtotal');
        $productionTradingSurplus = gr_vec_sub($revenue, $currentActivityCost);
        $rows[] = gr_row('فائض (عجز) الإنتاج والمتاجرة', '', $productionTradingSurplus, 'subtotal');
        $rows[] = gr_row('ينزل: كلفة الخدمات الإدارية والتمويلية', '8', $adminFinance, 'deduction');
        $operatingSurplus = gr_vec_sub($productionTradingSurplus, $adminFinance);
        $rows[] = gr_row('فائض (عجز) النشاط التشغيلي', '', $operatingSurplus, 'subtotal');
        $transferRevenue = $m(['48', '49'], 'credit');
        $transferExpense = $m(['38', '39'], 'debit', ['3841', '3842']);
    } elseif ($mode === 'natural') {
        $naturalParts = [];
        foreach ([
            '31' => 'الرواتب والأجور',
            '32' => 'المستلزمات السلعية',
            '33' => 'المستلزمات الخدمية',
            '34' => 'مقاولات وخدمات',
            '37' => 'الاندثارات',
            '3842' => 'رسوم الإنتاج',
        ] as $code => $label) {
            $amount = $m($code);
            $naturalParts[] = $amount;
            $rows[] = gr_row($label, $code, $amount);
        }
        $naturalCost = gr_vec_add(...$naturalParts);
        $rows[] = gr_row('مخزون إنتاج غير تام أول المدة', '', $openingWip);
        $rows[] = gr_row('ينزل: إيراد بيع المخلفات والمنتجات العرضية', '417', $byproductRevenue, 'deduction');
        $rows[] = gr_row('ينزل: مخزون إنتاج غير تام آخر المدة', '', $closingWip, 'deduction');
        $netProduction = gr_vec_sub(gr_vec_add($naturalCost, $openingWip), $byproductRevenue, $closingWip);
        $rows[] = gr_row('صافي كلفة الإنتاج خلال الفترة', '', $netProduction, 'subtotal');
        $rows[] = gr_row('مخزون إنتاج تام أول المدة', '', $openingFinished);
        $productionAvailable = gr_vec_add($netProduction, $openingFinished);
        $rows[] = gr_row('كلفة الإنتاج المعد للبيع', '', $productionAvailable, 'subtotal');
        $rows[] = gr_row('مشتريات بضائع وأراضٍ بغرض البيع خلال الفترة', '35', $purchases);
        $rows[] = gr_row('مخزون بضائع وأراضٍ بغرض البيع أول المدة', '', $openingGoods);
        $goodsAvailable = gr_vec_add($purchases, $openingGoods);
        $rows[] = gr_row('كلفة البضاعة المعدة للبيع', '', $goodsAvailable, 'subtotal');
        $allAvailable = gr_vec_add($productionAvailable, $goodsAvailable);
        $rows[] = gr_row('كلفة الإنتاج والبضائع والأراضي المعدة للبيع', '', $allAvailable, 'subtotal');
        $rows[] = gr_row('ينزل: مخزون إنتاج تام آخر المدة', '', $closingFinished, 'deduction');
        $rows[] = gr_row('ينزل: مخزون بضائع وأراضٍ بغرض البيع آخر المدة', '', $closingGoods, 'deduction');
        $cogs = gr_vec_sub($allAvailable, $closingFinished, $closingGoods);
        $rows[] = gr_row('كلفة البضاعة المباعة', '36', $cogs, 'subtotal');
        $operatingSurplus = gr_vec_sub($revenue, $cogs);
        $rows[] = gr_row('مجمل الفائض (العجز) للإنتاج والمتاجرة للنشاط التشغيلي', '', $operatingSurplus, 'subtotal');
        $transferRevenue = $m('48', 'credit');
        $transferExpense = $m('38', 'debit', ['3841', '3842']);
    } else {
        $cogs = $m('36');
        $rows[] = gr_row('كلفة البضاعة المباعة', '36', $cogs, 'deduction');
        $operatingSurplus = gr_vec_sub($revenue, $cogs);
        $rows[] = gr_row('مجمل الفائض (العجز) للإنتاج والمتاجرة للنشاط التشغيلي', '', $operatingSurplus, 'subtotal');
        $transferRevenue = $m('48', 'credit');
        $transferExpense = $m('38', 'debit', ['3841']);
    }

    $rows[] = gr_row($mode === 'functional' ? 'تضاف: الإيرادات التحويلية والأخرى' : 'تضاف: الإيرادات التحويلية والأخرى', $mode === 'functional' ? '48 و49' : '48', $transferRevenue);
    $rows[] = gr_row('تنزل: المصروفات التحويلية والأخرى', $mode === 'functional' ? '38 و39' : '38', $transferExpense, 'deduction');
    $preTax = gr_vec_sub(gr_vec_add($operatingSurplus, $transferRevenue), $transferExpense);
    $rows[] = gr_row('الربح أو (الخسارة) قبل الضريبة', '', $preTax, 'subtotal');
    $tax = $m('3841');
    $rows[] = gr_row('مصروف ضريبة الدخل', '3841', $tax, 'deduction');
    $afterTax = gr_vec_sub($preTax, $tax);
    $rows[] = gr_row('الربح أو (الخسارة) بعد الضريبة', '', $afterTax, 'grand');

    $rows[] = gr_row('الدخل الشامل الآخر', '264', null, 'section');
    $ociParts = [];
    foreach ([
        '2641' => 'فائض إعادة تقييم الأصول',
        '2642' => 'حصة المنشأة في الدخل الشامل الآخر للمنشآت الزميلة',
        '2643' => 'مكاسب وخسائر من خلال الدخل الشامل الآخر',
        '2644' => 'مكاسب وخسائر أسعار الصرف للعمليات الأجنبية',
        '2645' => 'مكاسب وخسائر تدوير الوفر الضريبي',
    ] as $code => $label) {
        $amount = $m($code, 'credit');
        $ociParts[] = $amount;
        $rows[] = gr_row($label, $code, $amount);
    }
    $ociTotal = gr_vec_add(...$ociParts);
    $rows[] = gr_row('مجموع الدخل الشامل الآخر', '', $ociTotal, 'subtotal');
    $comprehensive = gr_vec_add($afterTax, $ociTotal);
    $rows[] = gr_row('إجمالي الدخل الشامل', '', $comprehensive, 'grand');

    $profitNci = gr_period_value_triplet($ctx, 'profit_nci');
    $profitParent = gr_vec_sub($afterTax, $profitNci);
    $comprehensiveNci = gr_period_value_triplet($ctx, 'comprehensive_nci');
    $comprehensiveParent = gr_vec_sub($comprehensive, $comprehensiveNci);
    $rows[] = gr_row('ربح الفترة موزع إلى:', '', null, 'section');
    $rows[] = gr_row('- حصة أسهم الشركة الأم', '', $profitParent);
    $rows[] = gr_row('- حصة الحقوق غير المسيطر عليها', '', $profitNci);
    $rows[] = gr_row('الدخل الشامل موزع إلى:', '', null, 'section');
    $rows[] = gr_row('- حصة أسهم الشركة الأم', '', $comprehensiveParent);
    $rows[] = gr_row('- حصة الحقوق غير المسيطر عليها', '', $comprehensiveNci);

    return [
        'rows' => $rows,
        'after_tax' => $afterTax,
        'oci_total' => $ociTotal,
        'comprehensive' => $comprehensive,
        'unclassified_functional' => $mode === 'functional' ? gr_unclassified_functional_expense($ctx['from'], $ctx['to']) : 0.0,
    ];
}

function gr_equity_column_for_account(string $accountCode): ?string
{
    if (str_starts_with($accountCode, '2615')) return '2615';
    if (str_starts_with($accountCode, '261')) return '261';
    if (str_starts_with($accountCode, '262')) return '262';
    if (str_starts_with($accountCode, '2633') || str_starts_with($accountCode, '265')) return '265';
    if (str_starts_with($accountCode, '263')) return '263';
    if (str_starts_with($accountCode, '264')) return '264';
    return null;
}

function gr_equity_summary_period(string $from, string $to): array
{
    $columns = [
        '261' => 'رأس المال (عدا حـ/2615)',
        '262' => 'رأس المال الإضافي',
        '263' => 'الأرباح المحتجزة',
        '264' => 'الدخل الشامل الآخر',
        '265' => 'التغير في السياسات المحاسبية والتقديرات وتصحيح الأخطاء',
        '2615' => 'الحصص خارج السيطرة',
    ];
    $openingDate = (new DateTimeImmutable($from))->modify('-1 day')->format('Y-m-d');
    $opening = [
        '261' => guide_amount('261', $openingDate, null, 'credit', ['2615']),
        '262' => guide_amount('262', $openingDate, null, 'credit'),
        '263' => guide_amount('263', $openingDate, null, 'credit', ['2633']),
        '264' => guide_amount('264', $openingDate, null, 'credit'),
        '265' => guide_amount(gr_source_prefix(['265', '2633']), $openingDate, null, 'credit'),
        '2615' => guide_amount('2615', $openingDate, null, 'credit'),
    ];
    $closing = [
        '261' => guide_amount('261', $to, null, 'credit', ['2615']),
        '262' => guide_amount('262', $to, null, 'credit'),
        '263' => guide_amount('263', $to, null, 'credit', ['2633']),
        '264' => guide_amount('264', $to, null, 'credit'),
        '265' => guide_amount(gr_source_prefix(['265', '2633']), $to, null, 'credit'),
        '2615' => guide_amount('2615', $to, null, 'credit'),
    ];
    $rows = [
        'revaluation' => 'فائض إعادة التقييم',
        'profit' => 'ربح الفترة',
        'dividend' => 'توزيعات أرباح',
        'reserve' => 'احتياطي قانوني',
        'capital' => 'إصدار أسهم',
        'accumulated_loss_amortization' => 'ينزل: إطفاء خسائر متراكمة',
        'policy_change' => 'صافي التغير بالسياسات المحاسبية والتقديرات وتصحيح الأخطاء',
        'nci' => 'صافي الزيادة في حقوق الأقلية',
    ];
    $movements = [];
    foreach ($rows as $key => $_label) {
        $movements[$key] = array_fill_keys(array_keys($columns), 0.0);
    }
    $other = array_fill_keys(array_keys($columns), 0.0);
    $sql = "SELECT je.equity_movement_type,a.code,SUM(jl.credit-jl.debit) amount
            FROM journal_entries je
            JOIN journal_lines jl ON jl.journal_entry_id=je.id
            JOIN accounts a ON a.id=jl.account_id
            WHERE je.company_id=? AND " . posted_status_condition('je') . "
              AND je.entry_date BETWEEN ? AND ?
              AND (a.code LIKE '26%' OR a.code LIKE '2633%')
            GROUP BY je.equity_movement_type,a.code";
    $stmt = db()->prepare($sql);
    $stmt->execute([company_id(), $from, $to]);
    foreach ($stmt->fetchAll() as $result) {
        $column = gr_equity_column_for_account((string)$result['code']);
        if ($column === null) continue;
        $type = (string)$result['equity_movement_type'];
        if ($type === 'oci') $type = 'revaluation';
        if (!isset($movements[$type])) {
            $other[$column] += (float)$result['amount'];
        } else {
            $movements[$type][$column] += (float)$result['amount'];
        }
    }
    foreach ($movements as &$row) {
        foreach ($row as &$value) $value = round((float)$value, 3);
    }
    unset($row, $value);
    return compact('columns', 'opening', 'closing', 'rows', 'movements', 'other', 'from', 'to');
}

function gr_equity_summary_comparative(string $from, string $to): array
{
    $days = (new DateTimeImmutable($from))->diff(new DateTimeImmutable($to))->days + 1;
    $priorTo = (new DateTimeImmutable($from))->modify('-1 day');
    $priorFrom = $priorTo->modify('-' . ($days - 1) . ' days');
    return [
        'current' => gr_equity_summary_period($from, $to),
        'prior' => gr_equity_summary_period($priorFrom->format('Y-m-d'), $priorTo->format('Y-m-d')),
    ];
}

function gr_equity_detail_rows(): array
{
    return [
        ['261', '261', 'رأس المال (عدا حـ/2615)', ['2615']],
        ['2611', '2611', 'رأس المال المدفوع', []],
        ['2612', '2612', 'رأس المال المتبرع به', []],
        ['2613', '2613', 'رأس المال صافي موجودات', []],
        ['2614', '2614', 'رأس المال الاجتماعي', []],
        ['2615', '2615', 'الحصص خارج السيطرة *', []],
        ['262', '262', 'رأس المال الإضافي', []],
        ['2621', '2621', 'علاوة إصدار الأسهم والسندات', []],
        ['2622', '2622', 'احتياطيات رأسمالية', []],
        ['26221', '26221', 'احتياطي التوسعات', []],
        ['26222', '26222', 'احتياطي عام', []],
        ['26223', '26223', 'احتياطي استبدال الأصول غير المتداولة', []],
        ['2625', '2625', 'احتياطي قانوني', []],
        ['2627', '2627', 'احتياطيات متنوعة', []],
        ['263', '263', 'الأرباح المحتجزة', ['2633']],
        ['2631', '2631', 'الفائض المتراكم', []],
        ['2632', '2632', 'العجز المتراكم', []],
        ['2633', '2633', 'التغير بالسياسات المحاسبية والتقديرات وتصحيح الأخطاء', []],
        ['264', '264', 'الدخل الشامل الآخر', []],
        ['2641', '2641', 'فائض إعادة تقييم الأصول', []],
        ['2642', '2642', 'حصة المنشأة في الدخل الشامل الآخر للمنشآت الزميلة', []],
        ['2643', '2643', 'مكاسب وخسائر من خلال الدخل الشامل الآخر', []],
        ['2644', '2644', 'مكاسب وخسائر أسعار الصرف للعمليات الأجنبية', []],
        ['265', '2645', 'مكاسب وخسائر تدوير الوفر الضريبي', []],
    ];
}

function gr_equity_detail_period(string $from, string $to): array
{
    $openingDate = (new DateTimeImmutable($from))->modify('-1 day')->format('Y-m-d');
    $movementTypes = [
        'oci' => 'التغير في الدخل الشامل الآخر',
        'profit' => 'ربح (خسارة) الفترة',
        'dividend' => 'توزيعات أرباح',
        'reserve' => 'التغير في الاحتياطي',
        'capital' => 'التغير في رأس المال',
        'accumulated_loss_amortization' => 'ينزل: إطفاء خسائر متراكمة',
        'policy_change' => 'صافي التغير بالسياسات المحاسبية',
        'nci' => 'صافي الزيادة في حقوق الأقلية',
    ];
    $rows = [];
    foreach (gr_equity_detail_rows() as [$displayCode, $sourceCode, $label, $exclude]) {
        $opening = guide_amount($sourceCode, $openingDate, null, 'credit', $exclude);
        $closing = guide_amount($sourceCode, $to, null, 'credit', $exclude);
        $movements = array_fill_keys(array_keys($movementTypes), 0.0);
        $sql = "SELECT je.equity_movement_type,COALESCE(SUM(jl.credit-jl.debit),0) amount
                FROM journal_entries je
                JOIN journal_lines jl ON jl.journal_entry_id=je.id
                JOIN accounts a ON a.id=jl.account_id
                WHERE je.company_id=? AND " . posted_status_condition('je') . "
                  AND je.entry_date BETWEEN ? AND ?
                  AND (a.code=? OR a.code LIKE ?)";
        $params = [company_id(), $from, $to, $sourceCode, $sourceCode . '%'];
        foreach ($exclude as $ex) {
            $sql .= " AND NOT (a.code=? OR a.code LIKE ?)";
            $params[] = $ex;
            $params[] = $ex . '%';
        }
        $sql .= ' GROUP BY je.equity_movement_type';
        $stmt = db()->prepare($sql);
        $stmt->execute($params);
        $other = 0.0;
        foreach ($stmt->fetchAll() as $result) {
            $type = (string)$result['equity_movement_type'];
            if (isset($movements[$type])) {
                $movements[$type] += (float)$result['amount'];
            } else {
                $other += (float)$result['amount'];
            }
        }
        foreach ($movements as &$value) $value = round((float)$value, 3);
        unset($value);
        $rows[] = compact('displayCode', 'sourceCode', 'label', 'opening', 'closing', 'movements', 'other');
    }
    return compact('from', 'to', 'openingDate', 'movementTypes', 'rows');
}

function gr_cash_flow_definitions(): array
{
    return [
        'OP_RECEIPTS_REVENUE' => ['operating', 'in', '45-41', 'إيرادات النشاط الجاري (عدا حـ/435، 439)'],
        'OP_RECEIPTS_TRANSFER' => ['operating', 'in', '48', 'إيرادات تحويلية (عدا حـ/481، 483)'],
        'OP_RECEIPTS_DEBTORS' => ['operating', 'in', '132', 'المدينون'],
        'OP_PAYMENTS_USES' => ['operating', 'out', '35-31', 'الاستخدامات'],
        'OP_PAYMENTS_TRANSFER' => ['operating', 'out', '38', 'المصروفات التحويلية (عدا حـ/381، 383، 384)'],
        'OP_INVENTORY_CHANGE' => ['operating', 'out', '131', 'المخزون (رصيد آخر الفترة - رصيد أول الفترة)'],
        'OP_TAXES' => ['operating', 'out', '384', 'الضرائب والرسوم'],
        'OP_CREDITORS' => ['operating', 'out', '232', 'الدائنون (عدا حـ/2325، 2328)'],
        'INV_RECEIPT_PPE' => ['investing', 'in', '111', 'بيع الممتلكات والآلات والمعدات (القيمة البيعية المستلمة)'],
        'INV_RECEIPT_PROPERTY' => ['investing', 'in', '112', 'بيع العقارات الاستثمارية'],
        'INV_RECEIPT_BIO' => ['investing', 'in', '114', 'بيع الأصول الحية'],
        'INV_RECEIPT_LOANS' => ['investing', 'in', '1151', 'استرداد القروض الممنوحة والسلف المقدمة'],
        'INV_RECEIPT_INVEST' => ['investing', 'in', '1152', 'القيمة النقدية لبيع الاستثمارات'],
        'INV_RECEIPT_PROFIT' => ['investing', 'in', '435', 'أرباح الاستثمارات المالية المصنفة بالقيمة العادلة من خلال الأرباح والخسائر'],
        'INV_RECEIPT_CAP_GAIN' => ['investing', 'in', '491', 'المكاسب الرأسمالية'],
        'INV_RECEIPT_CAPEX' => ['investing', 'in', '12', 'بيع الإنفاق الرأسمالي'],
        'INV_RECEIPT_NONCURRENT_DEBTOR' => ['investing', 'in', '1325', 'مدينو النشاط غير الجاري'],
        'INV_PAYMENT_CAPEX' => ['investing', 'out', '12', 'الإنفاق الرأسمالي'],
        'INV_PAYMENT_NONCURRENT_CREDITOR' => ['investing', 'out', '2325', 'دائنو النشاط غير الجاري'],
        'INV_PAYMENT_LOANS' => ['investing', 'out', '1351', 'قروض ممنوحة قصيرة الأجل'],
        'INV_PAYMENT_INVEST' => ['investing', 'out', '1352', 'الاستثمارات في الأسهم والسندات والأوراق التجارية'],
        'INV_PAYMENT_CAP_LOSS' => ['investing', 'out', '391', 'الخسائر الرأسمالية'],
        'FIN_RECEIPT_GRANTS' => ['financing', 'in', '481', 'منح تمويلية'],
        'FIN_RECEIPT_SHARES' => ['financing', 'in', '2611', 'المتحصلات النقدية من إصدار أسهم وأدوات حقوق الملكية'],
        'FIN_RECEIPT_LOANS' => ['financing', 'in', '2351', 'قروض مستلمة'],
        'FIN_PAYMENT_RESERVES' => ['financing', 'out', '381', 'التدفقات النقدية عن المبالغ المحتجزة في حساب الاحتياطيات والمساهمة في نفقات الوحدات الاقتصادية الرئيسية أو التابعة'],
        'FIN_PAYMENT_SHARES' => ['financing', 'out', '2611', 'المدفوعات النقدية من استرداد الأسهم وأدوات حقوق الملكية'],
        'FIN_PAYMENT_LOANS' => ['financing', 'out', '2351', 'تسديد القروض المستلمة'],
        'FIN_PAYMENT_DIVIDENDS' => ['financing', 'out', '2328', 'الأرباح الموزعة'],
        'FX_EFFECT' => ['fx', 'net', '4395', 'أثر التغيرات في سعر الصرف على النقد ومعادلاته'],
        'UNCLASSIFIED' => ['unclassified', 'net', '', 'حركات نقدية غير مصنفة'],
    ];
}

function gr_auto_cash_flow_code(string $accountCode, float $cashEffect): string
{
    $inflow = $cashEffect > 0;
    $starts = static fn(string $prefix): bool => str_starts_with($accountCode, $prefix);
    if ($inflow) {
        if (($starts('41') || $starts('42') || $starts('43') || $starts('44') || $starts('45')) && !$starts('435') && !$starts('439')) return 'OP_RECEIPTS_REVENUE';
        if ($starts('48') && !$starts('481') && !$starts('483')) return 'OP_RECEIPTS_TRANSFER';
        if ($starts('132') && !$starts('1325')) return 'OP_RECEIPTS_DEBTORS';
        if ($starts('111')) return 'INV_RECEIPT_PPE';
        if ($starts('112')) return 'INV_RECEIPT_PROPERTY';
        if ($starts('114')) return 'INV_RECEIPT_BIO';
        if ($starts('1151')) return 'INV_RECEIPT_LOANS';
        if ($starts('1152')) return 'INV_RECEIPT_INVEST';
        if ($starts('435')) return 'INV_RECEIPT_PROFIT';
        if ($starts('491')) return 'INV_RECEIPT_CAP_GAIN';
        if ($starts('12')) return 'INV_RECEIPT_CAPEX';
        if ($starts('1325')) return 'INV_RECEIPT_NONCURRENT_DEBTOR';
        if ($starts('481') || $starts('482')) return 'FIN_RECEIPT_GRANTS';
        if ($starts('2611')) return 'FIN_RECEIPT_SHARES';
        if ($starts('2351')) return 'FIN_RECEIPT_LOANS';
    } else {
        if ($starts('31') || $starts('32') || $starts('33') || $starts('34') || $starts('35')) return 'OP_PAYMENTS_USES';
        if ($starts('38') && !$starts('381') && !$starts('383') && !$starts('384')) return 'OP_PAYMENTS_TRANSFER';
        if ($starts('384')) return 'OP_TAXES';
        if ($starts('232') && !$starts('2325') && !$starts('2328')) return 'OP_CREDITORS';
        if ($starts('12')) return 'INV_PAYMENT_CAPEX';
        if ($starts('2325')) return 'INV_PAYMENT_NONCURRENT_CREDITOR';
        if ($starts('1351')) return 'INV_PAYMENT_LOANS';
        if ($starts('1352')) return 'INV_PAYMENT_INVEST';
        if ($starts('391')) return 'INV_PAYMENT_CAP_LOSS';
        if ($starts('381')) return 'FIN_PAYMENT_RESERVES';
        if ($starts('2611')) return 'FIN_PAYMENT_SHARES';
        if ($starts('2351')) return 'FIN_PAYMENT_LOANS';
        if ($starts('2328')) return 'FIN_PAYMENT_DIVIDENDS';
    }
    if ($starts('4395')) return 'FX_EFFECT';
    return 'UNCLASSIFIED';
}

/**
 * Exact cash-flow allocation. Compound entries are never split by a guessed
 * percentage. They require explicit allocated amounts in the cash-flow
 * register; otherwise the full cash effect is marked unclassified.
 */
function gr_direct_cash_flow(string $from, string $to): array
{
    if (!valid_date($from) || !valid_date($to) || $from > $to) {
        throw new RuntimeException('نطاق التدفق النقدي غير صالح.');
    }
    $defs = gr_cash_flow_definitions();
    $totals = array_fill_keys(array_keys($defs), 0.0);
    $unclassified = [];
    $sql = "SELECT je.id entry_id,je.voucher_no,je.entry_date,jl.id line_id,jl.debit,jl.credit,jl.cash_flow_line_code,
                   a.code,a.name_ar,a.is_cash_account,o.line_code override_code,o.allocated_amount
            FROM journal_entries je
            JOIN journal_lines jl ON jl.journal_entry_id=je.id
            JOIN accounts a ON a.id=jl.account_id
            LEFT JOIN cash_flow_overrides o ON o.company_id=je.company_id AND o.journal_line_id=jl.id
            WHERE je.company_id=? AND " . posted_status_condition('je') . "
              AND je.entry_date BETWEEN ? AND ?
            ORDER BY je.id,jl.id";
    $stmt = db()->prepare($sql);
    $stmt->execute([company_id(), $from, $to]);
    $entries = [];
    foreach ($stmt->fetchAll() as $row) {
        $entries[(int)$row['entry_id']][] = $row;
    }
    foreach ($entries as $entryId => $lines) {
        $cashEffect = 0.0;
        $counterLines = [];
        foreach ($lines as $line) {
            $raw = (float)$line['debit'] - (float)$line['credit'];
            if ((int)$line['is_cash_account'] === 1) {
                $cashEffect += $raw;
            } else {
                $counterLines[] = $line;
            }
        }
        if (abs($cashEffect) < 0.0005) continue;
        if (count($counterLines) === 1) {
            $line = $counterLines[0];
            $code = $line['override_code'] ?: ($line['cash_flow_line_code'] ?: gr_auto_cash_flow_code((string)$line['code'], $cashEffect));
            $totals[$code] = ($totals[$code] ?? 0) + $cashEffect;
            if ($code === 'UNCLASSIFIED') {
                $unclassified[] = $line + ['cash_effect' => $cashEffect, 'reason' => 'لم يحدد بند التدفق النقدي.'];
            }
            continue;
        }
        $explicit = [];
        $explicitTotal = 0.0;
        foreach ($counterLines as $line) {
            if ($line['allocated_amount'] !== null && (float)$line['allocated_amount'] > 0) {
                $amount = abs((float)$line['allocated_amount']);
                $explicit[] = [$line, $amount];
                $explicitTotal += $amount;
            }
        }
        if (count($explicit) !== count($counterLines) || abs($explicitTotal - abs($cashEffect)) > 0.001) {
            $totals['UNCLASSIFIED'] += $cashEffect;
            foreach ($counterLines as $counterLine) {
                $unclassified[] = $counterLine + [
                    'cash_effect' => $cashEffect,
                    'suggested_amount' => abs((float)$counterLine['debit'] - (float)$counterLine['credit']),
                    'reason' => 'قيد نقدي مركب: يجب توزيع كامل الأثر النقدي يدوياً على جميع الحسابات المقابلة.',
                    'entry_total' => abs($cashEffect),
                    'allocated_total' => $explicitTotal,
                ];
            }
            continue;
        }
        $sign = $cashEffect >= 0 ? 1.0 : -1.0;
        foreach ($explicit as [$line, $absoluteAmount]) {
            $share = $sign * $absoluteAmount;
            $code = $line['override_code'] ?: ($line['cash_flow_line_code'] ?: gr_auto_cash_flow_code((string)$line['code'], $share));
            $totals[$code] = ($totals[$code] ?? 0) + $share;
            if ($code === 'UNCLASSIFIED') {
                $unclassified[] = $line + ['cash_effect' => $share, 'reason' => 'لم يحدد بند التدفق النقدي.'];
            }
        }
    }

    $openingDate = (new DateTimeImmutable($from))->modify('-1 day')->format('Y-m-d');
    $inventoryChange = guide_amount('131', $to) - guide_amount('131', $openingDate);
    $totals['OP_INVENTORY_CHANGE'] = round(-$inventoryChange, 3);
    foreach ($totals as $code => $amount) {
        $totals[$code] = round((float)$amount, 3);
    }
    $opening = guide_amount('134', $openingDate);
    $closing = guide_amount('134', $to);
    $operating = $investing = $financing = 0.0;
    foreach ($defs as $code => $definition) {
        if ($definition[0] === 'operating') $operating += $totals[$code];
        elseif ($definition[0] === 'investing') $investing += $totals[$code];
        elseif ($definition[0] === 'financing') $financing += $totals[$code];
    }
    $operating = round($operating, 3);
    $investing = round($investing, 3);
    $financing = round($financing, 3);
    $net = round($operating + $investing + $financing, 3);
    $fx = round((float)$totals['FX_EFFECT'], 3);
    $difference = round($opening + $net + $fx - $closing, 3);
    return compact('defs', 'totals', 'opening', 'closing', 'operating', 'investing', 'financing', 'net', 'fx', 'difference', 'unclassified', 'from', 'to');
}

function gr_cash_flow_direct_rows(array $cf): array
{
    $rows = [];
    $defs = $cf['defs'];
    $totals = $cf['totals'];
    $rows[] = ['kind' => 'section', 'code' => '', 'label' => 'التدفقات النقدية من النشاطات التشغيلية:', 'amounts' => [null, null, null]];
    $rows[] = ['kind' => 'subsection', 'code' => '', 'label' => 'النقد المستلم من:', 'amounts' => [null, null, null]];
    foreach (['OP_RECEIPTS_REVENUE', 'OP_RECEIPTS_TRANSFER', 'OP_RECEIPTS_DEBTORS'] as $code) {
        $d = $defs[$code];
        $rows[] = ['kind' => 'detail', 'code' => $d[2], 'label' => $d[3], 'amounts' => [abs((float)$totals[$code]), null, null]];
    }
    $receipts = abs((float)$totals['OP_RECEIPTS_REVENUE']) + abs((float)$totals['OP_RECEIPTS_TRANSFER']) + abs((float)$totals['OP_RECEIPTS_DEBTORS']);
    $rows[] = ['kind' => 'subtotal', 'code' => '', 'label' => 'مجموع المقبوضات التشغيلية', 'amounts' => [null, $receipts, null]];
    $rows[] = ['kind' => 'subsection', 'code' => '', 'label' => 'تنزل: المدفوعات النقدية عن:', 'amounts' => [null, null, null]];
    foreach (['OP_PAYMENTS_USES', 'OP_PAYMENTS_TRANSFER', 'OP_INVENTORY_CHANGE', 'OP_TAXES', 'OP_CREDITORS'] as $code) {
        $d = $defs[$code];
        $rows[] = ['kind' => 'detail', 'code' => $d[2], 'label' => $d[3], 'amounts' => [abs((float)$totals[$code]), null, null]];
    }
    $payments = abs((float)$totals['OP_PAYMENTS_USES']) + abs((float)$totals['OP_PAYMENTS_TRANSFER']) + abs((float)$totals['OP_INVENTORY_CHANGE']) + abs((float)$totals['OP_TAXES']) + abs((float)$totals['OP_CREDITORS']);
    $rows[] = ['kind' => 'subtotal', 'code' => '', 'label' => 'مجموع المدفوعات التشغيلية', 'amounts' => [null, $payments, null]];
    $rows[] = ['kind' => 'total', 'code' => '', 'label' => 'صافي التدفق النقدي عن الأنشطة التشغيلية', 'amounts' => [null, null, $cf['operating']]];

    $rows[] = ['kind' => 'section', 'code' => '', 'label' => 'التدفق النقدي عن الأنشطة الاستثمارية:', 'amounts' => [null, null, null]];
    $rows[] = ['kind' => 'subsection', 'code' => '', 'label' => 'النقد المستلم من:', 'amounts' => [null, null, null]];
    $investReceiptsCodes = ['INV_RECEIPT_PPE', 'INV_RECEIPT_PROPERTY', 'INV_RECEIPT_BIO', 'INV_RECEIPT_LOANS', 'INV_RECEIPT_INVEST', 'INV_RECEIPT_PROFIT', 'INV_RECEIPT_CAP_GAIN', 'INV_RECEIPT_CAPEX', 'INV_RECEIPT_NONCURRENT_DEBTOR'];
    foreach ($investReceiptsCodes as $code) {
        $d = $defs[$code];
        $rows[] = ['kind' => 'detail', 'code' => $d[2], 'label' => $d[3], 'amounts' => [abs((float)$totals[$code]), null, null]];
    }
    $investReceipts = array_sum(array_map(static fn(string $code): float => abs((float)$totals[$code]), $investReceiptsCodes));
    $rows[] = ['kind' => 'subtotal', 'code' => '', 'label' => 'مجموع المقبوضات الاستثمارية', 'amounts' => [null, $investReceipts, null]];
    $rows[] = ['kind' => 'subsection', 'code' => '', 'label' => 'تنزل: المدفوعات النقدية عن:', 'amounts' => [null, null, null]];
    $investPaymentCodes = ['INV_PAYMENT_CAPEX', 'INV_PAYMENT_NONCURRENT_CREDITOR', 'INV_PAYMENT_LOANS', 'INV_PAYMENT_INVEST', 'INV_PAYMENT_CAP_LOSS'];
    foreach ($investPaymentCodes as $code) {
        $d = $defs[$code];
        $rows[] = ['kind' => 'detail', 'code' => $d[2], 'label' => $d[3], 'amounts' => [abs((float)$totals[$code]), null, null]];
    }
    $investPayments = array_sum(array_map(static fn(string $code): float => abs((float)$totals[$code]), $investPaymentCodes));
    $rows[] = ['kind' => 'subtotal', 'code' => '', 'label' => 'مجموع المدفوعات الاستثمارية', 'amounts' => [null, $investPayments, null]];
    $rows[] = ['kind' => 'total', 'code' => '', 'label' => 'صافي التدفق النقدي عن الأنشطة الاستثمارية', 'amounts' => [null, null, $cf['investing']]];

    $rows[] = ['kind' => 'section', 'code' => '', 'label' => 'التدفق النقدي عن الأنشطة التمويلية:', 'amounts' => [null, null, null]];
    $rows[] = ['kind' => 'subsection', 'code' => '', 'label' => 'النقد المستلم من:', 'amounts' => [null, null, null]];
    $finReceiptCodes = ['FIN_RECEIPT_GRANTS', 'FIN_RECEIPT_SHARES', 'FIN_RECEIPT_LOANS'];
    foreach ($finReceiptCodes as $code) {
        $d = $defs[$code];
        $rows[] = ['kind' => 'detail', 'code' => $d[2], 'label' => $d[3], 'amounts' => [abs((float)$totals[$code]), null, null]];
    }
    $finReceipts = array_sum(array_map(static fn(string $code): float => abs((float)$totals[$code]), $finReceiptCodes));
    $rows[] = ['kind' => 'subtotal', 'code' => '', 'label' => 'مجموع المقبوضات التمويلية', 'amounts' => [null, $finReceipts, null]];
    $rows[] = ['kind' => 'subsection', 'code' => '', 'label' => 'تنزل: المدفوعات النقدية عن:', 'amounts' => [null, null, null]];
    $finPaymentCodes = ['FIN_PAYMENT_RESERVES', 'FIN_PAYMENT_SHARES', 'FIN_PAYMENT_LOANS', 'FIN_PAYMENT_DIVIDENDS'];
    foreach ($finPaymentCodes as $code) {
        $d = $defs[$code];
        $rows[] = ['kind' => 'detail', 'code' => $d[2], 'label' => $d[3], 'amounts' => [abs((float)$totals[$code]), null, null]];
    }
    $finPayments = array_sum(array_map(static fn(string $code): float => abs((float)$totals[$code]), $finPaymentCodes));
    $rows[] = ['kind' => 'subtotal', 'code' => '', 'label' => 'مجموع المدفوعات التمويلية', 'amounts' => [null, $finPayments, null]];
    $rows[] = ['kind' => 'total', 'code' => '', 'label' => 'صافي التدفق النقدي عن الأنشطة التمويلية', 'amounts' => [null, null, $cf['financing']]];
    $rows[] = ['kind' => 'grand', 'code' => '', 'label' => 'صافي التدفق النقدي عن الأنشطة الثلاث (التشغيلية، الاستثمارية، التمويلية)', 'amounts' => [null, null, $cf['net']]];
    $rows[] = ['kind' => 'detail', 'code' => '4395', 'label' => 'أثر التغيرات في سعر الصرف على النقد ومعادلاته', 'amounts' => [null, null, $cf['fx']]];
    $rows[] = ['kind' => 'detail', 'code' => '134', 'label' => 'يضاف: رصيد النقد ومعادلاته كما في بداية الفترة', 'amounts' => [null, null, $cf['opening']]];
    $rows[] = ['kind' => 'grand', 'code' => '134', 'label' => 'رصيد النقد ومعادلاته كما في نهاية الفترة', 'amounts' => [null, null, $cf['closing']]];
    return $rows;
}


function gr_cash_flow_indirect_rows(array $ind): array
{
    $c = $ind['current'];
    $p = $ind['prior'];
    $defs = $c['direct']['defs'];
    $rows = [];
    $add = static function(string $kind, string $code, string $label, array $current, array $prior) use (&$rows): void {
        $rows[] = compact('kind','code','label','current','prior');
    };
    $blank=[null,null,null];
    $one = static fn(float $v): array => [$v,null,null];
    $two = static fn(float $v): array => [null,$v,null];
    $three = static fn(float $v): array => [null,null,$v];

    $add('section','','التدفقات النقدية من النشاطات التشغيلية:',$blank,$blank);
    $add('subsection','','صافي الربح (الخسارة) يضاف (ينزل) التغيرات خلال الفترة على:',$blank,$blank);
    $operatingItems = [
        ['131','المخزون','changeInventory',-1.0],
        ['132','المدينون','changeDebtors',-1.0],
        ['232','الدائنون','changeCreditors',1.0],
        ['24','الالتزامات الأخرى','changeOtherLiabilities',1.0],
        ['25','التخصيصات','changeProvisions',1.0],
    ];
    $add('detail','','صافي الربح (الخسارة) بعد الضريبة',$one((float)$c['operating']['profit']),$one((float)$p['operating']['profit']));
    foreach($operatingItems as [$code,$label,$key,$factor]){
        $add('detail',$code,$label,$one(round((float)$c['operating'][$key]*$factor,3)),$one(round((float)$p['operating'][$key]*$factor,3)));
    }
    $add('detail','','ينزل/يضاف الإيرادات والمصروفات غير النقدية مثل الاندثارات والمخصصات والضرائب المؤجلة وغيرها',$one((float)$c['operating']['noncash']),$one((float)$p['operating']['noncash']));
    $add('total','','صافي التدفق النقدي عن الأنشطة التشغيلية',$three((float)$c['operating']['operating']),$three((float)$p['operating']['operating']));

    $add('section','','التدفق النقدي عن الأنشطة الاستثمارية:',$blank,$blank);
    $add('subsection','','النقد المستلم من:',$blank,$blank);
    $investReceipts=['INV_RECEIPT_PPE','INV_RECEIPT_PROPERTY','INV_RECEIPT_BIO','INV_RECEIPT_LOANS','INV_RECEIPT_INVEST','INV_RECEIPT_PROFIT','INV_RECEIPT_CAP_GAIN','INV_RECEIPT_CAPEX','INV_RECEIPT_NONCURRENT_DEBTOR'];
    foreach($investReceipts as $key){$d=$defs[$key];$display=$key==='INV_RECEIPT_PROFIT'?'4392':$d[2];$add('detail',$display,$d[3],$one(abs((float)$c['direct']['totals'][$key])),$one(abs((float)$p['direct']['totals'][$key])));}
    $cInvRec=array_sum(array_map(static fn($k)=>abs((float)$c['direct']['totals'][$k]),$investReceipts));
    $pInvRec=array_sum(array_map(static fn($k)=>abs((float)$p['direct']['totals'][$k]),$investReceipts));
    $add('subtotal','','مجموع المقبوضات الاستثمارية',$two($cInvRec),$two($pInvRec));
    $add('subsection','','تنزل: المدفوعات النقدية عن:',$blank,$blank);
    $investPayments=['INV_PAYMENT_CAPEX','INV_PAYMENT_NONCURRENT_CREDITOR','INV_PAYMENT_LOANS','INV_PAYMENT_INVEST','INV_PAYMENT_CAP_LOSS'];
    foreach($investPayments as $key){$d=$defs[$key];$add('detail',$d[2],$d[3],$one(abs((float)$c['direct']['totals'][$key])),$one(abs((float)$p['direct']['totals'][$key])));}
    $cInvPay=array_sum(array_map(static fn($k)=>abs((float)$c['direct']['totals'][$k]),$investPayments));
    $pInvPay=array_sum(array_map(static fn($k)=>abs((float)$p['direct']['totals'][$k]),$investPayments));
    $add('subtotal','','مجموع المدفوعات الاستثمارية',$two($cInvPay),$two($pInvPay));
    $add('total','','صافي التدفق النقدي عن الأنشطة الاستثمارية',$three((float)$c['direct']['investing']),$three((float)$p['direct']['investing']));

    $add('section','','التدفق النقدي عن الأنشطة التمويلية:',$blank,$blank);
    $add('subsection','','النقد المستلم من:',$blank,$blank);
    $finReceipts=['FIN_RECEIPT_GRANTS','FIN_RECEIPT_SHARES','FIN_RECEIPT_LOANS'];
    foreach($finReceipts as $key){$d=$defs[$key];$display=$key==='FIN_RECEIPT_GRANTS'?'482':$d[2];$add('detail',$display,$d[3],$one(abs((float)$c['direct']['totals'][$key])),$one(abs((float)$p['direct']['totals'][$key])));}
    $cFinRec=array_sum(array_map(static fn($k)=>abs((float)$c['direct']['totals'][$k]),$finReceipts));
    $pFinRec=array_sum(array_map(static fn($k)=>abs((float)$p['direct']['totals'][$k]),$finReceipts));
    $add('subtotal','','مجموع المقبوضات التمويلية',$two($cFinRec),$two($pFinRec));
    $add('subsection','','تنزل: المدفوعات النقدية عن:',$blank,$blank);
    $finPayments=['FIN_PAYMENT_RESERVES','FIN_PAYMENT_SHARES','FIN_PAYMENT_LOANS','FIN_PAYMENT_DIVIDENDS'];
    foreach($finPayments as $key){$d=$defs[$key];$add('detail',$d[2],$d[3],$one(abs((float)$c['direct']['totals'][$key])),$one(abs((float)$p['direct']['totals'][$key])));}
    $cFinPay=array_sum(array_map(static fn($k)=>abs((float)$c['direct']['totals'][$k]),$finPayments));
    $pFinPay=array_sum(array_map(static fn($k)=>abs((float)$p['direct']['totals'][$k]),$finPayments));
    $add('subtotal','','مجموع المدفوعات التمويلية',$two($cFinPay),$two($pFinPay));
    $add('total','','صافي التدفق النقدي عن الأنشطة التمويلية',$three((float)$c['direct']['financing']),$three((float)$p['direct']['financing']));
    $add('grand','','صافي التدفق النقدي عن الأنشطة الثلاث',$three((float)$c['direct']['net']),$three((float)$p['direct']['net']));
    $add('detail','4395','أثر التغيرات في سعر الصرف على النقد ومعادلاته',$three((float)$c['direct']['fx']),$three((float)$p['direct']['fx']));
    $add('detail','134','يضاف: رصيد النقد ومعادلاته في بداية الفترة',$three((float)$c['direct']['opening']),$three((float)$p['direct']['opening']));
    $add('grand','134','رصيد النقد ومعادلاته في نهاية الفترة',$three((float)$c['direct']['closing']),$three((float)$p['direct']['closing']));
    return $rows;
}

function gr_indirect_operating(string $from, string $to): array
{
    $ctx = reporting_context($from, $to);
    $income = gr_income_statement_rows($ctx, 'summary');
    $profit = (float)$income['after_tax'][0];
    $openingDate = (new DateTimeImmutable($from))->modify('-1 day')->format('Y-m-d');
    $changeInventory = guide_amount('131', $to) - guide_amount('131', $openingDate);
    $changeDebtors = guide_amount('132', $to) - guide_amount('132', $openingDate);
    $changeCreditors = guide_amount('232', $to, null, 'credit') - guide_amount('232', $openingDate, null, 'credit');
    $changeOtherLiabilities = guide_amount('24', $to, null, 'credit') - guide_amount('24', $openingDate, null, 'credit');
    $changeProvisions = guide_amount('25', $to, null, 'credit') - guide_amount('25', $openingDate, null, 'credit');
    $defaultNoncash = guide_amount('37', $to, $from, 'debit');
    $noncash = gr_period_value($to, 'cashflow_noncash_adjustments', $defaultNoncash);
    $operating = round($profit - $changeInventory - $changeDebtors + $changeCreditors + $changeOtherLiabilities + $changeProvisions + $noncash, 3);
    return compact('profit', 'changeInventory', 'changeDebtors', 'changeCreditors', 'changeOtherLiabilities', 'changeProvisions', 'noncash', 'operating');
}

function gr_indirect_cash_flow(string $from, string $to): array
{
    $days = (new DateTimeImmutable($from))->diff(new DateTimeImmutable($to))->days + 1;
    $priorTo = (new DateTimeImmutable($from))->modify('-1 day');
    $priorFrom = $priorTo->modify('-' . ($days - 1) . ' days');
    $currentDirect = gr_direct_cash_flow($from, $to);
    $priorDirect = gr_direct_cash_flow($priorFrom->format('Y-m-d'), $priorTo->format('Y-m-d'));
    return [
        'current' => ['operating' => gr_indirect_operating($from, $to), 'direct' => $currentDirect],
        'prior' => ['operating' => gr_indirect_operating($priorFrom->format('Y-m-d'), $priorTo->format('Y-m-d')), 'direct' => $priorDirect],
        'from' => $from,
        'to' => $to,
        'prior_from' => $priorFrom->format('Y-m-d'),
        'prior_to' => $priorTo->format('Y-m-d'),
    ];
}

function gr_report_readiness(string $from, string $to): array
{
    $cf = gr_direct_cash_flow($from, $to);
    $unclassifiedFunctional = gr_unclassified_functional_expense($from, $to);
    $position = gr_financial_position_rows(reporting_context($from, $to));
    $maxBalanceDifference = max(array_map(static fn($v): float => abs((float)$v), $position['balance_difference']));
    $items = [
        ['code' => 'FS-BALANCE', 'label' => 'توازن قائمة المركز المالي', 'ok' => $maxBalanceDifference < 0.001, 'detail' => 'أكبر فرق بين الأصول والالتزامات وحقوق الملكية: ' . gr_report_money($maxBalanceDifference)],
        ['code' => 'FUNCTION-MAP', 'label' => 'تصنيف المصروفات الوظيفي 5-8', 'ok' => abs($unclassifiedFunctional) < 0.001, 'detail' => 'المصروفات غير المصنفة: ' . gr_report_money($unclassifiedFunctional)],
        ['code' => 'CF-CLASS', 'label' => 'اكتمال تصنيف التدفقات النقدية', 'ok' => count($cf['unclassified']) === 0, 'detail' => 'الأسطر التي تحتاج معالجة: ' . count($cf['unclassified'])],
        ['code' => 'CF-RECON', 'label' => 'مطابقة رصيد النقد', 'ok' => abs($cf['difference']) < 0.001, 'detail' => 'فرق المطابقة: ' . gr_report_money($cf['difference'])],
    ];
    $ok = !array_filter($items, static fn(array $item): bool => !$item['ok']);
    return compact('items', 'ok');
}
