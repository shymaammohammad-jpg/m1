<?php
declare(strict_types=1);
require_once __DIR__ . '/core.php';

function setting_get(string $key, mixed $default = null): mixed
{
    $stmt = db()->prepare('SELECT setting_value FROM app_settings WHERE company_id=? AND setting_key=?');
    $stmt->execute([company_id(), $key]);
    $value = $stmt->fetchColumn();
    return $value === false ? $default : $value;
}

function setting_set(string $key, mixed $value, ?PDO $pdo = null): void
{
    $pdo ??= db();
    $stmt = $pdo->prepare('INSERT INTO app_settings(company_id,setting_key,setting_value) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
    $stmt->execute([company_id(), $key, is_scalar($value) || $value === null ? (string)$value : json_value($value)]);
}

function standards_library(): array
{
    if (!table_exists('standards_library')) return [];
    return db()->query('SELECT * FROM standards_library ORDER BY guide_order')->fetchAll();
}

function standard_title(string $code): string
{
    static $map = null;
    if ($map === null) {
        $map = [];
        foreach (standards_library() as $row) $map[$row['code']] = $row['title_ar'];
    }
    return $map[$code] ?? $code;
}

function reporting_context(string $from, string $to): array
{
    if (!valid_date($from) || !valid_date($to) || $from > $to) throw new RuntimeException('نطاق التقرير غير صالح.');
    $days = (new DateTimeImmutable($from))->diff(new DateTimeImmutable($to))->days + 1;
    $priorTo = (new DateTimeImmutable($from))->modify('-1 day');
    $priorFrom = $priorTo->modify('-' . ($days - 1) . ' days');
    $earlierTo = $priorFrom->modify('-1 day');
    $earlierFrom = $earlierTo->modify('-' . ($days - 1) . ' days');
    return [
        'from'=>$from,'to'=>$to,
        'prior_from'=>$priorFrom->format('Y-m-d'),'prior_to'=>$priorTo->format('Y-m-d'),
        'earlier_from'=>$earlierFrom->format('Y-m-d'),'earlier_to'=>$earlierTo->format('Y-m-d'),
        'beginning_prior'=>$priorFrom->modify('-1 day')->format('Y-m-d'),
    ];
}

function account_prefix_raw(string $prefix, string $to, ?string $from = null, array $excludePrefixes = []): float
{
    if (!valid_date($to) || ($from !== null && !valid_date($from))) throw new RuntimeException('تاريخ التقرير غير صالح.');
    $where = "(a.code=? OR a.code LIKE ?)";
    $params = [$prefix, $prefix . '%'];
    foreach ($excludePrefixes as $ex) {
        $where .= " AND NOT (a.code=? OR a.code LIKE ?)";
        $params[] = $ex; $params[] = $ex . '%';
    }
    $sql = "SELECT COALESCE(SUM(jl.debit-jl.credit),0)
            FROM journal_lines jl JOIN journal_entries je ON je.id=jl.journal_entry_id
            JOIN accounts a ON a.id=jl.account_id
            WHERE je.company_id=? AND " . posted_status_condition('je') . " AND je.entry_date<=? AND {$where}";
    $all = [company_id(), $to, ...$params];
    if ($from !== null) { $sql .= ' AND je.entry_date>=?'; $all[] = $from; }
    $stmt = db()->prepare($sql); $stmt->execute($all);
    return round((float)$stmt->fetchColumn(),3);
}

/**
 * Normalize one account prefix or a list of prefixes.
 *
 * PHP converts numeric-looking array keys (for example 121 or 2641) to
 * integers.  Report definitions therefore may legitimately pass an int even
 * though account codes are stored as strings in MySQL.  Accept mixed input at
 * this boundary and convert every supported scalar to a clean string before
 * any database query is prepared.
 */
function normalize_account_prefixes(mixed $prefixes, string $argumentName = 'include'): array
{
    if (is_array($prefixes)) {
        $items = $prefixes;
    } elseif (is_string($prefixes) || is_int($prefixes) || is_float($prefixes)) {
        $items = [$prefixes];
    } else {
        throw new InvalidArgumentException(
            sprintf('%s must be an account prefix or an array of prefixes; %s given.', $argumentName, get_debug_type($prefixes))
        );
    }

    $normalized = [];
    foreach ($items as $prefix) {
        if (!is_string($prefix) && !is_int($prefix) && !is_float($prefix)) {
            throw new InvalidArgumentException(
                sprintf('%s contains an unsupported value of type %s.', $argumentName, get_debug_type($prefix))
            );
        }
        $value = trim((string)$prefix);
        if ($value === '') {
            continue;
        }
        $normalized[$value] = $value;
    }

    if ($normalized === []) {
        throw new InvalidArgumentException(sprintf('%s does not contain a valid account prefix.', $argumentName));
    }

    return array_values($normalized);
}

function account_group_raw(mixed $include, string $to, ?string $from = null, mixed $exclude = []): float
{
    $includePrefixes = normalize_account_prefixes($include, 'include');
    $excludePrefixes = $exclude === [] || $exclude === null
        ? []
        : normalize_account_prefixes($exclude, 'exclude');

    $sum = 0.0;
    foreach ($includePrefixes as $prefix) {
        $sum += account_prefix_raw($prefix, $to, $from, $excludePrefixes);
    }
    return round($sum, 3);
}

function guide_amount(mixed $include, string $to, ?string $from = null, string $orientation = 'debit', mixed $exclude = []): float
{
    if (!in_array($orientation, ['debit', 'credit'], true)) {
        throw new InvalidArgumentException('Report orientation must be debit or credit.');
    }
    $raw = account_group_raw($include, $to, $from, $exclude);
    return round($orientation === 'credit' ? -$raw : $raw, 3);
}

function report_triplet(mixed $include, array $ctx, string $orientation = 'debit', mixed $exclude = []): array
{
    return [
        guide_amount($include, $ctx['to'], null, $orientation, $exclude),
        guide_amount($include, $ctx['prior_to'], null, $orientation, $exclude),
        guide_amount($include, $ctx['beginning_prior'], null, $orientation, $exclude),
    ];
}

function movement_triplet(mixed $include, array $ctx, string $orientation = 'debit', mixed $exclude = []): array
{
    return [
        guide_amount($include, $ctx['to'], $ctx['from'], $orientation, $exclude),
        guide_amount($include, $ctx['prior_to'], $ctx['prior_from'], $orientation, $exclude),
        guide_amount($include, $ctx['earlier_to'], $ctx['earlier_from'], $orientation, $exclude),
    ];
}

function vec_add(array ...$vectors): array
{
    $out=[0.0,0.0,0.0];
    foreach($vectors as $v) for($i=0;$i<3;$i++) $out[$i]+= (float)($v[$i]??0);
    return array_map(fn($x)=>round($x,3),$out);
}
function vec_sub(array $a,array ...$vectors): array { foreach($vectors as $v) for($i=0;$i<3;$i++) $a[$i]-=(float)($v[$i]??0); return array_map(fn($x)=>round($x,3),$a); }

/**
 * Build one financial-statement row.
 *
 * Numeric-looking PHP array keys are converted to integers even when they
 * represent account codes. Accept a scalar code at this presentation boundary
 * and normalize it to a string before the row is returned.
 */
function fp_row(string $label, mixed $code = '', ?array $values = null, string $kind = 'detail'): array
{
    if ($code === null) {
        $code = '';
    } elseif (!is_string($code) && !is_int($code) && !is_float($code)) {
        throw new InvalidArgumentException(
            sprintf('Financial-statement row code must be scalar; %s given.', get_debug_type($code))
        );
    }

    $code = trim((string)$code);
    return compact('label', 'code', 'values', 'kind');
}

function financial_position_guide_rows(array $ctx): array
{
    $v=fn($c,$o='debit',$x=[])=>report_triplet(is_array($c) ? $c : (string)$c,$ctx,$o,$x);
    $rows=[];
    $rows[]=fp_row('الأصول غير المتداولة','11',null,'section');
    $ppe=$v('111');$ppeDep=$v('221','credit');$ppeImp=$v('25111','credit');
    $rows[]=fp_row('الممتلكات والآلات والمعدات','111',$ppe);$rows[]=fp_row('ينزل: متراكم اندثار الممتلكات والآلات والمعدات','221',$ppeDep,'deduction');$rows[]=fp_row('ينزل: مخصص انخفاض الممتلكات والآلات والمعدات','25111',$ppeImp,'deduction');$rows[]=fp_row('صافي الممتلكات والآلات والمعدات','',vec_sub($ppe,$ppeDep,$ppeImp),'subtotal');
    $ip=$v('112');$ipDep=$v('222','credit');$ipImp=$v('25112','credit');
    $rows[]=fp_row('العقارات الاستثمارية','112',$ip);$rows[]=fp_row('ينزل: متراكم اندثار العقارات الاستثمارية','222',$ipDep,'deduction');$rows[]=fp_row('ينزل: مخصص انخفاض العقارات الاستثمارية','25112',$ipImp,'deduction');$rows[]=fp_row('صافي العقارات الاستثمارية','',vec_sub($ip,$ipDep,$ipImp),'subtotal');
    $lease=$v('113');$leaseImp=$v('25113','credit');$leaseDep=$v('223','credit');
    $rows[]=fp_row('الأصول غير المتداولة المستأجرة (إيجار تمويلي)','113',$lease);$rows[]=fp_row('ينزل: مخصص انخفاض الأصول غير المتداولة المستأجرة','25113',$leaseImp,'deduction');$rows[]=fp_row('ينزل: متراكم اندثار الأصول غير المتداولة المستأجرة','223',$leaseDep,'deduction');$rows[]=fp_row('صافي الأصول غير المتداولة المستأجرة','',vec_sub($lease,$leaseImp,$leaseDep),'subtotal');
    $bio=$v('114');$bioImp=$v('25114','credit');$rows[]=fp_row('أصول حية لأغراض العرض والإنتاج والحراسة','114',$bio);$rows[]=fp_row('ينزل: مخصص انخفاض الأصول الحية','25114',$bioImp,'deduction');$rows[]=fp_row('صافي الأصول الحية','',vec_sub($bio,$bioImp),'subtotal');
    $loans=$v('1151');$invest=$v('1152');$investImp=$v('256','credit');$rows[]=fp_row('القروض الممنوحة طويلة الأجل','1151',$loans);$rows[]=fp_row('الاستثمارات المالية','1152',$invest);$rows[]=fp_row('ينزل: مخصص انخفاض الاستثمارات المالية','256',$investImp,'deduction');$rows[]=fp_row('صافي الاستثمارات في أدوات حقوق الملكية','',vec_sub($invest,$investImp),'subtotal');$rows[]=fp_row('مجموع القروض وصافي الاستثمارات طويلة الأجل','',vec_add($loans,vec_sub($invest,$investImp)),'subtotal');
    $mine=$v('116');$mineDep=$v('226','credit');$mineAm=$v('229','credit');$mineImp=$v('25116','credit');$rows[]=fp_row('عقود التعدين','116',$mine);$rows[]=fp_row('ينزل: متراكم اندثار عقود التعدين الملموسة','226',$mineDep,'deduction');$rows[]=fp_row('ينزل: متراكم إطفاء عقود التعدين غير الملموسة','229',$mineAm,'deduction');$rows[]=fp_row('ينزل: مخصص انخفاض عقود التعدين','25116',$mineImp,'deduction');$rows[]=fp_row('صافي عقود التعدين','',vec_sub($mine,$mineDep,$mineAm,$mineImp),'subtotal');
    $joint=$v('117');$jointDep=$v('227','credit');$jointImp=$v('25117','credit');$rows[]=fp_row('الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة','117',$joint);$rows[]=fp_row('ينزل: متراكم اندثار الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة','227',$jointDep,'deduction');$rows[]=fp_row('ينزل: مخصص انخفاض الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة','25117',$jointImp,'deduction');$rows[]=fp_row('صافي الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة','',vec_sub($joint,$jointDep,$jointImp),'subtotal');
    $rows[]=fp_row('مجموع الأصول غير المتداولة','11',$v('11'),'total');
    $rows[]=fp_row('الإنفاق الرأسمالي','12',null,'section');foreach(['121'=>'الإنفاق الرأسمالي على الممتلكات والآلات والمعدات','122'=>'الإنفاق الرأسمالي على العقارات الاستثمارية','123'=>'الإنفاق الرأسمالي على الأصول غير المتداولة المستأجرة','124'=>'الإنفاق الرأسمالي على الأصول الحية','125'=>'إنفاق استثماري','126'=>'عقود التعدين','127'=>'الممتلكات والآلات والمعدات الخاضعة لسيطرة مشتركة'] as $c=>$l)$rows[]=fp_row($l,$c,$v($c));$rows[]=fp_row('مجموع الإنفاق الرأسمالي','12',$v('12'),'total');
    $rows[]=fp_row('الأصول المتداولة','13',null,'section');$inv=$v('131','debit',['1318']);$invProv=$v('25121','credit');$lc=$v('1318');$rows[]=fp_row('المخزون (عدا 1318)','131',$inv);$rows[]=fp_row('ينزل: مخصص هبوط أسعار المخزون','25121',$invProv,'deduction');$rows[]=fp_row('المخزون بالقيمة التحصيلية الصافية','',vec_sub($inv,$invProv),'subtotal');$rows[]=fp_row('اعتمادات مستندية لشراء مواد','1318',$lc);$rows[]=fp_row('إجمالي المخزون','',vec_add(vec_sub($inv,$invProv),$lc),'subtotal');
    $rec=$v('132');$bad=$v('224','credit');$rows[]=fp_row('الذمم المدينة','132',$rec);$rows[]=fp_row('ينزل: الديون المشكوك في تحصيلها','224',$bad,'deduction');$rows[]=fp_row('صافي الذمم المدينة','',vec_sub($rec,$bad),'subtotal');
    $sale=$v('133');$saleImp=$v('2581','credit');$rows[]=fp_row('الأصول غير المتداولة المعروضة للبيع أو المحتفظ بها للتوزيع على الملاك','133',$sale);$rows[]=fp_row('ينزل: مخصص انخفاض الأصول المعروضة للبيع','2581',$saleImp,'deduction');$rows[]=fp_row('صافي الأصول المعروضة للبيع','',vec_sub($sale,$saleImp),'subtotal');
    $cash=$v('134');$fx=$v('257','credit');$rows[]=fp_row('النقود','134',$cash);$rows[]=fp_row('ينزل: مخصص فروقات أسعار الصرف','257',$fx,'deduction');$rows[]=fp_row('صافي النقود','',vec_sub($cash,$fx),'subtotal');
    $rows[]=fp_row('قروض ممنوحة قصيرة الأجل','1351',$v('1351'));$rows[]=fp_row('الاستثمارات في الأسهم والسندات والأوراق التجارية','1352',$v('1352'));$rows[]=fp_row('مجموع القروض والاستثمارات قصيرة الأجل','135',$v('135'),'subtotal');$rows[]=fp_row('مجموع الأصول المتداولة','13',$v('13'),'total');
    $rows[]=fp_row('الأصول الأخرى','14',null,'section');foreach(['141'=>'أصول ضريبية مؤجلة','142'=>'تعويضات وغرامات مؤجلة','143'=>'حقوق التأجير طويلة الأجل','145'=>'استثمارات بالقيمة العادلة من خلال الدخل الشامل الآخر','225'=>'تعديلات القيمة العادلة للاستثمارات من خلال الدخل الشامل الآخر','146'=>'حقوق بيع البضائع وإعادة الشراء','148'=>'الحقوق الناشئة عن العقود'] as $c=>$l)$rows[]=fp_row($l,$c,$v($c));$rows[]=fp_row('مجموع الأصول الأخرى','14',$v('14'),'total');
    $rows[]=fp_row('الأصول غير الملموسة','15',null,'section');foreach(['151'=>'شهرة المحل','152'=>'حقوق اختراع','153'=>'حقوق الامتياز والتراخيص','154'=>'العلامة التجارية','155'=>'الأبحاث والتجارب','156'=>'حقوق النشر والطبع والتأليف','157'=>'حقوق عقود التأجير طويلة الأجل','158'=>'أصول غير ملموسة أخرى'] as $c=>$l)$rows[]=fp_row($l,$c,$v($c));$amort=$v('226','credit');$rows[]=fp_row('مجموع الأصول غير الملموسة','15',$v('15'),'subtotal');$rows[]=fp_row('ينزل: متراكم إطفاء الأصول غير الملموسة','226',$amort,'deduction');$rows[]=fp_row('صافي الأصول غير الملموسة','',vec_sub($v('15'),$amort),'subtotal');
    $rows[]=fp_row('مجموع الأصول','1',$v('1'),'grand');$rows[]=fp_row('الحسابات التنظيمية المؤجلة المدينة','18',$v('18'));$rows[]=fp_row('الحسابات المتقابلة المدينة','19',$v('19'));
    $rows[]=fp_row('الالتزامات غير المتداولة','21',null,'section');foreach(['211'=>'التزامات تمويل الممتلكات والآلات والمعدات','212'=>'التزامات تمويل العقارات الاستثمارية','213'=>'التزامات تمويل عقود الإيجار','214'=>'التزامات تمويل الأصول الحية','215'=>'الالتزامات طويلة الأجل'] as $c=>$l)$rows[]=fp_row($l,$c,$v($c,'credit'));$rows[]=fp_row('مجموع الالتزامات غير المتداولة','21',$v('21','credit'),'total');
    $rows[]=fp_row('الالتزامات المتداولة','23',null,'section');foreach(['232'=>'الذمم الدائنة','234'=>'المصارف الدائنة (جاري مكشوف)','235'=>'الالتزامات قصيرة الأجل'] as $c=>$l)$rows[]=fp_row($l,$c,$v($c,'credit'));$rows[]=fp_row('مجموع الالتزامات المتداولة','23',$v('23','credit'),'total');
    $rows[]=fp_row('الالتزامات الأخرى','24',null,'section');foreach(['241'=>'التزامات ضريبية مؤجلة','242'=>'التزامات وغرامات مؤجلة','243'=>'التزامات عقود إيجار طويلة الأجل','244'=>'إيرادات مؤجلة','245'=>'التزامات عقود إيجار','246'=>'التزامات بيع البضائع وعقود الصرف المؤجلة','247'=>'التزام منح حق استخدام الأصول غير الملموسة','248'=>'الالتزامات الناشئة عن العقود'] as $c=>$l)$rows[]=fp_row($l,$c,$v($c,'credit'));$rows[]=fp_row('مجموع الالتزامات الأخرى','24',$v('24','credit'),'total');
    $rows[]=fp_row('المخصصات','25',null,'section');foreach(['251'=>'مخصص مصروفات الشراء','252'=>'مخصص الخسائر المتوقعة لمشاريع قيد الإنجاز','253'=>'مخصص مصاريف الصيانة المحتملة وخدمات ما بعد البيع','255'=>'مخصص الالتزامات والمطالبات والغرامات','258'=>'مخصصات متنوعة'] as $c=>$l)$rows[]=fp_row($l,$c,$v($c,'credit'));$rows[]=fp_row('مجموع المخصصات','25',$v('25','credit'),'total');
    $rows[]=fp_row('حقوق الملكية','26',null,'section');foreach(['261'=>'رأس المال','262'=>'رأس المال الإضافي (الاحتياطيات)','263'=>'الأرباح المحتجزة','2631'=>'الفائض المتراكم','2632'=>'العجز المتراكم','264'=>'الدخل الشامل الآخر','265'=>'التغير بالسياسات المحاسبية والتقديرات وتصحيح الأخطاء'] as $c=>$l)$rows[]=fp_row($l,$c,$v($c,'credit'));$rows[]=fp_row('مجموع حقوق الملكية','26',$v('26','credit'),'total');
    $rows[]=fp_row('مجموع الالتزامات وحقوق الملكية','2',$v('2','credit'),'grand');$rows[]=fp_row('الحسابات التنظيمية المؤجلة الدائنة','28',$v('28','credit'));$rows[]=fp_row('الحسابات المتقابلة الدائنة','29',$v('29','credit'));
    return $rows;
}

function income_statement_guide_rows(array $ctx, string $mode='summary'): array
{
    $m=fn($c,$o='debit',$x=[])=>movement_triplet(is_array($c) ? $c : (string)$c,$ctx,$o,$x);$rows=[];
    $rev=$m(['41','42','43','44','45','46'],'credit');
    $transferRev=$m(['48','49'],'credit');$transferExp=$m(['38','39'],'debit',['3841','3842']);$tax=$m('3841');$oci=$m('264','credit');
    $rows[]=fp_row('إيرادات النشاط الجاري','41-46',$rev);
    if($mode==='natural'){
        $cost=vec_add($m('31'),$m('32'),$m('33'),$m('34'),$m('37'),$m('3842'));
        foreach(['31'=>'الرواتب والأجور','32'=>'المستلزمات السلعية','33'=>'المستلزمات الخدمية','34'=>'مقاولات وخدمات','37'=>'الاندثارات','3842'=>'رسوم الإنتاج'] as $c=>$l)$rows[]=fp_row($l,$c,$m($c));
        $rows[]=fp_row('كلفة البضاعة المباعة','36',$m('36'),'subtotal');
        $gross=vec_sub($rev,$m('36'));$rows[]=fp_row('مجمل فائض (عجز) الإنتاج والمتاجرة للنشاط التشغيلي','',$gross,'subtotal');
    } elseif($mode==='functional'){
        foreach(['5'=>'كلفة الإنتاج','6'=>'كلفة الإنتاج','35'=>'مشتريات بضائع وأراضٍ بغرض البيع خلال الفترة','7'=>'كلفة الخدمات التسويقية','8'=>'كلفة الخدمات الإدارية والتمويلية'] as $c=>$l)$rows[]=fp_row($l,$c,$m($c));
        $cost=vec_add($m('5'),$m('6'),$m('35'),$m('7'),$m('8'));
        $rows[]=fp_row('كلفة النشاط الجاري','',$cost,'subtotal');$rows[]=fp_row('فائض (عجز) النشاط التشغيلي','',vec_sub($rev,$cost),'subtotal');
    } else {
        $cogs=$m('36');$rows[]=fp_row('تنزل: كلفة البضاعة المباعة','36',$cogs,'deduction');$rows[]=fp_row('مجمل فائض (عجز) الإنتاج والمتاجرة للنشاط التشغيلي','',vec_sub($rev,$cogs),'subtotal');
    }
    $rows[]=fp_row('تضاف: الإيرادات التحويلية والأخرى','48-49',$transferRev);$rows[]=fp_row('تنزل: المصروفات التحويلية والأخرى','38-39',$transferExp,'deduction');
    $preTax=vec_sub(vec_add($rev,$transferRev), $mode==='functional'?$cost:($mode==='natural'?$m('36'):$m('36')), $transferExp);
    $rows[]=fp_row('الربح أو (الخسارة) قبل الضريبة','',$preTax,'subtotal');$rows[]=fp_row('مصروف ضريبة الدخل','3841',$tax,'deduction');$after=vec_sub($preTax,$tax);$rows[]=fp_row('الربح أو (الخسارة) بعد الضريبة','',$after,'grand');
    $rows[]=fp_row('الدخل الشامل الآخر','264',null,'section');foreach(['2641'=>'فائض إعادة تقييم الأصول','2642'=>'حصة المنشأة في الدخل الشامل الآخر للمنشآت الزميلة','2643'=>'مكاسب وخسائر من خلال الدخل الشامل الآخر','2644'=>'مكاسب وخسائر أسعار الصرف للعمليات الأجنبية','2645'=>'مكاسب وخسائر تدوير الوفر الضريبي'] as $c=>$l)$rows[]=fp_row($l,$c,$m($c,'credit'));$rows[]=fp_row('مجموع الدخل الشامل الآخر','264',$oci,'subtotal');$rows[]=fp_row('إجمالي الدخل الشامل','',vec_add($after,$oci),'grand');
    return $rows;
}

function cash_flow_line_definitions(): array
{
    return [
        'OP_RECEIPTS_REVENUE'=>['operating','in','45-41','إيرادات النشاط الجاري (عدا 435 و439)'],
        'OP_RECEIPTS_TRANSFER'=>['operating','in','48','إيرادات تحويلية (عدا 481 و483)'],
        'OP_RECEIPTS_DEBTORS'=>['operating','in','132','المتحصلات من المدينين'],
        'OP_PAYMENTS_USES'=>['operating','out','35-31','المدفوعات عن الاستخدامات'],
        'OP_PAYMENTS_TRANSFER'=>['operating','out','38','المصروفات التحويلية (عدا 381 و383 و384)'],
        'OP_INVENTORY_CHANGE'=>['operating','out','131','التغير في المخزون'],
        'OP_TAXES'=>['operating','out','384','الضرائب والرسوم'],
        'OP_CREDITORS'=>['operating','out','232','المدفوعات للدائنين (عدا 2325 و2328)'],
        'INV_RECEIPT_PPE'=>['investing','in','111','بيع الممتلكات والآلات والمعدات'],
        'INV_RECEIPT_PROPERTY'=>['investing','in','112','بيع العقارات الاستثمارية'],
        'INV_RECEIPT_BIO'=>['investing','in','114','بيع الأصول الحية'],
        'INV_RECEIPT_LOANS'=>['investing','in','1151','استرداد القروض الممنوحة والسلف'],
        'INV_RECEIPT_INVEST'=>['investing','in','1152','القيمة النقدية لبيع الاستثمارات'],
        'INV_RECEIPT_PROFIT'=>['investing','in','435','أرباح الاستثمارات بالقيمة العادلة'],
        'INV_RECEIPT_CAP_GAIN'=>['investing','in','491','المكاسب الرأسمالية'],
        'INV_RECEIPT_CAPEX'=>['investing','in','12','بيع الإنفاق الرأسمالي'],
        'INV_RECEIPT_NONCURRENT_DEBTOR'=>['investing','in','1325','مدينو النشاط غير الجاري'],
        'INV_PAYMENT_CAPEX'=>['investing','out','12','الإنفاق الرأسمالي'],
        'INV_PAYMENT_NONCURRENT_CREDITOR'=>['investing','out','2325','دائنو النشاط غير الجاري'],
        'INV_PAYMENT_LOANS'=>['investing','out','1351','قروض ممنوحة قصيرة الأجل'],
        'INV_PAYMENT_INVEST'=>['investing','out','1352','الاستثمارات في الأسهم والسندات'],
        'INV_PAYMENT_CAP_LOSS'=>['investing','out','391','الخسائر الرأسمالية'],
        'FIN_RECEIPT_GRANTS'=>['financing','in','481','منح تمويلية'],
        'FIN_RECEIPT_SHARES'=>['financing','in','2611','المتحصلات من إصدار الأسهم وأدوات حقوق الملكية'],
        'FIN_RECEIPT_LOANS'=>['financing','in','2351','قروض مستلمة'],
        'FIN_PAYMENT_RESERVES'=>['financing','out','381','المبالغ المحتجزة في حساب الاحتياطيات'],
        'FIN_PAYMENT_SHARES'=>['financing','out','2611','استرداد الأسهم وأدوات حقوق الملكية'],
        'FIN_PAYMENT_LOANS'=>['financing','out','2351','تسديد القروض المستلمة'],
        'FIN_PAYMENT_DIVIDENDS'=>['financing','out','2328','الأرباح الموزعة'],
        'FX_EFFECT'=>['fx','net','4395','أثر التغيرات في سعر الصرف على النقد ومعادلاته'],
        'UNCLASSIFIED'=>['unclassified','net','','حركات نقدية غير مصنفة'],
    ];
}

function auto_cash_flow_code(string $accountCode, float $cashEffect): string
{
    $in=$cashEffect>0;
    $starts=fn($p)=>str_starts_with($accountCode,$p);
    if($in){
        if(($starts('41')||$starts('42')||$starts('43')||$starts('44')||$starts('45'))&&!$starts('435')&&!$starts('439'))return 'OP_RECEIPTS_REVENUE';
        if($starts('48')&&!$starts('481')&&!$starts('483'))return 'OP_RECEIPTS_TRANSFER';
        if($starts('132')&&!$starts('1325'))return 'OP_RECEIPTS_DEBTORS';
        if($starts('111'))return 'INV_RECEIPT_PPE'; if($starts('112'))return 'INV_RECEIPT_PROPERTY'; if($starts('114'))return 'INV_RECEIPT_BIO'; if($starts('1151'))return 'INV_RECEIPT_LOANS'; if($starts('1152'))return 'INV_RECEIPT_INVEST'; if($starts('435'))return 'INV_RECEIPT_PROFIT'; if($starts('491'))return 'INV_RECEIPT_CAP_GAIN'; if($starts('12'))return 'INV_RECEIPT_CAPEX'; if($starts('1325'))return 'INV_RECEIPT_NONCURRENT_DEBTOR'; if($starts('481'))return 'FIN_RECEIPT_GRANTS'; if($starts('2611'))return 'FIN_RECEIPT_SHARES'; if($starts('2351'))return 'FIN_RECEIPT_LOANS';
    } else {
        if($starts('31')||$starts('32')||$starts('33')||$starts('34')||$starts('35'))return 'OP_PAYMENTS_USES';
        if($starts('38')&&!$starts('381')&&!$starts('383')&&!$starts('384'))return 'OP_PAYMENTS_TRANSFER'; if($starts('384'))return 'OP_TAXES'; if($starts('232')&&!$starts('2325')&&!$starts('2328'))return 'OP_CREDITORS'; if($starts('12'))return 'INV_PAYMENT_CAPEX'; if($starts('2325'))return 'INV_PAYMENT_NONCURRENT_CREDITOR'; if($starts('1351'))return 'INV_PAYMENT_LOANS'; if($starts('1352'))return 'INV_PAYMENT_INVEST'; if($starts('391'))return 'INV_PAYMENT_CAP_LOSS'; if($starts('381'))return 'FIN_PAYMENT_RESERVES'; if($starts('2611'))return 'FIN_PAYMENT_SHARES'; if($starts('2351'))return 'FIN_PAYMENT_LOANS'; if($starts('2328'))return 'FIN_PAYMENT_DIVIDENDS';
    }
    if($starts('4395'))return 'FX_EFFECT';
    return 'UNCLASSIFIED';
}

function direct_cash_flow_details(string $from,string $to): array
{
    if(!valid_date($from)||!valid_date($to)||$from>$to)throw new RuntimeException('نطاق التدفق النقدي غير صالح.');
    $defs=cash_flow_line_definitions();$totals=array_fill_keys(array_keys($defs),0.0);$unclassified=[];
    $sql="SELECT je.id entry_id,je.voucher_no,je.entry_date,jl.id line_id,jl.debit,jl.credit,jl.cash_flow_line_code,a.code,a.name_ar,a.is_cash_account,
                 o.line_code override_code
          FROM journal_entries je JOIN journal_lines jl ON jl.journal_entry_id=je.id JOIN accounts a ON a.id=jl.account_id
          LEFT JOIN cash_flow_overrides o ON o.company_id=je.company_id AND o.journal_line_id=jl.id
          WHERE je.company_id=? AND ".posted_status_condition('je')." AND je.entry_date BETWEEN ? AND ? ORDER BY je.id,jl.id";
    $stmt=db()->prepare($sql);$stmt->execute([company_id(),$from,$to]);$entries=[];foreach($stmt->fetchAll() as $r)$entries[$r['entry_id']][]=$r;
    foreach($entries as $lines){$cash=0.0;$counter=[];foreach($lines as $r){$raw=(float)$r['debit']-(float)$r['credit'];if((int)$r['is_cash_account']===1)$cash+=$raw;else $counter[]=$r;}
        if(abs($cash)<.0005)continue;$weight=array_sum(array_map(fn($r)=>abs((float)$r['debit']-(float)$r['credit']),$counter));if($weight<.0005){$totals['UNCLASSIFIED']+=$cash;continue;}
        foreach($counter as $r){$share=$cash*(abs((float)$r['debit']-(float)$r['credit'])/$weight);$code=$r['override_code']?:($r['cash_flow_line_code']?:auto_cash_flow_code((string)$r['code'],$share));$totals[$code]=($totals[$code]??0)+$share;if($code==='UNCLASSIFIED')$unclassified[]=$r+['cash_effect'=>$share];}
    }
    $inventoryChange=guide_amount('131',$to,null,'debit')-guide_amount('131',(new DateTimeImmutable($from))->modify('-1 day')->format('Y-m-d'),null,'debit');$totals['OP_INVENTORY_CHANGE']=-$inventoryChange;
    foreach($totals as $k=>$x)$totals[$k]=round($x,3);
    $opening=guide_amount('134',(new DateTimeImmutable($from))->modify('-1 day')->format('Y-m-d'));
    $closing=guide_amount('134',$to);$operating=0;$investing=0;$financing=0;foreach($defs as $k=>$d){if($d[0]==='operating')$operating+=$totals[$k];elseif($d[0]==='investing')$investing+=$totals[$k];elseif($d[0]==='financing')$financing+=$totals[$k];}
    return compact('defs','totals','opening','closing','operating','investing','financing','unclassified')+['net'=>$operating+$investing+$financing,'fx'=>$totals['FX_EFFECT']];
}

function equity_matrix(string $from,string $to): array
{
    $cols=['261'=>'رأس المال (عدا 2615)','262'=>'رأس المال الإضافي','263'=>'الأرباح المحتجزة','264'=>'الدخل الشامل الآخر','265'=>'التغير بالسياسات والتقديرات وتصحيح الأخطاء','2615'=>'الحصص خارج السيطرة'];
    $opening=[];$closing=[];foreach($cols as $c=>$l){$opening[$c]=guide_amount($c,(new DateTimeImmutable($from))->modify('-1 day')->format('Y-m-d'),null,'credit');$closing[$c]=guide_amount($c,$to,null,'credit');}
    $types=['profit'=>'ربح (خسارة) الفترة','dividend'=>'توزيعات أرباح','reserve'=>'التغير في الاحتياطي','capital'=>'التغير في رأس المال','accumulated_loss_amortization'=>'إطفاء خسائر متراكمة','policy_change'=>'صافي التغير بالسياسات المحاسبية والتقديرات وتصحيح الأخطاء','nci'=>'صافي الزيادة في حقوق الأقلية','oci'=>'الدخل الشامل الآخر','other'=>'حركات أخرى'];
    $movements=[];foreach($types as $t=>$l){$movements[$t]=array_fill_keys(array_keys($cols),0.0);}
    $sql="SELECT je.equity_movement_type,a.code,SUM(jl.credit-jl.debit) amount FROM journal_entries je JOIN journal_lines jl ON jl.journal_entry_id=je.id JOIN accounts a ON a.id=jl.account_id WHERE je.company_id=? AND ".posted_status_condition('je')." AND je.entry_date BETWEEN ? AND ? AND a.code LIKE '26%' GROUP BY je.equity_movement_type,a.code";
    $stmt=db()->prepare($sql);$stmt->execute([company_id(),$from,$to]);foreach($stmt->fetchAll() as $r){$t=$r['equity_movement_type'];if(!isset($movements[$t]))$t='other';foreach(array_keys($cols) as $c)if(str_starts_with($r['code'],$c)){$movements[$t][$c]+=(float)$r['amount'];break;}}
    return compact('cols','opening','closing','types','movements');
}

function compliance_check_items(): array
{
    return [
        ['FRAME-01','الإطار والعرض العادل','توثيق أساس الاستحقاق والاستمرارية والأهمية النسبية وعدم المقاصة.'],
        ['IFRS1-01','قائمة المركز المالي الافتتاحية','إعداد قائمة مركز مالي افتتاحية في تاريخ التحول.'],
        ['IFRS1-02','مطابقة حقوق الملكية','مطابقة حقوق الملكية وفق المبادئ السابقة مع IFRS.'],
        ['IFRS1-03','مطابقة الدخل الشامل','مطابقة إجمالي الدخل الشامل وفق المبادئ السابقة مع IFRS.'],
        ['IAS1-01','القوائم المقارنة','عرض السنة الحالية والسنة السابقة وبداية السنة السابقة عند اللزوم.'],
        ['IAS1-02','قائمة المركز المالي','مطابقة بنود وأرقام الدليل المحاسبي.'],
        ['IAS1-03','الدخل الشامل','عرض الربح أو الخسارة والدخل الشامل الآخر والتخصيصات.'],
        ['IAS1-04','التغيرات في حقوق الملكية','عرض حركات كل مكون من مكونات حقوق الملكية.'],
        ['IAS7-01','التدفقات النقدية المباشرة','توثيق المقبوضات والمدفوعات والتصنيف التشغيلي والاستثماري والتمويلي.'],
        ['NOTES-01','السياسات المحاسبية','توثيق السياسات المحاسبية المهمة لكل معيار قابل للتطبيق.'],
        ['NOTES-02','الإيضاحات','إعداد الملاحظات والإفصاحات ذات الصلة والمقارنة.'],
        ['CONTROL-01','سجل التدقيق','توثيق الإنشاء والتعديل والترحيل وإلغاء الترحيل والاعتماد.'],
        ['CONTROL-02','إقفال الفترة','عدم الإقفال مع وجود مسودات أو حسابات مؤقتة غير مقفلة.'],
        ['IAS2-01','المخزون','قياس المخزون بالتكلفة أو صافي القيمة القابلة للتحقق أيهما أقل.'],
        ['IAS16-01','الأصول الثابتة','سجل أصل، العمر، طريقة الاندثار، الانخفاض وإعادة التقييم.'],
        ['IFRS9-01','الأدوات المالية','توثيق التصنيف والقياس وخسائر الائتمان المتوقعة.'],
        ['IFRS15-01','عقود العملاء','توثيق العقود والتزامات الأداء والإيراد.'],
        ['IFRS16-01','عقود الإيجار','توثيق أصل حق الاستخدام والتزام الإيجار.'],
        ['IAS37-01','المخصصات','توثيق المخصصات والالتزامات والأصول المحتملة.'],
        ['IAS24-01','الأطراف ذات العلاقة','توثيق الأطراف والمعاملات والأرصدة.'],
    ];
}

function ensure_checklist_for_period(?int $periodId): void
{
    foreach(compliance_check_items() as [$code,$category,$title]){
        $stmt=db()->prepare("INSERT IGNORE INTO compliance_checklist(company_id,period_id,checklist_code,title_ar,category,status) VALUES(?,?,?,?,?,'not_started')");$stmt->execute([company_id(),$periodId,$code,$title,$category]);
    }
}

function compliance_summary(?int $periodId): array
{
    ensure_checklist_for_period($periodId);$stmt=db()->prepare('SELECT status,COUNT(*) c FROM compliance_checklist WHERE company_id=? AND period_id <=> ? GROUP BY status');$stmt->execute([company_id(),$periodId]);$counts=['not_started'=>0,'in_progress'=>0,'complete'=>0,'not_applicable'=>0];foreach($stmt->fetchAll() as $r)$counts[$r['status']]=(int)$r['c'];$den=$counts['not_started']+$counts['in_progress']+$counts['complete'];$score=$den?round(100*$counts['complete']/$den,1):0;return compact('counts','score');
}

function register_type_labels(): array
{
    return [
        'revenue_contract'=>['IFRS15','عقود العملاء والتزامات الأداء'], 'lease'=>['IFRS16','عقود الإيجار وأصول حق الاستخدام'],
        'financial_instrument'=>['IFRS9','الأدوات المالية وخسائر الائتمان المتوقعة'], 'provision'=>['IAS37','المخصصات والالتزامات المحتملة'],
        'government_grant'=>['IAS20','المنح والمساعدات الحكومية'], 'employee_benefit'=>['IAS19','منافع الموظفين'],
        'related_party'=>['IAS24','الأطراف ذات العلاقة'], 'income_tax'=>['IAS12','ضرائب الدخل والضريبة المؤجلة'],
        'fair_value'=>['IFRS13','قياسات القيمة العادلة'], 'segment'=>['IFRS8','القطاعات التشغيلية'],
        'foreign_currency'=>['IAS21','العملات الأجنبية وفروقات الصرف'], 'subsequent_event'=>['IAS10','الأحداث بعد فترة التقرير'],
        'agriculture'=>['IAS41','الأصول الحيوية والنشاط الزراعي'], 'held_for_sale'=>['IFRS5','الأصول المحتفظ بها للبيع والعمليات المتوقفة'],
        'borrowing_cost'=>['IAS23','تكاليف الاقتراض المؤهلة للرسملة'], 'joint_arrangement'=>['IFRS11','الترتيبات والمشروعات المشتركة'],
    ];
}
