<?php
declare(strict_types=1);

$configFile = __DIR__ . '/../config.php';
$defaultConfig = [
    'installed' => false,
    'db_host' => '127.0.0.1',
    'db_port' => '3306',
    'db_name' => 'ifrs_accounting',
    'db_user' => 'root',
    'db_pass' => '',
    'app_name' => 'نظام الميزان المحاسبي',
    'timezone' => 'Asia/Baghdad',
    'app_key' => '',
    'version' => '2.7.9.7',
];
if (is_file($configFile)) {
    $loadedConfig = require $configFile;
    $GLOBALS['app_config'] = is_array($loadedConfig) ? array_replace($defaultConfig, $loadedConfig) : $defaultConfig;
} else {
    $GLOBALS['app_config'] = $defaultConfig;
}
// هوية الإصدار جزء من ملفات التطبيق ولا تعتمد على config.php القديم عند التحديث.
$GLOBALS['app_config']['app_name'] = 'نظام الميزان المحاسبي';
$GLOBALS['app_config']['version'] = '2.7.9.7';

date_default_timezone_set((string)($GLOBALS['app_config']['timezone'] ?? 'Asia/Baghdad'));
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('IFRSACCSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

// In multi-institution mode the selected institution overrides only db_name.
// Host/user/password remain central so one installation can safely switch between
// completely separate databases without duplicating the application files.
if (isset($_SESSION['institution_db_name']) && is_string($_SESSION['institution_db_name'])
    && preg_match('/^[A-Za-z0-9_]{1,64}$/', $_SESSION['institution_db_name'])) {
    $GLOBALS['app_config']['db_name'] = $_SESSION['institution_db_name'];
}

function app_config(?string $key = null, mixed $default = null): mixed
{
    $cfg = $GLOBALS['app_config'] ?? [];
    return $key === null ? $cfg : ($cfg[$key] ?? $default);
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $cfg = app_config();
    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        $cfg['db_host'] ?? '127.0.0.1',
        $cfg['db_port'] ?? '3306',
        $cfg['db_name'] ?? 'ifrs_accounting'
    );
    $pdo = new PDO($dsn, (string)($cfg['db_user'] ?? 'root'), (string)($cfg['db_pass'] ?? ''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
    ]);
    return $pdo;
}

function e(mixed $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $page = 'dashboard', array $params = []): string
{
    return 'index.php?' . http_build_query(['page' => $page] + $params);
}

function redirect(string $location): never
{
    header('Location: ' . $location);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $posted = $_POST['csrf'] ?? '';
    $stored = $_SESSION['csrf'] ?? '';
    if (!is_string($posted) || !is_string($stored) || $stored === '' || !hash_equals($stored, $posted)) {
        http_response_code(419);
        throw new RuntimeException('انتهت صلاحية الجلسة أو رمز الحماية غير صالح. أعد تحميل الصفحة وحاول مرة أخرى.');
    }
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function pull_flashes(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return is_array($items) ? $items : [];
}

function old_input_store(array $input): void
{
    unset($input['csrf'], $input['password'], $input['admin_pass'], $input['db_pass']);
    $_SESSION['old_input'] = $input;
}

function old_input_pull(): array
{
    $data = $_SESSION['old_input'] ?? [];
    unset($_SESSION['old_input']);
    return is_array($data) ? $data : [];
}

function user(): ?array
{
    $u = $_SESSION['user'] ?? null;
    return is_array($u) ? $u : null;
}

function company_id(): int
{
    return (int)(user()['company_id'] ?? 0);
}

function require_auth(): void
{
    if (!user()) {
        redirect(url('login'));
    }
}

function require_role(array|string $roles): void
{
    require_auth();
    $roles = (array)$roles;
    if (!in_array((string)user()['role'], $roles, true)) {
        http_response_code(403);
        throw new RuntimeException('ليس لديك صلاحية لتنفيذ هذا الإجراء.');
    }
}

function table_exists(string $table): bool
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=? AND table_name=?');
    $stmt->execute([(string)app_config('db_name'), $table]);
    return (int)$stmt->fetchColumn() > 0;
}

function column_exists(string $table, string $column): bool
{
    $stmt = db()->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=? AND table_name=? AND column_name=?');
    $stmt->execute([(string)app_config('db_name'), $table, $column]);
    return (int)$stmt->fetchColumn() > 0;
}

function schema_is_current(): bool
{
    try {
        return table_exists('document_sequences')
            && table_exists('schema_migrations')
            && table_exists('standards_library')
            && table_exists('fixed_assets')
            && table_exists('compliance_checklist')
            && table_exists('report_account_function_map')
            && table_exists('report_period_values')
            && column_exists('journal_entries', 'version_no')
            && column_exists('journal_entries', 'origin_standard')
            && column_exists('journal_entries', 'document_series')
            && column_exists('journal_lines', 'cash_flow_line_code')
            && column_exists('cost_centers', 'functional_report_code')
            && column_exists('cash_flow_overrides', 'allocated_amount')
            && column_exists('audit_logs', 'before_json');
    } catch (Throwable) {
        return false;
    }
}

function company(bool $refresh = false): array
{
    if ($refresh || !isset($GLOBALS['company_cache'])) {
        $stmt = db()->prepare('SELECT * FROM companies WHERE id=?');
        $stmt->execute([company_id()]);
        $GLOBALS['company_cache'] = $stmt->fetch() ?: [];
    }
    return $GLOBALS['company_cache'];
}

function money(float|int|string|null $amount): string
{
    $places = (int)(company()['decimal_places'] ?? 0);
    return number_format((float)$amount, $places, '.', ',');
}

// التاريخ في المستندات: يوم/شهر/سنة، ويُقرأ من اليمين إلى اليسار داخل الصفحات العربية.
// نغلّف كل جزء بمحدّدات العزل (U+2066 … U+2069) حتى يضع المتصفح اليوم على اليمين
// بدل أن يدمج الأرقام والشرطات في مقطع واحد يُعرض من اليسار إلى اليمين.
function doc_date(?string $date, string $separator = '/', bool $isolate = true): string
{
    $date = trim((string)$date);
    if ($date === '') return '';
    $time = strtotime($date);
    if ($time === false) return $date;
    $parts = [date('d', $time), date('m', $time), date('Y', $time)];
    if (!$isolate) return implode($separator, $parts);
    $wrap = static fn(string $part): string => "\u{2066}" . $part . "\u{2069}";
    return implode($separator, array_map($wrap, $parts));
}

// الصيغة المجرّدة (بلا محدّدات) لحقول الإدخال والمقارنة.
function doc_date_plain(?string $date, string $separator = '/'): string
{
    return doc_date($date, $separator, false);
}

function voucher_amount_join(mixed $dinars, mixed $fils): string
{
    $fils = trim((string)$fils);
    $fils = str_replace(['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'], ['0','1','2','3','4','5','6','7','8','9'], $fils);
    $fils = preg_replace('/\D+/', '', $fils) ?? '';
    if ($fils === '') return (string)$dinars;
    $dinarPart = trim((string)$dinars);
    if ($dinarPart === '') $dinarPart = '0';
    return $dinarPart . '.' . str_pad(substr($fils, 0, 3), 3, '0', STR_PAD_RIGHT);
}

function parse_amount(mixed $value): float
{
    $value = trim((string)$value);
    if ($value === '') {
        return 0.0;
    }
    $value = str_replace([',', ' ', '٬'], '', $value);
    $value = str_replace('٫', '.', $value);
    if (!is_numeric($value)) {
        throw new RuntimeException('يوجد مبلغ غير صالح ضمن تفاصيل المستند.');
    }
    $number = round((float)$value, 3);
    if ($number < 0) {
        throw new RuntimeException('لا يسمح بإدخال مبالغ سالبة؛ استخدم الطرف المحاسبي المقابل.');
    }
    return $number;
}

function valid_date(string $date): bool
{
    $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    $errors = DateTimeImmutable::getLastErrors();
    return $parsed instanceof DateTimeImmutable
        && ($errors === false || ((int)$errors['warning_count'] === 0 && (int)$errors['error_count'] === 0))
        && $parsed->format('Y-m-d') === $date;
}

function json_value(mixed $value): ?string
{
    if ($value === null || $value === [] || $value === '') {
        return null;
    }
    return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
}

function log_exception(Throwable $error): void
{
    $dir = __DIR__ . '/../storage/logs';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $line = sprintf("[%s] %s: %s in %s:%d\n%s\n\n", date('c'), get_class($error), $error->getMessage(), $error->getFile(), $error->getLine(), $error->getTraceAsString());
    @file_put_contents($dir . '/app.log', $line, FILE_APPEND | LOCK_EX);
}

function audit(
    string $action,
    string $entityType,
    string|int|null $entityId = null,
    mixed $before = null,
    mixed $after = null,
    array $details = [],
    ?PDO $pdo = null
): void {
    if (!user()) {
        return;
    }
    $pdo ??= db();
    $hasExtended = column_exists('audit_logs', 'before_json');
    if ($hasExtended) {
        $stmt = $pdo->prepare(
            'INSERT INTO audit_logs(company_id,user_id,action,entity_type,entity_id,before_json,after_json,details_json,ip_address,user_agent)
             VALUES(?,?,?,?,?,?,?,?,?,?)'
        );
        $stmt->execute([
            company_id(), user()['id'], $action, $entityType, $entityId,
            json_value($before), json_value($after), json_value($details),
            $_SERVER['REMOTE_ADDR'] ?? null,
            mb_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        ]);
    } else {
        $stmt = $pdo->prepare(
            'INSERT INTO audit_logs(company_id,user_id,action,entity_type,entity_id,details_json,ip_address)
             VALUES(?,?,?,?,?,?,?)'
        );
        $stmt->execute([
            company_id(), user()['id'], $action, $entityType, $entityId,
            json_value(['before' => $before, 'after' => $after, 'details' => $details]),
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    }
}

function fiscal_period_for(string $date, ?PDO $pdo = null): ?array
{
    if (!valid_date($date)) {
        throw new RuntimeException('التاريخ المحدد غير صالح.');
    }
    $pdo ??= db();
    $stmt = $pdo->prepare(
        'SELECT * FROM fiscal_periods WHERE company_id=? AND ? BETWEEN start_date AND end_date ORDER BY start_date DESC LIMIT 1'
    );
    $stmt->execute([company_id(), $date]);
    return $stmt->fetch() ?: null;
}

function assert_open_period(string $date, ?PDO $pdo = null): array
{
    $period = fiscal_period_for($date, $pdo);
    if (!$period) {
        throw new RuntimeException('لا توجد فترة مالية معرفة للتاريخ المحدد. أضف الفترة من شاشة الفترات المالية.');
    }
    if ($period['status'] !== 'open') {
        throw new RuntimeException('الفترة المالية المحددة مغلقة. أعد فتحها بصلاحية المدير قبل التعديل أو الترحيل.');
    }
    return $period;
}

function source_prefix(string $source): string
{
    return match ($source) {
        'receipt' => 'RV',
        'payment' => 'PV',
        'opening' => 'OB',
        'adjustment' => 'ADJ',
        'closing' => 'CL',
        'reversal' => 'REV',
        default => 'JV',
    };
}

function source_label(string $source): string
{
    return [
        'manual' => 'قيد يومي',
        'opening' => 'قيد افتتاحي',
        'adjustment' => 'قيد تسوية',
        'receipt' => 'سند قبض',
        'payment' => 'سند صرف',
        'closing' => 'قيد إقفال',
        'reversal' => 'قيد عكسي',
    ][$source] ?? $source;
}

function status_label(string $status): string
{
    return [
        'draft' => 'مسودة',
        'posted' => 'مرحل',
        'reversed' => 'معكوس',
        'cancelled' => 'ملغى',
        'open' => 'مفتوحة',
        'closed' => 'مغلقة',
    ][$status] ?? $status;
}

function status_badge(string $status): string
{
    return '<span class="badge badge-' . e($status) . '">' . e(status_label($status)) . '</span>';
}

function document_series(string $source): string
{
    return match ($source) {
        'payment' => 'PAYMENT',
        'receipt' => 'RECEIPT',
        default => 'JOURNAL',
    };
}

function assert_voucher_no_available(PDO $pdo, string $voucherNo, string $source, ?int $ignoreId = null): void
{
    $series = document_series($source);
    $sql = 'SELECT id FROM journal_entries WHERE company_id=? AND document_series=? AND voucher_no=?';
    $params = [company_id(), $series, $voucherNo];
    if ($ignoreId !== null) { $sql .= ' AND id<>?'; $params[] = $ignoreId; }
    $stmt = $pdo->prepare($sql . ' LIMIT 1');
    $stmt->execute($params);
    if ($stmt->fetchColumn() !== false) {
        $label = $series === 'PAYMENT' ? 'مستند الصرف' : ($series === 'RECEIPT' ? 'سند القبض' : 'مستند القيد');
        throw new RuntimeException('رقم ' . $label . ' ' . $voucherNo . ' مستعمل مسبقاً ضمن نفس التسلسل.');
    }
}

/**
 * يعيد أول رقم موجب غير مستخدم فعلياً داخل السلسلة.
 * بهذا الأسلوب لا يبقى أثر عددي للحذف النهائي، كما تُملأ الفجوات الناتجة عن
 * مستند محذوف أو رقم تم نسيان إدخاله (مثلاً 1..9 ثم 11..20 => الرقم التالي 10).
 */
function first_available_document_number(PDO $pdo, string $sequenceKey): int
{
    $stmt = $pdo->prepare(
        "SELECT CAST(voucher_no AS UNSIGNED) AS n
         FROM journal_entries
         WHERE company_id=?
           AND document_series=?
           AND voucher_no REGEXP '^[0-9]+$'
           AND CAST(voucher_no AS UNSIGNED) > 0
         ORDER BY CAST(voucher_no AS UNSIGNED) ASC"
    );
    $stmt->execute([company_id(), $sequenceKey]);

    $expected = 1;
    while (($value = $stmt->fetchColumn()) !== false) {
        $n = (int)$value;
        if ($n < $expected) {
            continue;
        }
        if ($n === $expected) {
            $expected++;
            continue;
        }
        // وجدنا فجوة: expected غير مستخدم بينما الرقم الحالي أكبر منه.
        break;
    }
    return $expected;
}

/**
 * مزامنة عداد السلسلة مع المستندات الموجودة فعلياً بعد الحذف النهائي.
 * last_number يصبح أكبر رقم موجود حالياً (أو صفر إذا أصبحت السلسلة فارغة).
 */
function sync_document_sequence(PDO $pdo, string $sequenceKey): void
{
    $sequenceYear = 0;
    $stmt = $pdo->prepare(
        "SELECT COALESCE(MAX(CAST(voucher_no AS UNSIGNED)),0)
         FROM journal_entries
         WHERE company_id=? AND document_series=? AND voucher_no REGEXP '^[0-9]+$'"
    );
    $stmt->execute([company_id(), $sequenceKey]);
    $actualMax = max(0, (int)$stmt->fetchColumn());

    $pdo->prepare(
        'INSERT INTO document_sequences(company_id,prefix,sequence_year,last_number)
         VALUES(?,?,?,?)
         ON DUPLICATE KEY UPDATE last_number=VALUES(last_number)'
    )->execute([company_id(), $sequenceKey, $sequenceYear, $actualMax]);
}

function next_document_no(PDO $pdo, string $source, string $date): string
{
    // تسلسلات مستقلة: القيد / الصرف / القبض.
    // لا نعتمد على قيمة last_number وحدها؛ الرقم يصدر من المستندات الموجودة فعلياً
    // حتى لا يبقى أثر للحذف النهائي وحتى يمكن ملء أي رقم مفقود داخل التسلسل.
    $sequenceKey = document_series($source);
    $sequenceYear = 0;

    $lockStmt = $pdo->prepare(
        'SELECT id FROM document_sequences WHERE company_id=? AND prefix=? AND sequence_year=? FOR UPDATE'
    );
    $lockStmt->execute([company_id(), $sequenceKey, $sequenceYear]);
    $row = $lockStmt->fetch();

    if (!$row) {
        try {
            $pdo->prepare(
                'INSERT INTO document_sequences(company_id,prefix,sequence_year,last_number) VALUES(?,?,?,0)'
            )->execute([company_id(), $sequenceKey, $sequenceYear]);
        } catch (PDOException $e) {
            if ((string)$e->getCode() !== '23000') {
                throw $e;
            }
        }
        // قفل الصف بعد إنشائه (أو بعد أن يكون قد أنشأه طلب متزامن).
        $lockStmt->execute([company_id(), $sequenceKey, $sequenceYear]);
        $row = $lockStmt->fetch();
        if (!$row) {
            throw new RuntimeException('تعذر تهيئة تسلسل أرقام المستندات.');
        }
    }

    $next = first_available_document_number($pdo, $sequenceKey);
    $pdo->prepare('UPDATE document_sequences SET last_number=? WHERE id=?')
        ->execute([$next, (int)$row['id']]);

    return (string)$next;
}

function account_options(bool $postableOnly = true, ?string $type = null): array
{
    $sql = 'SELECT id,code,name_ar,account_type,is_cash_account,normal_balance FROM accounts WHERE company_id=? AND is_active=1';
    $params = [company_id()];
    if ($postableOnly) {
        $sql .= ' AND is_postable=1';
    }
    if ($type !== null) {
        $sql .= ' AND account_type=?';
        $params[] = $type;
    }
    $sql .= ' ORDER BY code';
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function cost_center_options(): array
{
    $stmt = db()->prepare('SELECT id,code,name_ar FROM cost_centers WHERE company_id=? AND is_active=1 ORDER BY code');
    $stmt->execute([company_id()]);
    return $stmt->fetchAll();
}

function party_options(): array
{
    $stmt = db()->prepare('SELECT id,code,name_ar,party_type FROM parties WHERE company_id=? AND is_active=1 ORDER BY name_ar');
    $stmt->execute([company_id()]);
    return $stmt->fetchAll();
}

function recalculate_account_levels(int $accountId, int $level, ?PDO $pdo = null): void
{
    $pdo ??= db();
    $pdo->prepare('UPDATE accounts SET level_no=? WHERE id=? AND company_id=?')->execute([$level, $accountId, company_id()]);
    $stmt = $pdo->prepare('SELECT id FROM accounts WHERE parent_id=? AND company_id=?');
    $stmt->execute([$accountId, company_id()]);
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $childId) {
        recalculate_account_levels((int)$childId, $level + 1, $pdo);
    }
}

function journal_snapshot(int $id, ?PDO $pdo = null): ?array
{
    $pdo ??= db();
    $stmt = $pdo->prepare('SELECT * FROM journal_entries WHERE id=? AND company_id=?');
    $stmt->execute([$id, company_id()]);
    $entry = $stmt->fetch();
    if (!$entry) {
        return null;
    }
    $stmt = $pdo->prepare(
        'SELECT jl.*,a.code account_code,a.name_ar account_name,cc.code cost_center_code,cc.name_ar cost_center_name,
                p.code party_code,p.name_ar party_name
         FROM journal_lines jl
         JOIN accounts a ON a.id=jl.account_id
         LEFT JOIN cost_centers cc ON cc.id=jl.cost_center_id
         LEFT JOIN parties p ON p.id=jl.party_id
         WHERE jl.journal_entry_id=? ORDER BY jl.line_order,jl.id'
    );
    $stmt->execute([$id]);
    $entry['lines'] = $stmt->fetchAll();
    return $entry;
}

function validate_journal_lines(array $lines, PDO $pdo): array
{
    $clean = [];
    $totalDebit = 0.0;
    $totalCredit = 0.0;
    $accountCheck = $pdo->prepare(
        'SELECT id FROM accounts WHERE id=? AND company_id=? AND is_active=1 AND is_postable=1'
    );
    $ccCheck = $pdo->prepare('SELECT id FROM cost_centers WHERE id=? AND company_id=? AND is_active=1');
    $partyCheck = $pdo->prepare('SELECT id FROM parties WHERE id=? AND company_id=? AND is_active=1');
    $baseCurrency = strtoupper((string)(company()['currency_code'] ?? 'IQD'));
    $validCashCodes = function_exists('cash_flow_line_definitions') ? array_keys(cash_flow_line_definitions()) : [];

    foreach ($lines as $index => $line) {
        $accountId = (int)($line['account_id'] ?? 0);
        $debit = parse_amount($line['debit'] ?? 0);
        $credit = parse_amount($line['credit'] ?? 0);
        if ($accountId === 0 && $debit === 0.0 && $credit === 0.0) {
            continue;
        }
        if ($accountId <= 0) {
            throw new RuntimeException('يرجى اختيار الحساب في جميع الأسطر التي تحتوي على مبالغ.');
        }
        if (($debit > 0 && $credit > 0) || ($debit <= 0 && $credit <= 0)) {
            throw new RuntimeException('كل سطر محاسبي يجب أن يحتوي مبلغاً في المدين أو الدائن فقط.');
        }
        $accountCheck->execute([$accountId, company_id()]);
        if (!$accountCheck->fetchColumn()) {
            throw new RuntimeException('أحد الحسابات المختارة غير فعال أو غير قابل للترحيل.');
        }
        $costCenterId = !empty($line['cost_center_id']) ? (int)$line['cost_center_id'] : null;
        if ($costCenterId !== null) {
            $ccCheck->execute([$costCenterId, company_id()]);
            if (!$ccCheck->fetchColumn()) throw new RuntimeException('أحد مراكز الكلفة غير صالح.');
        }
        $partyId = !empty($line['party_id']) ? (int)$line['party_id'] : null;
        if ($partyId !== null) {
            $partyCheck->execute([$partyId, company_id()]);
            if (!$partyCheck->fetchColumn()) throw new RuntimeException('إحدى الجهات المرتبطة بالقيد غير صالحة.');
        }
        $currency = strtoupper(trim((string)($line['currency_code'] ?? $baseCurrency)));
        if ($currency === '') $currency = $baseCurrency;
        if (!preg_match('/^[A-Z]{3,10}$/', $currency)) throw new RuntimeException('رمز العملة في أحد أسطر القيد غير صالح.');
        $rateRaw = trim((string)($line['exchange_rate'] ?? '1'));
        $rate = $rateRaw === '' ? 1.0 : (float)$rateRaw;
        if (!is_finite($rate) || $rate <= 0) throw new RuntimeException('سعر الصرف يجب أن يكون أكبر من صفر.');
        $foreignAmount = parse_amount($line['foreign_amount'] ?? 0);
        if ($currency === $baseCurrency) $rate = 1.0;
        $cashFlowCode = trim((string)($line['cash_flow_line_code'] ?? ''));
        if ($cashFlowCode !== '' && $validCashCodes && !in_array($cashFlowCode, $validCashCodes, true)) {
            throw new RuntimeException('تصنيف التدفق النقدي التفصيلي غير صالح.');
        }
        $clean[] = [
            'account_id' => $accountId,
            'cost_center_id' => $costCenterId,
            'party_id' => $partyId,
            'currency_code' => $currency,
            'exchange_rate' => round($rate, 8),
            'foreign_amount' => $foreignAmount,
            'cash_flow_line_code' => $cashFlowCode !== '' ? $cashFlowCode : null,
            'line_description' => trim((string)($line['line_description'] ?? '')),
            'debit' => $debit,
            'credit' => $credit,
            'line_order' => count($clean) + 1,
        ];
        $totalDebit += $debit;
        $totalCredit += $credit;
    }

    if (count($clean) < 2) throw new RuntimeException('يجب أن يحتوي المستند على طرفين محاسبيين على الأقل.');
    if ($totalDebit <= 0 || abs($totalDebit - $totalCredit) > 0.0005) {
        throw new RuntimeException('المستند غير متوازن؛ يجب أن يساوي إجمالي المدين إجمالي الدائن.');
    }
    return ['lines' => $clean, 'debit' => round($totalDebit, 3), 'credit' => round($totalCredit, 3)];
}

function save_journal_document(
    array $header,
    array $lines,
    ?int $id = null,
    ?int $expectedVersion = null,
    bool $postAfter = false
): array {
    $allowedSources = ['manual','opening','adjustment','receipt','payment','closing'];
    $source = (string)($header['source_type'] ?? 'manual');
    if (!in_array($source, $allowedSources, true)) throw new RuntimeException('نوع المستند المحاسبي غير صالح.');
    $series = document_series($source);
    $date = trim((string)($header['entry_date'] ?? ''));
    $description = trim((string)($header['description'] ?? ''));
    $reference = trim((string)($header['reference_no'] ?? ''));
    $manualVoucherNo = trim((string)($header['voucher_no'] ?? ''));
    if ($manualVoucherNo !== '' && mb_strlen($manualVoucherNo) > 50) {
        throw new RuntimeException('رقم المستند طويل جداً (الحد الأقصى 50 خانة).');
    }
    $originStandard = strtoupper(trim((string)($header['origin_standard'] ?? '')));
    $equityType = (string)($header['equity_movement_type'] ?? 'none');
    $equityAllowed = ['none','profit','dividend','reserve','capital','accumulated_loss_amortization','policy_change','nci','oci','other'];
    if (!in_array($equityType, $equityAllowed, true)) throw new RuntimeException('نوع حركة حقوق الملكية غير صالح.');
    if (!valid_date($date)) throw new RuntimeException('تاريخ المستند غير صالح.');
    if ($description === '') throw new RuntimeException('يرجى إدخال بيان واضح للمستند.');

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $period = assert_open_period($date, $pdo);
        $validated = validate_journal_lines($lines, $pdo);
        $before = null;
        $isUpdate = $id !== null && $id > 0;
        if ($isUpdate) {
            $stmt = $pdo->prepare('SELECT * FROM journal_entries WHERE id=? AND company_id=? FOR UPDATE');
            $stmt->execute([$id, company_id()]);
            $old = $stmt->fetch();
            if (!$old) throw new RuntimeException('المستند المطلوب تعديله غير موجود.');
            if ($old['status'] !== 'draft') throw new RuntimeException('يجب إلغاء ترحيل المستند قبل تعديله.');
            if ($expectedVersion !== null && (int)$old['version_no'] !== $expectedVersion) {
                throw new RuntimeException('تم تعديل المستند من مستخدم آخر. أعد فتحه قبل حفظ التغييرات.');
            }
            $before = journal_snapshot($id, $pdo);
            $oldSeries = (string)($old['document_series'] ?? document_series((string)$old['source_type']));
            // إذا تغيّر نوع السلسلة (مثلاً من صرف إلى قبض) يُمنح المستند رقماً من السلسلة الجديدة.
            if ($manualVoucherNo !== '') {
                $voucherNo = $manualVoucherNo;
            } elseif ($oldSeries !== $series) {
                $voucherNo = next_document_no($pdo, $source, $date);
            } else {
                $voucherNo = (string)$old['voucher_no'];
            }
            if ($voucherNo !== (string)$old['voucher_no'] || $oldSeries !== $series) {
                assert_voucher_no_available($pdo, $voucherNo, $source, $id);
            }
            $stmt = $pdo->prepare(
                "UPDATE journal_entries SET period_id=?,document_series=?,voucher_no=?,entry_date=?,reference_no=?,description=?,source_type=?,origin_standard=?,equity_movement_type=?,approval_status='not_required',submitted_by=NULL,submitted_at=NULL,approved_by=NULL,approved_at=NULL,approval_notes=NULL,version_no=version_no+1,last_modified_by=? WHERE id=? AND company_id=?"
            );
            $stmt->execute([$period['id'],$series,$voucherNo,$date,$reference!==''?$reference:null,$description,$source,$originStandard!==''?$originStandard:null,$equityType,user()['id'],$id,company_id()]);
            $pdo->prepare('DELETE FROM journal_lines WHERE journal_entry_id=?')->execute([$id]);
        } else {
            // الترقيم تلقائي ومستقل لكل سلسلة. يبقى الإدخال اليدوي مدعوماً للبيانات القديمة أو حالات خاصة.
            if ($manualVoucherNo !== '') {
                $voucherNo = $manualVoucherNo;
                assert_voucher_no_available($pdo, $voucherNo, $source, null);
            } else {
                $voucherNo = next_document_no($pdo, $source, $date);
            }
            $stmt = $pdo->prepare(
                "INSERT INTO journal_entries(company_id,period_id,document_series,voucher_no,entry_date,reference_no,description,source_type,origin_standard,equity_movement_type,status,created_by,last_modified_by) VALUES(?,?,?,?,?,?,?,?,?,?,'draft',?,?)"
            );
            $stmt->execute([company_id(),$period['id'],$series,$voucherNo,$date,$reference!==''?$reference:null,$description,$source,$originStandard!==''?$originStandard:null,$equityType,user()['id'],user()['id']]);
            $id = (int)$pdo->lastInsertId();
        }

        $insert = $pdo->prepare(
            'INSERT INTO journal_lines(journal_entry_id,account_id,cost_center_id,party_id,currency_code,exchange_rate,foreign_amount,cash_flow_line_code,line_description,debit,credit,line_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)'
        );
        foreach ($validated['lines'] as $line) {
            $insert->execute([$id,$line['account_id'],$line['cost_center_id'],$line['party_id'],$line['currency_code'],$line['exchange_rate'],$line['foreign_amount'],$line['cash_flow_line_code'],$line['line_description']!==''?$line['line_description']:$description,$line['debit'],$line['credit'],$line['line_order']]);
        }
        $after = journal_snapshot((int)$id, $pdo);
        audit($isUpdate?'update':'create','journal_entry',(int)$id,$before,$after,['total_debit'=>$validated['debit'],'voucher_no'=>$voucherNo,'origin_standard'=>$originStandard],$pdo);
        $pdo->commit();

        $posted = false;
        $pendingApproval = false;
        if ($postAfter) {
            $needsApproval = function_exists('setting_get') && setting_get('posting_requires_approval','0') === '1' && (string)user()['role'] !== 'admin';
            if ($needsApproval) {
                db()->prepare("UPDATE journal_entries SET approval_status='pending',submitted_by=?,submitted_at=NOW() WHERE id=? AND company_id=? AND status='draft'")->execute([user()['id'],$id,company_id()]);
                audit('submit_approval','journal_entry',(int)$id,null,['automatic'=>true]);
                $pendingApproval = true;
            } else {
                post_journal((int)$id);
                $posted = true;
            }
        }
        return ['id'=>(int)$id,'voucher_no'=>$voucherNo,'posted'=>$posted,'pending_approval'=>$pendingApproval];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function post_journal(int $id): void
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT * FROM journal_entries WHERE id=? AND company_id=? FOR UPDATE');
        $stmt->execute([$id, company_id()]);
        $entry = $stmt->fetch();
        if (!$entry) {
            throw new RuntimeException('المستند غير موجود.');
        }
        if ($entry['status'] !== 'draft') {
            throw new RuntimeException('يمكن ترحيل المستندات المسودة فقط.');
        }
        $needsApproval = function_exists('setting_get') && setting_get('posting_requires_approval','0') === '1';
        if ($needsApproval && (string)user()['role'] !== 'admin' && (string)$entry['approval_status'] !== 'approved') {
            throw new RuntimeException('يجب اعتماد المستند من مدير النظام قبل الترحيل.');
        }
        if ((string)$entry['approval_status'] === 'rejected') {
            throw new RuntimeException('المستند مرفوض؛ عدّله ثم أرسله للاعتماد من جديد.');
        }
        assert_open_period((string)$entry['entry_date'], $pdo);
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) line_count,COALESCE(SUM(debit),0) total_debit,COALESCE(SUM(credit),0) total_credit
             FROM journal_lines WHERE journal_entry_id=?'
        );
        $stmt->execute([$id]);
        $summary = $stmt->fetch();
        if ((int)$summary['line_count'] < 2 || (float)$summary['total_debit'] <= 0
            || abs((float)$summary['total_debit'] - (float)$summary['total_credit']) > 0.0005) {
            throw new RuntimeException('تعذر الترحيل لأن المستند غير متوازن أو لا يحتوي على طرفين صالحين.');
        }
        $before = journal_snapshot($id, $pdo);
        $stmt = $pdo->prepare(
            "UPDATE journal_entries SET status='posted',posted_by=?,posted_at=NOW(),unposted_by=NULL,unposted_at=NULL,
             version_no=version_no+1,last_modified_by=? WHERE id=? AND company_id=?"
        );
        $stmt->execute([user()['id'], user()['id'], $id, company_id()]);
        $after = journal_snapshot($id, $pdo);
        audit('post', 'journal_entry', $id, $before, $after, ['voucher_no' => $entry['voucher_no']], $pdo);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function unpost_journal(int $id): array
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT * FROM journal_entries WHERE id=? AND company_id=? FOR UPDATE');
        $stmt->execute([$id, company_id()]);
        $entry = $stmt->fetch();
        if (!$entry) {
            throw new RuntimeException('المستند غير موجود.');
        }
        if ($entry['status'] !== 'posted') {
            throw new RuntimeException('يمكن إلغاء ترحيل المستندات المرحلة فقط.');
        }
        if ($entry['source_type'] === 'reversal') {
            throw new RuntimeException('قيد العكس لا يلغى ترحيله مباشرة. استخدم وظيفة عكس القيد عند الحاجة.');
        }
        assert_open_period((string)$entry['entry_date'], $pdo);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM journal_entries WHERE reversal_of=? AND status IN ('posted','reversed')");
        $stmt->execute([$id]);
        if ((int)$stmt->fetchColumn() > 0) {
            throw new RuntimeException('لا يمكن إلغاء ترحيل مستند مرتبط بقيد عكسي مرحل. راجع قيد العكس أولاً.');
        }
        $before = journal_snapshot($id, $pdo);
        $stmt = $pdo->prepare(
            "UPDATE journal_entries SET status='draft',approval_status='not_required',submitted_by=NULL,submitted_at=NULL,approved_by=NULL,approved_at=NULL,approval_notes=NULL,posted_by=NULL,posted_at=NULL,unposted_by=?,unposted_at=NOW(),
             version_no=version_no+1,last_modified_by=? WHERE id=? AND company_id=?"
        );
        $stmt->execute([user()['id'], user()['id'], $id, company_id()]);
        $after = journal_snapshot($id, $pdo);
        audit('unpost', 'journal_entry', $id, $before, $after, ['voucher_no' => $entry['voucher_no']], $pdo);
        $pdo->commit();
        return $after ?: $entry;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function delete_journal_permanently(int $id): void
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT id,company_id,voucher_no,source_type,status,document_series FROM journal_entries WHERE id=? AND company_id=? FOR UPDATE');
        $stmt->execute([$id, company_id()]);
        $entry = $stmt->fetch();
        if (!$entry) {
            throw new RuntimeException('المستند غير موجود.');
        }

        // حذف أي قيود عكس مرتبطة بالمستند أيضاً حتى لا يبقى أثر محاسبي غير مكتمل.
        $ids = [(int)$entry['id']];
        $frontier = $ids;
        while ($frontier !== []) {
            $placeholders = implode(',', array_fill(0, count($frontier), '?'));
            $childStmt = $pdo->prepare(
                "SELECT id FROM journal_entries WHERE company_id=? AND reversal_of IN ($placeholders)"
            );
            $childStmt->execute(array_merge([company_id()], $frontier));
            $children = array_map('intval', $childStmt->fetchAll(PDO::FETCH_COLUMN));
            $children = array_values(array_diff($children, $ids));
            if ($children === []) break;
            $ids = array_values(array_unique(array_merge($ids, $children)));
            $frontier = $children;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        // نحفظ السلاسل المتأثرة قبل الحذف حتى نعيد مزامنة العدادات بعدها.
        // قد يشمل الحذف سند صرف/قبض ومعه قيد عكس من سلسلة JOURNAL.
        $seriesStmt = $pdo->prepare(
            "SELECT DISTINCT document_series FROM journal_entries WHERE company_id=? AND id IN ($placeholders)"
        );
        $seriesStmt->execute(array_merge([company_id()], $ids));
        $affectedSeries = array_values(array_filter(array_map('strval', $seriesStmt->fetchAll(PDO::FETCH_COLUMN))));
        if ($affectedSeries === []) {
            $affectedSeries = [document_series((string)$entry['source_type'])];
        }

        // إذا كان القيد قد نشأ من تسوية IFRS نعيد التسوية إلى مسودة حتى لا يبقى سجل "مرحل" بلا قيد.
        if (table_exists('ifrs_transition_adjustments')) {
            $transitionSql = "UPDATE ifrs_transition_adjustments SET journal_entry_id=NULL,status='draft' WHERE company_id=? AND journal_entry_id IN ($placeholders)";
            $pdo->prepare($transitionSql)->execute(array_merge([company_id()], $ids));
        }

        // سجل التدقيق لا يحتفظ بنسخة من المستند المحذوف لأن المطلوب حذف نهائي من النظام.
        if (table_exists('audit_logs')) {
            $auditSql = "DELETE FROM audit_logs WHERE company_id=? AND entity_type='journal_entry' AND entity_id IN ($placeholders)";
            $pdo->prepare($auditSql)->execute(array_merge([company_id()], array_map('strval', $ids)));
        }

        // القيود التفصيلية، تفاصيل مستند الصرف، وتصنيفات التدفق تحذف تلقائياً بواسطة ON DELETE CASCADE.
        // المراجع الاختيارية في الوحدات الأخرى تتحول إلى NULL بواسطة علاقات قاعدة البيانات.
        $deleteSql = "DELETE FROM journal_entries WHERE company_id=? AND id IN ($placeholders)";
        $pdo->prepare($deleteSql)->execute(array_merge([company_id()], $ids));

        // الحذف النهائي يعني إزالة أثر المستند من الترقيم أيضاً.
        // بعد الحذف نطابق كل عداد مع أكبر رقم ما زال موجوداً فعلياً.
        foreach (array_unique($affectedSeries) as $seriesKey) {
            if (in_array($seriesKey, ['JOURNAL','PAYMENT','RECEIPT'], true)) {
                sync_document_sequence($pdo, $seriesKey);
            }
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

// اسم قديم للتوافق مع أي استدعاء سابق.
function delete_draft_journal(int $id): void
{
    delete_journal_permanently($id);
}

function reverse_journal(int $id, string $date): int
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $period = assert_open_period($date, $pdo);
        $stmt = $pdo->prepare('SELECT * FROM journal_entries WHERE id=? AND company_id=? FOR UPDATE');
        $stmt->execute([$id, company_id()]);
        $entry = $stmt->fetch();
        if (!$entry || $entry['status'] !== 'posted') {
            throw new RuntimeException('يمكن عكس المستندات المرحلة فقط.');
        }
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM journal_entries WHERE reversal_of=? AND status IN ('posted','reversed')");
        $stmt->execute([$id]);
        if ((int)$stmt->fetchColumn() > 0) {
            throw new RuntimeException('تم إنشاء قيد عكس لهذا المستند سابقاً.');
        }
        $before = journal_snapshot($id, $pdo);
        $lines = $before['lines'] ?? [];
        if (!$lines) {
            throw new RuntimeException('المستند لا يحتوي على تفاصيل قابلة للعكس.');
        }
        $voucherNo = next_document_no($pdo, 'reversal', $date);
        $stmt = $pdo->prepare(
            "INSERT INTO journal_entries(company_id,period_id,voucher_no,entry_date,reference_no,description,source_type,origin_standard,equity_movement_type,status,reversal_of,
             created_by,last_modified_by,posted_by,posted_at)
             VALUES(?,?,?,?,?,?,'reversal',?,?,'posted',?,?,?,?,NOW())"
        );
        $stmt->execute([
            company_id(), $period['id'], $voucherNo, $date, $entry['voucher_no'],
            'عكس المستند ' . $entry['voucher_no'] . ': ' . $entry['description'],
            $entry['origin_standard'], $entry['equity_movement_type'], $id, user()['id'], user()['id'], user()['id'],
        ]);
        $newId = (int)$pdo->lastInsertId();
        $insert = $pdo->prepare(
            'INSERT INTO journal_lines(journal_entry_id,account_id,cost_center_id,party_id,currency_code,exchange_rate,foreign_amount,cash_flow_line_code,line_description,debit,credit,line_order)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?)'
        );
        foreach ($lines as $line) {
            $insert->execute([
                $newId, $line['account_id'], $line['cost_center_id'], $line['party_id'],
                $line['currency_code'] ?? null, $line['exchange_rate'] ?? 1, $line['foreign_amount'] ?? 0, $line['cash_flow_line_code'] ?? null,
                'عكس: ' . ($line['line_description'] ?: $entry['description']),
                $line['credit'], $line['debit'], $line['line_order'],
            ]);
        }
        $pdo->prepare(
            "UPDATE journal_entries SET status='reversed',version_no=version_no+1,last_modified_by=? WHERE id=? AND company_id=?"
        )->execute([user()['id'], $id, company_id()]);
        $after = journal_snapshot($id, $pdo);
        audit('reverse', 'journal_entry', $id, $before, $after, ['reversal_id' => $newId, 'reversal_no' => $voucherNo], $pdo);
        audit('create_reversal', 'journal_entry', $newId, null, journal_snapshot($newId, $pdo), ['original_id' => $id], $pdo);
        $pdo->commit();
        return $newId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function posted_status_condition(string $alias = 'je'): string
{
    return $alias . ".status IN ('posted','reversed')";
}

function raw_account_balance(int $accountId, string $toDate, ?string $fromDate = null): float
{
    if (!valid_date($toDate) || ($fromDate !== null && !valid_date($fromDate))) {
        throw new RuntimeException('نطاق التاريخ غير صالح.');
    }
    if ($fromDate !== null && $fromDate > $toDate) {
        throw new RuntimeException('تاريخ البداية يجب ألا يتجاوز تاريخ النهاية.');
    }
    $sql = 'SELECT COALESCE(SUM(jl.debit-jl.credit),0)
            FROM journal_lines jl JOIN journal_entries je ON je.id=jl.journal_entry_id
            WHERE je.company_id=? AND ' . posted_status_condition('je') . ' AND jl.account_id=? AND je.entry_date<=?';
    $params = [company_id(), $accountId, $toDate];
    if ($fromDate !== null) {
        $sql .= ' AND je.entry_date>=?';
        $params[] = $fromDate;
    }
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return (float)$stmt->fetchColumn();
}

function report_balances(string $toDate, ?string $fromDate = null, bool $excludeClosingEffects = false): array
{
    if (!valid_date($toDate) || ($fromDate !== null && !valid_date($fromDate))) {
        throw new RuntimeException('نطاق تاريخ التقرير غير صالح.');
    }
    if ($fromDate !== null && $fromDate > $toDate) {
        throw new RuntimeException('تاريخ بداية التقرير يجب ألا يتجاوز تاريخ النهاية.');
    }
    $closingFilter = '';
    if ($excludeClosingEffects) {
        $closingFilter = " AND je.source_type<>'closing'"
            . " AND NOT (je.source_type='reversal' AND EXISTS (SELECT 1 FROM journal_entries original_closing"
            . " WHERE original_closing.id=je.reversal_of AND original_closing.source_type='closing'))";
    }
    $sql = 'SELECT a.id,a.code,a.name_ar,a.account_type,a.normal_balance,a.statement_section,a.cash_flow_category,a.is_cash_account,
                   COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jl.debit ELSE 0 END),0) debit,
                   COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jl.credit ELSE 0 END),0) credit
            FROM accounts a
            LEFT JOIN journal_lines jl ON jl.account_id=a.id
            LEFT JOIN journal_entries je ON je.id=jl.journal_entry_id
                 AND je.company_id=a.company_id AND ' . posted_status_condition('je') . ' AND je.entry_date<=?' . $closingFilter;
    $params = [$toDate];
    if ($fromDate !== null) {
        $sql .= ' AND je.entry_date>=?';
        $params[] = $fromDate;
    }
    $sql .= ' WHERE a.company_id=? AND a.is_postable=1 GROUP BY a.id ORDER BY a.code';
    $params[] = company_id();
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function performance_profit(string $from, string $to): float
{
    $profit = 0.0;
    foreach (report_balances($to, $from, true) as $row) {
        $raw = (float)$row['debit'] - (float)$row['credit'];
        if ($row['account_type'] === 'revenue') {
            $profit += -$raw;
        } elseif ($row['account_type'] === 'expense') {
            $profit -= $raw;
        }
    }
    return round($profit, 3);
}

function period_profit(string $from, string $to): float
{
    $profit = 0.0;
    foreach (report_balances($to, $from) as $row) {
        $raw = (float)$row['debit'] - (float)$row['credit'];
        if ($row['account_type'] === 'revenue') {
            $profit += -$raw;
        } elseif ($row['account_type'] === 'expense') {
            $profit -= $raw;
        }
    }
    return round($profit, 3);
}

function create_closing_entry(int $periodId, int $resultAccountId, bool $postAfter): array
{
    $stmt = db()->prepare('SELECT * FROM fiscal_periods WHERE id=? AND company_id=?');
    $stmt->execute([$periodId, company_id()]);
    $period = $stmt->fetch();
    if (!$period) {
        throw new RuntimeException('الفترة المالية غير موجودة.');
    }
    if ($period['status'] !== 'open') {
        throw new RuntimeException('يجب أن تكون الفترة مفتوحة لإنشاء قيد الإقفال.');
    }
    $stmt = db()->prepare("SELECT COUNT(*) FROM journal_entries WHERE company_id=? AND period_id=? AND source_type='closing' AND status IN ('draft','posted')");
    $stmt->execute([company_id(), $periodId]);
    if ((int)$stmt->fetchColumn() > 0) {
        throw new RuntimeException('يوجد قيد إقفال سابق لهذه الفترة. راجعه أو احذفه قبل إنشاء قيد جديد.');
    }
    $stmt = db()->prepare("SELECT id FROM accounts WHERE id=? AND company_id=? AND account_type='equity' AND is_active=1 AND is_postable=1");
    $stmt->execute([$resultAccountId, company_id()]);
    if (!$stmt->fetchColumn()) {
        throw new RuntimeException('حساب نتيجة النشاط يجب أن يكون حساب حقوق ملكية فعالاً وقابلاً للترحيل.');
    }

    $rows = report_balances((string)$period['end_date'], (string)$period['start_date']);
    $lines = [];
    $sumDebit = 0.0;
    $sumCredit = 0.0;
    foreach ($rows as $row) {
        if (!in_array($row['account_type'], ['revenue','expense'], true)) {
            continue;
        }
        $raw = round((float)$row['debit'] - (float)$row['credit'], 3);
        if (abs($raw) < 0.0005) {
            continue;
        }
        if ($raw > 0) {
            $debit = 0.0;
            $credit = $raw;
        } else {
            $debit = -$raw;
            $credit = 0.0;
        }
        $lines[] = [
            'account_id' => (int)$row['id'],
            'debit' => $debit,
            'credit' => $credit,
            'line_description' => 'إقفال ' . $row['name_ar'],
        ];
        $sumDebit += $debit;
        $sumCredit += $credit;
    }
    if (!$lines) {
        throw new RuntimeException('لا توجد أرصدة إيرادات أو مصروفات غير مقفلة ضمن الفترة المحددة.');
    }
    $difference = round($sumDebit - $sumCredit, 3);
    if (abs($difference) < 0.0005) {
        throw new RuntimeException('صافي نتيجة الفترة يساوي صفراً، ولا توجد قيمة لتحويلها إلى حقوق الملكية.');
    }
    $lines[] = [
        'account_id' => $resultAccountId,
        'debit' => $difference < 0 ? -$difference : 0,
        'credit' => $difference > 0 ? $difference : 0,
        'line_description' => 'تحويل صافي نتيجة الفترة إلى حقوق الملكية',
    ];

    return save_journal_document([
        'entry_date' => $period['end_date'],
        'reference_no' => 'CLOSE-' . $periodId,
        'description' => 'قيد إقفال ' . $period['name_ar'],
        'source_type' => 'closing',
    ], $lines, null, null, $postAfter);
}

function calculate_cash_flow(string $from, string $to): array
{
    if (!valid_date($from) || !valid_date($to) || $from > $to) {
        throw new RuntimeException('نطاق تاريخ قائمة التدفقات النقدية غير صالح.');
    }
    $stmt = db()->prepare(
        "SELECT je.id,je.entry_date,jl.debit,jl.credit,a.is_cash_account,a.cash_flow_category,a.account_type
         FROM journal_entries je
         JOIN journal_lines jl ON jl.journal_entry_id=je.id
         JOIN accounts a ON a.id=jl.account_id
         WHERE je.company_id=? AND " . posted_status_condition('je') . " AND je.entry_date BETWEEN ? AND ?
         ORDER BY je.id,jl.id"
    );
    $stmt->execute([company_id(), $from, $to]);
    $entries = [];
    foreach ($stmt->fetchAll() as $row) {
        $entries[$row['id']][] = $row;
    }
    $flow = ['operating' => 0.0, 'investing' => 0.0, 'financing' => 0.0];
    foreach ($entries as $lines) {
        $cashNet = 0.0;
        $weights = ['operating' => 0.0, 'investing' => 0.0, 'financing' => 0.0];
        foreach ($lines as $line) {
            $raw = (float)$line['debit'] - (float)$line['credit'];
            if ((int)$line['is_cash_account'] === 1) {
                $cashNet += $raw;
            } else {
                $category = in_array($line['cash_flow_category'], ['operating','investing','financing'], true)
                    ? $line['cash_flow_category'] : 'operating';
                $weights[$category] += abs($raw);
            }
        }
        if (abs($cashNet) < 0.0005) {
            continue;
        }
        $totalWeight = array_sum($weights);
        if ($totalWeight < 0.0005) {
            $flow['operating'] += $cashNet;
            continue;
        }
        foreach ($weights as $category => $weight) {
            if ($weight > 0) {
                $flow[$category] += $cashNet * ($weight / $totalWeight);
            }
        }
    }
    $openingStmt = db()->prepare(
        "SELECT COALESCE(SUM(jl.debit-jl.credit),0)
         FROM journal_entries je JOIN journal_lines jl ON jl.journal_entry_id=je.id JOIN accounts a ON a.id=jl.account_id
         WHERE je.company_id=? AND " . posted_status_condition('je') . " AND a.is_cash_account=1 AND je.entry_date<?"
    );
    $openingStmt->execute([company_id(), $from]);
    $opening = (float)$openingStmt->fetchColumn();
    $net = array_sum($flow);
    return [
        'opening' => round($opening, 3),
        'operating' => round($flow['operating'], 3),
        'investing' => round($flow['investing'], 3),
        'financing' => round($flow['financing'], 3),
        'net' => round($net, 3),
        'closing' => round($opening + $net, 3),
    ];
}

function sql_quote_value(PDO $pdo, mixed $value): string
{
    if ($value === null) {
        return 'NULL';
    }
    return $pdo->quote((string)$value);
}

function backup_storage_dir(): string
{
    if (function_exists('institution_backup_dir')) {
        return institution_backup_dir();
    }
    return __DIR__ . '/../storage/backups';
}

function create_backup_file(): array
{
    $pdo = db();
    $dir = backup_storage_dir();
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('تعذر إنشاء مجلد النسخ الاحتياطية.');
    }
    if (!is_writable($dir)) {
        throw new RuntimeException('مجلد النسخ الاحتياطية غير قابل للكتابة.');
    }
    $companyCode = preg_replace('/[^A-Za-z0-9_-]+/', '_', (string)(company()['name_en'] ?: 'company')) ?: 'company';
    $institutionKey = function_exists('institution_storage_key') ? institution_storage_key() : 'main';
    $filename = sprintf('ifrs_backup_%s_%s_%s.sql', $institutionKey, $companyCode, date('Ymd_His'));
    $path = $dir . '/' . $filename;
    $fh = fopen($path, 'wb');
    if (!$fh) {
        throw new RuntimeException('تعذر إنشاء ملف النسخة الاحتياطية.');
    }
    fwrite($fh, "-- IFRS Accounting System backup\n");
    fwrite($fh, '-- Created: ' . date('c') . "\n");
    if (function_exists('institution_storage_key')) {
        fwrite($fh, '-- Institution-Key: ' . institution_storage_key() . "\n");
        fwrite($fh, '-- Institution-Name: ' . str_replace(["\r", "\n"], ' ', (string)($_SESSION['institution_name'] ?? (company()['name_ar'] ?? ''))) . "\n");
        fwrite($fh, '-- Institution-Database: ' . (string)app_config('db_name', '') . "\n");
    }
    fwrite($fh, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n");
    $tables = $pdo->query("SHOW FULL TABLES WHERE Table_type='BASE TABLE'")->fetchAll(PDO::FETCH_NUM);
    foreach ($tables as $tableRow) {
        $table = (string)$tableRow[0];
        $create = $pdo->query('SHOW CREATE TABLE `' . str_replace('`', '``', $table) . '`')->fetch(PDO::FETCH_NUM);
        fwrite($fh, "DROP TABLE IF EXISTS `{$table}`;\n" . ($create[1] ?? '') . ";\n\n");
        $rows = $pdo->query('SELECT * FROM `' . str_replace('`', '``', $table) . '`');
        while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
            $columns = array_map(static fn(string $c): string => '`' . str_replace('`', '``', $c) . '`', array_keys($row));
            $values = array_map(static fn(mixed $v): string => sql_quote_value($pdo, $v), array_values($row));
            fwrite($fh, 'INSERT INTO `' . $table . '` (' . implode(',', $columns) . ') VALUES (' . implode(',', $values) . ");\n");
        }
        fwrite($fh, "\n");
    }
    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
    audit('backup_create', 'database_backup', $filename, null, null, ['size' => filesize($path)]);
    return ['filename' => $filename, 'path' => $path, 'size' => filesize($path) ?: 0];
}

function list_backup_files(): array
{
    $dir = backup_storage_dir();
    if (!is_dir($dir)) {
        return [];
    }
    $items = [];
    foreach (glob($dir . '/*.sql') ?: [] as $path) {
        $items[] = [
            'filename' => basename($path),
            'size' => filesize($path) ?: 0,
            'modified_at' => date('Y-m-d H:i:s', filemtime($path) ?: time()),
        ];
    }
    usort($items, static fn(array $a, array $b): int => strcmp($b['modified_at'], $a['modified_at']));
    return $items;
}

function safe_backup_path(string $filename): string
{
    $filename = basename($filename);
    if (!preg_match('/^[A-Za-z0-9_.-]+\.sql$/', $filename)) {
        throw new RuntimeException('اسم ملف النسخة الاحتياطية غير صالح.');
    }
    $path = backup_storage_dir() . '/' . $filename;
    if (!is_file($path)) {
        throw new RuntimeException('ملف النسخة الاحتياطية غير موجود.');
    }
    return $path;
}


/**
 * Maximum upload size accepted by the in-app restore screen.
 * The effective limit is the smallest of PHP upload_max_filesize,
 * post_max_size and 200 MB.
 */
function parse_ini_size_bytes(string $value): int
{
    $value = trim($value);
    if ($value === '') return 0;
    $last = strtolower(substr($value, -1));
    $number = (float)$value;
    return match ($last) {
        'g' => (int)round($number * 1024 * 1024 * 1024),
        'm' => (int)round($number * 1024 * 1024),
        'k' => (int)round($number * 1024),
        default => (int)round($number),
    };
}

function backup_restore_upload_limit(): int
{
    $limits = [200 * 1024 * 1024];
    foreach (['upload_max_filesize', 'post_max_size'] as $key) {
        $parsed = parse_ini_size_bytes((string)ini_get($key));
        if ($parsed > 0) $limits[] = $parsed;
    }
    return min($limits);
}

/**
 * Yields SQL statements while respecting quotes, backticks and comments.
 * This parser is intentionally limited to ordinary MySQL dump syntax.
 */
function backup_sql_statements(string $path): Generator
{
    $handle = fopen($path, 'rb');
    if (!$handle) throw new RuntimeException('تعذر فتح ملف النسخة الاحتياطية.');

    $buffer = '';
    $quote = null;
    $escaped = false;
    $lineComment = false;
    $blockComment = false;
    $prev = '';

    try {
        while (!feof($handle)) {
            $chunk = fread($handle, 65536);
            if ($chunk === false) throw new RuntimeException('تعذر قراءة ملف النسخة الاحتياطية.');
            $length = strlen($chunk);
            for ($i = 0; $i < $length; $i++) {
                $char = $chunk[$i];
                $next = $i + 1 < $length ? $chunk[$i + 1] : '';

                if ($lineComment) {
                    if ($char === "\n") {
                        $lineComment = false;
                        $buffer .= "\n";
                    }
                    $prev = $char;
                    continue;
                }
                if ($blockComment) {
                    if ($char === '*' && $next === '/') {
                        $blockComment = false;
                        $i++;
                    }
                    $prev = $char;
                    continue;
                }

                if ($quote !== null) {
                    $buffer .= $char;
                    if ($escaped) {
                        $escaped = false;
                    } elseif ($char === '\\') {
                        $escaped = true;
                    } elseif ($char === $quote) {
                        // MySQL supports doubled quote characters inside strings.
                        if ($next === $quote && $quote !== '`') {
                            $buffer .= $next;
                            $i++;
                        } else {
                            $quote = null;
                        }
                    }
                    $prev = $char;
                    continue;
                }

                if ($char === '-' && $next === '-') {
                    $after = $i + 2 < $length ? $chunk[$i + 2] : '';
                    if ($after === '' || ctype_space($after)) {
                        $lineComment = true;
                        $i++;
                        $prev = '-';
                        continue;
                    }
                }
                if ($char === '#') {
                    $lineComment = true;
                    $prev = $char;
                    continue;
                }
                if ($char === '/' && $next === '*') {
                    $blockComment = true;
                    $i++;
                    $prev = '*';
                    continue;
                }
                if ($char === "'" || $char === '"' || $char === '`') {
                    $quote = $char;
                    $buffer .= $char;
                    $prev = $char;
                    continue;
                }
                if ($char === ';') {
                    $statement = trim($buffer);
                    $buffer = '';
                    if ($statement !== '') yield $statement;
                    $prev = $char;
                    continue;
                }
                $buffer .= $char;
                $prev = $char;
            }
        }
        $statement = trim($buffer);
        if ($statement !== '') yield $statement;
    } finally {
        fclose($handle);
    }
}

function validate_ifrs_backup_file(string $path): array
{
    if (!is_file($path) || !is_readable($path)) {
        throw new RuntimeException('ملف النسخة الاحتياطية غير موجود أو غير قابل للقراءة.');
    }
    $size = filesize($path) ?: 0;
    if ($size < 100) throw new RuntimeException('ملف النسخة الاحتياطية فارغ أو غير مكتمل.');
    if ($size > backup_restore_upload_limit()) {
        throw new RuntimeException('حجم ملف النسخة الاحتياطية يتجاوز الحد المسموح به على الخادم.');
    }

    $head = file_get_contents($path, false, null, 0, 4096);
    if (!is_string($head) || !str_contains($head, 'IFRS Accounting System backup')) {
        throw new RuntimeException('الملف ليس نسخة احتياطية صادرة من نظام الميزان المحاسبي.');
    }
    if (function_exists('institution_storage_key') && preg_match('/^--\s*Institution-Key:\s*([A-Za-z0-9_-]+)\s*$/mi', $head, $m)) {
        $backupInstitution = (string)$m[1];
        $currentInstitution = institution_storage_key();
        if ($backupInstitution !== $currentInstitution) {
            throw new RuntimeException('هذه النسخة الاحتياطية تخص مؤسسة أخرى (' . $backupInstitution . '). اختر المؤسسة الصحيحة قبل الاستعادة.');
        }
    }

    $allowed = [
        '/^SET\s+NAMES\s+UTF8MB4$/i',
        '/^SET\s+FOREIGN_KEY_CHECKS\s*=\s*[01]$/i',
        '/^DROP\s+TABLE\s+IF\s+EXISTS\s+`?[A-Za-z0-9_]+`?$/i',
        '/^CREATE\s+TABLE\s+`?[A-Za-z0-9_]+`?\s*\(/is',
        '/^INSERT\s+INTO\s+`?[A-Za-z0-9_]+`?\s*\(/is',
    ];
    $required = ['companies','users','accounts','journal_entries','journal_lines'];
    $created = [];
    $statements = 0;
    $inserts = 0;

    foreach (backup_sql_statements($path) as $statement) {
        $statements++;
        $ok = false;
        foreach ($allowed as $pattern) {
            if (preg_match($pattern, $statement) === 1) {
                $ok = true;
                break;
            }
        }
        if (!$ok) {
            $preview = mb_substr(preg_replace('/\s+/', ' ', $statement) ?? '', 0, 140);
            throw new RuntimeException('يتضمن ملف النسخة أمراً غير مسموح به: ' . $preview);
        }
        if (preg_match('/^CREATE\s+TABLE\s+`?([A-Za-z0-9_]+)`?/i', $statement, $m)) {
            $created[strtolower($m[1])] = true;
        }
        if (preg_match('/^INSERT\s+INTO\s+/i', $statement)) $inserts++;
        if ($statements > 5000000) {
            throw new RuntimeException('عدد أوامر النسخة الاحتياطية غير منطقي.');
        }
    }
    foreach ($required as $table) {
        if (!isset($created[$table])) {
            throw new RuntimeException('النسخة الاحتياطية لا تحتوي على الجدول الأساسي: ' . $table);
        }
    }
    if ($statements < 10 || $inserts < 1) {
        throw new RuntimeException('ملف النسخة الاحتياطية غير مكتمل أو لا يحتوي على بيانات.');
    }
    return ['size' => $size, 'statements' => $statements, 'tables' => count($created), 'inserts' => $inserts];
}

function quote_mysql_identifier(string $name): string
{
    if ($name === '' || preg_match('/^[A-Za-z0-9_$-]+$/', $name) !== 1) {
        throw new RuntimeException('اسم قاعدة البيانات غير صالح.');
    }
    return '`' . str_replace('`', '``', $name) . '`';
}

function database_connection(string $database): PDO
{
    $cfg = app_config();
    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        $cfg['db_host'] ?? '127.0.0.1',
        $cfg['db_port'] ?? '3306',
        $database
    );
    return new PDO($dsn, (string)($cfg['db_user'] ?? 'root'), (string)($cfg['db_pass'] ?? ''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci',
    ]);
}

function locate_mysql_client(): ?string
{
    $candidates = [];
    if (PHP_OS_FAMILY === 'Windows') {
        $xamppRoot = dirname(dirname(PHP_BINARY));
        $candidates[] = $xamppRoot . DIRECTORY_SEPARATOR . 'mysql' . DIRECTORY_SEPARATOR . 'bin' . DIRECTORY_SEPARATOR . 'mysql.exe';
        $candidates[] = 'C:\\xampp\\mysql\\bin\\mysql.exe';
    } else {
        $candidates[] = '/usr/bin/mysql';
        $candidates[] = '/usr/local/bin/mysql';
        $candidates[] = '/usr/bin/mariadb';
    }
    foreach ($candidates as $candidate) {
        if (is_file($candidate) && is_executable($candidate)) return $candidate;
    }
    return null;
}

function mysql_defaults_file(): string
{
    $dir = __DIR__ . '/../storage/tmp';
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('تعذر إنشاء مجلد الملفات المؤقتة.');
    }
    $path = $dir . '/mysql_restore_' . bin2hex(random_bytes(8)) . '.cnf';
    $cfg = app_config();
    $escape = static fn(string $value): string => str_replace(["\\", '"', "\r", "\n"], ["\\\\", '\\"', '', ''], $value);
    $content = "[client]\n"
        . 'host="' . $escape((string)($cfg['db_host'] ?? '127.0.0.1')) . "\"\n"
        . 'port="' . $escape((string)($cfg['db_port'] ?? '3306')) . "\"\n"
        . 'user="' . $escape((string)($cfg['db_user'] ?? 'root')) . "\"\n"
        . 'password="' . $escape((string)($cfg['db_pass'] ?? '')) . "\"\n"
        . "default-character-set=utf8mb4\n";
    if (file_put_contents($path, $content, LOCK_EX) === false) {
        throw new RuntimeException('تعذر إنشاء ملف اتصال MySQL المؤقت.');
    }
    @chmod($path, 0600);
    return $path;
}

function import_sql_with_client(string $path, string $database): void
{
    $client = locate_mysql_client();
    if ($client === null || !function_exists('proc_open')) {
        throw new RuntimeException('MYSQL_CLIENT_UNAVAILABLE');
    }
    $defaults = mysql_defaults_file();
    $command = [
        $client,
        '--defaults-extra-file=' . $defaults,
        '--database=' . $database,
        '--binary-mode',
        '--default-character-set=utf8mb4',
        '--show-warnings',
    ];
    $descriptors = [
        0 => ['file', $path, 'rb'],
        1 => ['pipe', 'w'],
        2 => ['pipe', 'w'],
    ];
    $process = proc_open($command, $descriptors, $pipes, null, null, ['bypass_shell' => true]);
    if (!is_resource($process)) {
        @unlink($defaults);
        throw new RuntimeException('تعذر تشغيل عميل MySQL لاستعادة النسخة.');
    }
    $stdout = stream_get_contents($pipes[1]);
    $stderr = stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    $exit = proc_close($process);
    @unlink($defaults);
    if ($exit !== 0) {
        $message = trim((string)$stderr) ?: trim((string)$stdout);
        throw new RuntimeException('فشل استيراد ملف SQL بواسطة MySQL: ' . mb_substr($message, 0, 1200));
    }
}

function import_sql_with_pdo(string $path, string $database): void
{
    $pdo = database_connection($database);
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    try {
        foreach (backup_sql_statements($path) as $statement) {
            $pdo->exec($statement);
        }
    } finally {
        try { $pdo->exec('SET FOREIGN_KEY_CHECKS=1'); } catch (Throwable) {}
    }
}

function import_sql_file(string $path, string $database): void
{
    try {
        import_sql_with_client($path, $database);
    } catch (RuntimeException $e) {
        if ($e->getMessage() !== 'MYSQL_CLIENT_UNAVAILABLE') throw $e;
        import_sql_with_pdo($path, $database);
    }
}

function drop_all_database_tables(string $database): void
{
    $pdo = database_connection($database);
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    try {
        $tables = $pdo->query("SHOW FULL TABLES WHERE Table_type='BASE TABLE'")->fetchAll(PDO::FETCH_NUM);
        foreach ($tables as $row) {
            $table = (string)$row[0];
            $pdo->exec('DROP TABLE IF EXISTS `' . str_replace('`', '``', $table) . '`');
        }
    } finally {
        $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
    }
}

function verify_restored_database(string $database): array
{
    $pdo = database_connection($database);
    $required = ['companies','users','accounts','journal_entries','journal_lines'];
    $tables = $pdo->query("SHOW FULL TABLES WHERE Table_type='BASE TABLE'")->fetchAll(PDO::FETCH_NUM);
    $available = [];
    foreach ($tables as $row) $available[strtolower((string)$row[0])] = true;
    foreach ($required as $table) {
        if (!isset($available[$table])) throw new RuntimeException('القاعدة المستعادة تفتقد الجدول الأساسي: ' . $table);
    }
    $companyCount = (int)$pdo->query('SELECT COUNT(*) FROM companies')->fetchColumn();
    $adminCount = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin' AND is_active=1")->fetchColumn();
    if ($companyCount < 1) throw new RuntimeException('النسخة المستعادة لا تحتوي على منشأة.');
    if ($adminCount < 1) throw new RuntimeException('النسخة المستعادة لا تحتوي على مدير نظام فعال.');
    return ['tables' => count($available), 'companies' => $companyCount, 'admins' => $adminCount];
}

function restore_database_from_backup(string $path, string $sourceLabel): array
{
    $validation = validate_ifrs_backup_file($path);
    $cfg = app_config();
    $database = (string)($cfg['db_name'] ?? '');
    quote_mysql_identifier($database);

    $maintenance = __DIR__ . '/../storage/restore.lock';
    if (is_file($maintenance)) {
        throw new RuntimeException('توجد عملية استعادة أخرى قيد التنفيذ.');
    }
    if (file_put_contents($maintenance, json_encode([
        'started_at' => date('c'),
        'user_id' => user()['id'] ?? null,
        'source' => $sourceLabel,
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX) === false) {
        throw new RuntimeException('تعذر تفعيل وضع الصيانة للاستعادة.');
    }

    $tempDb = 'ifrs_restore_check_' . bin2hex(random_bytes(5));
    $server = db();
    $preBackup = null;
    try {
        // Test the entire backup in an isolated temporary database first.
        $server->exec('CREATE DATABASE ' . quote_mysql_identifier($tempDb) . ' CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        import_sql_file($path, $tempDb);
        $test = verify_restored_database($tempDb);
        $server->exec('DROP DATABASE ' . quote_mysql_identifier($tempDb));
        $tempDb = '';

        // Create an automatic rollback point immediately before touching the live database.
        $preBackup = create_backup_file();
        try {
            drop_all_database_tables($database);
            import_sql_file($path, $database);
            $restored = verify_restored_database($database);
        } catch (Throwable $restoreError) {
            // Automatic rollback using the snapshot created above.
            try {
                drop_all_database_tables($database);
                import_sql_file((string)$preBackup['path'], $database);
                verify_restored_database($database);
                throw new RuntimeException('فشلت الاستعادة، وتمت إعادة قاعدة البيانات السابقة تلقائياً. السبب: ' . $restoreError->getMessage());
            } catch (RuntimeException $rollbackError) {
                if (str_starts_with($rollbackError->getMessage(), 'فشلت الاستعادة، وتمت إعادة')) throw $rollbackError;
                throw new RuntimeException(
                    'فشلت الاستعادة وفشلت الإعادة التلقائية. النسخة الوقائية محفوظة في: '
                    . (string)$preBackup['path'] . '. السبب الأصلي: ' . $restoreError->getMessage()
                    . '. سبب فشل الإعادة: ' . $rollbackError->getMessage()
                );
            }
        }

        try {
            audit('backup_restore', 'database_backup', basename($path), null, null, [
                'source' => $sourceLabel,
                'pre_restore_backup' => $preBackup['filename'] ?? null,
                'validation' => $validation,
                'restored' => $restored,
            ]);
        } catch (Throwable $auditError) {
            log_exception($auditError);
        }
        return [
            'source' => $sourceLabel,
            'pre_backup' => $preBackup,
            'validation' => $validation,
            'restored' => $restored,
            'test' => $test,
        ];
    } finally {
        if ($tempDb !== '') {
            try { $server->exec('DROP DATABASE IF EXISTS ' . quote_mysql_identifier($tempDb)); } catch (Throwable) {}
        }
        @unlink($maintenance);
    }
}

function save_uploaded_backup(array $upload): array
{
    $error = (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'حجم الملف يتجاوز upload_max_filesize.',
            UPLOAD_ERR_FORM_SIZE => 'حجم الملف يتجاوز الحد المحدد في النموذج.',
            UPLOAD_ERR_PARTIAL => 'لم يكتمل رفع الملف.',
            UPLOAD_ERR_NO_FILE => 'اختر ملف نسخة احتياطية أولاً.',
            UPLOAD_ERR_NO_TMP_DIR => 'مجلد الرفع المؤقت غير متوفر.',
            UPLOAD_ERR_CANT_WRITE => 'تعذر كتابة الملف على الخادم.',
            UPLOAD_ERR_EXTENSION => 'أوقف امتداد PHP عملية الرفع.',
        ];
        throw new RuntimeException($messages[$error] ?? 'فشل رفع ملف النسخة الاحتياطية.');
    }
    $tmp = (string)($upload['tmp_name'] ?? '');
    $original = basename((string)($upload['name'] ?? 'backup.sql'));
    if (!is_uploaded_file($tmp)) throw new RuntimeException('ملف الرفع غير موثوق.');
    if (strtolower(pathinfo($original, PATHINFO_EXTENSION)) !== 'sql') {
        throw new RuntimeException('يسمح باستيراد ملفات SQL فقط.');
    }
    $size = (int)($upload['size'] ?? 0);
    if ($size <= 0 || $size > backup_restore_upload_limit()) {
        throw new RuntimeException('حجم ملف النسخة الاحتياطية غير صالح أو يتجاوز الحد المسموح.');
    }
    $dir = backup_storage_dir();
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('تعذر إنشاء مجلد النسخ الاحتياطية.');
    }
    $safeBase = preg_replace('/[^A-Za-z0-9_.-]+/', '_', pathinfo($original, PATHINFO_FILENAME)) ?: 'uploaded_backup';
    $filename = 'imported_' . date('Ymd_His') . '_' . $safeBase . '.sql';
    $path = $dir . '/' . $filename;
    if (!move_uploaded_file($tmp, $path)) {
        throw new RuntimeException('تعذر حفظ ملف النسخة الاحتياطية داخل النظام.');
    }
    try {
        $validation = validate_ifrs_backup_file($path);
    } catch (Throwable $e) {
        @unlink($path);
        throw $e;
    }
    return ['filename' => $filename, 'path' => $path, 'size' => filesize($path) ?: 0, 'validation' => $validation];
}

function verify_admin_restore_authorization(string $password, string $confirmation): void
{
    require_role('admin');
    if (trim($confirmation) !== 'استعادة') {
        throw new RuntimeException('اكتب كلمة استعادة في حقل التأكيد.');
    }
    if ($password === '') throw new RuntimeException('أدخل كلمة مرور مدير النظام.');
    $stmt = db()->prepare("SELECT password_hash FROM users WHERE id=? AND company_id=? AND role='admin' AND is_active=1");
    $stmt->execute([user()['id'], company_id()]);
    $hash = $stmt->fetchColumn();
    if (!is_string($hash) || !password_verify($password, $hash)) {
        throw new RuntimeException('كلمة مرور مدير النظام غير صحيحة.');
    }
}

function format_bytes(int $bytes): string
{
    $units = ['B','KB','MB','GB'];
    $size = (float)$bytes;
    $i = 0;
    while ($size >= 1024 && $i < count($units) - 1) {
        $size /= 1024;
        $i++;
    }
    return number_format($size, $i === 0 ? 0 : 2) . ' ' . $units[$i];
}

/**
 * تحويل مبلغ صحيح إلى كتابة عربية لاستخدامه في مستند القيد المطبوع.
 * صُممت الدالة للمبالغ المحاسبية حتى التريليونات، مع إبقاء الكسر رقمياً عند وجوده.
 */
function arabic_integer_words(int $number): string
{
    if ($number === 0) return 'صفر';
    if ($number < 0) return 'سالب ' . arabic_integer_words(abs($number));

    $underThousand = static function (int $n): string {
        $units = [
            0 => '', 1 => 'واحد', 2 => 'اثنان', 3 => 'ثلاثة', 4 => 'أربعة', 5 => 'خمسة',
            6 => 'ستة', 7 => 'سبعة', 8 => 'ثمانية', 9 => 'تسعة', 10 => 'عشرة',
            11 => 'أحد عشر', 12 => 'اثنا عشر', 13 => 'ثلاثة عشر', 14 => 'أربعة عشر',
            15 => 'خمسة عشر', 16 => 'ستة عشر', 17 => 'سبعة عشر', 18 => 'ثمانية عشر', 19 => 'تسعة عشر',
        ];
        $tens = [20 => 'عشرون', 30 => 'ثلاثون', 40 => 'أربعون', 50 => 'خمسون', 60 => 'ستون', 70 => 'سبعون', 80 => 'ثمانون', 90 => 'تسعون'];
        $hundreds = [1 => 'مائة', 2 => 'مائتان', 3 => 'ثلاثمائة', 4 => 'أربعمائة', 5 => 'خمسمائة', 6 => 'ستمائة', 7 => 'سبعمائة', 8 => 'ثمانمائة', 9 => 'تسعمائة'];
        $parts = [];
        if ($n >= 100) {
            $parts[] = $hundreds[intdiv($n, 100)];
            $n %= 100;
        }
        if ($n > 0) {
            if ($n < 20) {
                $parts[] = $units[$n];
            } else {
                $u = $n % 10;
                $t = $n - $u;
                if ($u > 0) $parts[] = $units[$u] . ' و' . $tens[$t];
                else $parts[] = $tens[$t];
            }
        }
        return implode(' و', array_filter($parts));
    };

    $scales = [
        1000000000000 => ['تريليون', 'تريليونان', 'تريليونات'],
        1000000000 => ['مليار', 'ملياران', 'مليارات'],
        1000000 => ['مليون', 'مليونان', 'ملايين'],
        1000 => ['ألف', 'ألفان', 'آلاف'],
    ];
    $parts = [];
    foreach ($scales as $value => $labels) {
        if ($number < $value) continue;
        $count = intdiv($number, $value);
        $number %= $value;
        if ($count === 1) $parts[] = $labels[0];
        elseif ($count === 2) $parts[] = $labels[1];
        elseif ($count >= 3 && $count <= 10) $parts[] = $underThousand($count) . ' ' . $labels[2];
        else $parts[] = $underThousand($count) . ' ' . $labels[0];
    }
    if ($number > 0) $parts[] = $underThousand($number);
    return implode(' و', array_filter($parts));
}

function arabic_amount_words(float|int|string|null $amount, ?string $currencyName = null): string
{
    $value = round((float)$amount, 3);
    $whole = (int)floor(abs($value));
    $fraction = (int)round((abs($value) - $whole) * 1000);
    $words = arabic_integer_words($whole);
    if ($value < 0) $words = 'سالب ' . $words;
    $currencyName ??= (string)(company()['currency_name_ar'] ?? 'دينار عراقي');
    $result = 'فقط ' . $words . ' ' . $currencyName;
    if ($fraction > 0) $result .= ' و' . arabic_integer_words($fraction) . ' فلساً';
    return $result . ' لا غير';
}
