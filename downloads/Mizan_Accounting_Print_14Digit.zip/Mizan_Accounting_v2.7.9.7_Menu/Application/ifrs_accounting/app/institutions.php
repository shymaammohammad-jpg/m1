<?php
declare(strict_types=1);

/**
 * Multi-institution database selector for Mizan 2.7.9.1.
 *
 * One application installation can operate several fully separate MySQL databases.
 * Only the database connection settings are shared. Each institution keeps its own
 * entries, vouchers, balances, bank reconciliation, users and accounting data.
 */

function institution_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    session_name('IFRSACCSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

function institution_registry_path(): string
{
    return __DIR__ . '/../storage/institutions.json';
}

function institution_registry_default(): array
{
    return [
        'version' => 1,
        'default_key' => '',
        'institutions' => [],
        'updated_at' => null,
        'bootstrap_warning' => null,
    ];
}

function institution_safe_key(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9_-]+/', '-', $value) ?? '';
    $value = trim($value, '-_');
    if ($value === '') {
        $value = 'unit-' . substr(hash('sha256', random_bytes(16)), 0, 8);
    }
    return substr($value, 0, 48);
}

function institution_validate_db_name(string $dbName): string
{
    $dbName = trim($dbName);
    if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $dbName)) {
        throw new RuntimeException('اسم قاعدة بيانات المؤسسة غير صالح.');
    }
    return $dbName;
}

function institution_server_pdo(array $config): PDO
{
    return new PDO(
        sprintf(
            'mysql:host=%s;port=%s;charset=utf8mb4',
            (string)($config['db_host'] ?? '127.0.0.1'),
            (string)($config['db_port'] ?? '3306')
        ),
        (string)($config['db_user'] ?? 'root'),
        (string)($config['db_pass'] ?? ''),
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
}

function institution_database_exists(PDO $server, string $dbName): bool
{
    $stmt = $server->prepare('SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name=?');
    $stmt->execute([$dbName]);
    return (int)$stmt->fetchColumn() > 0;
}

function institution_database_is_mizan(PDO $server, string $dbName): bool
{
    if (!institution_database_exists($server, $dbName)) {
        return false;
    }
    $required = ['companies', 'users', 'accounts', 'journal_entries', 'journal_lines'];
    $stmt = $server->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=? AND table_name=?');
    foreach ($required as $table) {
        $stmt->execute([$dbName, $table]);
        if ((int)$stmt->fetchColumn() < 1) {
            return false;
        }
    }
    return true;
}

function institution_company_name(PDO $server, string $dbName): string
{
    if (!institution_database_is_mizan($server, $dbName)) {
        return '';
    }
    $quotedDb = '`' . str_replace('`', '``', $dbName) . '`';
    $value = $server->query("SELECT name_ar FROM {$quotedDb}.companies ORDER BY id LIMIT 1")->fetchColumn();
    return is_string($value) ? trim($value) : '';
}

function institution_database_created_from(PDO $server, string $dbName, string $sourceDb): bool
{
    if (!institution_database_is_mizan($server, $dbName)) return false;
    $dbQ = institution_quote_ident($dbName);
    try {
        $stmt = $server->prepare("SELECT setting_value FROM {$dbQ}.app_settings WHERE setting_key='multi_institution.source_db' ORDER BY id DESC LIMIT 1");
        $stmt->execute();
        $value = $stmt->fetchColumn();
        return is_string($value) && hash_equals($sourceDb, $value);
    } catch (Throwable) {
        return false;
    }
}

function institution_base_name(string $name): string
{
    $name = trim($name);
    $name = preg_replace('/\s*[-–—]?\s*(?:الدراسة\s+)?(?:الصباحي|صباحي|المسائي|مسائي)\s*$/u', '', $name) ?? $name;
    return trim($name, " \t\n\r\0\x0B-–—");
}

function institution_names_from_company(string $companyName): array
{
    $base = institution_base_name($companyName);
    if ($base === '') {
        $base = 'كلية الإدارة والاقتصاد';
    }
    return [
        'morning' => $base . ' - الصباحي',
        'evening' => $base . ' - المسائي',
    ];
}

function institution_save_registry(array $registry): void
{
    $path = institution_registry_path();
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('تعذر إنشاء مجلد إعدادات المؤسسات.');
    }
    $registry['version'] = 1;
    $registry['updated_at'] = date('c');
    $json = json_encode($registry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR);
    $tmp = $path . '.tmp-' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $json, LOCK_EX) === false || !@rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('تعذر حفظ إعدادات المؤسسات. تحقق من صلاحيات مجلد storage.');
    }
}

function institution_load_registry(): array
{
    $path = institution_registry_path();
    if (!is_file($path)) {
        return institution_registry_default();
    }
    try {
        $decoded = json_decode((string)file_get_contents($path), true, 64, JSON_THROW_ON_ERROR);
        if (!is_array($decoded)) {
            return institution_registry_default();
        }
        $registry = array_replace(institution_registry_default(), $decoded);
        $registry['institutions'] = is_array($registry['institutions'] ?? null) ? $registry['institutions'] : [];
        return $registry;
    } catch (Throwable) {
        return institution_registry_default();
    }
}

function institution_quote_ident(string $name): string
{
    return '`' . str_replace('`', '``', $name) . '`';
}

/**
 * Create a clean institution database from the current institution.
 * Structure and master configuration are copied; all financial transactions are empty.
 */
function institution_clone_clean_database(array $config, string $sourceDb, string $targetDb, string $targetName): void
{
    $sourceDb = institution_validate_db_name($sourceDb);
    $targetDb = institution_validate_db_name($targetDb);
    if ($sourceDb === $targetDb) {
        throw new RuntimeException('قاعدة بيانات المؤسسة الجديدة يجب أن تكون مختلفة عن القاعدة الحالية.');
    }

    $server = institution_server_pdo($config);
    if (!institution_database_is_mizan($server, $sourceDb)) {
        throw new RuntimeException('قاعدة البيانات الحالية ليست قاعدة ميزان صالحة للنسخ.');
    }
    if (institution_database_exists($server, $targetDb)) {
        if (institution_database_is_mizan($server, $targetDb)) {
            return;
        }
        throw new RuntimeException('اسم قاعدة البيانات الجديدة مستخدم مسبقاً لقاعدة أخرى.');
    }

    $sourceQ = institution_quote_ident($sourceDb);
    $targetQ = institution_quote_ident($targetDb);
    $server->exec("CREATE DATABASE {$targetQ} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

    try {
        $server->exec('SET FOREIGN_KEY_CHECKS=0');
        $tablesStmt = $server->query("SELECT table_name FROM information_schema.tables WHERE table_schema=" . $server->quote($sourceDb) . " AND table_type='BASE TABLE' ORDER BY table_name");
        $tables = array_map(static fn(array $r): string => (string)$r['table_name'], $tablesStmt->fetchAll());
        if ($tables === []) {
            throw new RuntimeException('قاعدة البيانات الحالية لا تحتوي على جداول قابلة للنسخ.');
        }

        // Recreate tables from SHOW CREATE TABLE so foreign keys and constraints are preserved.
        $server->exec("USE {$targetQ}");
        foreach ($tables as $table) {
            $tableQ = institution_quote_ident($table);
            $createRow = $server->query("SHOW CREATE TABLE {$sourceQ}.{$tableQ}")->fetch(PDO::FETCH_NUM);
            $createSql = is_array($createRow) ? (string)($createRow[1] ?? '') : '';
            if ($createSql === '') {
                throw new RuntimeException('تعذر نسخ بنية الجدول: ' . $table);
            }
            $server->exec($createSql);
        }

        // Master data needed for an immediately usable but financially independent institution.
        $copyWhole = [
            'companies',
            'users',
            'fiscal_periods',
            'accounts',
            'standards_library',
            'accounting_policies',
            'report_account_function_map',
            'schema_migrations',
        ];
        foreach ($copyWhole as $table) {
            if (!in_array($table, $tables, true)) continue;
            $tableQ = institution_quote_ident($table);
            $server->exec("INSERT INTO {$targetQ}.{$tableQ} SELECT * FROM {$sourceQ}.{$tableQ}");
        }

        if (in_array('app_settings', $tables, true)) {
            $server->exec(
                "INSERT INTO {$targetQ}.app_settings SELECT * FROM {$sourceQ}.app_settings " .
                "WHERE setting_key NOT LIKE 'bank_statement.%'"
            );
            $markerStmt = $server->prepare(
                "INSERT INTO {$targetQ}.app_settings(company_id,setting_key,setting_value) " .
                "SELECT id,'multi_institution.source_db',? FROM {$targetQ}.companies ORDER BY id LIMIT 1 " .
                "ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)"
            );
            $markerStmt->execute([$sourceDb]);
        }
        if (in_array('compliance_checklist', $tables, true)) {
            $server->exec("INSERT INTO {$targetQ}.compliance_checklist SELECT * FROM {$sourceQ}.compliance_checklist");
            $server->exec(
                "UPDATE {$targetQ}.compliance_checklist SET status='not_started', evidence_text=NULL, reviewed_by=NULL, reviewed_at=NULL"
            );
        }

        $stmt = $server->prepare("UPDATE {$targetQ}.companies SET name_ar=? ORDER BY id LIMIT 1");
        $stmt->execute([$targetName]);
        if (in_array('users', $tables, true)) {
            $server->exec("UPDATE {$targetQ}.users SET last_login_at=NULL");
        }
        if (in_array('fiscal_periods', $tables, true)) {
            // A new institution starts with the same fiscal calendar but without inherited closures.
            $server->exec("UPDATE {$targetQ}.fiscal_periods SET status='open', closed_at=NULL, closed_by=NULL");
        }
        $server->exec('SET FOREIGN_KEY_CHECKS=1');
    } catch (Throwable $error) {
        try { $server->exec('SET FOREIGN_KEY_CHECKS=1'); } catch (Throwable) {}
        try { $server->exec("DROP DATABASE IF EXISTS {$targetQ}"); } catch (Throwable) {}
        throw $error;
    }
}

function institution_unique_db_name(PDO $server, string $baseDb, string $suffix): string
{
    $baseDb = institution_validate_db_name($baseDb);
    $suffix = preg_replace('/[^A-Za-z0-9_]+/', '_', strtolower($suffix)) ?? 'unit';
    $suffix = trim($suffix, '_');
    if ($suffix === '') $suffix = 'unit';
    $maxBase = max(1, 64 - strlen($suffix) - 1);
    $candidateBase = substr($baseDb, 0, $maxBase);
    $candidate = $candidateBase . '_' . $suffix;
    if (!institution_database_exists($server, $candidate)) return $candidate;
    for ($i = 2; $i <= 99; $i++) {
        $tail = '_' . $suffix . $i;
        $candidate = substr($baseDb, 0, max(1, 64 - strlen($tail))) . $tail;
        if (!institution_database_exists($server, $candidate)) return $candidate;
    }
    throw new RuntimeException('تعذر توليد اسم قاعدة بيانات جديد تلقائياً.');
}

/**
 * On the first run of this custom build, keep the current database as the morning
 * institution and automatically create an empty evening database with the same chart/users.
 */
function institution_bootstrap_registry(array $config): array
{
    $registry = institution_load_registry();
    if (($registry['institutions'] ?? []) !== []) {
        return $registry;
    }

    $sourceDb = institution_validate_db_name((string)($config['db_name'] ?? 'ifrs_accounting'));
    $warning = null;
    try {
        $server = institution_server_pdo($config);
        if (!institution_database_is_mizan($server, $sourceDb)) {
            return $registry;
        }
        $currentName = institution_company_name($server, $sourceDb);
        $names = institution_names_from_company($currentName);

        // Existing data remains exactly in the original database; only its display name is clarified as morning.
        $sourceQ = institution_quote_ident($sourceDb);
        $stmt = $server->prepare("UPDATE {$sourceQ}.companies SET name_ar=? ORDER BY id LIMIT 1");
        $stmt->execute([$names['morning']]);

        $eveningDb = substr($sourceDb, 0, 56) . '_evening';
        // Reuse only a database previously created by this multi-institution feature.
        // Any unrelated pre-existing database is never overwritten or adopted silently.
        if (institution_database_exists($server, $eveningDb)) {
            if (!institution_database_created_from($server, $eveningDb, $sourceDb)) {
                $eveningDb = institution_unique_db_name($server, $sourceDb, 'evening');
                institution_clone_clean_database($config, $sourceDb, $eveningDb, $names['evening']);
            }
        } else {
            institution_clone_clean_database($config, $sourceDb, $eveningDb, $names['evening']);
        }
        $eveningQ = institution_quote_ident($eveningDb);
        $stmt = $server->prepare("UPDATE {$eveningQ}.companies SET name_ar=? ORDER BY id LIMIT 1");
        $stmt->execute([$names['evening']]);

        $registry['institutions'] = [
            [
                'key' => 'morning',
                'name' => $names['morning'],
                'db_name' => $sourceDb,
                'kind' => 'morning',
                'created_at' => date('c'),
            ],
            [
                'key' => 'evening',
                'name' => $names['evening'],
                'db_name' => $eveningDb,
                'kind' => 'evening',
                'created_at' => date('c'),
            ],
        ];
        $registry['default_key'] = 'morning';
        $registry['bootstrap_warning'] = null;
    } catch (Throwable $error) {
        // Never block access to existing accounting data if automatic evening creation fails.
        $warning = $error->getMessage();
        $sourceUsable = false;
        try {
            $server ??= institution_server_pdo($config);
            $sourceUsable = institution_database_is_mizan($server, $sourceDb);
            $currentName = $sourceUsable ? institution_company_name($server, $sourceDb) : '';
        } catch (Throwable) {
            $currentName = '';
            $sourceUsable = false;
        }
        $registry['institutions'] = [[
            'key' => 'morning',
            'name' => $currentName !== '' ? $currentName : 'المؤسسة الرئيسية',
            'db_name' => $sourceDb,
            'kind' => 'morning',
            'created_at' => date('c'),
        ]];
        $registry['default_key'] = 'morning';
        $registry['bootstrap_warning'] = $warning;
        // If MySQL itself is temporarily unavailable, keep this fallback only in memory
        // so the next request retries automatic morning/evening initialization.
        if (!$sourceUsable) {
            return $registry;
        }
    }
    institution_save_registry($registry);
    return $registry;
}

function institution_find(array $registry, string $key): ?array
{
    foreach (($registry['institutions'] ?? []) as $item) {
        if (is_array($item) && hash_equals((string)($item['key'] ?? ''), $key)) {
            return $item;
        }
    }
    return null;
}

function institution_current(array $registry): ?array
{
    $key = (string)($_SESSION['institution_key'] ?? '');
    if ($key === '') return null;
    return institution_find($registry, $key);
}

function institution_select(array $registry, string $key): array
{
    $institution = institution_find($registry, $key);
    if (!$institution) {
        throw new RuntimeException('المؤسسة المختارة غير موجودة.');
    }
    $dbName = institution_validate_db_name((string)($institution['db_name'] ?? ''));
    unset($_SESSION['user'], $_SESSION['company_cache'], $_SESSION['login_attempts'], $_SESSION['login_last_attempt']);
    $_SESSION['institution_key'] = (string)$institution['key'];
    $_SESSION['institution_name'] = (string)$institution['name'];
    $_SESSION['institution_db_name'] = $dbName;
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    session_regenerate_id(true);
    return $institution;
}

function institution_clear_selection(): void
{
    unset(
        $_SESSION['institution_key'],
        $_SESSION['institution_name'],
        $_SESSION['institution_db_name'],
        $_SESSION['user'],
        $_SESSION['company_cache'],
        $_SESSION['login_attempts'],
        $_SESSION['login_last_attempt']
    );
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    session_regenerate_id(true);
}

function institution_session_snapshot(): array
{
    return [
        'institution_key' => $_SESSION['institution_key'] ?? null,
        'institution_name' => $_SESSION['institution_name'] ?? null,
        'institution_db_name' => $_SESSION['institution_db_name'] ?? null,
    ];
}

function institution_restore_session_snapshot(array $snapshot): void
{
    foreach (['institution_key', 'institution_name', 'institution_db_name'] as $key) {
        if (isset($snapshot[$key]) && is_string($snapshot[$key]) && $snapshot[$key] !== '') {
            $_SESSION[$key] = $snapshot[$key];
        }
    }
}

function institution_storage_key(): string
{
    $key = (string)($_SESSION['institution_key'] ?? 'main');
    $key = preg_replace('/[^A-Za-z0-9_-]+/', '_', $key) ?? 'main';
    return $key !== '' ? $key : 'main';
}

function institution_backup_dir(): string
{
    return __DIR__ . '/../storage/backups/' . institution_storage_key();
}

function institution_add_from_current(array $config, string $name, string $dbSuffix = ''): array
{
    $name = trim($name);
    if ($name === '' || mb_strlen($name) > 190) {
        throw new RuntimeException('أدخل اسماً صحيحاً للمؤسسة الجديدة.');
    }
    $registry = institution_load_registry();
    $current = institution_current($registry);
    if (!$current) {
        throw new RuntimeException('اختر المؤسسة الحالية أولاً.');
    }
    $sourceDb = institution_validate_db_name((string)$current['db_name']);
    $server = institution_server_pdo($config);
    $suffix = $dbSuffix !== '' ? $dbSuffix : 'unit';
    $targetDb = institution_unique_db_name($server, $sourceDb, $suffix);
    institution_clone_clean_database($config, $sourceDb, $targetDb, $name);

    $baseKey = institution_safe_key($dbSuffix !== '' ? $dbSuffix : 'unit');
    $key = $baseKey;
    $n = 2;
    while (institution_find($registry, $key)) {
        $key = substr($baseKey, 0, 42) . '-' . $n++;
    }
    $item = [
        'key' => $key,
        'name' => $name,
        'db_name' => $targetDb,
        'kind' => 'custom',
        'created_at' => date('c'),
    ];
    $registry['institutions'][] = $item;
    institution_save_registry($registry);
    return $item;
}

function institution_rename(array $config, string $key, string $newName): array
{
    $newName = trim($newName);
    if ($newName === '' || mb_strlen($newName) > 190) {
        throw new RuntimeException('اسم المؤسسة غير صالح.');
    }
    $registry = institution_load_registry();
    $found = false;
    foreach ($registry['institutions'] as &$item) {
        if (!is_array($item) || (string)($item['key'] ?? '') !== $key) continue;
        $dbName = institution_validate_db_name((string)$item['db_name']);
        $server = institution_server_pdo($config);
        $dbQ = institution_quote_ident($dbName);
        $stmt = $server->prepare("UPDATE {$dbQ}.companies SET name_ar=? ORDER BY id LIMIT 1");
        $stmt->execute([$newName]);
        $item['name'] = $newName;
        $found = true;
        break;
    }
    unset($item);
    if (!$found) throw new RuntimeException('المؤسسة غير موجودة.');
    institution_save_registry($registry);
    if ((string)($_SESSION['institution_key'] ?? '') === $key) {
        $_SESSION['institution_name'] = $newName;
    }
    return $registry;
}
