<?php
declare(strict_types=1);

/**
 * Bank reconciliation helpers.
 * The bank statement is entered by the user and stored as JSON in app_settings.
 * All book-side figures and reconciliation differences are calculated from posted journal lines.
 */

function br_bank_accounts(): array
{
    $pdo = db();
    $stmt = $pdo->prepare(
        "SELECT id,code,name_ar,account_type,normal_balance,is_cash_account
         FROM accounts
         WHERE company_id=? AND is_active=1 AND is_postable=1
           AND (is_cash_account=1 OR name_ar LIKE '%بنك%' OR name_ar LIKE '%مصرف%')
         ORDER BY is_cash_account DESC, code"
    );
    $stmt->execute([company_id()]);
    $rows = $stmt->fetchAll();
    if ($rows !== []) return $rows;

    // Fallback for charts of accounts where bank accounts were not marked as cash accounts.
    $stmt = $pdo->prepare(
        "SELECT id,code,name_ar,account_type,normal_balance,is_cash_account
         FROM accounts
         WHERE company_id=? AND is_active=1 AND is_postable=1 AND account_type IN ('asset','contra_asset')
         ORDER BY code"
    );
    $stmt->execute([company_id()]);
    return $stmt->fetchAll();
}

function br_month_bounds(string $month): array
{
    if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
        throw new RuntimeException('الشهر المختار غير صالح.');
    }
    $start = DateTimeImmutable::createFromFormat('!Y-m-d', $month . '-01');
    if (!$start || $start->format('Y-m') !== $month) {
        throw new RuntimeException('الشهر المختار غير صالح.');
    }
    $end = $start->modify('last day of this month');
    return [$start->format('Y-m-d'), $end->format('Y-m-d')];
}

function br_setting_key(int $accountId, string $month): string
{
    return 'bank_statement.' . $accountId . '.' . $month;
}

function br_load_statement(int $accountId, string $month): array
{
    $default = [
        'bank_name' => '',
        'bank_account_no' => '',
        'closing_balance' => 0.0,
        'rows' => [],
        'updated_at' => null,
    ];
    if ($accountId <= 0) return $default;
    $raw = (string)setting_get(br_setting_key($accountId, $month), '');
    if ($raw === '') return $default;
    try {
        $decoded = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($decoded)) return $default;
        $decoded['rows'] = is_array($decoded['rows'] ?? null) ? $decoded['rows'] : [];
        $decoded['closing_balance'] = (float)($decoded['closing_balance'] ?? 0);
        return array_replace($default, $decoded);
    } catch (Throwable $e) {
        log_exception($e);
        return $default;
    }
}

function br_normalize_reference(string $reference): string
{
    $reference = mb_strtoupper(trim($reference));
    return preg_replace('/[^\p{L}\p{N}]+/u', '', $reference) ?? '';
}

function br_signed_amount(mixed $value): float
{
    $text = trim((string)$value);
    if ($text === '') return 0.0;
    $text = strtr($text, ['٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9','۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
    $text = str_replace([',', ' ', '٬'], '', $text);
    $text = str_replace('٫', '.', $text);
    if (!is_numeric($text)) throw new RuntimeException('يوجد مبلغ غير صالح في كشف البنك.');
    return round((float)$text, 3);
}

function br_prepare_statement_payload(array $post): array
{
    $accountId = (int)($post['account_id'] ?? 0);
    $month = trim((string)($post['month'] ?? ''));
    if ($accountId <= 0) throw new RuntimeException('اختر حساب البنك.');
    br_month_bounds($month);

    $stmt = db()->prepare('SELECT id FROM accounts WHERE id=? AND company_id=? AND is_active=1 AND is_postable=1');
    $stmt->execute([$accountId, company_id()]);
    if (!$stmt->fetchColumn()) throw new RuntimeException('حساب البنك المختار غير صالح.');

    $bankName = mb_substr(trim((string)($post['bank_name'] ?? '')), 0, 190);
    $bankAccountNo = mb_substr(trim((string)($post['bank_account_no'] ?? '')), 0, 100);
    $closingBalance = br_signed_amount($post['closing_balance'] ?? 0);

    $dates = (array)($post['statement_date'] ?? []);
    $references = (array)($post['statement_reference'] ?? []);
    $descriptions = (array)($post['statement_description'] ?? []);
    $deposits = (array)($post['statement_deposit'] ?? []);
    $withdrawals = (array)($post['statement_withdrawal'] ?? []);
    $count = min(300, max(count($dates), count($references), count($descriptions), count($deposits), count($withdrawals)));
    $rows = [];
    for ($i = 0; $i < $count; $i++) {
        $date = trim((string)($dates[$i] ?? ''));
        $reference = mb_substr(trim((string)($references[$i] ?? '')), 0, 100);
        $description = mb_substr(trim((string)($descriptions[$i] ?? '')), 0, 300);
        $deposit = abs(br_signed_amount($deposits[$i] ?? 0));
        $withdrawal = abs(br_signed_amount($withdrawals[$i] ?? 0));
        if ($date === '' && $reference === '' && $description === '' && $deposit < 0.0005 && $withdrawal < 0.0005) continue;
        if (!valid_date($date)) throw new RuntimeException('يوجد تاريخ غير صالح في كشف البنك.');
        if ($deposit >= 0.0005 && $withdrawal >= 0.0005) throw new RuntimeException('كل حركة في كشف البنك يجب أن تكون إيداعاً أو سحباً، وليس الاثنين معاً.');
        if ($deposit < 0.0005 && $withdrawal < 0.0005) throw new RuntimeException('أدخل مبلغ الإيداع أو السحب لكل حركة في كشف البنك.');
        $rows[] = [
            'date' => $date,
            'reference' => $reference,
            'description' => $description,
            'deposit' => $deposit,
            'withdrawal' => $withdrawal,
        ];
    }

    return [
        'account_id' => $accountId,
        'month' => $month,
        'bank_name' => $bankName,
        'bank_account_no' => $bankAccountNo,
        'closing_balance' => $closingBalance,
        'rows' => $rows,
        'updated_at' => date('Y-m-d H:i:s'),
    ];
}

function br_save_statement(array $post): array
{
    $payload = br_prepare_statement_payload($post);
    $key = br_setting_key((int)$payload['account_id'], (string)$payload['month']);
    setting_set($key, $payload);
    audit('save', 'bank_statement', $key, null, [
        'account_id' => $payload['account_id'],
        'month' => $payload['month'],
        'rows' => count($payload['rows']),
        'closing_balance' => $payload['closing_balance'],
    ]);
    return $payload;
}

function br_clear_statement(int $accountId, string $month): void
{
    br_month_bounds($month);
    if ($accountId <= 0) throw new RuntimeException('اختر حساب البنك.');
    $key = br_setting_key($accountId, $month);
    $stmt = db()->prepare('DELETE FROM app_settings WHERE company_id=? AND setting_key=?');
    $stmt->execute([company_id(), $key]);
    audit('delete', 'bank_statement', $key, ['account_id'=>$accountId,'month'=>$month], null);
}

function br_book_data(int $accountId, string $month): array
{
    [$from, $to] = br_month_bounds($month);
    $pdo = db();
    $stmt = $pdo->prepare('SELECT id,code,name_ar,normal_balance FROM accounts WHERE id=? AND company_id=? AND is_active=1');
    $stmt->execute([$accountId, company_id()]);
    $account = $stmt->fetch();
    if (!$account) throw new RuntimeException('حساب البنك غير موجود.');
    $normalDebit = (string)$account['normal_balance'] !== 'credit';

    $openingSql = "SELECT COALESCE(SUM(jl.debit-jl.credit),0)
                   FROM journal_lines jl
                   JOIN journal_entries je ON je.id=jl.journal_entry_id
                   WHERE je.company_id=? AND " . posted_status_condition('je') . "
                     AND jl.account_id=? AND je.entry_date<?";
    $stmt = $pdo->prepare($openingSql);
    $stmt->execute([company_id(), $accountId, $from]);
    $rawOpening = (float)$stmt->fetchColumn();
    $opening = $normalDebit ? $rawOpening : -$rawOpening;

    $sql = "SELECT jl.id AS line_id,je.id AS entry_id,je.voucher_no,je.entry_date,je.reference_no,
                   je.description,je.source_type,jl.line_description,jl.debit,jl.credit,
                   vd.check_no,vd.check_date
            FROM journal_lines jl
            JOIN journal_entries je ON je.id=jl.journal_entry_id
            LEFT JOIN voucher_details vd ON vd.journal_entry_id=je.id
            WHERE je.company_id=? AND " . posted_status_condition('je') . "
              AND jl.account_id=? AND je.entry_date BETWEEN ? AND ?
            ORDER BY je.entry_date,je.id,jl.id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([company_id(), $accountId, $from, $to]);
    $transactions = [];
    $deposits = 0.0;
    $withdrawals = 0.0;
    foreach ($stmt->fetchAll() as $row) {
        $debit = (float)$row['debit'];
        $credit = (float)$row['credit'];
        $increase = $normalDebit ? $debit : $credit;
        $decrease = $normalDebit ? $credit : $debit;
        if ($increase >= 0.0005) {
            $type = 'deposit'; $amount = $increase; $deposits += $amount;
        } elseif ($decrease >= 0.0005) {
            $type = 'withdrawal'; $amount = $decrease; $withdrawals += $amount;
        } else {
            continue;
        }
        $description = trim((string)($row['line_description'] ?: $row['description']));
        $references = array_values(array_filter([
            trim((string)$row['reference_no']),
            trim((string)$row['check_no']),
            trim((string)$row['voucher_no']),
        ], static fn($v) => $v !== ''));
        $transactions[] = [
            'line_id' => (int)$row['line_id'],
            'entry_id' => (int)$row['entry_id'],
            'voucher_no' => (string)$row['voucher_no'],
            'date' => (string)$row['entry_date'],
            'reference' => trim((string)$row['reference_no']),
            'check_no' => trim((string)$row['check_no']),
            'description' => $description,
            'source_type' => (string)$row['source_type'],
            'type' => $type,
            'amount' => round($amount, 3),
            'reference_tokens' => array_map('br_normalize_reference', $references),
        ];
    }

    $closing = round($opening + $deposits - $withdrawals, 3);
    return [
        'account' => $account,
        'from' => $from,
        'to' => $to,
        'opening' => round($opening, 3),
        'deposits' => round($deposits, 3),
        'withdrawals' => round($withdrawals, 3),
        'closing' => $closing,
        'transactions' => $transactions,
    ];
}

function br_reference_match_score(string $bankReference, array $bookTokens): int
{
    $bank = br_normalize_reference($bankReference);
    if ($bank === '') return 0;
    $best = 0;
    foreach ($bookTokens as $token) {
        if ($token === '') continue;
        if ($bank === $token) return 30;
        if (mb_strlen($bank) >= 3 && mb_strlen($token) >= 3 && (str_contains($bank, $token) || str_contains($token, $bank))) {
            $best = max($best, 18);
        }
    }
    return $best;
}

function br_date_diff_days(string $a, string $b): int
{
    try {
        $d1 = new DateTimeImmutable($a);
        $d2 = new DateTimeImmutable($b);
        return (int)$d1->diff($d2)->days;
    } catch (Throwable) {
        return 9999;
    }
}

function br_match_statement(array $bookData, array $statement): array
{
    $books = array_values($bookData['transactions'] ?? []);
    $bankRows = [];
    foreach (($statement['rows'] ?? []) as $idx => $row) {
        $deposit = (float)($row['deposit'] ?? 0);
        $withdrawal = (float)($row['withdrawal'] ?? 0);
        $type = $deposit >= 0.0005 ? 'deposit' : 'withdrawal';
        $amount = $type === 'deposit' ? $deposit : $withdrawal;
        $bankRows[] = array_merge($row, [
            '_index' => $idx,
            'type' => $type,
            'amount' => round($amount, 3),
            'matched_book_index' => null,
            'match_quality' => '',
        ]);
    }

    $matchedBook = [];
    foreach ($bankRows as $bi => &$bank) {
        $candidates = [];
        foreach ($books as $ki => $book) {
            if (isset($matchedBook[$ki])) continue;
            if ((string)$book['type'] !== (string)$bank['type']) continue;
            if (abs((float)$book['amount'] - (float)$bank['amount']) > 0.0005) continue;
            $days = br_date_diff_days((string)$bank['date'], (string)$book['date']);
            $refScore = br_reference_match_score((string)($bank['reference'] ?? ''), (array)($book['reference_tokens'] ?? []));
            // Exact/contained reference may legitimately clear several days later; amount-only matches are kept tighter.
            $maxDays = $refScore >= 18 ? 15 : 5;
            if ($days > $maxDays) continue;
            $score = ($refScore * 100) - ($days * 10);
            // Prefer same-day and true check/reference matches when amounts repeat.
            if ($days === 0) $score += 25;
            if ((string)$book['source_type'] === 'payment' && (string)$bank['type'] === 'withdrawal') $score += 3;
            $candidates[] = ['index'=>$ki,'score'=>$score,'days'=>$days,'ref'=>$refScore];
        }
        if ($candidates !== []) {
            $best = $candidates[0];
            foreach ($candidates as $candidate) {
                if ($candidate['score'] > $best['score']
                    || ($candidate['score'] === $best['score'] && $candidate['days'] < $best['days'])
                    || ($candidate['score'] === $best['score'] && $candidate['days'] === $best['days'] && $candidate['ref'] > $best['ref'])) {
                    $best = $candidate;
                }
            }
            $matchedBook[(int)$best['index']] = $bi;
            $bank['matched_book_index'] = (int)$best['index'];
            $bank['match_quality'] = (int)$best['ref'] >= 30 ? 'مرجع ومبلغ' : ((int)$best['days'] === 0 ? 'مبلغ وتاريخ' : 'مبلغ/أقرب تاريخ');
        }
    }
    unset($bank);

    $unmatchedBank = array_values(array_filter($bankRows, static fn($row) => $row['matched_book_index'] === null));
    $unmatchedBooks = [];
    foreach ($books as $ki => $book) {
        if (!isset($matchedBook[$ki])) $unmatchedBooks[] = $book;
    }

    $sumBy = static function(array $rows, string $type): float {
        $sum = 0.0;
        foreach ($rows as $row) if ((string)$row['type'] === $type) $sum += (float)$row['amount'];
        return round($sum, 3);
    };

    $bankDepositsNotBooks = $sumBy($unmatchedBank, 'deposit');
    $bankWithdrawalsNotBooks = $sumBy($unmatchedBank, 'withdrawal');
    $booksDepositsNotBank = 0.0;
    $outstandingChecks = 0.0;
    $booksWithdrawalsNotBank = 0.0;
    foreach ($unmatchedBooks as $book) {
        if ((string)$book['type'] === 'deposit') {
            $booksDepositsNotBank += (float)$book['amount'];
        } else {
            $isCheck = trim((string)($book['check_no'] ?? '')) !== '' || (string)($book['source_type'] ?? '') === 'payment';
            if ($isCheck) $outstandingChecks += (float)$book['amount'];
            else $booksWithdrawalsNotBank += (float)$book['amount'];
        }
    }
    $booksDepositsNotBank = round($booksDepositsNotBank, 3);
    $outstandingChecks = round($outstandingChecks, 3);
    $booksWithdrawalsNotBank = round($booksWithdrawalsNotBank, 3);

    $bankBalance = round((float)($statement['closing_balance'] ?? 0), 3);
    $adjustedBankBalance = round(
        $bankBalance
        - $outstandingChecks
        - $booksWithdrawalsNotBank
        + $booksDepositsNotBank
        + $bankWithdrawalsNotBooks
        - $bankDepositsNotBooks,
        3
    );
    $difference = round((float)$bookData['closing'] - $adjustedBankBalance, 3);

    $statementDeposits = 0.0; $statementWithdrawals = 0.0;
    foreach ($bankRows as $row) {
        $statementDeposits += (float)($row['deposit'] ?? 0);
        $statementWithdrawals += (float)($row['withdrawal'] ?? 0);
    }
    $statementOpening = round($bankBalance - $statementDeposits + $statementWithdrawals, 3);

    return [
        'bank_rows' => $bankRows,
        'matched_count' => count($bankRows) - count($unmatchedBank),
        'unmatched_bank' => $unmatchedBank,
        'unmatched_books' => $unmatchedBooks,
        'bank_deposits_not_books' => $bankDepositsNotBooks,
        'bank_withdrawals_not_books' => $bankWithdrawalsNotBooks,
        'books_deposits_not_bank' => $booksDepositsNotBank,
        'outstanding_checks' => $outstandingChecks,
        'books_withdrawals_not_bank' => $booksWithdrawalsNotBank,
        'bank_balance' => $bankBalance,
        'adjusted_bank_balance' => $adjustedBankBalance,
        'difference' => $difference,
        'statement_deposits' => round($statementDeposits, 3),
        'statement_withdrawals' => round($statementWithdrawals, 3),
        'statement_opening' => $statementOpening,
    ];
}

function br_month_label_ar(string $month): string
{
    static $names = [1=>'كانون الثاني',2=>'شباط',3=>'آذار',4=>'نيسان',5=>'أيار',6=>'حزيران',7=>'تموز',8=>'آب',9=>'أيلول',10=>'تشرين الأول',11=>'تشرين الثاني',12=>'كانون الأول'];
    [$year,$m] = array_map('intval', explode('-', $month));
    return ($names[$m] ?? (string)$m) . ' ' . $year;
}

function br_money(float $amount): string
{
    $places = (int)(company()['decimal_places'] ?? 0);
    return number_format($amount, max(0, min(3, $places)), '.', ',');
}
