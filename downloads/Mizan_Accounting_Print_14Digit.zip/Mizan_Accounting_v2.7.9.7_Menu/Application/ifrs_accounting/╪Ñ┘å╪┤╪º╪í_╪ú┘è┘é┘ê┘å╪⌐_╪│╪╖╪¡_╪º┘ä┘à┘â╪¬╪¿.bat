@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "LAUNCHER=%ProgramFiles%\Mizan Accounting\Start_Mizan_Accounting.cmd"
set "ICON=%ProgramFiles%\Mizan Accounting\Mizan_Accounting_Icon.ico"
if not exist "%LAUNCHER%" (
  set "LAUNCHER=%~dp0launcher\Start_Mizan_Accounting.cmd"
  set "ICON=%~dp0launcher\app_icon.ico"
)
if not exist "%LAUNCHER%" (
  echo لم يتم العثور على ملف تشغيل نظام الميزان المحاسبي.
  echo أعد تشغيل START_INSTALL.cmd كمسؤول لإصلاح التثبيت.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\create_shortcut.ps1" -LauncherPath "%LAUNCHER%" -IconPath "%ICON%"
if errorlevel 1 (
  echo تعذر إنشاء الاختصار.
  pause
  exit /b 2
)
echo تم إنشاء أيقونة نظام الميزان المحاسبي بنجاح.
pause
endlocal
