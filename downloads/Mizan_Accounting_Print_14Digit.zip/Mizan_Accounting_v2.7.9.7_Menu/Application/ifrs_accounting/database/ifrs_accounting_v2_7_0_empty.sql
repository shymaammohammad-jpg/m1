-- قاعدة بيانات فارغة للتثبيت الجديد على XAMPP — إصدار التطبيق 2.7.0
CREATE DATABASE IF NOT EXISTS `ifrs_accounting_v262`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE `ifrs_accounting_v262`;
-- لا تضف جداول يدوياً. افتح install.php لإنشاء مخطط قاعدة البيانات واستيراد دليل الحسابات.
-- رقم مخطط قاعدة البيانات الحالي: 2.3.0.
