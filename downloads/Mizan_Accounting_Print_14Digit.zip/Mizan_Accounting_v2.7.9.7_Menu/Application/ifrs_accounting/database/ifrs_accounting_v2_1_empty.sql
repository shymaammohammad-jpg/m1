-- قاعدة بيانات فارغة للتثبيت الجديد على XAMPP — الإصدار 2.3.0
CREATE DATABASE IF NOT EXISTS `ifrs_accounting_v21`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE `ifrs_accounting_v21`;
-- لا تضف جداول يدوياً. افتح install.php ليقوم النظام بإنشاء المخطط واستيراد دليل الحسابات.
