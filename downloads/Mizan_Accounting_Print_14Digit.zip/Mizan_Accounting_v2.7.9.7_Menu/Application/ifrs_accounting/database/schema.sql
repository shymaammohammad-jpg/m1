SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS schema_migrations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  version VARCHAR(30) NOT NULL UNIQUE,
  applied_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS companies (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name_ar VARCHAR(190) NOT NULL,
  name_en VARCHAR(190) NULL,
  ministry_name_ar VARCHAR(190) NULL,
  formation_name_ar VARCHAR(190) NULL,
  registration_no VARCHAR(100) NULL,
  tax_no VARCHAR(100) NULL,
  address_ar VARCHAR(255) NULL,
  phone VARCHAR(60) NULL,
  email VARCHAR(190) NULL,
  currency_code VARCHAR(10) NOT NULL DEFAULT 'IQD',
  currency_name_ar VARCHAR(50) NOT NULL DEFAULT 'دينار عراقي',
  decimal_places TINYINT UNSIGNED NOT NULL DEFAULT 0,
  fiscal_year_start_month TINYINT UNSIGNED NOT NULL DEFAULT 1,
  reporting_basis ENUM('going_concern','other') NOT NULL DEFAULT 'going_concern',
  statement_scope ENUM('separate','consolidated') NOT NULL DEFAULT 'separate',
  expense_presentation ENUM('functional','natural','summary') NOT NULL DEFAULT 'functional',
  rounding_level VARCHAR(50) NOT NULL DEFAULT 'دينار',
  ifrs_transition_date DATE NULL,
  previous_gaap_name VARCHAR(190) NULL,
  logo_path VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  full_name VARCHAR(190) NOT NULL,
  username VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','accountant','viewer') NOT NULL DEFAULT 'accountant',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  last_login_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_company_username(company_id,username),
  CONSTRAINT fk_users_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fiscal_periods (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  name_ar VARCHAR(100) NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  closed_at DATETIME NULL,
  closed_by INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_period(company_id,start_date,end_date),
  KEY idx_period_company_dates(company_id,start_date,end_date),
  CONSTRAINT fk_period_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_period_closed_by FOREIGN KEY(closed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS accounts (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  code VARCHAR(30) NOT NULL,
  name_ar VARCHAR(255) NOT NULL,
  name_en VARCHAR(255) NULL,
  parent_id INT UNSIGNED NULL,
  level_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
  account_type ENUM('asset','contra_asset','liability','equity','revenue','expense','oci','off_balance') NOT NULL,
  normal_balance ENUM('debit','credit') NOT NULL,
  statement_section VARCHAR(80) NOT NULL DEFAULT 'other',
  cash_flow_category ENUM('none','operating','investing','financing') NOT NULL DEFAULT 'operating',
  is_cash_account TINYINT(1) NOT NULL DEFAULT 0,
  is_postable TINYINT(1) NOT NULL DEFAULT 1,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  source_reference VARCHAR(190) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_account_code(company_id,code),
  KEY idx_accounts_parent(parent_id),
  KEY idx_accounts_company_type(company_id,account_type),
  KEY idx_accounts_search(company_id,is_active,is_postable,code),
  CONSTRAINT fk_accounts_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_accounts_parent FOREIGN KEY(parent_id) REFERENCES accounts(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cost_centers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  code VARCHAR(30) NOT NULL,
  name_ar VARCHAR(190) NOT NULL,
  functional_report_code ENUM('none','5','6','7','8') NOT NULL DEFAULT 'none',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cost_center(company_id,code),
  CONSTRAINT fk_cc_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS parties (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  party_type ENUM('customer','supplier','employee','other') NOT NULL DEFAULT 'other',
  code VARCHAR(30) NULL,
  name_ar VARCHAR(190) NOT NULL,
  tax_no VARCHAR(100) NULL,
  phone VARCHAR(60) NULL,
  email VARCHAR(190) NULL,
  address_ar VARCHAR(255) NULL,
  account_id INT UNSIGNED NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_party_code(company_id,code),
  CONSTRAINT fk_party_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_party_account FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journal_entries (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  period_id INT UNSIGNED NULL,
  document_series VARCHAR(12) NOT NULL DEFAULT 'JOURNAL',
  voucher_no VARCHAR(50) NOT NULL,
  entry_date DATE NOT NULL,
  reference_no VARCHAR(100) NULL,
  description VARCHAR(500) NOT NULL,
  source_type ENUM('manual','opening','adjustment','receipt','payment','closing','reversal') NOT NULL DEFAULT 'manual',
  origin_standard VARCHAR(30) NULL,
  equity_movement_type ENUM('none','profit','dividend','reserve','capital','accumulated_loss_amortization','policy_change','nci','oci','other') NOT NULL DEFAULT 'none',
  status ENUM('draft','posted','reversed','cancelled') NOT NULL DEFAULT 'draft',
  approval_status ENUM('not_required','pending','approved','rejected') NOT NULL DEFAULT 'not_required',
  reversal_of BIGINT UNSIGNED NULL,
  version_no INT UNSIGNED NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NOT NULL,
  last_modified_by INT UNSIGNED NULL,
  submitted_by INT UNSIGNED NULL,
  submitted_at DATETIME NULL,
  approved_by INT UNSIGNED NULL,
  approved_at DATETIME NULL,
  approval_notes VARCHAR(500) NULL,
  posted_by INT UNSIGNED NULL,
  posted_at DATETIME NULL,
  unposted_by INT UNSIGNED NULL,
  unposted_at DATETIME NULL,
  cancelled_by INT UNSIGNED NULL,
  cancelled_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_voucher_series(company_id,document_series,voucher_no),
  KEY idx_je_company_date_status(company_id,entry_date,status),
  KEY idx_je_period(period_id,status),
  KEY idx_je_reversal(reversal_of),
  CONSTRAINT fk_je_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_je_period FOREIGN KEY(period_id) REFERENCES fiscal_periods(id) ON DELETE SET NULL,
  CONSTRAINT fk_je_created_by FOREIGN KEY(created_by) REFERENCES users(id),
  CONSTRAINT fk_je_modified_by FOREIGN KEY(last_modified_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_je_submitted_by FOREIGN KEY(submitted_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_je_approved_by FOREIGN KEY(approved_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_je_posted_by FOREIGN KEY(posted_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_je_unposted_by FOREIGN KEY(unposted_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_je_cancelled_by FOREIGN KEY(cancelled_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_je_reversal FOREIGN KEY(reversal_of) REFERENCES journal_entries(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journal_lines (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  journal_entry_id BIGINT UNSIGNED NOT NULL,
  account_id INT UNSIGNED NOT NULL,
  cost_center_id INT UNSIGNED NULL,
  party_id INT UNSIGNED NULL,
  currency_code VARCHAR(10) NULL,
  exchange_rate DECIMAL(20,8) NOT NULL DEFAULT 1,
  foreign_amount DECIMAL(20,3) NOT NULL DEFAULT 0,
  cash_flow_line_code VARCHAR(40) NULL,
  line_description VARCHAR(500) NULL,
  debit DECIMAL(20,3) NOT NULL DEFAULT 0,
  credit DECIMAL(20,3) NOT NULL DEFAULT 0,
  line_order INT UNSIGNED NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_jl_entry(journal_entry_id),
  KEY idx_jl_account_entry(account_id,journal_entry_id),
  KEY idx_jl_party(party_id),
  KEY idx_jl_cost_center(cost_center_id),
  CONSTRAINT fk_jl_entry FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
  CONSTRAINT fk_jl_account FOREIGN KEY(account_id) REFERENCES accounts(id),
  CONSTRAINT fk_jl_cc FOREIGN KEY(cost_center_id) REFERENCES cost_centers(id) ON DELETE SET NULL,
  CONSTRAINT fk_jl_party FOREIGN KEY(party_id) REFERENCES parties(id) ON DELETE SET NULL,
  CONSTRAINT chk_jl_nonnegative CHECK (debit >= 0 AND credit >= 0),
  CONSTRAINT chk_jl_one_side CHECK ((debit > 0 AND credit = 0) OR (credit > 0 AND debit = 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS document_sequences (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  prefix VARCHAR(12) NOT NULL,
  sequence_year SMALLINT UNSIGNED NOT NULL,
  last_number INT UNSIGNED NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_document_sequence(company_id,prefix,sequence_year),
  CONSTRAINT fk_seq_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_settings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  setting_key VARCHAR(100) NOT NULL,
  setting_value LONGTEXT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_setting(company_id,setting_key),
  CONSTRAINT fk_setting_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id VARCHAR(100) NULL,
  before_json LONGTEXT NULL,
  after_json LONGTEXT NULL,
  details_json LONGTEXT NULL,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_audit_company_date(company_id,created_at),
  KEY idx_audit_entity(entity_type,entity_id),
  CONSTRAINT fk_audit_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_audit_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS standards_library (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL UNIQUE,
  title_ar VARCHAR(255) NOT NULL,
  standard_type ENUM('IAS','IFRS') NOT NULL,
  standard_no VARCHAR(10) NOT NULL,
  guide_order INT UNSIGNED NOT NULL,
  guide_page VARCHAR(30) NULL,
  is_applicable TINYINT(1) NOT NULL DEFAULT 1,
  notes TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS accounting_policies (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  standard_code VARCHAR(20) NOT NULL,
  title_ar VARCHAR(255) NOT NULL,
  policy_text LONGTEXT NOT NULL,
  effective_from DATE NULL,
  review_date DATE NULL,
  status ENUM('draft','approved','retired') NOT NULL DEFAULT 'draft',
  approved_by INT UNSIGNED NULL,
  approved_at DATETIME NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_policy(company_id,standard_code,title_ar),
  CONSTRAINT fk_policy_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_policy_created FOREIGN KEY(created_by) REFERENCES users(id),
  CONSTRAINT fk_policy_approved FOREIGN KEY(approved_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS financial_statement_notes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  period_id INT UNSIGNED NULL,
  note_no VARCHAR(30) NOT NULL,
  standard_code VARCHAR(20) NULL,
  title_ar VARCHAR(255) NOT NULL,
  note_text LONGTEXT NOT NULL,
  comparative_text LONGTEXT NULL,
  materiality_level ENUM('normal','material','critical') NOT NULL DEFAULT 'normal',
  status ENUM('draft','approved') NOT NULL DEFAULT 'draft',
  display_order INT UNSIGNED NOT NULL DEFAULT 1,
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_note(company_id,period_id,note_no),
  CONSTRAINT fk_note_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_note_period FOREIGN KEY(period_id) REFERENCES fiscal_periods(id) ON DELETE CASCADE,
  CONSTRAINT fk_note_user FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ifrs_transition_adjustments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  adjustment_date DATE NOT NULL,
  reference_no VARCHAR(100) NULL,
  standard_code VARCHAR(20) NOT NULL,
  description VARCHAR(500) NOT NULL,
  previous_gaap_amount DECIMAL(20,3) NOT NULL DEFAULT 0,
  ifrs_amount DECIMAL(20,3) NOT NULL DEFAULT 0,
  equity_effect DECIMAL(20,3) NOT NULL DEFAULT 0,
  comprehensive_income_effect DECIMAL(20,3) NOT NULL DEFAULT 0,
  debit_account_id INT UNSIGNED NULL,
  credit_account_id INT UNSIGNED NULL,
  journal_entry_id BIGINT UNSIGNED NULL,
  adjustment_type ENUM('recognition','derecognition','reclassification','remeasurement','policy','error') NOT NULL DEFAULT 'remeasurement',
  status ENUM('draft','posted') NOT NULL DEFAULT 'draft',
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_transition_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_transition_debit FOREIGN KEY(debit_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_transition_credit FOREIGN KEY(credit_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_transition_journal FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE SET NULL,
  CONSTRAINT fk_transition_user FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fixed_assets (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  asset_code VARCHAR(50) NOT NULL,
  name_ar VARCHAR(255) NOT NULL,
  asset_class VARCHAR(100) NOT NULL,
  acquisition_date DATE NOT NULL,
  available_for_use_date DATE NULL,
  cost DECIMAL(20,3) NOT NULL DEFAULT 0,
  residual_value DECIMAL(20,3) NOT NULL DEFAULT 0,
  useful_life_months INT UNSIGNED NOT NULL DEFAULT 60,
  depreciation_method ENUM('straight_line','declining_balance','units_of_production','none') NOT NULL DEFAULT 'straight_line',
  accumulated_depreciation DECIMAL(20,3) NOT NULL DEFAULT 0,
  impairment_loss DECIMAL(20,3) NOT NULL DEFAULT 0,
  revaluation_surplus DECIMAL(20,3) NOT NULL DEFAULT 0,
  account_id INT UNSIGNED NULL,
  accumulated_account_id INT UNSIGNED NULL,
  depreciation_expense_account_id INT UNSIGNED NULL,
  impairment_account_id INT UNSIGNED NULL,
  cost_center_id INT UNSIGNED NULL,
  status ENUM('active','idle','held_for_sale','disposed') NOT NULL DEFAULT 'active',
  disposal_date DATE NULL,
  disposal_proceeds DECIMAL(20,3) NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_asset_code(company_id,asset_code),
  CONSTRAINT fk_asset_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_asset_account FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_asset_accum FOREIGN KEY(accumulated_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_asset_expense FOREIGN KEY(depreciation_expense_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_asset_impair FOREIGN KEY(impairment_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_asset_cc FOREIGN KEY(cost_center_id) REFERENCES cost_centers(id) ON DELETE SET NULL,
  CONSTRAINT fk_asset_user FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inventory_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  item_code VARCHAR(50) NOT NULL,
  name_ar VARCHAR(255) NOT NULL,
  unit_name VARCHAR(50) NOT NULL DEFAULT 'وحدة',
  quantity DECIMAL(20,3) NOT NULL DEFAULT 0,
  unit_cost DECIMAL(20,3) NOT NULL DEFAULT 0,
  net_realizable_value DECIMAL(20,3) NOT NULL DEFAULT 0,
  cost_method ENUM('weighted_average','fifo','specific_identification') NOT NULL DEFAULT 'weighted_average',
  inventory_account_id INT UNSIGNED NULL,
  cogs_account_id INT UNSIGNED NULL,
  write_down_account_id INT UNSIGNED NULL,
  provision_account_id INT UNSIGNED NULL,
  last_count_date DATE NULL,
  status ENUM('active','obsolete','discontinued') NOT NULL DEFAULT 'active',
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_inventory_code(company_id,item_code),
  CONSTRAINT fk_inv_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_inv_account FOREIGN KEY(inventory_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_inv_cogs FOREIGN KEY(cogs_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_inv_write FOREIGN KEY(write_down_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_inv_provision FOREIGN KEY(provision_account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_inv_user FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ifrs_registers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  register_type ENUM('revenue_contract','lease','financial_instrument','provision','government_grant','employee_benefit','related_party','income_tax','fair_value','segment','foreign_currency','subsequent_event','agriculture','held_for_sale','borrowing_cost','joint_arrangement') NOT NULL,
  standard_code VARCHAR(20) NOT NULL,
  reference_no VARCHAR(100) NULL,
  title_ar VARCHAR(255) NOT NULL,
  counterparty VARCHAR(255) NULL,
  start_date DATE NULL,
  end_date DATE NULL,
  amount DECIMAL(20,3) NOT NULL DEFAULT 0,
  carrying_amount DECIMAL(20,3) NOT NULL DEFAULT 0,
  fair_value DECIMAL(20,3) NOT NULL DEFAULT 0,
  status VARCHAR(50) NOT NULL DEFAULT 'active',
  account_id INT UNSIGNED NULL,
  data_json LONGTEXT NULL,
  notes LONGTEXT NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_ifrs_register(company_id,register_type,standard_code),
  CONSTRAINT fk_register_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_register_account FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE SET NULL,
  CONSTRAINT fk_register_user FOREIGN KEY(created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cash_flow_overrides (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  journal_line_id BIGINT UNSIGNED NOT NULL,
  line_code VARCHAR(40) NOT NULL,
  allocated_amount DECIMAL(20,3) NULL,
  notes VARCHAR(500) NULL,
  updated_by INT UNSIGNED NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cash_override(company_id,journal_line_id),
  CONSTRAINT fk_cash_override_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_cash_override_line FOREIGN KEY(journal_line_id) REFERENCES journal_lines(id) ON DELETE CASCADE,
  CONSTRAINT fk_cash_override_user FOREIGN KEY(updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS report_account_function_map (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  account_id INT UNSIGNED NOT NULL,
  function_code ENUM('5','6','7','8') NOT NULL,
  updated_by INT UNSIGNED NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_report_function_account(company_id,account_id),
  KEY idx_report_function_code(company_id,function_code),
  CONSTRAINT fk_report_function_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_report_function_account FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE,
  CONSTRAINT fk_report_function_user FOREIGN KEY(updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS report_period_values (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  period_end DATE NOT NULL,
  value_code VARCHAR(60) NOT NULL,
  amount DECIMAL(20,3) NOT NULL DEFAULT 0,
  notes VARCHAR(500) NULL,
  updated_by INT UNSIGNED NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_report_period_value(company_id,period_end,value_code),
  KEY idx_report_period_value(company_id,period_end),
  CONSTRAINT fk_report_value_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_report_value_user FOREIGN KEY(updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS compliance_checklist (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id INT UNSIGNED NOT NULL,
  period_id INT UNSIGNED NULL,
  checklist_code VARCHAR(60) NOT NULL,
  title_ar VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  status ENUM('not_started','in_progress','complete','not_applicable') NOT NULL DEFAULT 'not_started',
  evidence_text LONGTEXT NULL,
  reviewed_by INT UNSIGNED NULL,
  reviewed_at DATETIME NULL,
  UNIQUE KEY uq_checklist(company_id,period_id,checklist_code),
  CONSTRAINT fk_checklist_company FOREIGN KEY(company_id) REFERENCES companies(id) ON DELETE CASCADE,
  CONSTRAINT fk_checklist_period FOREIGN KEY(period_id) REFERENCES fiscal_periods(id) ON DELETE CASCADE,
  CONSTRAINT fk_checklist_user FOREIGN KEY(reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS voucher_details (
  journal_entry_id BIGINT UNSIGNED PRIMARY KEY,
  sheet_no VARCHAR(100) NULL,
  check_no VARCHAR(100) NULL,
  check_date DATE NULL,
  payee_name VARCHAR(255) NULL,
  recipient_name VARCHAR(255) NULL,
  updated_by INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_voucher_details_entry FOREIGN KEY(journal_entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,
  CONSTRAINT fk_voucher_details_user FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO schema_migrations(version) VALUES ('2.3.0');
SET FOREIGN_KEY_CHECKS=1;
