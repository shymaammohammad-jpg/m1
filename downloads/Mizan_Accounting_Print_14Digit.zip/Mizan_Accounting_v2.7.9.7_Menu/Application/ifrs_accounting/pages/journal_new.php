<?php
declare(strict_types=1);
require_role(['admin','accountant']);

$id = (int)($_GET['id'] ?? 0);
$entry = null;
$lines = [];
if ($id > 0) {
    $entry = journal_snapshot($id);
    if (!$entry) throw new RuntimeException('القيد غير موجود.');
    if (in_array($entry['source_type'], ['receipt','payment'], true)) redirect(url('cash_voucher', ['id' => $id]));
    if ($entry['status'] !== 'draft') redirect(url('journal_view', ['id' => $id]));
    $lines = $entry['lines'];
}

$old = old_input_pull();
$source = $entry['source_type'] ?? ($old['source_type'] ?? ($_GET['source'] ?? 'manual'));
if (!in_array($source, ['manual','opening','adjustment','closing'], true)) $source = 'manual';

$accountStmt = db()->prepare('SELECT id,code,name_ar,parent_id,level_no,is_postable FROM accounts WHERE company_id=? AND is_active=1 ORDER BY code');
$accountStmt->execute([company_id()]);
$accountMap = [];
$postableAccounts = [];
foreach ($accountStmt->fetchAll() as $row) {
    $row['id'] = (int)$row['id'];
    $row['parent_id'] = $row['parent_id'] !== null ? (int)$row['parent_id'] : null;
    $row['level_no'] = (int)$row['level_no'];
    $accountMap[$row['id']] = $row;
    if ((int)$row['is_postable'] === 1) $postableAccounts[] = $row;
}
$ccs = cost_center_options();
$parties = party_options();
$standards = standards_library();
$cashDefs = cash_flow_line_definitions();
$decimals = (int)(company()['decimal_places'] ?? 0);

if (!$lines) {
    $oldAccounts = (array)($old['account_id'] ?? []);
    $lineCount = max(2, count($oldAccounts));
    for ($i = 0; $i < $lineCount; $i++) {
        $lines[] = [
            'account_id' => $oldAccounts[$i] ?? '',
            'cost_center_id' => ((array)($old['cost_center_id'] ?? []))[$i] ?? '',
            'party_id' => ((array)($old['party_id'] ?? []))[$i] ?? '',
            'currency_code' => ((array)($old['currency_code'] ?? []))[$i] ?? (company()['currency_code'] ?? 'IQD'),
            'exchange_rate' => ((array)($old['exchange_rate'] ?? []))[$i] ?? 1,
            'foreign_amount' => ((array)($old['foreign_amount'] ?? []))[$i] ?? 0,
            'cash_flow_line_code' => ((array)($old['cash_flow_line_code'] ?? []))[$i] ?? '',
            'line_description' => ((array)($old['line_description'] ?? []))[$i] ?? '',
            'debit' => ((array)($old['debit'] ?? []))[$i] ?? '',
            'credit' => ((array)($old['credit'] ?? []))[$i] ?? '',
        ];
    }
}

$accountOptions = static function ($selected) use ($postableAccounts, $accountMap): string {
    $html = '<option value="">— اختر الحساب من القائمة —</option>';
    foreach ($postableAccounts as $account) {
        $parent = $account['parent_id'] !== null ? ($accountMap[$account['parent_id']] ?? null) : null;
        $sel = (string)$selected === (string)$account['id'] ? ' selected' : '';
        $html .= '<option value="' . e((string)$account['id']) . '"' . $sel
            . ' data-code="' . e((string)$account['code']) . '"'
            . ' data-name="' . e((string)$account['name_ar']) . '"'
            . ' data-level="' . e((string)$account['level_no']) . '"'
            . ' data-parent-code="' . e((string)($parent['code'] ?? '')) . '"'
            . ' data-parent-name="' . e((string)($parent['name_ar'] ?? '')) . '">'
            . e((string)$account['code'] . ' — ' . (string)$account['name_ar']) . '</option>';
    }
    return $html;
};

$codeCells = static function (string $code): array {
    $length = strlen(preg_replace('/\D+/', '', $code) ?? '');
    if ($length <= 3) return [$code, '', ''];
    if ($length === 4) return ['', $code, ''];
    return ['', '', $code];
};

// مراكز الكلف: خمسة أعمدة مرقّمة ٥ ٦ ٧ ٨ ٩ كما في السند الرسمي
$ccCells = static function (string $code): array {
    $cells = ['', '', '', '', ''];
    $digits = preg_replace('/\D+/', '', $code) ?? '';
    if ($digits === '') return $cells;
    $level = max(5, min(9, strlen($digits)));
    $cells[$level - 5] = $code;
    return $cells;
};

$splitAmount = static function ($value): array {
    $value = (float)$value;
    if ($value <= 0) return ['', ''];
    $dinars = (int)floor($value);
    $fils = (int)round(($value - $dinars) * 1000);
    return [(string)$dinars, $fils > 0 ? str_pad((string)$fils, 3, '0', STR_PAD_LEFT) : ''];
};

$ccCodeById = [];
foreach ($ccs as $cc) $ccCodeById[(int)$cc['id']] = (string)$cc['code'];

$GLOBALS['fixed_print_template'] = 'journal-voucher';
render_header($entry ? 'تعديل قيد' : 'قيد جديد', 'journal_new');
page_heading(
    $entry ? 'تعديل ' . (string)$entry['voucher_no'] : 'إضافة سند قيد',
    'مستند القيد له تسلسل مستقل عن مستندات الصرف والقبض، ويمكن اختيار أي حساب قابل للترحيل في الطرف المدين أو الدائن.'
);
?>
<form method="post" id="excelVoucherForm" class="excel-voucher-form">
<input type="hidden" name="action" value="journal_save">
<input type="hidden" name="id" value="<?=e($entry['id'] ?? '')?>">
<input type="hidden" name="version_no" value="<?=e($entry['version_no'] ?? '')?>">
<input type="hidden" name="reference_no" value="<?=e($old['reference_no'] ?? $entry['reference_no'] ?? '')?>">
<?=csrf_field()?>

<div class="voucher-control-strip no-print">
    <div class="field"><label>نوع القيد</label><select name="source_type"><?php foreach(['manual'=>'قيد يومي','opening'=>'قيد افتتاحي','adjustment'=>'قيد تسوية','closing'=>'قيد إقفال يدوي'] as $key=>$label):?><option value="<?=$key?>" <?=$source===$key?'selected':''?>><?=$label?></option><?php endforeach;?></select></div>
    <div class="field"><label>المعيار المرتبط</label><select name="origin_standard"><option value="">— عام —</option><?php foreach($standards as $standard):?><option value="<?=e($standard['code'])?>" <?=($old['origin_standard'] ?? $entry['origin_standard'] ?? '') === $standard['code'] ? 'selected' : ''?>><?=e($standard['code'].' — '.$standard['title_ar'])?></option><?php endforeach;?></select></div>
    <div class="field"><label>حركة حقوق الملكية</label><select name="equity_movement_type"><?php foreach(['none'=>'لا ينطبق','profit'=>'ربح/خسارة الفترة','dividend'=>'توزيعات أرباح','reserve'=>'احتياطيات','capital'=>'رأس المال','accumulated_loss_amortization'=>'إطفاء خسائر متراكمة','policy_change'=>'سياسات/تقديرات/أخطاء','nci'=>'حقوق غير مسيطرة','oci'=>'دخل شامل آخر','other'=>'حركة أخرى'] as $key=>$label):?><option value="<?=$key?>" <?=($old['equity_movement_type'] ?? $entry['equity_movement_type'] ?? 'none') === $key ? 'selected' : ''?>><?=$label?></option><?php endforeach;?></select></div>
    <button type="button" class="btn btn-outline" id="add-voucher-line">+ إضافة حساب / صف</button>
</div>
<div class="alert alert-info no-print" style="margin:.5rem 0">الحساب الدائن غير مقيد بالنقد أو الصندوق: يمكنك اختيار <strong>أي حساب قابل للترحيل</strong> من دليل الحسابات، وكذلك في الجانب المدين.</div>

<section class="excel-voucher-sheet" aria-label="سند قيد">
    <div class="excel-voucher-top">
        <div class="excel-voucher-cash-box">
            <div>رقم سند الصرف</div>
            <div>أو القبض</div>
            <div>التاريخ:</div>
        </div>
        <div class="excel-voucher-title">سند قيد</div>
        <div class="excel-voucher-dept-box">
            <div><span>أسم الدائرة:</span><strong><?=e((string)(company()['name_ar'] ?? ''))?></strong></div>
            <label><span>الرقم:</span>
                <input name="voucher_no" value="<?=e($old['voucher_no'] ?? $entry['voucher_no'] ?? '')?>" placeholder="ينشأ تلقائياً من تسلسل مستند القيد" autocomplete="off" readonly>
            </label>
            <?php
            $entryDateValue = (string)($old['entry_date'] ?? $entry['entry_date'] ?? date('Y-m-d'));
            $entryDateTime = strtotime($entryDateValue) ?: time();
            ?>
            <label><span>التاريخ:</span>
                <span class="doc-date-field">
                    <input type="text" class="doc-date-part doc-date-day" inputmode="numeric" maxlength="2" placeholder="يوم" value="<?=e(date('d', $entryDateTime))?>" autocomplete="off" required>
                    <span class="doc-date-sep">/</span>
                    <input type="text" class="doc-date-part doc-date-month" inputmode="numeric" maxlength="2" placeholder="شهر" value="<?=e(date('m', $entryDateTime))?>" autocomplete="off" required>
                    <span class="doc-date-sep">/</span>
                    <input type="text" class="doc-date-part doc-date-year" inputmode="numeric" maxlength="4" placeholder="سنة" value="<?=e(date('Y', $entryDateTime))?>" autocomplete="off" required>
                    <input type="hidden" class="doc-date-value" name="entry_date" value="<?=e($entryDateValue)?>">
                </span>
            </label>
            <label><span>رقم صفحة اليومية:</span>
                <input name="journal_page_no" value="<?=e($old['journal_page_no'] ?? '')?>" autocomplete="off">
            </label>
        </div>
    </div>

    <div class="excel-voucher-table-wrap">
        <table class="excel-voucher-table" id="journal-lines" data-decimals="<?=max(3,$decimals)?>">
            <colgroup><col class="voucher-col-fils"><col class="voucher-col-dinar"><col class="voucher-col-fils"><col class="voucher-col-dinar"><col class="voucher-col-statement"><col class="voucher-col-code"><col class="voucher-col-code"><col class="voucher-col-code"><col class="voucher-col-cc"><col class="voucher-col-cc"><col class="voucher-col-cc"><col class="voucher-col-cc"><col class="voucher-col-cc"></colgroup>
            <thead>
                <tr><th colspan="2">المدين</th><th colspan="2">الدائن</th><th rowspan="2">البيان</th><th colspan="3">رقم الدليل المحاسبي</th><th colspan="5">مراكز الكلف</th></tr>
                <tr><th>ف</th><th>د</th><th>ف</th><th>د</th><th>٣</th><th>٤</th><th>٥</th><th>٥</th><th>٦</th><th>٧</th><th>٨</th><th>٩</th></tr>
            </thead>
            <tbody id="voucher-line-body">
            <?php foreach($lines as $index=>$line):
                $accountId = (int)($line['account_id'] ?? 0);
                $selected = $accountMap[$accountId] ?? null;
                [$d3,$d4,$d5] = $codeCells((string)($selected['code'] ?? ''));
                $ccParts = $ccCells($ccCodeById[(int)($line['cost_center_id'] ?? 0)] ?? '');
                [$debitDinar,$debitFils] = $splitAmount($line['debit'] ?? 0);
                [$creditDinar,$creditFils] = $splitAmount($line['credit'] ?? 0);
                $side = $debitDinar !== '' ? 'من ح/ ' : ($creditDinar !== '' ? 'الى ح/ ' : '');
            ?>
                <tr class="voucher-line" data-line-index="<?=$index?>">
                    <td><input class="voucher-fils-input voucher-debit-fils" name="debit_fils[]" inputmode="numeric" maxlength="3" value="<?=e($debitFils)?>" aria-label="مدين فلس"></td>
                    <td><input class="num voucher-debit" name="debit[]" inputmode="decimal" value="<?=e($debitDinar)?>" aria-label="مدين دينار"></td>
                    <td><input class="voucher-fils-input voucher-credit-fils" name="credit_fils[]" inputmode="numeric" maxlength="3" value="<?=e($creditFils)?>" aria-label="دائن فلس"></td>
                    <td><input class="num voucher-credit" name="credit[]" inputmode="decimal" value="<?=e($creditDinar)?>" aria-label="دائن دينار"></td>
                    <td class="voucher-statement-cell">
                        <div class="voucher-statement-print"><span class="voucher-line-side"><?=e($side)?></span><span class="voucher-account-print-name"><?=e((string)($selected['name_ar'] ?? ''))?></span></div>
                        <div class="voucher-account-controls no-print">
                            <input class="voucher-account-code-input" inputmode="numeric" value="<?=e((string)($selected['code'] ?? ''))?>" placeholder="رقم الحساب" list="account-code-list" autocomplete="off">
                            <select class="voucher-account-select" name="account_id[]"><?=$accountOptions($line['account_id'] ?? '')?></select>
                            <select class="voucher-cc-select" name="cost_center_id[]"><option value="">— مركز الكلفة —</option><?php foreach($ccs as $cc):?><option value="<?=e((string)$cc['id'])?>" data-code="<?=e((string)$cc['code'])?>" <?=(int)($line['cost_center_id'] ?? 0)===(int)$cc['id']?'selected':''?>><?=e($cc['code'].' — '.$cc['name_ar'])?></option><?php endforeach;?></select>
                            <input type="hidden" name="line_description[]" value="<?=e($line['line_description'] ?? '')?>">
                            <button type="button" class="voucher-remove-line" title="حذف هذا الصف">×</button>
                        </div>
                        <input type="hidden" name="party_id[]" value="<?=e($line['party_id'] ?? '')?>">
                        <input type="hidden" name="currency_code[]" value="<?=e($line['currency_code'] ?? (company()['currency_code'] ?? 'IQD'))?>">
                        <input type="hidden" name="exchange_rate[]" value="<?=e($line['exchange_rate'] ?? 1)?>">
                        <input type="hidden" name="foreign_amount[]" value="<?=e($line['foreign_amount'] ?? 0)?>">
                        <input type="hidden" name="cash_flow_line_code[]" value="<?=e($line['cash_flow_line_code'] ?? '')?>">
                    </td>
                    <td class="voucher-detail-code code-level-3"><?=e($d3)?></td><td class="voucher-detail-code code-level-4"><?=e($d4)?></td><td class="voucher-detail-code code-level-5"><?=e($d5)?></td>
                    <?php foreach([5,6,7,8,9] as $slot=>$level):?><td class="voucher-cc-code cc-level-<?=$level?>"><?=e($ccParts[$slot])?></td><?php endforeach;?>
                </tr>
            <?php endforeach;?>
            </tbody>
            <tfoot>
                <tr class="voucher-description-row"><td></td><td></td><td></td><td></td><td colspan="9"><textarea name="description" required placeholder="عن ... (البيان العام للقيد)"><?=e($old['description'] ?? $entry['description'] ?? '')?></textarea></td></tr>
                <tr class="voucher-words-row"><td class="voucher-fils-total" id="voucher-total-debit-fils"></td><td class="num" id="voucher-total-debit">0</td><td class="voucher-fils-total" id="voucher-total-credit-fils"></td><td class="num" id="voucher-total-credit">0</td><td colspan="9" data-currency="<?=e((string)(company()['currency_name_ar'] ?? 'دينار عراقي'))?>"><span class="voucher-total-label">المجموع</span> <span id="voucher-amount-words" data-currency="<?=e((string)(company()['currency_name_ar'] ?? 'دينار عراقي'))?>">فقط صفر <?=e((string)(company()['currency_name_ar'] ?? 'دينار عراقي'))?> لا غير</span></td></tr>
            </tfoot>
        </table>
    </div>

    <div class="excel-voucher-signatures">
    <?php foreach ([
        'organizer' => ['المنظم', (string)(user()['full_name'] ?? '')],
        'auditor' => ['المدقق', ''],
        'accounts_manager' => ['مدير الحسابات', ''],
        'department_head' => ['رئيس الدائرة', ''],
    ] as $sigKey => $sig):
        $sigValue = (string)($old['signature_' . $sigKey] ?? setting_get('voucher_sign_' . $sigKey, $sig[1]));
    ?>
        <div><strong><?=e($sig[0])?></strong><input class="voucher-sign-input" name="signature_<?=e($sigKey)?>" value="<?=e($sigValue)?>" autocomplete="off" placeholder="الاسم"></div>
    <?php endforeach;?>
    </div>
</section>

<datalist id="account-code-list"><?php foreach($postableAccounts as $account):?><option value="<?=e((string)$account['code'])?>"><?=e((string)$account['name_ar'])?></option><?php endforeach;?></datalist>

<template id="voucher-line-template">
<tr class="voucher-line" data-line-index="__INDEX__"><td><input class="voucher-fils-input voucher-debit-fils" name="debit_fils[]" inputmode="numeric" maxlength="3" aria-label="مدين فلس"></td><td><input class="num voucher-debit" name="debit[]" inputmode="decimal" aria-label="مدين دينار"></td><td><input class="voucher-fils-input voucher-credit-fils" name="credit_fils[]" inputmode="numeric" maxlength="3" aria-label="دائن فلس"></td><td><input class="num voucher-credit" name="credit[]" inputmode="decimal" aria-label="دائن دينار"></td><td class="voucher-statement-cell"><div class="voucher-statement-print"><span class="voucher-line-side"></span><span class="voucher-account-print-name"></span></div><div class="voucher-account-controls no-print"><input class="voucher-account-code-input" inputmode="numeric" placeholder="رقم الحساب" list="account-code-list" autocomplete="off"><select class="voucher-account-select" name="account_id[]"><?=$accountOptions('')?></select><select class="voucher-cc-select" name="cost_center_id[]"><option value="">— مركز الكلفة —</option><?php foreach($ccs as $cc):?><option value="<?=e((string)$cc['id'])?>" data-code="<?=e((string)$cc['code'])?>"><?=e($cc['code'].' — '.$cc['name_ar'])?></option><?php endforeach;?></select><input type="hidden" name="line_description[]"><button type="button" class="voucher-remove-line" title="حذف هذا الصف">×</button></div><input type="hidden" name="party_id[]"><input type="hidden" name="currency_code[]" value="<?=e((string)(company()['currency_code'] ?? 'IQD'))?>"><input type="hidden" name="exchange_rate[]" value="1"><input type="hidden" name="foreign_amount[]" value="0"><input type="hidden" name="cash_flow_line_code[]"></td><td class="voucher-detail-code code-level-3"></td><td class="voucher-detail-code code-level-4"></td><td class="voucher-detail-code code-level-5"></td><td class="voucher-cc-code cc-level-5"></td><td class="voucher-cc-code cc-level-6"></td><td class="voucher-cc-code cc-level-7"></td><td class="voucher-cc-code cc-level-8"></td><td class="voucher-cc-code cc-level-9"></td></tr>
</template>

<div class="voucher-form-actions no-print">
    <div class="voucher-balance-status">الفرق: <strong id="voucher-total-diff">0</strong></div>
    <button class="btn btn-light" name="submit_mode" value="draft">حفظ كمسودة</button>
    <button class="btn btn-primary" name="submit_mode" value="post" data-confirm="حفظ المستند وترحيله إلى الحسابات؟">حفظ وترحيل</button>
    <a class="btn btn-outline" href="<?=e($entry ? url('journal_view',['id'=>$entry['id']]) : url('journal_list'))?>">إلغاء</a>
</div>
</form>
<?php render_footer(); ?>
