<?php
declare(strict_types=1);
require_once __DIR__ . '/../app/smart_assistant.php';

$history = array_reverse(sa_history());
$guideMeta = sa_load_guide();
$aiSettings = sa_ai_settings();
$aiStatus = sa_ollama_status();
$aiReady = !empty($aiStatus['connected']) && (string)($aiStatus['model'] ?? '') !== '';
render_header('المساعد المحاسبي الذكي', 'smart_assistant');
page_heading(
    'المساعد المحاسبي الذكي',
    'مساعد Gemma 4 محلي متخصص يسترجع المعرفة من دليل النظام والحسابات والمعايير، ويستخدم Gemma 4 محلياً دون إرسال البيانات إلى الإنترنت.',
    '<a class="btn btn-outline" target="_blank" href="knowledge/guide.pdf">فتح الدليل الكامل</a>'
);
?>
<div class="assistant-layout">
    <section class="assistant-main card">
        <div class="assistant-hero">
            <div class="assistant-orb">ذ</div>
            <div class="assistant-hero-copy">
                <h2>مساعد Gemma 4 المحاسبي المحلي — RAG</h2>
                <p>يسترجع المساعد المعرفة من <?= e((string)($guideMeta['page_count'] ?? 65)) ?> صفحة في الدليل المرفق، ودليل الحسابات الفعلي، ومكتبة المعايير، ثم يمرر السياق فقط إلى نموذج Gemma 4 المحلي الذي يعمل عبر Ollama.</p>
                <div class="assistant-agent-status <?= $aiReady ? 'is-ready' : 'is-offline' ?>">
                    <span class="assistant-status-dot"></span>
                    <?php if ($aiReady): ?>
                        Gemma 4 متصل • النموذج: <strong><?= e((string)$aiStatus['model']) ?></strong>
                    <?php else: ?>
                        <?= e((string)($aiStatus['message'] ?? 'Gemma 4 غير متاح')) ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="assistant-suggestions no-print">
            <?php foreach ([
                'ما الحساب المناسب لشراء أثاث نقداً؟',
                'اشرح قائمة المركز المالي وأعمدتها المقارنة.',
                'ما متطلبات تطبيق IFRS 1 لأول مرة؟',
                'أين يظهر المخزون في دليل الحسابات؟',
                'كيف أسجل سند صرف لمصروف الكهرباء؟',
                'ما الفرق بين إلغاء الترحيل وعكس القيد؟'
            ] as $suggestion): ?>
                <button type="button" class="assistant-chip" data-assistant-question="<?= e($suggestion) ?>"><?= e($suggestion) ?></button>
            <?php endforeach; ?>
        </div>

        <form method="post" class="assistant-question-form no-print" id="assistantQuestionForm">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="assistant_ask">
            <textarea id="assistantQuestion" name="question" rows="3" maxlength="700" placeholder="مثال: كيف أسجل شراء أجهزة حاسوب على الحساب؟" required autofocus></textarea>
            <div class="assistant-form-footer">
                <span>Gemma 4 يعمل محلياً وبوضع قرائي فقط. إذا تعذر النموذج يستمر البحث المحلي في الدليل والحسابات كخطة بديلة.</span>
                <button class="btn btn-primary" type="submit">اسأل Gemma 4 المحلي</button>
            </div>
        </form>

        <?php if ($history === []): ?>
            <div class="assistant-empty">
                <strong>ابدأ بسؤال محاسبي واضح</strong>
                <p>يمكن البحث باسم الحساب أو رقمه، رقم المعيار، نوع العملية، أو اسم القائمة المالية.</p>
            </div>
        <?php else: ?>
            <div class="assistant-thread">
                <?php foreach ($history as $answer): ?>
                    <article class="assistant-exchange">
                        <div class="assistant-user-message">
                            <span>سؤالك</span>
                            <p><?= e((string)($answer['question'] ?? '')) ?></p>
                        </div>
                        <div class="assistant-answer-message">
                            <div class="assistant-answer-head">
                                <div class="assistant-mini-orb">ذ</div>
                                <div><strong>إجابة المساعد</strong><small><?= e((string)($answer['generated_at'] ?? '')) ?></small></div>
                            </div>
                            <?php $agent = is_array($answer['agent'] ?? null) ? $answer['agent'] : []; ?>
                            <?php if (!empty($agent['ok']) && trim((string)($agent['content'] ?? '')) !== ''): ?>
                                <div class="assistant-ai-response">
                                    <div class="assistant-agent-meta">
                                        <span>Gemma 4 المحلي</span>
                                        <span><?= e((string)($agent['model'] ?? '')) ?><?= !empty($agent['latency_ms']) ? ' • ' . e((string)$agent['latency_ms']) . ' ms' : '' ?></span>
                                    </div>
                                    <div class="assistant-ai-text"><?= nl2br(e((string)$agent['content'])) ?></div>
                                </div>
                            <?php else: ?>
                                <p class="assistant-summary"><?= e((string)($answer['summary'] ?? '')) ?></p>
                                <?php if (trim((string)($agent['error'] ?? '')) !== ''): ?>
                                    <div class="assistant-agent-warning"><strong>تعذر تشغيل النموذج المحلي:</strong> <?= e((string)$agent['error']) ?><br>تم عرض نتائج الاسترجاع المحلية أدناه ولم يتم إرسال السؤال إلى أي خدمة خارجية.</div>
                                <?php endif; ?>
                            <?php endif; ?>

                            <?php if (!empty($answer['application'])): $item = $answer['application']; ?>
                                <div class="assistant-block assistant-block-action">
                                    <h3><?= e((string)$item['title']) ?></h3>
                                    <p><?= e((string)$item['text']) ?></p>
                                    <a class="btn btn-sm btn-outline" href="<?= e(url((string)$item['page'])) ?>">فتح الشاشة المرتبطة</a>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($answer['template'])): $template = $answer['template']; ?>
                                <div class="assistant-block">
                                    <h3>نموذج قيد إرشادي: <?= e((string)$template['title']) ?></h3>
                                    <div class="table-wrap assistant-table-wrap">
                                        <table class="data-table assistant-table">
                                            <thead><tr><th>الطرف</th><th>الحساب المقترح</th></tr></thead>
                                            <tbody>
                                            <?php foreach ($template['lines'] as $line): ?>
                                                <tr><td><span class="badge <?= $line[0] === 'مدين' ? 'badge-posted' : 'badge-reversed' ?>"><?= e($line[0]) ?></span></td><td><?= e($line[1]) ?></td></tr>
                                            <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <p class="help"><?= e((string)$template['note']) ?></p>
                                    <a class="btn btn-sm btn-primary" href="<?= e(url('journal_new')) ?>">فتح قيد جديد</a>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($answer['accounts'])): ?>
                                <div class="assistant-block">
                                    <h3>حسابات مطابقة من دليل حسابات المنشأة</h3>
                                    <div class="assistant-result-grid">
                                    <?php foreach ($answer['accounts'] as $account): ?>
                                        <a class="assistant-result-card" href="<?= e(url('accounts', ['q'=>(string)$account['code']])) ?>">
                                            <span class="code"><?= e((string)$account['code']) ?></span>
                                            <strong><?= e((string)$account['name_ar']) ?></strong>
                                            <small><?= e(sa_account_type_label((string)$account['account_type'])) ?> • <?= (int)$account['is_postable'] === 1 ? 'قابل للترحيل' : 'تجميعي' ?></small>
                                        </a>
                                    <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($answer['standards'])): ?>
                                <div class="assistant-block">
                                    <h3>المعايير المرتبطة</h3>
                                    <div class="assistant-result-grid">
                                    <?php foreach ($answer['standards'] as $standard): ?>
                                        <a class="assistant-result-card" href="<?= e(url('standards_library', ['q'=>(string)$standard['code']])) ?>">
                                            <span class="code"><?= e((string)$standard['code']) ?></span>
                                            <strong><?= e((string)$standard['title_ar']) ?></strong>
                                            <small>مرجع الدليل: <?= e((string)($standard['guide_page'] ?: 'غير محدد')) ?></small>
                                        </a>
                                    <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($answer['report'])): ?>
                                <div class="assistant-block assistant-block-action">
                                    <h3>التقرير المرتبط</h3>
                                    <a class="btn btn-primary" href="<?= e(url((string)$answer['report']['page'])) ?>">فتح <?= e((string)$answer['report']['label']) ?></a>
                                </div>
                            <?php endif; ?>

                            <?php if (!empty($answer['guide'])): ?>
                                <div class="assistant-block">
                                    <h3>مراجع من النص الكامل للدليل</h3>
                                    <div class="assistant-guide-results">
                                    <?php foreach ($answer['guide'] as $result): ?>
                                        <div class="assistant-guide-card">
                                            <div class="assistant-guide-meta">
                                                <strong><?= e((string)$result['title']) ?></strong>
                                                <a target="_blank" href="knowledge/guide.pdf#page=<?= (int)$result['pdf_page'] ?>">صفحة الملف <?= (int)$result['pdf_page'] ?></a>
                                            </div>
                                            <p><?= e((string)$result['excerpt']) ?></p>
                                        </div>
                                    <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="assistant-notice"><?= e((string)($answer['notice'] ?? '')) ?></div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <form method="post" class="no-print assistant-clear-form">
                <?= csrf_field() ?><input type="hidden" name="action" value="assistant_clear">
                <button class="btn btn-light btn-sm" data-confirm="مسح سجل الأسئلة الحالي؟">مسح المحادثة</button>
            </form>
        <?php endif; ?>
    </section>

    <aside class="assistant-side">
        <div class="card">
            <h3 class="card-title">مصادر المعرفة</h3>
            <div class="assistant-source-item"><strong>الدليل الكامل</strong><span><?= e((string)($guideMeta['page_count'] ?? 65)) ?> صفحة مفهرسة محلياً</span></div>
            <div class="assistant-source-item"><strong>دليل الحسابات</strong><span>يقرأ الحسابات الفعلية النشطة للمنشأة</span></div>
            <div class="assistant-source-item"><strong>مكتبة المعايير</strong><span>IAS وIFRS المثبتة في النظام</span></div>
            <div class="assistant-source-item"><strong>مساعدة البرنامج</strong><span>القيود والسندات والترحيل والإقفال والنسخ الاحتياطية</span></div>
        </div>
        <div class="card assistant-ai-card">
            <h3 class="card-title">Gemma 4 المحلي</h3>
            <div class="assistant-source-item"><strong>الحالة</strong><span class="<?= $aiReady ? 'text-success' : 'text-danger' ?>"><?= e((string)($aiStatus['message'] ?? '')) ?></span></div>
            <div class="assistant-source-item"><strong>العنوان المحلي</strong><span dir="ltr">127.0.0.1:11434</span></div>
            <div class="assistant-source-item"><strong>النموذج</strong><span><?= e((string)($aiStatus['model'] ?: 'gemma4:26b غير مثبت')) ?></span></div>
            <?php if ((string)(user()['role'] ?? '') === 'admin'): ?>
                <form method="post" class="assistant-ai-settings no-print">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="assistant_ai_settings_save">
                    <label class="check-row"><input type="checkbox" name="ai_enabled" value="1" <?= !empty($aiSettings['enabled']) ? 'checked' : '' ?>> <span>تفعيل Gemma 4 المحلي</span></label>
                    <div class="assistant-source-item"><strong>النموذج المعتمد</strong><span dir="ltr">gemma4:26b</span></div>
                    <p class="muted" style="margin:.35rem 0">هذه النسخة لا تستخدم أي نموذج آخر. إذا لم يكن gemma4:26b مثبتاً، يبحث النظام عن أي إصدار محلي آخر من عائلة gemma4 فقط.</p>
                    <div class="assistant-ai-settings-grid">
                        <label>مهلة الإجابة (ثانية)<input type="number" min="20" max="70" step="5" name="ai_timeout" value="<?= (int)$aiSettings['timeout'] ?>"></label>
                        <label>الإبداع<input type="number" min="0" max="0.8" step="0.05" name="ai_temperature" value="<?= e((string)$aiSettings['temperature']) ?>"></label>
                    </div>
                    <p class="muted" style="margin:.35rem 0">لمنع توقف PHP، الحد الأقصى للمهلة 70 ثانية. قد تحتاج الإجابة الأولى وقتاً أطول بسبب تحميل Gemma 4 إلى الذاكرة؛ إذا انتهت المهلة، انتظر قليلاً ثم أعد السؤال.</p>
                    <button class="btn btn-primary btn-sm" type="submit">حفظ إعدادات Gemma 4</button>
                </form>
            <?php endif; ?>
            <?php if (!$aiReady): ?>
                <p class="help assistant-ollama-help">شغّل Ollama وتأكد أن gemma4:26b مثبت محلياً. يستخدم النظام Ollama كمحرك تشغيل محلي فقط، ولا يتصل بخدمة سحابية.</p>
            <?php endif; ?>
        </div>
        <div class="card">
            <h3 class="card-title">الخصوصية</h3>
            <p class="help">Gemma 4 يعمل محلياً عبر Ollama على 127.0.0.1 فقط. لا يوجد مفتاح API ولا اتصال بنموذج سحابي، ويُرسل إلى Gemma 4 السؤال مع المقاطع المسترجعة من النظام فقط.</p>
        </div>
        <div class="card">
            <h3 class="card-title">حدود الاستخدام</h3>
            <p class="help">يعرض المساعد مراجع واقتراحات، لكنه لا يستبدل التقدير المهني ولا اعتماد المحاسب أو الجهة الرقابية، ولا ينفذ عمليات محاسبية تلقائياً.</p>
        </div>
    </aside>
</div>
<?php render_footer(); ?>
