<?php
declare(strict_types=1);

require_role('admin');
$registry = institution_load_registry();
$currentKey = (string)($_SESSION['institution_key'] ?? '');
$server = institution_server_pdo(app_config());

render_header('إدارة المؤسسات وقواعد البيانات', 'institutions');
page_heading(
    'إدارة المؤسسات وقواعد البيانات',
    'كل مؤسسة تعمل بقاعدة MySQL منفصلة بالكامل. يمكنك الانتقال بينها من زر تبديل المؤسسة في أعلى البرنامج.'
);
?>

<div class="alert alert-info institution-separation-note">
    <strong>العزل المحاسبي كامل:</strong>
    القيود والسندات وأرقامها، الأرصدة، الحسابات البنكية، كشوف البنك، شهادة المطابقة، اليومية، الأستاذ، الموازين والحسابات الختامية محفوظة داخل قاعدة المؤسسة المختارة فقط.
</div>

<div class="institution-admin-grid">
<?php foreach ((array)($registry['institutions'] ?? []) as $inst):
    if (!is_array($inst)) continue;
    $key = (string)($inst['key'] ?? '');
    $dbName = (string)($inst['db_name'] ?? '');
    $isCurrent = $key === $currentKey;
    $isValid = false;
    try { $isValid = institution_database_is_mizan($server, $dbName); } catch (Throwable) { $isValid = false; }
?>
    <section class="card institution-admin-card <?= $isCurrent ? 'is-current' : '' ?>">
        <div class="institution-admin-card-head">
            <div class="institution-admin-icon"><?= (($inst['kind'] ?? '') === 'evening') ? '🌙' : ((($inst['kind'] ?? '') === 'morning') ? '☀️' : '🏛️') ?></div>
            <div>
                <h2><?= e((string)($inst['name'] ?? 'مؤسسة')) ?></h2>
                <div class="institution-db-name"><?= e($dbName) ?></div>
            </div>
            <?php if ($isCurrent): ?><span class="badge badge-posted">المؤسسة الحالية</span><?php endif; ?>
        </div>
        <div class="institution-db-status <?= $isValid ? 'ok' : 'bad' ?>">
            <?= $isValid ? 'قاعدة البيانات متصلة وجاهزة' : 'تعذر التحقق من قاعدة البيانات' ?>
        </div>
        <form method="post" class="institution-rename-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="institution_rename">
            <input type="hidden" name="institution_key" value="<?= e($key) ?>">
            <div class="field">
                <label>اسم المؤسسة الظاهر في البرنامج والتقارير</label>
                <input name="institution_name" value="<?= e((string)($inst['name'] ?? '')) ?>" required maxlength="190">
            </div>
            <button class="btn btn-outline" type="submit">حفظ الاسم</button>
        </form>
        <?php if (!$isCurrent): ?>
            <a class="btn btn-primary" href="index.php?page=institution_switch">الانتقال إلى شاشة اختيار المؤسسة</a>
        <?php endif; ?>
    </section>
<?php endforeach; ?>
</div>

<section class="card institution-create-card">
    <div class="card-title">إضافة مؤسسة أخرى بقاعدة بيانات مستقلة</div>
    <p class="muted institution-create-help">
        ينشئ النظام قاعدة جديدة بهيكل البرنامج نفسه، ويأخذ دليل الحسابات والمستخدمين والفترات والإعدادات الأساسية من المؤسسة الحالية فقط،
        بينما تبدأ القيود والسندات والأرصدة وشهادة مطابقة البنك من الصفر.
    </p>
    <form method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="institution_add">
        <div class="form-grid">
            <div class="field col-8">
                <label>اسم المؤسسة الجديدة</label>
                <input name="institution_name" placeholder="مثال: كلية الإدارة والاقتصاد - المسائي" required maxlength="190">
            </div>
            <div class="field col-4">
                <label>رمز قاعدة البيانات بالإنجليزية</label>
                <input name="db_suffix" value="unit" pattern="[A-Za-z0-9_]{2,24}" maxlength="24" dir="ltr" required>
                <small>مثال: evening أو postgraduate</small>
            </div>
        </div>
        <div class="form-actions">
            <button class="btn btn-primary" type="submit">إنشاء المؤسسة وقاعدة البيانات</button>
        </div>
    </form>
</section>

<section class="card institution-safety-card">
    <div class="card-title">حماية البيانات عند التبديل</div>
    <div class="institution-safety-list">
        <span>✓ تسجيل الخروج من حساب المستخدم عند تغيير المؤسسة.</span>
        <span>✓ عرض اسم المؤسسة المختارة دائماً في أعلى البرنامج.</span>
        <span>✓ نسخ احتياطية في مجلد مستقل لكل مؤسسة.</span>
        <span>✓ تسلسل أرقام القيود والسندات مستقل داخل كل قاعدة بيانات.</span>
        <span>✓ لا يمكن أن تدخل قيود الصباحي ضمن تقارير المسائي أو العكس.</span>
    </div>
</section>

<?php render_footer(); ?>
