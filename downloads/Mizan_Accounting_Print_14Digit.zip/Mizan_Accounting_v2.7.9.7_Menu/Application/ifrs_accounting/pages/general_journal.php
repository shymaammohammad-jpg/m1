<?php
declare(strict_types=1);

$monthNames = [
    1 => 'كانون الثاني',
    2 => 'شباط',
    3 => 'آذار',
    4 => 'نيسان',
    5 => 'أيار',
    6 => 'حزيران',
    7 => 'تموز',
    8 => 'آب',
    9 => 'أيلول',
    10 => 'تشرين الأول',
    11 => 'تشرين الثاني',
    12 => 'كانون الأول',
];

// توافق خلفي: إذا فُتح رابط قديم يحتوي from/to نشتق منه الشهر والسنة.
$legacyFrom = (string)($_GET['from'] ?? '');
$defaultYear = (int)date('Y');
$defaultMonth = (int)date('n');
if ($legacyFrom !== '' && valid_date($legacyFrom)) {
    $legacyTs = strtotime($legacyFrom);
    if ($legacyTs !== false) {
        $defaultYear = (int)date('Y', $legacyTs);
        $defaultMonth = (int)date('n', $legacyTs);
    }
}

$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : $defaultYear;
$selectedMonth = isset($_GET['month']) ? (int)$_GET['month'] : $defaultMonth;
$status = (string)($_GET['status'] ?? 'posted');
$showReference = isset($_GET['show_reference']) && (string)$_GET['show_reference'] === '1';
$showAllBinary = isset($_GET['show_all_binary']) && (string)$_GET['show_all_binary'] === '1';

if ($selectedYear < 2000 || $selectedYear > 2100) {
    $selectedYear = (int)date('Y');
}
if ($selectedMonth < 1 || $selectedMonth > 12) {
    $selectedMonth = (int)date('n');
}
if (!in_array($status, ['posted', 'all'], true)) {
    $status = 'posted';
}

$monthStart = new DateTimeImmutable(sprintf('%04d-%02d-01', $selectedYear, $selectedMonth));
$from = $monthStart->format('Y-m-d');
$to = $monthStart->modify('last day of this month')->format('Y-m-d');
$previousFrom = sprintf('%04d-01-01', $selectedYear);
$previousTo = $monthStart->modify('-1 day')->format('Y-m-d');
$hasPreviousMonths = $selectedMonth > 1;
$selectedMonthName = $monthNames[$selectedMonth];
$periodLabel = $selectedMonthName . ' ' . $selectedYear;

// السنوات المتاحة في اليومية + السنة الحالية/المختارة لضمان إمكانية الاختيار حتى قبل وجود حركة.
$yearStmt = db()->prepare('SELECT DISTINCT YEAR(entry_date) AS y FROM journal_entries WHERE company_id=? ORDER BY y DESC');
$yearStmt->execute([company_id()]);
$availableYears = [];
foreach ($yearStmt->fetchAll() as $row) {
    $y = (int)($row['y'] ?? 0);
    if ($y >= 2000 && $y <= 2100) {
        $availableYears[$y] = true;
    }
}
$availableYears[$selectedYear] = true;
$availableYears[(int)date('Y')] = true;
$availableYears = array_keys($availableYears);
rsort($availableYears, SORT_NUMERIC);

// حركات الشهر الحالي فقط.
$entrySql = "SELECT je.id,je.voucher_no,je.entry_date,je.reference_no,je.description,je.source_type,je.status,
                    COALESCE(SUM(jl.debit),0) AS total_amount
             FROM journal_entries je
             LEFT JOIN journal_lines jl ON jl.journal_entry_id = je.id
             WHERE je.company_id=? AND je.entry_date BETWEEN ? AND ?";
$params = [company_id(), $from, $to];
if ($status !== 'all') {
    $entrySql .= ' AND ' . posted_status_condition('je');
}
$entrySql .= ' GROUP BY je.id ORDER BY je.entry_date ASC, je.id ASC';
$stmt = db()->prepare($entrySql);
$stmt->execute($params);
$entries = $stmt->fetchAll();
$entryIds = array_map(static fn(array $row): int => (int)$row['id'], $entries);

// تحميل شجرة الدليل كاملة لتجميع أي حساب تفصيلي في أقرب حساب من المستوى الثاني.
$accountStmt = db()->prepare(
    'SELECT id,code,name_ar,parent_id,level_no,is_active
     FROM accounts
     WHERE company_id=? AND is_active=1
     ORDER BY code'
);
$accountStmt->execute([company_id()]);
$allAccounts = [];
$binaryAccounts = [];
foreach ($accountStmt->fetchAll() as $account) {
    $id = (int)$account['id'];
    $account['id'] = $id;
    $account['parent_id'] = $account['parent_id'] !== null ? (int)$account['parent_id'] : null;
    $account['level_no'] = (int)$account['level_no'];
    $allAccounts[$id] = $account;
    if ((int)$account['level_no'] === 2) {
        $binaryAccounts[$id] = $account;
    }
}

$binaryAncestorCache = [];
$binaryAncestor = static function (int $accountId) use (&$binaryAncestorCache, $allAccounts): ?int {
    if (array_key_exists($accountId, $binaryAncestorCache)) {
        return $binaryAncestorCache[$accountId];
    }
    $current = $accountId;
    $visited = [];
    while (isset($allAccounts[$current]) && !isset($visited[$current])) {
        $visited[$current] = true;
        $level = (int)$allAccounts[$current]['level_no'];
        if ($level === 2) {
            return $binaryAncestorCache[$accountId] = $current;
        }
        if ($level < 2) {
            break;
        }
        $parentId = $allAccounts[$current]['parent_id'];
        if ($parentId === null) {
            break;
        }
        $current = (int)$parentId;
    }
    return $binaryAncestorCache[$accountId] = null;
};

$linesByEntry = [];
$usedBinaryIds = [];
$currentByBinary = [];
$previousByBinary = [];
$currentTransactionAmount = 0.0;
$previousTransactionAmount = 0.0;

// تفاصيل الشهر الحالي ومجاميعه.
if ($entryIds !== []) {
    $placeholders = implode(',', array_fill(0, count($entryIds), '?'));
    $lineStmt = db()->prepare(
        "SELECT jl.journal_entry_id,jl.account_id,jl.debit,jl.credit
         FROM journal_lines jl
         WHERE jl.journal_entry_id IN ($placeholders)
         ORDER BY jl.journal_entry_id ASC, jl.line_order ASC, jl.id ASC"
    );
    $lineStmt->execute($entryIds);
    foreach ($lineStmt->fetchAll() as $line) {
        $entryId = (int)$line['journal_entry_id'];
        $sourceAccountId = (int)$line['account_id'];
        $binaryId = $binaryAncestor($sourceAccountId);
        if ($binaryId === null || !isset($binaryAccounts[$binaryId])) {
            continue;
        }
        $debit = round((float)$line['debit'], 3);
        $credit = round((float)$line['credit'], 3);
        if (!isset($linesByEntry[$entryId][$binaryId])) {
            $linesByEntry[$entryId][$binaryId] = ['debit' => 0.0, 'credit' => 0.0];
        }
        $linesByEntry[$entryId][$binaryId]['debit'] += $debit;
        $linesByEntry[$entryId][$binaryId]['credit'] += $credit;
        $usedBinaryIds[$binaryId] = true;
        if (!isset($currentByBinary[$binaryId])) {
            $currentByBinary[$binaryId] = ['debit' => 0.0, 'credit' => 0.0];
        }
        $currentByBinary[$binaryId]['debit'] += $debit;
        $currentByBinary[$binaryId]['credit'] += $credit;
    }
}
foreach ($entries as $entry) {
    $currentTransactionAmount += (float)$entry['total_amount'];
}

// المجموع السابق = التراكمي من 1 كانون الثاني حتى نهاية الشهر السابق.
if ($hasPreviousMonths) {
    $previousSql = "SELECT jl.account_id,
                           COALESCE(SUM(jl.debit),0) AS debit,
                           COALESCE(SUM(jl.credit),0) AS credit
                    FROM journal_lines jl
                    JOIN journal_entries je ON je.id=jl.journal_entry_id
                    WHERE je.company_id=? AND je.entry_date BETWEEN ? AND ?";
    $previousParams = [company_id(), $previousFrom, $previousTo];
    if ($status !== 'all') {
        $previousSql .= ' AND ' . posted_status_condition('je');
    }
    $previousSql .= ' GROUP BY jl.account_id';
    $previousStmt = db()->prepare($previousSql);
    $previousStmt->execute($previousParams);
    foreach ($previousStmt->fetchAll() as $line) {
        $debit = round((float)$line['debit'], 3);
        $credit = round((float)$line['credit'], 3);
        // مجموع مبلغ المعاملة = مجموع الجانب المدين لجميع القيود السابقة.
        $previousTransactionAmount += $debit;
        $binaryId = $binaryAncestor((int)$line['account_id']);
        if ($binaryId === null || !isset($binaryAccounts[$binaryId])) {
            continue;
        }
        if (!isset($previousByBinary[$binaryId])) {
            $previousByBinary[$binaryId] = ['debit' => 0.0, 'credit' => 0.0];
        }
        $previousByBinary[$binaryId]['debit'] += $debit;
        $previousByBinary[$binaryId]['credit'] += $credit;
        if (abs($debit) >= 0.0005 || abs($credit) >= 0.0005) {
            $usedBinaryIds[$binaryId] = true;
        }
    }
}

$accounts = [];
foreach ($binaryAccounts as $id => $account) {
    if ($showAllBinary || isset($usedBinaryIds[$id])) {
        $accounts[] = $account;
    }
}
usort($accounts, static fn(array $a, array $b): int => strnatcmp((string)$a['code'], (string)$b['code']));

$totalTransactionAmount = $previousTransactionAmount + $currentTransactionAmount;

function gj_amount_display(float $amount): string
{
    return abs($amount) < 0.0005 ? '' : money($amount);
}

function gj_total_display(float $amount): string
{
    return money(abs($amount) < 0.0005 ? 0.0 : $amount);
}

if ((string)($_GET['format'] ?? '') === 'csv') {
    require_role(['admin', 'accountant', 'viewer']);
    $filename = 'general_journal_' . $selectedYear . '_' . str_pad((string)$selectedMonth, 2, '0', STR_PAD_LEFT) . '.csv';
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('X-Content-Type-Options: nosniff');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'wb');
    fputcsv($out, ['الفترة', $periodLabel]);
    $header = ['اليوم', 'الشهر', 'رقم المستند', 'نوع المستند', 'البيان', 'مبلغ المعاملة'];
    foreach ($accounts as $account) {
        $header[] = (string)$account['name_ar'] . ' [' . (string)$account['code'] . '] مدين';
        $header[] = (string)$account['name_ar'] . ' [' . (string)$account['code'] . '] دائن';
    }
    fputcsv($out, $header);
    foreach ($entries as $entry) {
        $date = new DateTimeImmutable((string)$entry['entry_date']);
        $entryId = (int)$entry['id'];
        $description = (string)$entry['description'];
        if ($showReference && trim((string)$entry['reference_no']) !== '') {
            $description .= ' — مرجع: ' . trim((string)$entry['reference_no']);
        }
        $row = [
            $date->format('d'),
            $monthNames[(int)$date->format('n')],
            (string)$entry['voucher_no'],
            source_label((string)$entry['source_type']),
            $description,
            round((float)$entry['total_amount'], 3),
        ];
        foreach ($accounts as $account) {
            $line = $linesByEntry[$entryId][$account['id']] ?? ['debit' => 0.0, 'credit' => 0.0];
            $row[] = round((float)$line['debit'], 3);
            $row[] = round((float)$line['credit'], 3);
        }
        fputcsv($out, $row);
    }

    foreach ([
        ['المجموع الحالي', $currentTransactionAmount, $currentByBinary],
        ['المجموع السابق', $previousTransactionAmount, $previousByBinary],
        ['المجموع الكلي', $totalTransactionAmount, null],
    ] as [$label, $transactionAmount, $bucket]) {
        $footer = ['', '', '', '', $label, round((float)$transactionAmount, 3)];
        foreach ($accounts as $account) {
            $id = (int)$account['id'];
            if ($bucket === null) {
                $currentTotals = $currentByBinary[$id] ?? ['debit' => 0.0, 'credit' => 0.0];
                $previousTotals = $previousByBinary[$id] ?? ['debit' => 0.0, 'credit' => 0.0];
                $debit = (float)$currentTotals['debit'] + (float)$previousTotals['debit'];
                $credit = (float)$currentTotals['credit'] + (float)$previousTotals['credit'];
            } else {
                $totals = $bucket[$id] ?? ['debit' => 0.0, 'credit' => 0.0];
                $debit = (float)$totals['debit'];
                $credit = (float)$totals['credit'];
            }
            $footer[] = round($debit, 3);
            $footer[] = round($credit, 3);
        }
        fputcsv($out, $footer);
    }
    fclose($out);
    exit;
}

render_header('سجل اليومية العامة', 'general_journal');
page_heading(
    'سجل اليومية العامة',
    'عرض شهري مع مجاميع الشهر الحالي، والمجموع التراكمي السابق، والمجموع الكلي.'
);
$commonUrlParams = [
    'year' => (string)$selectedYear,
    'month' => (string)$selectedMonth,
    'status' => $status,
    'show_reference' => $showReference ? '1' : '0',
    'show_all_binary' => $showAllBinary ? '1' : '0',
];
$exportUrl = url('general_journal', $commonUrlParams + ['format' => 'csv']);
$professionalPrintUrl = url('general_journal', $commonUrlParams + ['print_view' => '1']);
$journalPrintDensity = count($accounts) > 12 ? 'gj-print-ultra' : (count($accounts) > 8 ? 'gj-print-compact' : 'gj-print-normal');
$journalTableMinWidth = 650 + (count($accounts) * 260); // كل حساب = مدين + دائن، وكل خانة مهيأة لما يصل إلى 12 مرتبة رقمية.
?>
<form class="filters no-print">
    <input type="hidden" name="page" value="general_journal">
    <div class="field" style="min-width:170px"><label>الشهر</label><select name="month"><?php foreach ($monthNames as $monthNo => $monthName): ?><option value="<?=e((string)$monthNo)?>" <?=$selectedMonth === $monthNo ? 'selected' : ''?>><?=e($monthName)?></option><?php endforeach; ?></select></div>
    <div class="field" style="min-width:120px"><label>السنة</label><select name="year"><?php foreach ($availableYears as $year): ?><option value="<?=e((string)$year)?>" <?=$selectedYear === (int)$year ? 'selected' : ''?>><?=e((string)$year)?></option><?php endforeach; ?></select></div>
    <div class="field" style="min-width:180px"><label>حالة القيود</label><select name="status"><option value="posted" <?= $status === 'posted' ? 'selected' : '' ?>>القيود المرحلة فقط</option><option value="all" <?= $status === 'all' ? 'selected' : '' ?>>جميع القيود</option></select></div>
    <label class="check-inline"><input type="checkbox" name="show_reference" value="1" <?= $showReference ? 'checked' : '' ?>> إظهار رقم المرجع داخل البيان</label>
    <label class="check-inline"><input type="checkbox" name="show_all_binary" value="1" <?= $showAllBinary ? 'checked' : '' ?>> إظهار الحسابات الثنائية بلا حركة</label>
    <button class="btn btn-primary">عرض</button>
    <a class="btn btn-primary" target="_blank" rel="noopener" href="<?=e($professionalPrintUrl)?>">طباعة احترافية</a>
    <button type="button" class="btn btn-outline print-btn">طباعة سريعة</button>
    <button type="button" class="btn btn-outline excel-export-btn">تصدير Excel</button>
</form>

<div class="alert alert-info no-print">الفترة الحالية: <strong><?=e($periodLabel)?></strong>. المجموع السابق يحسب تلقائياً من كانون الثاني حتى نهاية الشهر السابق، والمجموع الكلي = الحالي + السابق.</div>

<div class="card general-journal-card wide-report <?=e($journalPrintDensity)?>">
    <div class="report-head general-journal-head">
        <h2><?= e((string)(company()['name_ar'] ?? '')) ?></h2>
        <h2>يومية عامة</h2>
        <h3 class="gj-period-title">شهر <?=e($selectedMonthName)?> / <?=e((string)$selectedYear)?></h3>
        <small><?= $status === 'posted' ? 'يشمل القيود المرحلة فقط.' : 'يشمل جميع القيود.' ?> الأعمدة المحاسبية للحسابات الثنائية فقط.</small>
    </div>
    <div class="table-wrap general-journal-wrap" style="box-shadow:none">
        <table class="general-journal-table" style="min-width:<?=e((string)$journalTableMinWidth)?>px">
            <thead>
                <tr>
                    <th rowspan="2" class="gj-small-head">اليوم</th>
                    <th rowspan="2" class="gj-month-head">الشهر</th>
                    <th rowspan="2" class="gj-doc-head">رقم المستند</th>
                    <th rowspan="2" class="gj-type-head">نوع المستند</th>
                    <th rowspan="2" class="gj-desc-head">البيان</th>
                    <th rowspan="2" class="gj-amount-head">مبلغ المعاملة</th>
                    <?php foreach ($accounts as $account): ?>
                        <th colspan="2" class="gj-account-head"><div><?= e((string)$account['name_ar']) ?></div><small><?= e((string)$account['code']) ?></small></th>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <?php foreach ($accounts as $account): ?><th class="gj-subhead">مدين</th><th class="gj-subhead">دائن</th><?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
            <?php if ($entries === []): ?>
                <tr><td colspan="<?= e((string)(6 + count($accounts) * 2)) ?>" class="empty">لا توجد قيود في شهر <?=e($selectedMonthName)?> <?=e((string)$selectedYear)?>.</td></tr>
            <?php else: ?>
                <?php foreach ($entries as $entry):
                    $date = new DateTimeImmutable((string)$entry['entry_date']);
                    $entryId = (int)$entry['id'];
                    $description = (string)$entry['description'];
                    if ($showReference && trim((string)$entry['reference_no']) !== '') {
                        $description .= ' — مرجع: ' . trim((string)$entry['reference_no']);
                    }
                ?>
                <tr>
                    <td class="gj-date-cell"><?= e($date->format('d')) ?></td>
                    <td class="gj-month-cell"><?= e($monthNames[(int)$date->format('n')]) ?></td>
                    <td class="gj-doc-cell"><?= e((string)$entry['voucher_no']) ?></td>
                    <td class="gj-type-cell"><?= e(source_label((string)$entry['source_type'])) ?></td>
                    <td class="gj-desc-cell"><?= e($description) ?></td>
                    <td class="num gj-amount-cell"><?= e(gj_amount_display((float)$entry['total_amount'])) ?></td>
                    <?php foreach ($accounts as $account):
                        $line = $linesByEntry[$entryId][$account['id']] ?? ['debit' => 0.0, 'credit' => 0.0];
                    ?>
                        <td class="num gj-side-cell"><?= e(gj_amount_display((float)$line['debit'])) ?></td>
                        <td class="num gj-side-cell"><?= e(gj_amount_display((float)$line['credit'])) ?></td>
                    <?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
            <tfoot>
                <tr class="gj-total-row gj-current-total"><td colspan="5">المجموع الحالي — <?=e($selectedMonthName)?></td><td class="num"><?= e(gj_total_display($currentTransactionAmount)) ?></td><?php foreach ($accounts as $account): $totals = $currentByBinary[$account['id']] ?? ['debit' => 0.0, 'credit' => 0.0]; ?><td class="num"><?= e(gj_total_display((float)$totals['debit'])) ?></td><td class="num"><?= e(gj_total_display((float)$totals['credit'])) ?></td><?php endforeach; ?></tr>
                <tr class="gj-total-row gj-previous-total"><td colspan="5">المجموع السابق — حتى نهاية <?=e($selectedMonth === 1 ? 'السنة السابقة = صفر' : $monthNames[$selectedMonth - 1])?></td><td class="num"><?= e(gj_total_display($previousTransactionAmount)) ?></td><?php foreach ($accounts as $account): $totals = $previousByBinary[$account['id']] ?? ['debit' => 0.0, 'credit' => 0.0]; ?><td class="num"><?= e(gj_total_display((float)$totals['debit'])) ?></td><td class="num"><?= e(gj_total_display((float)$totals['credit'])) ?></td><?php endforeach; ?></tr>
                <tr class="gj-total-row gj-grand-total"><td colspan="5">المجموع الكلي = الحالي + السابق</td><td class="num"><?= e(gj_total_display($totalTransactionAmount)) ?></td><?php foreach ($accounts as $account): $id=(int)$account['id']; $currentTotals=$currentByBinary[$id]??['debit'=>0.0,'credit'=>0.0]; $previousTotals=$previousByBinary[$id]??['debit'=>0.0,'credit'=>0.0]; ?><td class="num"><?= e(gj_total_display((float)$currentTotals['debit'] + (float)$previousTotals['debit'])) ?></td><td class="num"><?= e(gj_total_display((float)$currentTotals['credit'] + (float)$previousTotals['credit'])) ?></td><?php endforeach; ?></tr>
            </tfoot>
        </table>
    </div>
</div>
<?php render_footer(); ?>
