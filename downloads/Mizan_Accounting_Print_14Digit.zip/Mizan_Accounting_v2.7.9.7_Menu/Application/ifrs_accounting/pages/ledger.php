<?php
declare(strict_types=1);
require_role(['admin','accountant','viewer']);

$from = (string)($_GET['from'] ?? date('Y-01-01'));
$to = (string)($_GET['to'] ?? date('Y-m-d'));
$statementNo = trim((string)($_GET['statement_no'] ?? ''));
if (!valid_date($from) || !valid_date($to) || $from > $to) {
    throw new RuntimeException('نطاق التاريخ غير صالح.');
}

// قائمة الأستاذ تعرض فقط الحسابات الفعالة التي لها رصيد فعلي غير صفري حتى تاريخ نهاية التقرير.
$balanceAccountsStmt = db()->prepare(
    "SELECT a.id,a.code,a.name_ar,a.account_type,a.is_cash_account,a.normal_balance,
            COALESCE(SUM(jl.debit-jl.credit),0) AS balance_raw
     FROM accounts a
     JOIN journal_lines jl ON jl.account_id=a.id
     JOIN journal_entries je ON je.id=jl.journal_entry_id
     WHERE a.company_id=? AND a.is_active=1 AND a.is_postable=1
       AND je.company_id=a.company_id AND " . posted_status_condition('je') . " AND je.entry_date<=?
     GROUP BY a.id,a.code,a.name_ar,a.account_type,a.is_cash_account,a.normal_balance
     HAVING ABS(COALESCE(SUM(jl.debit-jl.credit),0)) >= 0.0005
     ORDER BY a.code"
);
$balanceAccountsStmt->execute([company_id(), $to]);
$accounts = $balanceAccountsStmt->fetchAll();

$requestedAccountId = (int)($_GET['account_id'] ?? 0);
$allowedAccountIds = array_map(static fn(array $row): int => (int)$row['id'], $accounts);
$accountId = in_array($requestedAccountId, $allowedAccountIds, true)
    ? $requestedAccountId
    : (int)($accounts[0]['id'] ?? 0);

$account = null;
$lines = [];
$opening = 0.0;
if ($accountId > 0) {
    $stmt = db()->prepare('SELECT * FROM accounts WHERE id=? AND company_id=?');
    $stmt->execute([$accountId, company_id()]);
    $account = $stmt->fetch() ?: null;
    if ($account) {
        $stmt = db()->prepare(
            "SELECT COALESCE(SUM(jl.debit-jl.credit),0)
             FROM journal_lines jl
             JOIN journal_entries je ON je.id=jl.journal_entry_id
             WHERE je.company_id=? AND " . posted_status_condition('je') . "
               AND jl.account_id=? AND je.entry_date<?"
        );
        $stmt->execute([company_id(), $accountId, $from]);
        $opening = (float)$stmt->fetchColumn();

        $stmt = db()->prepare(
            "SELECT je.id,je.voucher_no,je.entry_date,je.description,je.source_type,
                    jl.line_description,jl.debit,jl.credit,cc.name_ar cost_center,p.name_ar party
             FROM journal_lines jl
             JOIN journal_entries je ON je.id=jl.journal_entry_id
             LEFT JOIN cost_centers cc ON cc.id=jl.cost_center_id
             LEFT JOIN parties p ON p.id=jl.party_id
             WHERE je.company_id=? AND " . posted_status_condition('je') . "
               AND jl.account_id=? AND je.entry_date BETWEEN ? AND ?
             ORDER BY je.entry_date ASC,je.id ASC,jl.id ASC"
        );
        $stmt->execute([company_id(), $accountId, $from, $to]);
        $lines = $stmt->fetchAll();
    }
}

function iraqi_ledger_number(float $value, bool $blankZero = true): string
{
    if ($blankZero && abs($value) < 0.0005) return '';
    $decimals = (int)(company()['decimal_places'] ?? 0);
    return number_format(abs($value), max(0, min(3, $decimals)), '.', ',');
}

function iraqi_ledger_date(string $date): string
{
    $time = strtotime($date);
    return $time ? date('d/m/Y', $time) : $date;
}

function iraqi_ledger_document_type(string $source): string
{
    return match ($source) {
        'payment' => 'صرف',
        'receipt' => 'قبض',
        default => 'قيد',
    };
}

function iraqi_ledger_balance(float $net): array
{
    if (abs($net) < 0.0005) {
        return ['debit' => 0.0, 'credit' => 0.0, 'net' => 0.0, 'side' => 'متعادل'];
    }
    if ($net > 0) {
        return ['debit' => $net, 'credit' => 0.0, 'net' => $net, 'side' => 'مدين'];
    }
    return ['debit' => 0.0, 'credit' => abs($net), 'net' => abs($net), 'side' => 'دائن'];
}

$GLOBALS['fixed_print_template'] = 'ledger';
render_header('دفتر الأستاذ', 'ledger');
$professionalPrintUrl = $accountId > 0 ? url('ledger', [
    'account_id' => (string)$accountId,
    'from' => $from,
    'to' => $to,
    'statement_no' => $statementNo,
    'print_view' => '1',
]) : '';
$headingPrintAction = $professionalPrintUrl !== ''
    ? '<a id="ledgerProfessionalPrintTop" class="btn btn-success ledger-professional-print-link" target="_blank" rel="noopener" href="' . e($professionalPrintUrl) . '">' . icon('print') . ' طباعة احترافية PDF</a>'
    : '<button class="btn btn-light" type="button" disabled>' . icon('print') . ' طباعة احترافية PDF</button>';
page_heading('دفتر الأستاذ العام', 'اختر حساباً ذا رصيد فعلي لعرض سجله كاملاً ضمن الفترة المحددة.', $headingPrintAction);
?>
<form class="filters no-print" id="ledgerFilterForm">
    <input type="hidden" name="page" value="ledger">
    <div class="field" style="min-width:180px">
        <label>رقم الحساب</label>
        <input id="ledgerAccountCode" inputmode="numeric" list="ledgerAccountCodeList" placeholder="اكتب رقم الحساب" autocomplete="off">
    </div>
    <div class="field" style="min-width:340px">
        <label>الحسابات التي تحتوي على رصيد حتى تاريخ النهاية (<?=e((string)count($accounts))?>)</label>
        <select name="account_id" id="ledgerAccountSelect" required>
            <?php foreach ($accounts as $a): $listBalance=(float)$a['balance_raw']; $listSide=$listBalance>=0?'مدين':'دائن'; ?>
                <option value="<?=e((string)$a['id'])?>" data-code="<?=e((string)$a['code'])?>" <?=$accountId === (int)$a['id'] ? 'selected' : ''?>><?=e((string)$a['code'].' — '.(string)$a['name_ar'].' — '.number_format(abs($listBalance), (int)(company()['decimal_places'] ?? 0), '.', ',').' '.$listSide)?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="field"><label>من</label><input type="date" name="from" value="<?=e($from)?>"></div>
    <div class="field"><label>إلى</label><input type="date" name="to" value="<?=e($to)?>"></div>
    <div class="field" style="min-width:120px"><label>رقم كشف الحساب</label><input name="statement_no" value="<?=e($statementNo)?>" placeholder="اختياري"></div>
    <button class="btn btn-primary">عرض</button>
    <?php if ($professionalPrintUrl !== ''): ?><a id="ledgerProfessionalPrintFilter" class="btn btn-success ledger-professional-print-link" target="_blank" rel="noopener" href="<?=e($professionalPrintUrl)?>"><?=icon('print')?> طباعة احترافية PDF</a><?php endif; ?>
    <button type="button" class="btn btn-outline print-btn">طباعة سريعة</button>
    <button type="button" class="btn btn-outline excel-export-btn">تصدير Excel</button>
</form>
<datalist id="ledgerAccountCodeList"><?php foreach($accounts as $a):?><option value="<?=e((string)$a['code'])?>"><?=e((string)$a['name_ar'])?></option><?php endforeach;?></datalist>
<?php if ($accounts === []): ?><div class="alert alert-info">لا توجد حسابات ذات رصيد غير صفري حتى تاريخ <?=e(doc_date($to))?>.</div><?php endif; ?>

<?php if ($account):
    $running = $opening;
    $totalDebit = 0.0;
    $totalCredit = 0.0;
    $yearTitle = date('Y', strtotime($to));
    $sequence = 0;
    $movementCount = count($lines) + (abs($opening) >= 0.0005 ? 1 : 0);
?>
<section class="excel-ledger-sheet iraqi-ledger-sheet" aria-label="سجل الأستاذ العام">
    <header class="excel-ledger-company"><?=e((string)(company()['name_ar'] ?? ''))?></header>
    <div class="excel-ledger-title">سجل الأستاذ العام / <?=e($yearTitle)?></div>
    <div class="excel-ledger-meta">
        <div class="ledger-statement-number">كشف حساب رقم ( <strong><?=e($statementNo !== '' ? $statementNo : ' ')?></strong> )</div>
        <div class="ledger-account-number"><span>رقم الحساب :</span> <strong><?=e((string)$account['code'])?></strong></div>
    </div>
    <div class="excel-ledger-account-name"><span>اسم الحساب :</span><strong><?=e((string)$account['name_ar'])?></strong></div>

    <div class="excel-ledger-table-wrap" dir="rtl">
    <table class="excel-ledger-table iraqi-ledger-table" dir="rtl">
        <colgroup>
            <col class="ledger-seq"><col class="ledger-date"><col class="ledger-doc-type"><col class="ledger-doc">
            <col class="ledger-desc"><col class="ledger-debit"><col class="ledger-credit">
            <col class="ledger-bal-debit"><col class="ledger-bal-credit"><col class="ledger-bal-net">
        </colgroup>
        <thead>
            <tr>
                <th rowspan="2">ت</th>
                <th rowspan="2">التاريخ</th>
                <th rowspan="2">نوع المستند</th>
                <th rowspan="2">رقم المستند</th>
                <th rowspan="2">البيان</th>
                <th rowspan="2">مدين</th>
                <th rowspan="2">دائن</th>
                <th colspan="3">الرصيد</th>
            </tr>
            <tr><th>مدين</th><th>دائن</th><th>الصافي</th></tr>
        </thead>
        <tbody>
        <?php if (abs($opening) >= 0.0005): $sequence++; $openingBalance = iraqi_ledger_balance($running); ?>
            <tr class="ledger-opening-row">
                <td><?=e((string)$sequence)?></td>
                <td class="ledger-date-cell"><bdi dir="ltr"><?=e(iraqi_ledger_date($from))?></bdi></td>
                <td class="ledger-doc-type-cell">قيد</td>
                <td>—</td>
                <td class="ledger-desc-cell">الرصيد المدور من قبل</td>
                <td class="num"></td><td class="num"></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$openingBalance['debit']))?></bdi></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$openingBalance['credit']))?></bdi></td>
                <td class="num ledger-net-balance"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$openingBalance['net'], false))?></bdi><small><?=e((string)$openingBalance['side'])?></small></td>
            </tr>
        <?php endif; ?>
        <?php foreach ($lines as $row):
            $sequence++;
            $debit = (float)$row['debit'];
            $credit = (float)$row['credit'];
            $running += $debit - $credit;
            $balance = iraqi_ledger_balance($running);
            $documentType = iraqi_ledger_document_type((string)$row['source_type']);
            $totalDebit += $debit;
            $totalCredit += $credit;
            $description = trim((string)($row['line_description'] ?: $row['description']));
            $extra = trim((string)($row['cost_center'] ?? '').' / '.(string)($row['party'] ?? ''), ' /');
            if ($extra !== '') $description .= ' — '.$extra;
            $documentNo = (string)$row['voucher_no'];
        ?>
            <tr>
                <td><?=e((string)$sequence)?></td>
                <td class="ledger-date-cell"><bdi dir="ltr"><?=e(iraqi_ledger_date((string)$row['entry_date']))?></bdi></td>
                <td class="ledger-doc-type-cell"><?=e($documentType)?></td>
                <td><a class="code" href="<?=e(url('journal_view',['id'=>$row['id']]))?>"><?=e($documentNo)?></a></td>
                <td class="ledger-desc-cell"><?=e($description)?></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number($debit))?></bdi></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number($credit))?></bdi></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$balance['debit']))?></bdi></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$balance['credit']))?></bdi></td>
                <td class="num ledger-net-balance"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$balance['net'], false))?></bdi><small><?=e((string)$balance['side'])?></small></td>
            </tr>
        <?php endforeach; ?>
        <?php if ($lines === [] && abs($opening) < 0.0005): ?>
            <tr><td colspan="10" class="empty">لا توجد حركات للحساب ضمن المدة المحددة.</td></tr>
        <?php endif; ?>
        </tbody>
        <?php $closingBalance = iraqi_ledger_balance($running); ?>
        <tfoot>
            <tr>
                <td colspan="5" class="ledger-closing-label">المجاميع / الرصيد كما في <bdi dir="ltr"><?=e(iraqi_ledger_date($to))?></bdi></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number($totalDebit, false))?></bdi></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number($totalCredit, false))?></bdi></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$closingBalance['debit']))?></bdi></td>
                <td class="num"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$closingBalance['credit']))?></bdi></td>
                <td class="num ledger-net-balance"><bdi dir="ltr"><?=e(iraqi_ledger_number((float)$closingBalance['net'], false))?></bdi><small><?=e((string)$closingBalance['side'])?></small></td>
            </tr>
        </tfoot>
    </table>
    </div>
    <div class="iraqi-ledger-summary">
        <span>الرصيد النهائي: <strong><?=e(iraqi_ledger_number((float)$closingBalance['net'], false))?> <?=e((string)$closingBalance['side'])?></strong></span>
        <span>إجمالي مدين: <strong><?=e(iraqi_ledger_number($totalDebit, false))?></strong></span>
        <span>إجمالي دائن: <strong><?=e(iraqi_ledger_number($totalCredit, false))?></strong></span>
        <span>عدد الحركات: <strong><?=e((string)$movementCount)?></strong></span>
    </div>
</section>
<script>
(() => {
  const code = document.getElementById('ledgerAccountCode');
  const select = document.getElementById('ledgerAccountSelect');
  const form = document.getElementById('ledgerFilterForm');
  if (!code || !select || !form) return;
  const updateProfessionalPrintLinks = () => {
    const accountId = select.value || '';
    const from = form.querySelector('[name="from"]')?.value || '';
    const to = form.querySelector('[name="to"]')?.value || '';
    const statementNo = form.querySelector('[name="statement_no"]')?.value || '';
    if (!accountId) return;
    const printUrl = new URL('index.php', window.location.href);
    printUrl.search = '';
    printUrl.searchParams.set('page', 'ledger');
    printUrl.searchParams.set('account_id', accountId);
    printUrl.searchParams.set('from', from);
    printUrl.searchParams.set('to', to);
    if (statementNo !== '') printUrl.searchParams.set('statement_no', statementNo);
    printUrl.searchParams.set('print_view', '1');
    document.querySelectorAll('.ledger-professional-print-link').forEach((link) => {
      link.href = printUrl.toString();
    });
  };
  const syncCode = () => { code.value = select.selectedOptions[0]?.dataset.code || ''; code.setCustomValidity(''); updateProfessionalPrintLinks(); };
  const syncSelect = (force) => {
    const value = code.value.trim();
    const options = Array.from(select.options);
    const exact = options.find(o => o.dataset.code === value);
    const prefixes = options.filter(o => (o.dataset.code || '').startsWith(value));
    const match = exact || (force && prefixes.length === 1 ? prefixes[0] : null);
    if (match) { select.value = match.value; code.value = match.dataset.code || value; code.setCustomValidity(''); }
    else if (!value) code.setCustomValidity('');
    else if (force) { code.setCustomValidity('رقم الحساب غير موجود في الدليل.'); code.reportValidity(); }
  };
  select.addEventListener('change', syncCode);
  code.addEventListener('input', () => syncSelect(false));
  code.addEventListener('change', () => { syncSelect(true); updateProfessionalPrintLinks(); });
  code.addEventListener('blur', () => { syncSelect(true); updateProfessionalPrintLinks(); });
  form.querySelectorAll('input[name="from"],input[name="to"],input[name="statement_no"]').forEach((input) => {
    input.addEventListener('change', updateProfessionalPrintLinks);
    input.addEventListener('input', updateProfessionalPrintLinks);
  });
  syncCode();
  updateProfessionalPrintLinks();
})();
</script>
<?php endif; ?>
<div class="programmer-print">المبرمج: م. أرشد حميد حسن • واتساب: 07735882844</div>
<?php render_footer(); ?>
