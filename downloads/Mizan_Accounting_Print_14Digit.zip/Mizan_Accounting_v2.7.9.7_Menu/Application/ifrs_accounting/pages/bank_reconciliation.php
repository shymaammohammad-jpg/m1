<?php
declare(strict_types=1);
require_role(['admin','accountant','viewer']);

$accounts = br_bank_accounts();
$accountId = (int)($_GET['account_id'] ?? ($accounts[0]['id'] ?? 0));
$month = trim((string)($_GET['month'] ?? date('Y-m')));
try {
    br_month_bounds($month);
} catch (Throwable) {
    $month = date('Y-m');
}

$GLOBALS['fixed_print_template'] = 'bank-reconciliation';
render_header('شهادة مطابقة البنك', 'bank_reconciliation');
page_heading('شهادة مطابقة البنك', 'يدخل المستخدم كشف البنك فقط، بينما تُسحب أرصدة وحركات السجلات وتُحسب فروقات المطابقة تلقائياً.');

if ($accounts === []) {
    echo '<div class="alert alert-warning">لا يوجد حساب بنكي/نقدي قابل للترحيل. عرّف حساب البنك من دليل الحسابات ثم أعد فتح الشهادة.</div>';
    render_footer();
    return;
}

$validAccountIds = array_map(static fn(array $a): int => (int)$a['id'], $accounts);
if (!in_array($accountId, $validAccountIds, true)) $accountId = (int)$accounts[0]['id'];

$statement = br_load_statement($accountId, $month);
$bookData = br_book_data($accountId, $month);
$recon = br_match_statement($bookData, $statement);
$account = $bookData['account'];
[$from, $to] = br_month_bounds($month);
$company = company();
$header2Parts = array_values(array_filter([
    trim((string)($company['ministry_name_ar'] ?? '')),
    trim((string)($company['formation_name_ar'] ?? '')),
]));
$header2 = implode(' - ', $header2Parts);
$bankName = trim((string)($statement['bank_name'] ?? ''));
$bankAccountNo = trim((string)($statement['bank_account_no'] ?? ''));
if ($bankAccountNo === '') $bankAccountNo = (string)$account['code'];
$statementMonthLabel = br_month_label_ar($month);
$printAsOf = doc_date($to);
$leftTotal = round((float)$bookData['withdrawals'] + (float)$bookData['closing'], 3);
$rightTotal = round((float)$bookData['opening'] + (float)$bookData['deposits'], 3);
$hasStatementRows = count((array)($statement['rows'] ?? [])) > 0;
$isBalanced = $hasStatementRows && abs((float)$recon['difference']) < 0.0005;
$editable = in_array((string)user()['role'], ['admin','accountant'], true);
$existingRows = (array)($statement['rows'] ?? []);
$displayRows = max(8, count($existingRows) + 2);
?>

<form class="filters no-print bank-reconciliation-filter" method="get">
    <input type="hidden" name="page" value="bank_reconciliation">
    <div class="field" style="min-width:340px">
        <label>حساب البنك في دليل الحسابات</label>
        <select name="account_id" required>
            <?php foreach ($accounts as $a): ?>
                <option value="<?=e((string)$a['id'])?>" <?=$accountId === (int)$a['id'] ? 'selected' : ''?>><?=e((string)$a['code'].' — '.(string)$a['name_ar'])?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="field"><label>شهر المطابقة</label><input type="month" name="month" value="<?=e($month)?>" required></div>
    <button class="btn btn-primary">عرض الشهر</button>
    <button type="button" class="btn btn-outline print-btn">طباعة الشهادة</button>
</form>

<?php if ($editable): ?>
<section class="card bank-statement-entry no-print">
    <div class="bank-entry-heading">
        <div><h3>إدخال كشف البنك</h3><p>هذا هو الجزء الوحيد الذي يدخله المستخدم. بعد الحفظ يعيد النظام المطابقة والحساب تلقائياً.</p></div>
        <div class="bank-entry-actions"><button type="button" class="btn btn-light" id="bankAddRow">إضافة صف</button></div>
    </div>
    <form method="post" id="bankStatementForm">
        <?=csrf_field()?>
        <input type="hidden" name="action" value="bank_reconciliation_save">
        <input type="hidden" name="account_id" value="<?=e((string)$accountId)?>">
        <input type="hidden" name="month" value="<?=e($month)?>">
        <div class="grid grid-3 bank-entry-meta">
            <div class="field"><label>اسم البنك</label><input name="bank_name" value="<?=e((string)($statement['bank_name'] ?? ''))?>" placeholder="مثال: مصرف الرشيد"></div>
            <div class="field"><label>رقم الحساب البنكي</label><input name="bank_account_no" value="<?=e((string)($statement['bank_account_no'] ?? ''))?>" placeholder="رقم الحساب في كشف البنك"></div>
            <div class="field"><label>الرصيد النهائي حسب كشف البنك</label><input class="num" inputmode="decimal" name="closing_balance" value="<?=e((string)($statement['closing_balance'] ?? 0))?>" required></div>
        </div>
        <div class="table-wrap bank-statement-table-wrap">
            <table class="data-table bank-statement-table" id="bankStatementTable">
                <thead><tr><th>التاريخ</th><th>رقم/مرجع الحركة</th><th>البيان</th><th>إيداع</th><th>سحب</th><th class="bank-row-action">حذف</th></tr></thead>
                <tbody id="bankStatementRows">
                <?php for ($i=0; $i<$displayRows; $i++): $r=$existingRows[$i] ?? []; ?>
                    <tr>
                        <td><input type="date" name="statement_date[]" value="<?=e((string)($r['date'] ?? ''))?>"></td>
                        <td><input name="statement_reference[]" value="<?=e((string)($r['reference'] ?? ''))?>"></td>
                        <td><input name="statement_description[]" value="<?=e((string)($r['description'] ?? ''))?>"></td>
                        <td><input class="num bank-side-input" inputmode="decimal" name="statement_deposit[]" value="<?=isset($r['deposit']) && (float)$r['deposit'] != 0 ? e((string)$r['deposit']) : ''?>"></td>
                        <td><input class="num bank-side-input" inputmode="decimal" name="statement_withdrawal[]" value="<?=isset($r['withdrawal']) && (float)$r['withdrawal'] != 0 ? e((string)$r['withdrawal']) : ''?>"></td>
                        <td class="bank-row-action"><button type="button" class="btn btn-sm btn-light bankRemoveRow" aria-label="حذف الصف">×</button></td>
                    </tr>
                <?php endfor; ?>
                </tbody>
            </table>
        </div>
        <div class="bank-entry-footer">
            <button class="btn btn-primary">حفظ الكشف وإجراء المطابقة الآلية</button>
            <span class="muted small">المطابقة تعتمد على المبلغ والاتجاه والتاريخ، وتُعطي أولوية لرقم المرجع/الشيك عند توفره.</span>
        </div>
    </form>
    <form method="post" class="bank-clear-form">
        <?=csrf_field()?>
        <input type="hidden" name="action" value="bank_reconciliation_clear">
        <input type="hidden" name="account_id" value="<?=e((string)$accountId)?>">
        <input type="hidden" name="month" value="<?=e($month)?>">
        <button class="btn btn-sm btn-danger" data-confirm="مسح كشف البنك المدخل لهذا الحساب والشهر؟">مسح كشف هذا الشهر</button>
    </form>
</section>
<?php endif; ?>

<section class="reconciliation-status no-print">
    <div class="recon-stat"><span>رصيد السجلات</span><strong><?=e(br_money((float)$bookData['closing']))?></strong></div>
    <div class="recon-stat"><span>رصيد كشف البنك</span><strong><?=e(br_money((float)$recon['bank_balance']))?></strong></div>
    <div class="recon-stat"><span>الرصيد البنكي المعدل</span><strong><?=e(br_money((float)$recon['adjusted_bank_balance']))?></strong></div>
    <div class="recon-stat <?=$isBalanced?'recon-ok':'recon-warn'?>"><span>فرق المطابقة</span><strong><?=e(br_money((float)$recon['difference']))?></strong><small><?=$isBalanced?'مطابق':'يحتاج مراجعة'?></small></div>
</section>

<?php if (!$hasStatementRows): ?>
<div class="alert alert-info no-print">تم حساب جانب السجلات تلقائياً. أدخل حركات كشف البنك ثم اضغط «حفظ الكشف وإجراء المطابقة الآلية» لإكمال فروقات المطابقة.</div>
<?php else: ?>
<div class="card no-print reconciliation-audit-card">
    <div class="bank-entry-heading"><div><h3>نتيجة المطابقة الآلية</h3><p>تمت مطابقة <?=e((string)$recon['matched_count'])?> من أصل <?=e((string)count($recon['bank_rows']))?> حركة في كشف البنك.</p></div></div>
    <div class="grid grid-3 recon-differences">
        <div><span>شيكات موقوفة</span><strong><?=e(br_money((float)$recon['outstanding_checks']))?></strong></div>
        <div><span>مسحوبات بالبنك غير مسجلة</span><strong><?=e(br_money((float)$recon['bank_withdrawals_not_books']))?></strong></div>
        <div><span>إيداعات بالبنك غير مسجلة</span><strong><?=e(br_money((float)$recon['bank_deposits_not_books']))?></strong></div>
        <div><span>مسحوبات بالسجلات لم تظهر بالبنك</span><strong><?=e(br_money((float)$recon['books_withdrawals_not_bank']))?></strong></div>
        <div><span>إيداعات بالسجلات لم تظهر بالبنك</span><strong><?=e(br_money((float)$recon['books_deposits_not_bank']))?></strong></div>
        <div><span>رصيد افتتاح كشف البنك المستنتج</span><strong><?=e(br_money((float)$recon['statement_opening']))?></strong></div>
    </div>
    <?php if ($recon['unmatched_bank'] || $recon['unmatched_books']): ?>
    <details class="recon-details"><summary>عرض الحركات غير المطابقة</summary>
        <div class="grid grid-2">
            <div><h4>في كشف البنك ولم تُطابق السجلات</h4><div class="table-wrap"><table class="data-table"><thead><tr><th>التاريخ</th><th>المرجع</th><th>النوع</th><th>المبلغ</th></tr></thead><tbody><?php foreach($recon['unmatched_bank'] as $r):?><tr><td><?=e(doc_date((string)$r['date']))?></td><td><?=e((string)($r['reference']??''))?></td><td><?=e($r['type']==='deposit'?'إيداع':'سحب')?></td><td class="num"><?=e(br_money((float)$r['amount']))?></td></tr><?php endforeach;?></tbody></table></div></div>
            <div><h4>في السجلات ولم تُطابق كشف البنك</h4><div class="table-wrap"><table class="data-table"><thead><tr><th>التاريخ</th><th>المستند</th><th>النوع</th><th>المبلغ</th></tr></thead><tbody><?php foreach($recon['unmatched_books'] as $r):?><tr><td><?=e(doc_date((string)$r['date']))?></td><td><?=e((string)$r['voucher_no'])?></td><td><?=e($r['type']==='deposit'?'إيداع':'سحب')?></td><td class="num"><?=e(br_money((float)$r['amount']))?></td></tr><?php endforeach;?></tbody></table></div></div>
        </div>
    </details>
    <?php endif; ?>
</div>
<?php endif; ?>

<section class="bank-reconciliation-sheet" id="bankReconciliationSheet" aria-label="شهادة مطابقة البنك">
    <div class="br-header-line br-header-1"><?=e((string)($company['name_ar'] ?? ''))?></div>
    <div class="br-header-line br-header-2"><?=e($header2)?></div>
    <div class="br-header-line br-header-3">
        <span>مطابقة كشف البنك<?= $bankName!=='' ? ' — '.e($bankName) : '' ?></span>
        <span class="br-dot">.</span>
        <span><?=e($bankAccountNo)?></span>
        <span class="br-dot">.</span>
        <span>كما في (</span><bdi dir="rtl"><?=e($printAsOf)?></bdi><span>)</span>
    </div>

    <div class="br-section-title">رصيد البنك بموجب السجلات</div>
    <table class="br-table br-books-table" aria-label="رصيد البنك بموجب السجلات">
        <colgroup><col class="br-col-detail"><col class="br-col-amount"><col class="br-col-detail"><col class="br-col-amount"></colgroup>
        <thead>
            <tr><th rowspan="2">التفاصيل</th><th>المبلغ</th><th rowspan="2">التفاصيل</th><th>المبلغ</th></tr>
            <tr><th>دينار</th><th>دينار</th></tr>
        </thead>
        <tbody>
            <tr>
                <td>مسحوبات خلال الشهر</td><td class="br-money"><?=e(br_money((float)$bookData['withdrawals']))?></td>
                <td>الرصيد بداية الشهر</td><td class="br-money"><?=e(br_money((float)$bookData['opening']))?></td>
            </tr>
            <tr>
                <td>يضاف الرصيد النهائي بموجب السجلات</td><td class="br-money"><?=e(br_money((float)$bookData['closing']))?></td>
                <td>تضاف + الإيداعات</td><td class="br-money"><?=e(br_money((float)$bookData['deposits']))?></td>
            </tr>
            <tr class="br-total-row">
                <td></td><td class="br-money br-total-cell"><?=e(br_money($leftTotal))?></td>
                <td>المجموع</td><td class="br-money br-total-cell"><?=e(br_money($rightTotal))?></td>
            </tr>
        </tbody>
    </table>

    <div class="br-section-title br-section-title-bank">رصيد البنك بموجب كشف البنك</div>
    <table class="br-table br-bank-table" aria-label="رصيد البنك بموجب كشف البنك">
        <colgroup><col class="br-side-empty"><col class="br-side-empty"><col class="br-detail-wide"><col class="br-bank-amount"></colgroup>
        <thead>
            <tr><th colspan="3">التفاصيل</th><th>المبلغ</th></tr>
            <tr><th colspan="3"></th><th>دينار</th></tr>
        </thead>
        <tbody>
            <tr><td>0</td><td></td><td>الرصيد مطابق لكشف البنك لشهر <?=e($statementMonthLabel)?></td><td class="br-money br-gray"><?=e(br_money((float)$recon['bank_balance']))?></td></tr>
            <tr><td></td><td></td><td>تطرح الشيكات الموقوفة</td><td class="br-money"><?=e(br_money((float)$recon['outstanding_checks']))?></td></tr>
            <tr class="br-highlight"><td></td><td></td><td>مسحوبات ظهرت في كشف البنك ولم تظهر في السجلات</td><td class="br-money"><?=e(br_money((float)$recon['bank_withdrawals_not_books']))?></td></tr>
            <tr><td></td><td></td><td>إيداعات ظهرت في كشف البنك ولم تظهر في السجلات</td><td class="br-money"><?=e(br_money((float)$recon['bank_deposits_not_books']))?></td></tr>
            <tr><td></td><td></td><td>مسحوبات ظهرت في السجلات ولم تظهر في كشف البنك</td><td class="br-money"><?=e(br_money((float)$recon['books_withdrawals_not_bank']))?></td></tr>
            <tr class="br-highlight"><td></td><td></td><td>إيداعات ظهرت في السجلات ولم تظهر في كشف البنك</td><td class="br-money"><?=e(br_money((float)$recon['books_deposits_not_bank']))?></td></tr>
            <tr><td></td><td></td><td><strong>إيداعات لم تظهر في الكشف</strong></td><td class="br-money"><?=e(br_money((float)$recon['books_deposits_not_bank']))?></td></tr>
            <tr><td></td><td></td><td>الرصيد النهائي في السجلات لشهر <?=e($statementMonthLabel)?></td><td class="br-money br-gray"><?=e(br_money((float)$bookData['closing']))?></td></tr>
        </tbody>
    </table>

    <div class="br-signatures" id="bankReconciliationSignatures">
        <div><strong>المنظم</strong><span contenteditable="true" data-br-sign="organizer"></span></div>
        <div><strong>المدقق</strong><span contenteditable="true" data-br-sign="auditor"></span></div>
        <div><strong>المحاسب</strong><span contenteditable="true" data-br-sign="accountant"></span></div>
        <div><strong>مدير الحسابات</strong><span contenteditable="true" data-br-sign="accountsManager"></span></div>
        <div><strong>مدير الدائرة</strong><span contenteditable="true" data-br-sign="director"></span></div>
    </div>
</section>

<script>
(() => {
  const rows = document.getElementById('bankStatementRows');
  const add = document.getElementById('bankAddRow');
  const makeRow = () => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td><input type="date" name="statement_date[]"></td>
      <td><input name="statement_reference[]"></td>
      <td><input name="statement_description[]"></td>
      <td><input class="num bank-side-input" inputmode="decimal" name="statement_deposit[]"></td>
      <td><input class="num bank-side-input" inputmode="decimal" name="statement_withdrawal[]"></td>
      <td class="bank-row-action"><button type="button" class="btn btn-sm btn-light bankRemoveRow" aria-label="حذف الصف">×</button></td>`;
    return tr;
  };
  add?.addEventListener('click', () => { rows?.appendChild(makeRow()); rows?.lastElementChild?.querySelector('input')?.focus(); });
  rows?.addEventListener('click', (event) => {
    const button = event.target.closest('.bankRemoveRow');
    if (!button) return;
    const tr = button.closest('tr');
    if (rows.children.length > 1) tr?.remove();
    else tr?.querySelectorAll('input').forEach(input => input.value = '');
  });
  rows?.addEventListener('input', (event) => {
    const input = event.target;
    if (!input.classList.contains('bank-side-input') || !input.value.trim()) return;
    const tr = input.closest('tr');
    if (!tr) return;
    const otherName = input.name === 'statement_deposit[]' ? 'statement_withdrawal[]' : 'statement_deposit[]';
    const other = tr.querySelector(`input[name="${otherName}"]`);
    if (other && other.value.trim()) other.value = '';
  });

  const sigRoot = document.getElementById('bankReconciliationSignatures');
  if (sigRoot) {
    const companyId = <?=json_encode((string)company_id(), JSON_UNESCAPED_UNICODE)?>;
    const key = `mizan.bank-reconciliation.signatures.v2791.${companyId}`;
    const fields = Array.from(sigRoot.querySelectorAll('[data-br-sign]'));
    let data = {};
    try { data = JSON.parse(localStorage.getItem(key) || '{}') || {}; } catch (_) {}
    fields.forEach(el => {
      el.textContent = data[el.dataset.brSign] || '';
      el.setAttribute('spellcheck','false');
      el.addEventListener('input', () => {
        const value = Object.fromEntries(fields.map(f => [f.dataset.brSign, f.textContent.trim()]));
        try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {}
      });
    });
  }
})();
</script>
<?php render_footer(); ?>
