<?php
declare(strict_types=1);
require_role('admin');

$appVersionFile = __DIR__ . '/../VERSION';
$appVersion = is_file($appVersionFile) ? trim((string)file_get_contents($appVersionFile)) : (string)app_config('version', 'غير معروف');
$prefixTypeCheck = normalize_account_prefixes(121) === ['121']
    && normalize_account_prefixes([121, '2641']) === ['121', '2641'];
$rowTypeCheck = gr_row('اختبار', 121, [0.0, 0.0, 0.0])['code'] === '121'
    && gr_row('اختبار', '2641', [0.0, 0.0, 0.0])['code'] === '2641';

$checks = [];
$checks['إصدار PHP'] = 'PHP ' . PHP_VERSION;
$checks['امتداد PDO MySQL'] = extension_loaded('pdo_mysql') ? 'فعال' : 'غير فعال';
$checks['الاتصال بقاعدة البيانات'] = db()->query('SELECT 1')->fetchColumn() == 1 ? 'ناجح' : 'فاشل';
$checks['إصدار قاعدة البيانات'] = (string)db()->query('SELECT VERSION()')->fetchColumn();
$checks['مخطط الإصدار 2.2'] = schema_is_current() ? 'محدّث' : 'يحتاج ترقية';
$checks['محرك التقارير المطابق للدليل'] = ($prefixTypeCheck && $rowTypeCheck) ? 'ناجح' : 'فاشل';
$guidePath = __DIR__ . '/../knowledge/guide_pages.json';
$pdfPath = __DIR__ . '/../knowledge/guide.pdf';
$guidePages = 0;
if (is_file($guidePath)) {
    try { $guidePages = (int)(json_decode((string)file_get_contents($guidePath), true, 512, JSON_THROW_ON_ERROR)['page_count'] ?? 0); } catch (Throwable) { $guidePages = 0; }
}
$checks['قاعدة معرفة المساعد الذكي'] = $guidePages === 65 ? 'ناجح — 65 صفحة' : 'فاشل';
$checks['ملف الدليل داخل المساعد'] = is_file($pdfPath) ? 'متوفر' : 'فاشل';
$checks['مجلد التخزين'] = is_writable(__DIR__ . '/../storage') ? 'قابل للكتابة' : 'غير قابل للكتابة';
$checks['مجلد النسخ الاحتياطية'] = is_writable(__DIR__ . '/../storage/backups') ? 'قابل للكتابة' : 'غير قابل للكتابة';

$stmt = db()->prepare('SELECT COUNT(*) FROM accounts WHERE company_id=?');
$stmt->execute([company_id()]);
$checks['عدد الحسابات'] = number_format((int)$stmt->fetchColumn());
$stmt = db()->prepare('SELECT COUNT(*) FROM standards_library');
$stmt->execute();
$checks['عدد المعايير المرجعية'] = number_format((int)$stmt->fetchColumn());
$stmt = db()->prepare('SELECT COUNT(*) FROM compliance_checklist WHERE company_id=?');
$stmt->execute([company_id()]);
$checks['بنود المطابقة'] = number_format((int)$stmt->fetchColumn());
$stmt = db()->prepare('SELECT COUNT(*) FROM journal_entries WHERE company_id=?');
$stmt->execute([company_id()]);
$checks['عدد المستندات'] = number_format((int)$stmt->fetchColumn());

render_header('فحص النظام', 'diagnostics');
page_heading('فحص سلامة النظام', 'تحقق تقني سريع من البيئة وقاعدة البيانات والتخزين ومحرك التقارير والمساعد الذكي.');
?>
<div class="grid grid-2">
    <div class="card">
        <h3 class="card-title">نتائج الفحص</h3>
        <?php foreach ($checks as $label => $value):
            $bad = str_contains($value, 'غير فعال')
                || str_contains($value, 'فاشل')
                || str_contains($value, 'يحتاج')
                || str_contains($value, 'غير قابل');
        ?>
            <div class="health-item">
                <span><?= e($label) ?></span>
                <strong class="<?= $bad ? 'health-bad' : 'health-ok' ?>"><?= e($value) ?></strong>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="card">
        <h3 class="card-title">معلومات التشغيل</h3>
        <div class="health-item"><span>اسم قاعدة البيانات</span><strong class="code"><?= e(app_config('db_name')) ?></strong></div>
        <div class="health-item"><span>الخادم والمنفذ</span><strong class="code"><?= e(app_config('db_host') . ':' . app_config('db_port')) ?></strong></div>
        <div class="health-item"><span>إصدار النظام</span><strong><?= e($appVersion) ?></strong></div>
        <div class="health-item"><span>المنطقة الزمنية</span><strong><?= e(date_default_timezone_get()) ?></strong></div>
        <div class="notice-box" style="margin-top:14px">
            عند ظهور مشكلة في PDO MySQL، فعّل <span class="code">extension=pdo_mysql</span> في ملف php.ini ثم أعد تشغيل Apache.
        </div>
    </div>
</div>
<?php render_footer(); ?>
