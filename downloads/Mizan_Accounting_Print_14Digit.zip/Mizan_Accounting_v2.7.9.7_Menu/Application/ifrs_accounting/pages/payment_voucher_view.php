<?php
/** @var array $entry */
$details = ['sheet_no'=>(string)($entry['reference_no'] ?? ''),'check_no'=>'','check_date'=>'','payee_name'=>'','recipient_name'=>''];
if (table_exists('voucher_details')) {
    $stmt = db()->prepare('SELECT sheet_no,check_no,check_date,payee_name,recipient_name FROM voucher_details WHERE journal_entry_id=?');
    $stmt->execute([(int)$entry['id']]);
    $stored = $stmt->fetch();
    if ($stored) $details = array_merge($details, $stored);
}
$lines = $entry['lines'] ?? [];
$totalDebit = 0.0;
$totalCredit = 0.0;
foreach ($lines as $line) {
    $totalDebit += (float)$line['debit'];
    $totalCredit += (float)$line['credit'];
}
$amount = max($totalDebit, $totalCredit);
$date = new DateTimeImmutable((string)$entry['entry_date']);
$checkDate = valid_date((string)($details['check_date'] ?? '')) ? new DateTimeImmutable((string)$details['check_date']) : null;
$codeLevel = static function(string $code): array {
    $n = strlen(preg_replace('/\D+/', '', $code) ?? '');
    return $n <= 3 ? [$code,'',''] : ($n === 4 ? ['', $code, ''] : ['', '', $code]);
};
$costDigits = static function(string $code): array {
    $digits = preg_replace('/\D+/', '', $code) ?: '';
    return str_split(str_pad(substr($digits, -5), 5, ' ', STR_PAD_LEFT));
};
$fmt = static fn(float $v): string => abs($v) < 0.0005 ? '' : number_format($v, (int)(company()['decimal_places'] ?? 0), '.', ',');
$isPayment = (string)$entry['source_type'] === 'payment';
$title = $isPayment ? 'مستند صرف' : 'سند قبض';
$payeeLabel = $isPayment ? 'المدفوع له:' : 'المستلم منه:';
$firstParty = '';
foreach ($lines as $line) {
    if (!empty($line['party_name'])) {
        $firstParty = (string)$line['party_name'];
        break;
    }
}
?>
<section class="official-payment-voucher" aria-label="<?=e($title)?>">
    <header class="opv-company"><?=e((string)(company()['name_ar'] ?? ''))?></header>
    <div class="opv-top-grid">
        <div class="opv-box opv-money-box">
            <div><strong>المبلغ:</strong> <span class="num"><?=e($fmt($amount))?></span></div>
            <div><strong>رقم الصك:</strong> <?=e((string)($details['check_no'] ?: '—'))?></div>
            <div><strong>تاريخ الصك:</strong> <?=e($checkDate ? doc_date($checkDate->format('Y-m-d')) : '—')?></div>
        </div>
        <div class="opv-center-head">
            <div class="opv-title"><?=e($title)?></div>
            <div class="opv-payee"><span><?=e($payeeLabel)?></span><strong><?=e((string)($details['payee_name'] ?: $firstParty ?: '—'))?></strong></div>
        </div>
        <div class="opv-box opv-document-box">
            <div><strong>اسم الدائرة:</strong> <?=e((string)(company()['name_ar'] ?? ''))?></div>
            <div><strong>رقم المستند:</strong> <?=e((string)$entry['voucher_no'])?></div>
            <div><strong>تاريخ المستند:</strong> <?=e(doc_date($date->format('Y-m-d')))?></div>
            <div><strong>رقم صحيفة السند:</strong> <?=e((string)($details['sheet_no'] ?: '—'))?></div>
        </div>
    </div>
    <div class="opv-table-wrap"><table class="opv-table">
        <colgroup><col class="opv-fils"><col class="opv-dinar"><col class="opv-fils"><col class="opv-dinar"><col class="opv-account"><col class="opv-guide"><col class="opv-guide"><col class="opv-guide"><col class="opv-cost"><col class="opv-cost"><col class="opv-cost"><col class="opv-cost"><col class="opv-cost"></colgroup>
        <thead><tr><th colspan="2">مبلغ المدين</th><th colspan="2">مبلغ الدائن</th><th rowspan="2">اسم الحساب وتفاصيله</th><th colspan="3">رقم الدليل المحاسبي</th><th colspan="5">مراكز الكلف</th></tr><tr><th>ف</th><th>د</th><th>ف</th><th>د</th><th>3</th><th>4</th><th>5</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th></tr></thead>
        <tbody>
        <?php foreach ($lines as $line): ?>
        <?php [$code3,$code4,$code5] = $codeLevel((string)$line['account_code']); $digits = $costDigits((string)($line['cost_center_code'] ?? '')); ?>
        <tr class="opv-account-row">
            <td></td><td class="num"><?=e($fmt((float)$line['debit']))?></td><td></td><td class="num"><?=e($fmt((float)$line['credit']))?></td>
            <td class="opv-account-cell"><div class="opv-account-print"><?=e((string)$line['account_name'])?></div><div><?=e((string)($line['line_description'] ?: $entry['description']))?></div></td>
            <td class="opv-code"><?=e($code3)?></td><td class="opv-code"><?=e($code4)?></td><td class="opv-code"><?=e($code5)?></td>
            <?php foreach($digits as $digit):?><td class="opv-cc-digit"><?=e(trim($digit))?></td><?php endforeach;?>
        </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot><tr class="opv-total-row"><td></td><td class="num"><?=e($fmt($totalDebit))?></td><td></td><td class="num"><?=e($fmt($totalCredit))?></td><td colspan="9"><?=e('المجموع '.arabic_amount_words($amount))?></td></tr></tfoot>
    </table></div>
    <div class="opv-signatures">
    <?php foreach ([
        'organizer' => ['المنظم', (string)($entry['creator_name'] ?? '')],
        'accountant' => ['المحاسب', ''],
        'auditor' => ['المدقق', ''],
        'accounts_manager' => ['مدير الحسابات', ''],
        'general_manager' => ['المدير العام', ''],
    ] as $sigKey => $sig): ?>
        <div><strong><?=e($sig[0])?></strong><input class="voucher-sign-input" value="<?=e((string)setting_get('voucher_sign_' . $sigKey, $sig[1]))?>" autocomplete="off" placeholder="الاسم"></div>
    <?php endforeach;?>
    </div>
    <div class="opv-receipt-ack"><div>إني الموقع أدناه استلمت من <span class="opv-line"></span></div><div>الصك المرقم <span class="opv-line"><?=e((string)($details['check_no'] ?? ''))?></span></div><div>اسم المستلم: <strong><?=e((string)($details['recipient_name'] ?: '—'))?></strong></div><div class="opv-receipt-sign">التوقيع: <span class="opv-line"></span></div></div>
</section>
<div class="small muted no-print" style="margin:14px auto;max-width:1120px">أنشئ في <?=e((string)$entry['created_at'])?><?php if($entry['posted_at']):?> • رُحّل في <?=e((string)$entry['posted_at'])?><?php endif;?></div>
