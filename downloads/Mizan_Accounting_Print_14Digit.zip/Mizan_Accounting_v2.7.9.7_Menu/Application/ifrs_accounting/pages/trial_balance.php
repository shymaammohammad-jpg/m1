<?php
declare(strict_types=1);
$monthNames = [
    1 => 'كانون الثاني',
    2 => 'شباط',
    3 => 'آذار',
    4 => 'نيسان',
    5 => 'أيار',
    6 => 'حزيران',
    7 => 'تموز',
    8 => 'آب',
    9 => 'أيلول',
    10 => 'تشرين الأول',
    11 => 'تشرين الثاني',
    12 => 'كانون الأول',
];

// توافق مع الروابط القديمة from/to: نشتق الشهر والسنة منها عند عدم تمرير month/year.
$legacyFrom = (string)($_GET['from'] ?? '');
$legacyTo = (string)($_GET['to'] ?? '');
$defaultYear = (int)date('Y');
$defaultMonth = (int)date('n');
$legacyDate = $legacyTo !== '' && valid_date($legacyTo) ? $legacyTo : ($legacyFrom !== '' && valid_date($legacyFrom) ? $legacyFrom : '');
if ($legacyDate !== '') {
    $legacyTs = strtotime($legacyDate);
    if ($legacyTs !== false) {
        $defaultYear = (int)date('Y', $legacyTs);
        $defaultMonth = (int)date('n', $legacyTs);
    }
}
$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : $defaultYear;
$selectedMonth = isset($_GET['month']) ? (int)$_GET['month'] : $defaultMonth;
if ($selectedYear < 2000 || $selectedYear > 2100) $selectedYear = (int)date('Y');
if ($selectedMonth < 1 || $selectedMonth > 12) $selectedMonth = (int)date('n');
$monthStart = new DateTimeImmutable(sprintf('%04d-%02d-01', $selectedYear, $selectedMonth));
$from = $monthStart->format('Y-m-d');
$to = $monthStart->modify('last day of this month')->format('Y-m-d');
$selectedMonthName = $monthNames[$selectedMonth];
$periodLabel = $selectedMonthName . ' ' . $selectedYear;

$yearStmt = db()->prepare('SELECT DISTINCT YEAR(entry_date) AS y FROM journal_entries WHERE company_id=? ORDER BY y DESC');
$yearStmt->execute([company_id()]);
$availableYears = [];
foreach ($yearStmt->fetchAll() as $yearRow) {
    $y = (int)($yearRow['y'] ?? 0);
    if ($y >= 2000 && $y <= 2100) $availableYears[$y] = true;
}
$availableYears[$selectedYear] = true;
$availableYears[(int)date('Y')] = true;
$availableYears = array_keys($availableYears);
rsort($availableYears, SORT_NUMERIC);

$closingState = (string)($_GET['closing_state'] ?? 'before');
if (!in_array($closingState, ['before','after'], true)) $closingState = 'before';

$closingFilter = '';
$closingFilterParams = [];
if ($closingState === 'before') {
    // نحافظ على قيود غلق السنوات السابقة ضمن الرصيد الافتتاحي، ونستبعد فقط آثار الغلق داخل الفترة المعروضة.
    $closingFilter = " AND NOT (je.entry_date BETWEEN ? AND ? AND (je.source_type='closing'"
        . " OR (je.source_type='reversal' AND EXISTS (SELECT 1 FROM journal_entries original_closing"
        . " WHERE original_closing.id=je.reversal_of AND original_closing.source_type='closing'))))";
    $closingFilterParams = [$from, $to];
}

$sql = "SELECT a.id,a.code,a.name_ar,a.normal_balance,
 SUM(CASE WHEN je.entry_date<? THEN jl.debit-jl.credit ELSE 0 END) opening_raw,
 SUM(CASE WHEN je.entry_date BETWEEN ? AND ? THEN jl.debit ELSE 0 END) movement_debit,
 SUM(CASE WHEN je.entry_date BETWEEN ? AND ? THEN jl.credit ELSE 0 END) movement_credit
 FROM accounts a LEFT JOIN journal_lines jl ON jl.account_id=a.id LEFT JOIN journal_entries je ON je.id=jl.journal_entry_id AND je.company_id=a.company_id AND ".posted_status_condition('je')." AND je.entry_date<=?".$closingFilter."
 WHERE a.company_id=? AND a.is_postable=1 GROUP BY a.id ORDER BY a.code";
$stmt=db()->prepare($sql);
$params = [$from,$from,$to,$from,$to,$to];
array_push($params, ...$closingFilterParams);
$params[] = company_id();
$stmt->execute($params);$rows=$stmt->fetchAll();

$hasPostedClosing = false;
$stmtClosing = db()->prepare("SELECT COUNT(*) FROM journal_entries WHERE company_id=? AND source_type='closing' AND status='posted' AND entry_date BETWEEN ? AND ?");
$stmtClosing->execute([company_id(), $from, $to]);
$hasPostedClosing = (int)$stmtClosing->fetchColumn() > 0;

$stateLabel = $closingState === 'after' ? 'بعد الغلق' : 'قبل الغلق';
$stateDescription = $closingState === 'after'
    ? 'يشمل قيد الغلق المرحّل وآثاره ضمن الشهر المحدد.'
    : 'يستبعد قيود الغلق وآثار عكسها لعرض أرصدة الحسابات قبل الغلق.';
$professionalPrintUrl = url('trial_balance', ['year'=>$selectedYear,'month'=>$selectedMonth,'closing_state'=>$closingState,'print_view'=>'1']);
render_header('ميزان المراجعة '.$stateLabel,'trial_balance');
page_heading('ميزان المراجعة '.$stateLabel, $stateDescription);
?>
<form class="filters no-print">
    <input type="hidden" name="page" value="trial_balance">
    <div class="field" style="min-width:170px"><label>الشهر</label><select name="month"><?php foreach ($monthNames as $monthNo => $monthName): ?><option value="<?=e((string)$monthNo)?>" <?=$selectedMonth === $monthNo ? 'selected' : ''?>><?=e($monthName)?></option><?php endforeach; ?></select></div>
    <div class="field" style="min-width:120px"><label>السنة</label><select name="year"><?php foreach ($availableYears as $year): ?><option value="<?=e((string)$year)?>" <?=$selectedYear === (int)$year ? 'selected' : ''?>><?=e((string)$year)?></option><?php endforeach; ?></select></div>
    <div class="field" style="min-width:220px"><label>حالة ميزان المراجعة</label><select name="closing_state">
        <option value="before" <?=$closingState==='before'?'selected':''?>>ميزان المراجعة قبل الغلق</option>
        <option value="after" <?=$closingState==='after'?'selected':''?>>ميزان المراجعة بعد الغلق</option>
    </select></div>
    <button class="btn btn-primary">عرض</button><a class="btn btn-primary" target="_blank" rel="noopener" href="<?=e($professionalPrintUrl)?>">طباعة احترافية</a><button type="button" class="btn btn-outline print-btn">طباعة سريعة</button>
</form>
<div class="trial-balance-state-tabs no-print">
    <a class="btn <?=$closingState==='before'?'btn-primary':'btn-outline'?>" href="<?=e(url('trial_balance',['year'=>$selectedYear,'month'=>$selectedMonth,'closing_state'=>'before']))?>">قبل الغلق</a>
    <a class="btn <?=$closingState==='after'?'btn-primary':'btn-outline'?>" href="<?=e(url('trial_balance',['year'=>$selectedYear,'month'=>$selectedMonth,'closing_state'=>'after']))?>">بعد الغلق</a>
</div>
<?php if ($closingState === 'after' && !$hasPostedClosing): ?>
<div class="alert alert-warning">لا يوجد قيد غلق مرحّل ضمن الشهر المحدد؛ لذلك ستتطابق أرقام «بعد الغلق» مع «قبل الغلق» إلى أن يتم إنشاء وترحيل قيد الغلق.</div>
<?php endif; ?>
<div class="card"><div class="report-head"><h2><?=e(company()['name_ar'])?></h2><h2>ميزان المراجعة <?=e($stateLabel)?></h2><p>شهر <?=e($selectedMonthName)?> / <?=e((string)$selectedYear)?></p><small><?=e($stateDescription)?></small></div><div class="table-wrap" style="box-shadow:none"><table class="data-table"><thead><tr><th rowspan="2">الرمز</th><th rowspan="2">الحساب</th><th colspan="2">الرصيد الافتتاحي</th><th colspan="2">حركة الشهر</th><th colspan="2">الرصيد الختامي</th></tr><tr><th>مدين</th><th>دائن</th><th>مدين</th><th>دائن</th><th>مدين</th><th>دائن</th></tr></thead><tbody>
<?php $od=$oc=$md=$mc=$cd=$cc=0.0;foreach($rows as $r):$opening=(float)$r['opening_raw'];$movementD=(float)$r['movement_debit'];$movementC=(float)$r['movement_credit'];$closing=$opening+$movementD-$movementC;if(abs($opening)+abs($movementD)+abs($movementC)<.0005)continue;$opD=max($opening,0);$opC=max(-$opening,0);$clD=max($closing,0);$clC=max(-$closing,0);$od+=$opD;$oc+=$opC;$md+=$movementD;$mc+=$movementC;$cd+=$clD;$cc+=$clC;?><tr><td class="code"><?=e($r['code'])?></td><td><?=e($r['name_ar'])?></td><td class="num"><?=money($opD)?></td><td class="num"><?=money($opC)?></td><td class="num"><?=money($movementD)?></td><td class="num"><?=money($movementC)?></td><td class="num"><?=money($clD)?></td><td class="num"><?=money($clC)?></td></tr><?php endforeach;?><tr class="grand-total"><td colspan="2">الإجمالي</td><td class="num"><?=money($od)?></td><td class="num"><?=money($oc)?></td><td class="num"><?=money($md)?></td><td class="num"><?=money($mc)?></td><td class="num"><?=money($cd)?></td><td class="num"><?=money($cc)?></td></tr></tbody></table></div><div class="notice-box" style="margin-top:14px">الحالة: <strong><?=e($stateLabel)?></strong> • فرق الحركة: <?=money($md-$mc)?> • فرق الرصيد الختامي: <?=money($cd-$cc)?></div></div>
<div class="programmer-print">المبرمج: م. أرشد حميد حسن • واتساب: 07735882844</div><?php render_footer(); ?>
