<?php
declare(strict_types=1);
$q=trim((string)($_GET['q']??''));$type=(string)($_GET['type']??'');$edit=null;
if(isset($_GET['edit'])){$stmt=db()->prepare('SELECT * FROM accounts WHERE id=? AND company_id=?');$stmt->execute([(int)$_GET['edit'],company_id()]);$edit=$stmt->fetch()?:null;}
$sql='SELECT * FROM accounts WHERE company_id=?';$params=[company_id()];
if($q!==''){$sql.=' AND (code LIKE ? OR name_ar LIKE ?)';$params[]='%'.$q.'%';$params[]='%'.$q.'%';}
if(in_array($type,['asset','contra_asset','liability','equity','revenue','expense','oci','off_balance'],true)){$sql.=' AND account_type=?';$params[]=$type;}
$sql.=' ORDER BY code LIMIT 2500';$stmt=db()->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();
$stmt=db()->prepare('SELECT id,code,name_ar,level_no FROM accounts WHERE company_id=? ORDER BY code');$stmt->execute([company_id()]);$parents=$stmt->fetchAll();
$types=['asset'=>'أصل','contra_asset'=>'مقابل أصل','liability'=>'التزام','equity'=>'حقوق ملكية','revenue'=>'إيراد','expense'=>'مصروف','oci'=>'دخل شامل آخر','off_balance'=>'حساب نظامي'];
render_header('دليل الحسابات','accounts');page_heading('دليل الحسابات الموحد','هيكل هرمي مستورد من الدليل، مع إمكانية إضافة الحسابات التحليلية وتحديد تصنيف التدفق النقدي.');
?>
<?php if(in_array(user()['role'],['admin','accountant'],true)):?>
<form method="post" class="card" style="margin-bottom:18px">
<input type="hidden" name="action" value="account_save"><input type="hidden" name="id" value="<?=e($edit['id']??'')?>"><?=csrf_field()?>
<h3 class="card-title"><?=$edit?'تعديل الحساب':'إضافة حساب تحليلي جديد'?></h3>
<div class="form-grid">
 <div class="field col-2"><label>رمز الحساب</label><input name="code" value="<?=e($edit['code']??'')?>" required></div>
 <div class="field col-4"><label>اسم الحساب</label><input name="name_ar" value="<?=e($edit['name_ar']??'')?>" required></div>
 <div class="field col-3"><label>الحساب الأب</label><select name="parent_id"><option value="">— حساب رئيسي —</option><?php foreach($parents as $p):if($edit&&(int)$p['id']===(int)$edit['id'])continue;?><option value="<?=$p['id']?>" <?=($edit['parent_id']??'')==$p['id']?'selected':''?>><?=e($p['code'].' — '.$p['name_ar'])?></option><?php endforeach;?></select></div>
 <div class="field col-3"><label>النوع</label><select name="account_type"><?php foreach($types as $k=>$v):?><option value="<?=$k?>" <?=($edit['account_type']??'asset')===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></div>
 <div class="field col-2"><label>الطبيعة</label><select name="normal_balance"><option value="debit" <?=($edit['normal_balance']??'debit')==='debit'?'selected':''?>>مدين</option><option value="credit" <?=($edit['normal_balance']??'')==='credit'?'selected':''?>>دائن</option></select></div>
 <div class="field col-3"><label>قسم القائمة المالية</label><input name="statement_section" value="<?=e($edit['statement_section']??'other')?>"></div>
 <div class="field col-3"><label>تصنيف التدفق النقدي</label><select name="cash_flow_category"><?php foreach(['none'=>'لا ينطبق','operating'=>'تشغيلي','investing'=>'استثماري','financing'=>'تمويلي'] as $k=>$v):?><option value="<?=$k?>" <?=($edit['cash_flow_category']??'operating')===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></div>
 <div class="field col-4"><label>الخصائص</label><div class="switch-line"><label><input type="checkbox" name="is_postable" <?=($edit['is_postable']??1)?'checked':''?>> قابل للترحيل</label><label><input type="checkbox" name="is_cash_account" <?=($edit['is_cash_account']??0)?'checked':''?>> نقدي</label><label><input type="checkbox" name="is_active" <?=($edit['is_active']??1)?'checked':''?>> فعال</label></div></div>
</div><div class="form-actions"><button class="btn btn-primary">حفظ الحساب</button><?php if($edit):?><a class="btn btn-light" href="<?=e(url('accounts'))?>">إلغاء</a><?php endif;?></div>
</form>
<?php endif;?>
<form class="filters"><input type="hidden" name="page" value="accounts"><div class="field"><label>بحث</label><input name="q" value="<?=e($q)?>" placeholder="الرمز أو الاسم"></div><div class="field"><label>نوع الحساب</label><select name="type"><option value="">الكل</option><?php foreach($types as $k=>$v):?><option value="<?=$k?>" <?=$type===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></div><button class="btn btn-primary">تطبيق</button><a class="btn btn-light" href="<?=e(url('accounts'))?>">إلغاء التصفية</a></form>
<div class="table-wrap"><table class="data-table"><thead><tr><th>الرمز</th><th>اسم الحساب</th><th>النوع</th><th>الطبيعة</th><th>قابل للترحيل</th><th>نقدي</th><th>الحالة</th><th class="no-print">الإجراءات</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td><span class="code"><?=e($r['code'])?></span></td><td class="indent-<?=min(7,(int)$r['level_no'])?> <?=$r['is_postable']?'':'account-parent'?>"><?=e($r['name_ar'])?></td><td><?=e($types[$r['account_type']]??$r['account_type'])?></td><td><?=$r['normal_balance']==='debit'?'مدين':'دائن'?></td><td><?=$r['is_postable']?'نعم':'لا'?></td><td><?=$r['is_cash_account']?'نعم':'لا'?></td><td><?=$r['is_active']?'<span class="positive">فعال</span>':'<span class="negative">موقوف</span>'?></td><td class="no-print"><div class="row-actions"><?php if(in_array(user()['role'],['admin','accountant'],true)):?><a class="btn btn-sm btn-light" href="<?=e(url('accounts',['edit'=>$r['id']]))?>">تعديل</a><?php endif;?><?php if(user()['role']==='admin'):?><form method="post"><input type="hidden" name="action" value="account_delete"><input type="hidden" name="id" value="<?=$r['id']?>"><?=csrf_field()?><button class="btn btn-sm btn-danger" data-confirm="حذف الحساب نهائياً؟">حذف</button></form><?php endif;?></div></td></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="8" class="empty">لا توجد حسابات مطابقة.</td></tr><?php endif;?></tbody></table></div>
<?php render_footer(); ?>
