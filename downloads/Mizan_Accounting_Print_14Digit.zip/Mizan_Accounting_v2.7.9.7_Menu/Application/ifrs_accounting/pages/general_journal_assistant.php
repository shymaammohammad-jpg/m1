<?php
declare(strict_types=1);
require_role(['admin','accountant','viewer']);

$from = (string)($_GET['from'] ?? date('Y-01-01'));
$to = (string)($_GET['to'] ?? date('Y-m-d'));
$status = (string)($_GET['status'] ?? 'posted');
$showAllAccounts = (string)($_GET['show_all_accounts'] ?? '0') === '1';
if (!valid_date($from) || !valid_date($to) || $from > $to) {
    throw new RuntimeException('نطاق التاريخ غير صالح.');
}
if (!in_array($status, ['posted','all'], true)) $status = 'posted';

$statusSql = $status === 'posted' ? " AND je.status IN ('posted','reversed')" : '';
$stmt = db()->prepare(
    "SELECT je.id,je.voucher_no,je.entry_date,je.reference_no,je.description,je.source_type,je.status,
            COALESCE(SUM(jl.debit),0) total_debit,COALESCE(SUM(jl.credit),0) total_credit
     FROM journal_entries je
     JOIN journal_lines jl ON jl.journal_entry_id=je.id
     WHERE je.company_id=? AND je.entry_date BETWEEN ? AND ?{$statusSql}
     GROUP BY je.id
     ORDER BY je.entry_date,je.id"
);
$stmt->execute([company_id(), $from, $to]);
$entries = $stmt->fetchAll();
$entryIds = array_map(static fn(array $entry): int => (int)$entry['id'], $entries);

$linesByEntry = [];
$accountTotals = [];
$usedAccountIds = [];
if ($entryIds !== []) {
    $placeholders = implode(',', array_fill(0, count($entryIds), '?'));
    $stmt = db()->prepare(
        "SELECT jl.journal_entry_id,jl.account_id,a.code,a.name_ar,
                SUM(jl.debit) debit,SUM(jl.credit) credit
         FROM journal_lines jl
         JOIN accounts a ON a.id=jl.account_id
         WHERE jl.journal_entry_id IN ({$placeholders})
         GROUP BY jl.journal_entry_id,jl.account_id,a.code,a.name_ar
         ORDER BY a.code"
    );
    $stmt->execute($entryIds);
    foreach ($stmt->fetchAll() as $row) {
        $entryId = (int)$row['journal_entry_id'];
        $accountId = (int)$row['account_id'];
        $linesByEntry[$entryId][$accountId] = ['debit'=>(float)$row['debit'],'credit'=>(float)$row['credit']];
        $usedAccountIds[$accountId] = true;
        if (!isset($accountTotals[$accountId])) $accountTotals[$accountId] = ['debit'=>0.0,'credit'=>0.0];
        $accountTotals[$accountId]['debit'] += (float)$row['debit'];
        $accountTotals[$accountId]['credit'] += (float)$row['credit'];
    }
}

$accountSql = 'SELECT id,code,name_ar FROM accounts WHERE company_id=? AND is_active=1 AND is_postable=1';
$params = [company_id()];
if (!$showAllAccounts) {
    if ($usedAccountIds === []) {
        $accountSql .= ' AND 1=0';
    } else {
        $accountSql .= ' AND id IN ('.implode(',', array_fill(0,count($usedAccountIds),'?')).')';
        array_push($params, ...array_keys($usedAccountIds));
    }
}
$accountSql .= ' ORDER BY code';
$stmt = db()->prepare($accountSql);
$stmt->execute($params);
$accounts = $stmt->fetchAll();

function assistant_journal_number(float $amount): string
{
    if (abs($amount) < 0.0005) return '';
    $decimals = (int)(company()['decimal_places'] ?? 0);
    return number_format($amount, max(0,min(3,$decimals)), '.', '');
}

function assistant_journal_document_number(array $entry): string
{
    $reference = trim((string)($entry['reference_no'] ?? ''));
    if ($reference !== '') return $reference;
    $voucher = (string)($entry['voucher_no'] ?? '');
    if (preg_match('/(\d+)$/', $voucher, $match)) return (string)((int)$match[1]);
    return $voucher;
}

function assistant_journal_document_type(string $source): string
{
    return in_array($source, ['manual','opening','adjustment','closing','reversal'], true) ? 'قيد' : source_label($source);
}

function assistant_journal_date_display(string $date): string
{
    $time = strtotime($date);
    return $time ? doc_date($date) : $date;
}

$GLOBALS['fixed_print_template'] = 'assistant-journal';
render_header('اليومية العامة المساعد', 'general_journal_assistant');
page_heading('اليومية العامة المساعد', 'سجل إضافي مطابق لبنية ملف اليومية العامة المرفق، مع الكتابة العمودية وأعمدة مدين ودائن لكل حساب.');
?>
<form class="filters no-print">
    <input type="hidden" name="page" value="general_journal_assistant">
    <div class="field"><label>من</label><input type="date" name="from" value="<?=e($from)?>"></div>
    <div class="field"><label>إلى</label><input type="date" name="to" value="<?=e($to)?>"></div>
    <div class="field" style="min-width:180px"><label>حالة القيود</label><select name="status"><option value="posted" <?=$status==='posted'?'selected':''?>>القيود المرحلة فقط</option><option value="all" <?=$status==='all'?'selected':''?>>جميع القيود</option></select></div>
    <label class="check-inline"><input type="checkbox" name="show_all_accounts" value="1" <?=$showAllAccounts?'checked':''?>> إظهار الحسابات بلا حركة</label>
    <button class="btn btn-primary">عرض</button>
    <button type="button" class="btn btn-outline print-btn">طباعة</button>
    <button type="button" class="btn btn-outline excel-export-btn">تصدير Excel</button>
</form>

<div class="card assistant-journal-card wide-report">
<section class="assistant-journal-sheet" aria-label="اليومية العامة المساعد">
    <header class="assistant-journal-company"><?=e((string)(company()['name_ar'] ?? ''))?></header>
    <div class="assistant-journal-title">اليومية العامة / <?=e(date('Y', strtotime($to)))?></div>
    <div class="assistant-journal-date-range report-date-range">من تاريخ <bdi dir="rtl"><?=e(assistant_journal_date_display($from))?></bdi> إلى تاريخ <bdi dir="rtl"><?=e(assistant_journal_date_display($to))?></bdi></div>
    <div class="assistant-journal-scroll">
    <table class="assistant-journal-table">
        <thead>
            <tr>
                <th colspan="3" class="aj-document-group">المستند</th>
                <th rowspan="2" class="aj-diff"></th>
                <th rowspan="2" class="aj-description"><div class="excel-vertical">البيان</div></th>
                <th colspan="2" class="aj-transaction">مبلغ المعاملة</th>
                <?php foreach ($accounts as $account): ?>
                    <th colspan="2" class="aj-account-head">حـ/<?=e((string)$account['code'])?></th>
                <?php endforeach; ?>
            </tr>
            <tr>
                <th class="aj-date"><div class="excel-vertical">تاريخه</div></th>
                <th class="aj-doc-no"><div class="excel-vertical">رقمه</div></th>
                <th class="aj-doc-type"><div class="excel-vertical">نوعه</div></th>
                <th class="aj-side"><div class="excel-vertical">مدين</div></th>
                <th class="aj-side"><div class="excel-vertical">دائن</div></th>
                <?php foreach ($accounts as $account): ?>
                    <th class="aj-side"><div class="excel-vertical">مدين</div></th>
                    <th class="aj-side"><div class="excel-vertical">دائن</div></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
        <?php if ($entries === []): ?>
            <tr><td colspan="<?=e((string)(7+count($accounts)*2))?>" class="empty">لا توجد قيود ضمن المدة المحددة.</td></tr>
        <?php else: ?>
            <?php foreach ($entries as $entry):
                $entryId = (int)$entry['id'];
                $totalDebit = (float)$entry['total_debit'];
                $totalCredit = (float)$entry['total_credit'];
                $difference = $totalDebit - $totalCredit;
            ?>
            <tr>
                <td class="aj-date"><div class="excel-vertical-number"><?=e(date('j/n/y', strtotime((string)$entry['entry_date'])))?></div></td>
                <td class="aj-doc-no"><div class="excel-vertical-number"><?=e(assistant_journal_document_number($entry))?></div></td>
                <td class="aj-doc-type"><div class="excel-vertical"><?=e(assistant_journal_document_type((string)$entry['source_type']))?></div></td>
                <td class="aj-diff"><div class="excel-vertical-number"><?=e(assistant_journal_number($difference))?></div></td>
                <td class="aj-description"><div class="excel-vertical"><?=e((string)$entry['description'])?></div></td>
                <td class="aj-side"><div class="excel-vertical-number"><?=e(assistant_journal_number($totalDebit))?></div></td>
                <td class="aj-side"><div class="excel-vertical-number"><?=e(assistant_journal_number($totalCredit))?></div></td>
                <?php foreach ($accounts as $account):
                    $movement = $linesByEntry[$entryId][(int)$account['id']] ?? ['debit'=>0.0,'credit'=>0.0];
                ?>
                    <td class="aj-side"><div class="excel-vertical-number"><?=e(assistant_journal_number((float)$movement['debit']))?></div></td>
                    <td class="aj-side"><div class="excel-vertical-number"><?=e(assistant_journal_number((float)$movement['credit']))?></div></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
        <?php if ($entries !== []):
            $grandDebit = array_sum(array_map(static fn(array $entry): float => (float)$entry['total_debit'], $entries));
            $grandCredit = array_sum(array_map(static fn(array $entry): float => (float)$entry['total_credit'], $entries));
        ?>
        <tfoot><tr class="aj-total-row">
            <td colspan="5"><div class="excel-vertical">المجموع</div></td>
            <td><div class="excel-vertical-number"><?=e(assistant_journal_number($grandDebit))?></div></td>
            <td><div class="excel-vertical-number"><?=e(assistant_journal_number($grandCredit))?></div></td>
            <?php foreach ($accounts as $account): $totals=$accountTotals[(int)$account['id']]??['debit'=>0.0,'credit'=>0.0]; ?>
                <td><div class="excel-vertical-number"><?=e(assistant_journal_number((float)$totals['debit']))?></div></td>
                <td><div class="excel-vertical-number"><?=e(assistant_journal_number((float)$totals['credit']))?></div></td>
            <?php endforeach; ?>
        </tr></tfoot>
        <?php endif; ?>
    </table>
    </div>
</section>
</div>
<?php render_footer(); ?>
