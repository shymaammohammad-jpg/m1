<?php
declare(strict_types=1);
$id = (int)($_GET['id'] ?? 0);
$entry = journal_snapshot($id);
if (!$entry) throw new RuntimeException('المستند غير موجود.');
$totalDebit = 0.0;
$totalCredit = 0.0;
$accountIds = [];
foreach ($entry['lines'] as $line) {
    $totalDebit += (float)$line['debit'];
    $totalCredit += (float)$line['credit'];
    $accountIds[] = (int)$line['account_id'];
}
$accountInfo = [];
if ($accountIds !== []) {
    $placeholders = implode(',', array_fill(0, count($accountIds), '?'));
    $stmt = db()->prepare("SELECT a.id,a.code,a.name_ar,a.level_no,p.code parent_code,p.name_ar parent_name FROM accounts a LEFT JOIN accounts p ON p.id=a.parent_id WHERE a.company_id=? AND a.id IN ($placeholders)");
    $stmt->execute(array_merge([company_id()], $accountIds));
    foreach ($stmt->fetchAll() as $row) $accountInfo[(int)$row['id']] = $row;
}
$displayLines = $entry['lines'];
$codeCells = static function (string $code): array {
    $length = strlen(preg_replace('/\D+/', '', $code) ?? '');
    if ($length <= 3) return [$code, '', ''];
    if ($length === 4) return ['', $code, ''];
    return ['', '', $code];
};
$ccCells = static function (string $code): array {
    $cells = ['', '', '', '', ''];
    $digits = preg_replace('/\D+/', '', $code) ?? '';
    if ($digits === '') return $cells;
    $cells[max(5, min(9, strlen($digits))) - 5] = $code;
    return $cells;
};
$splitAmount = static function ($value): array {
    $value = (float)$value;
    if ($value <= 0) return ['', ''];
    $dinars = (int)floor($value);
    $fils = (int)round(($value - $dinars) * 1000);
    return [number_format((float)$dinars, 0, '.', ','), $fils > 0 ? str_pad((string)$fils, 3, '0', STR_PAD_LEFT) : ''];
};
$ccCodeById = [];
foreach (cost_center_options() as $cc) $ccCodeById[(int)$cc['id']] = (string)$cc['code'];
$editUrl = in_array($entry['source_type'], ['receipt','payment'], true) ? url('cash_voucher', ['id'=>$id]) : url('journal_new', ['id'=>$id]);
$GLOBALS['fixed_print_template'] = (string)$entry['source_type'] === 'payment' ? 'payment-voucher' : 'journal-voucher';
render_header('عرض المستند', 'journal_list');
ob_start();
?>
<button class="btn btn-outline print-btn" type="button">طباعة</button>
<?php $approvalRequired = setting_get('posting_requires_approval','0') === '1'; ?>
<?php if($entry['status']==='draft' && $approvalRequired && user()['role']==='accountant' && $entry['approval_status']!=='pending' && $entry['approval_status']!=='approved'):?><form method="post"><input type="hidden" name="action" value="journal_submit_approval"><input type="hidden" name="id" value="<?=$id?>"><?=csrf_field()?><button class="btn btn-info">إرسال للاعتماد</button></form><?php endif;?>
<?php if($entry['status']==='draft' && user()['role']==='admin' && $entry['approval_status']==='pending'):?><form method="post" class="inline-form"><input type="hidden" name="action" value="journal_approve"><input type="hidden" name="id" value="<?=$id?>"><?=csrf_field()?><input name="approval_notes" placeholder="ملاحظات الاعتماد"><button class="btn btn-success" name="decision" value="approved">اعتماد</button><button class="btn btn-danger" name="decision" value="rejected">رفض</button></form><?php endif;?>
<?php if(in_array(user()['role'],['admin','accountant'],true)&&$entry['status']==='draft'):?><a class="btn btn-light" href="<?=e($editUrl)?>">تعديل</a><form method="post"><input type="hidden" name="action" value="journal_post"><input type="hidden" name="id" value="<?=$id?>"><?=csrf_field()?><button class="btn btn-success" data-confirm="ترحيل المستند وإدراجه في التقارير؟">ترحيل</button></form><?php endif;?>
<?php if(in_array(user()['role'],['admin','accountant'],true)&&$entry['status']==='posted'&&$entry['source_type']!=='reversal'):?><form method="post"><input type="hidden" name="action" value="journal_unpost"><input type="hidden" name="id" value="<?=$id?>"><input type="hidden" name="edit_after" value="0"><?=csrf_field()?><button class="btn btn-warning" data-confirm="إلغاء الترحيل سيستبعد المستند من التقارير إلى أن يعاد ترحيله. متابعة؟">إلغاء الترحيل</button></form><form method="post"><input type="hidden" name="action" value="journal_unpost"><input type="hidden" name="id" value="<?=$id?>"><input type="hidden" name="edit_after" value="1"><?=csrf_field()?><button class="btn btn-light" data-confirm="إلغاء الترحيل وفتح شاشة التعديل؟">إلغاء الترحيل والتعديل</button></form><?php endif;?>
<?php if(in_array(user()['role'],['admin','accountant'],true)&&$entry['status']==='posted'):?><form method="post" class="inline-form"><input type="hidden" name="action" value="journal_reverse"><input type="hidden" name="id" value="<?=$id?>"><?=csrf_field()?><div class="field"><label>تاريخ العكس</label><input type="date" name="reversal_date" value="<?=date('Y-m-d')?>" required></div><button class="btn btn-danger" data-confirm="إنشاء قيد عكسي مرحل؟">عكس المستند</button></form><?php endif;?>
<?php if(in_array(user()['role'],['admin','accountant'],true)):?><form method="post"><input type="hidden" name="action" value="journal_delete"><input type="hidden" name="id" value="<?=$id?>"><?=csrf_field()?><button class="btn btn-danger" data-confirm="حذف نهائي من النظام؟ سيختفي المستند من جميع السجلات والتقارير ولوحة المؤشرات، كما سيزال أثره من تسلسل الأرقام ويعاد احتساب الرقم التالي فعلياً. لا يمكن التراجع عن الحذف.">حذف نهائي</button></form><?php endif;?>
<?php
$actions = ob_get_clean();
page_heading((string)$entry['voucher_no'], source_label((string)$entry['source_type']).' • '.status_label((string)$entry['status']), $actions);
$date = new DateTimeImmutable((string)$entry['entry_date']);
?>
<div class="document-status-strip no-print">
    <span>الحالة: <?=status_badge((string)$entry['status'])?></span>
    <span>المرجع: <?=e((string)($entry['reference_no'] ?: '—'))?></span>
    <span>المعيار: <?=e((string)($entry['origin_standard'] ?: 'عام'))?></span>
    <span>الإصدار الداخلي: <?=e((string)$entry['version_no'])?></span>
</div>

<?php if ((string)$entry['source_type'] === 'payment') {
    require __DIR__ . '/payment_voucher_view.php';
    render_footer();
    return;
} ?>

<section class="excel-voucher-sheet" aria-label="سند قيد">
    <div class="excel-voucher-top">
        <div class="excel-voucher-cash-box"><div>رقم سند الصرف</div><div>أو القبض</div><div>التاريخ:</div></div>
        <div class="excel-voucher-title">سند قيد</div>
        <div class="excel-voucher-dept-box">
            <div><span>أسم الدائرة:</span><strong><?=e((string)(company()['name_ar'] ?? ''))?></strong></div>
            <div><span>الرقم:</span><strong><?=e((string)$entry['voucher_no'])?></strong></div>
            <div><span>التاريخ:</span><strong><?=e(doc_date((string)$entry['entry_date']))?></strong></div>
            <div><span>رقم صفحة اليومية:</span><strong></strong></div>
        </div>
    </div>
    <div class="excel-voucher-table-wrap">
        <table class="excel-voucher-table">
            <colgroup><col class="voucher-col-fils"><col class="voucher-col-dinar"><col class="voucher-col-fils"><col class="voucher-col-dinar"><col class="voucher-col-statement"><col class="voucher-col-code"><col class="voucher-col-code"><col class="voucher-col-code"><col class="voucher-col-cc"><col class="voucher-col-cc"><col class="voucher-col-cc"><col class="voucher-col-cc"><col class="voucher-col-cc"></colgroup>
            <thead><tr><th colspan="2">المدين</th><th colspan="2">الدائن</th><th rowspan="2">البيان</th><th colspan="3">رقم الدليل المحاسبي</th><th colspan="5">مراكز الكلف</th></tr><tr><th>ف</th><th>د</th><th>ف</th><th>د</th><th>٣</th><th>٤</th><th>٥</th><th>٥</th><th>٦</th><th>٧</th><th>٨</th><th>٩</th></tr></thead>
            <tbody>
            <?php foreach($displayLines as $line):
                    $info = $accountInfo[(int)$line['account_id']] ?? ['code'=>$line['account_code'],'name_ar'=>$line['account_name'],'parent_code'=>'','parent_name'=>''];
                    [$d3,$d4,$d5] = $codeCells((string)$info['code']);
                    $ccParts = $ccCells($ccCodeById[(int)($line['cost_center_id'] ?? 0)] ?? '');
                    [$debitDinar,$debitFils] = $splitAmount($line['debit']);
                    [$creditDinar,$creditFils] = $splitAmount($line['credit']);
                    $side = (float)$line['debit'] > 0 ? 'من ح/ ' : ((float)$line['credit'] > 0 ? 'الى ح/ ' : '');
                ?>
                    <tr>
                        <td class="voucher-fils-cell"><?=e($debitFils)?></td><td class="num"><?=e($debitDinar)?></td>
                        <td class="voucher-fils-cell"><?=e($creditFils)?></td><td class="num"><?=e($creditDinar)?></td>
                        <td class="voucher-statement-cell"><div class="voucher-statement-print"><span class="voucher-line-side"><?=e($side)?></span><span class="voucher-account-print-name"><?=e((string)$info['name_ar'])?></span></div></td>
                        <td class="voucher-detail-code"><?=e($d3)?></td><td class="voucher-detail-code"><?=e($d4)?></td><td class="voucher-detail-code"><?=e($d5)?></td>
                        <?php foreach($ccParts as $ccPart):?><td class="voucher-cc-code"><?=e($ccPart)?></td><?php endforeach;?>
                    </tr>
            <?php endforeach;?>
            </tbody>
            <tfoot>
                <tr class="voucher-description-row"><td></td><td></td><td></td><td></td><td colspan="9"><?=e((string)$entry['description'])?></td></tr>
                <?php [$td,$tdf] = $splitAmount($totalDebit); [$tc,$tcf] = $splitAmount($totalCredit); ?>
                <tr class="voucher-words-row"><td class="voucher-fils-total"><?=e($tdf)?></td><td class="num"><?=e($td !== '' ? $td : '0')?></td><td class="voucher-fils-total"><?=e($tcf)?></td><td class="num"><?=e($tc !== '' ? $tc : '0')?></td><td colspan="9"><span class="voucher-total-label">المجموع</span> <?=e(arabic_amount_words($totalDebit))?></td></tr>
            </tfoot>
        </table>
    </div>
    <div class="excel-voucher-signatures">
    <?php foreach ([
        'organizer' => ['المنظم', (string)($entry['creator_name'] ?? '')],
        'auditor' => ['المدقق', ''],
        'accounts_manager' => ['مدير الحسابات', ''],
        'department_head' => ['رئيس الدائرة', ''],
    ] as $sigKey => $sig): ?>
        <div><strong><?=e($sig[0])?></strong><input class="voucher-sign-input" value="<?=e((string)setting_get('voucher_sign_' . $sigKey, $sig[1]))?>" autocomplete="off" placeholder="الاسم"></div>
    <?php endforeach;?>
    </div>
</section>
<div class="small muted no-print" style="margin:14px auto;max-width:930px">أنشئ في <?=e(doc_date((string)$entry['created_at']).' '.date('H:i', strtotime((string)$entry['created_at'])))?><?php if($entry['posted_at']):?> • رُحّل في <?=e((string)$entry['posted_at'])?><?php endif;?><?php if($entry['unposted_at']):?> • آخر إلغاء ترحيل في <?=e((string)$entry['unposted_at'])?><?php endif;?></div>
<?php render_footer(); ?>
