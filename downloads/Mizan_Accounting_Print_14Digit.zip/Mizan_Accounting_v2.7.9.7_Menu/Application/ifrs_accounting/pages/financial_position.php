<?php
declare(strict_types=1);
$to=(string)($_GET['to']??date('Y-m-d'));
if(!valid_date($to)) throw new RuntimeException('تاريخ قائمة المركز المالي غير صالح.');
$period=fiscal_period_for($to);
$from=(string)($period['start_date']??date('Y-01-01'));
$ctx=reporting_context($from,$to);
$report=gr_financial_position_rows($ctx);
$rows=$report['rows'];$c=company();
render_header('قائمة المركز المالي وفق الدليل','financial_position');
page_heading('قائمة المركز المالي (الميزانية العامة)','نموذج الدليل الرسمي: السنة الحالية، السنة السابقة، وبداية السنة السابقة، مع مجاميع صافية غير شاملة للحسابات التنظيمية والمتقابلة.');
?>
<form class="filters no-print"><input type="hidden" name="page" value="financial_position"><div class="field"><label>كما في</label><input type="date" name="to" value="<?=e($to)?>"></div><button class="btn btn-primary">عرض</button><a class="btn btn-outline" href="<?=e(url('report_settings',['period_end'=>$to]))?>">إعدادات المطابقة</a><button type="button" class="btn btn-outline print-btn">طباعة</button></form>
<div class="card report-card exact-guide-report"><div class="report-head"><div><?=e($c['ministry_name_ar']??'جمهورية العراق')?></div><div><?=e($c['formation_name_ar']??'')?></div><h2><?=e($c['name_ar'])?></h2><h2>قائمة المركز المالي (الميزانية العامة) كما في <?=e(doc_date($to))?></h2><p>وحدة القياس: <?=e($c['rounding_level']??$c['currency_name_ar'])?></p></div>
<div class="table-wrap"><table class="data-table guide-table exact-statement-table"><thead><tr><th>رقم الكشف</th><th>رقم الدليل المحاسبي</th><th>اسم الحساب</th><th>السنة الحالية<br><?=e(doc_date($ctx['to']))?></th><th>السنة السابقة<br><?=e(doc_date($ctx['prior_to']))?></th><th>بداية السنة السابقة<br><?=e(doc_date($ctx['beginning_prior']))?></th></tr></thead><tbody>
<?php $n=0;foreach($rows as $r):$vals=$r['values'];$class='guide-'.$r['kind'];?>
<tr class="<?=e($class)?>"><td><?=in_array($r['kind'],['detail','deduction'],true)?++$n:''?></td><td class="code"><?=e($r['code'])?></td><td><?=e($r['label'])?><?php if($r['source_code']!==''&&$r['source_code']!==$r['code']):?><small class="source-hint no-print">مصدر الحساب: <?=e($r['source_code'])?></small><?php endif;?><?php if($r['formula']!==''):?><small class="formula-hint no-print"><?=e($r['formula'])?></small><?php endif;?></td><?php if($vals===null):?><td colspan="3"></td><?php else:foreach($vals as $v):?><td class="num"><?=gr_report_money($v)?></td><?php endforeach;endif;?></tr>
<?php endforeach;?></tbody></table></div>
<div class="statement-validation no-print"><h3>فحص المعادلة المحاسبية</h3><div class="validation-grid"><?php foreach(['الحالية','السابقة','بداية السابقة'] as $i=>$label):$d=(float)$report['balance_difference'][$i];?><div class="validation-item <?=abs($d)<0.001?'valid':'invalid'?>"><span><?=$label?></span><strong><?=gr_report_money($d)?></strong><small><?=abs($d)<0.001?'متوازنة':'يوجد فرق يحتاج مراجعة'?></small></div><?php endforeach;?></div></div>
<div class="report-note">تستند القائمة إلى القيود المرحلة، وتحتسب المجاميع من البنود الصافية الظاهرة في النموذج. الحسابات التنظيمية المؤجلة والمتقابلة تعرض بعد المجاميع ولا تدخل فيها، وفق ترتيب الدليل.</div></div>
<div class="programmer-print">المبرمج: م. أرشد حميد حسن • واتساب: 07735882844</div><?php render_footer(); ?>
