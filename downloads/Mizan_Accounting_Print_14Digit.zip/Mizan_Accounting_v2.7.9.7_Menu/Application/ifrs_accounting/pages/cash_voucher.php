<?php
declare(strict_types=1);
require_role(['admin','accountant']);

$id = (int)($_GET['id'] ?? 0);
$entry = null;
$source = (string)($_GET['type'] ?? 'payment');
$lineRows = [];
$details = ['sheet_no'=>'','check_no'=>'','check_date'=>'','payee_name'=>'','recipient_name'=>''];

if ($id > 0) {
    $entry = journal_snapshot($id);
    if (!$entry || !in_array($entry['source_type'], ['receipt','payment'], true)) {
        throw new RuntimeException('السند غير موجود.');
    }
    if ($entry['status'] !== 'draft') {
        redirect(url('journal_view', ['id'=>$id]));
    }
    $source = (string)$entry['source_type'];
    foreach ($entry['lines'] as $line) {
        $lineRows[] = [
            'account_id' => (string)$line['account_id'],
            'debit' => (string)((float)$line['debit'] > 0 ? $line['debit'] : ''),
            'credit' => (string)((float)$line['credit'] > 0 ? $line['credit'] : ''),
            'description' => (string)($line['line_description'] ?: $entry['description']),
            'cost_center_id' => (string)($line['cost_center_id'] ?? ''),
            'party_id' => (string)($line['party_id'] ?? ''),
        ];
    }
    if (table_exists('voucher_details')) {
        $stmt = db()->prepare('SELECT sheet_no,check_no,check_date,payee_name,recipient_name FROM voucher_details WHERE journal_entry_id=?');
        $stmt->execute([$id]);
        $stored = $stmt->fetch();
        if ($stored) $details = array_merge($details, $stored);
    }
}
if (!in_array($source, ['receipt','payment'], true)) $source = 'payment';
$old = old_input_pull();

$stmt = db()->prepare('SELECT a.id,a.code,a.name_ar,a.parent_id,a.level_no,a.is_cash_account,a.is_postable,p.code parent_code,p.name_ar parent_name FROM accounts a LEFT JOIN accounts p ON p.id=a.parent_id WHERE a.company_id=? AND a.is_active=1 ORDER BY a.code');
$stmt->execute([company_id()]);
$allAccounts = $stmt->fetchAll();
$accounts = array_values(array_filter($allAccounts, static fn(array $a): bool => (int)$a['is_postable'] === 1));
$standards = standards_library();
$cashDefs = cash_flow_line_definitions();
$ccs = cost_center_options();
$parties = party_options();

$value = static function(string $key, mixed $fallback='') use ($old, $details): mixed {
    return $old[$key] ?? $details[$key] ?? $fallback;
};
$entryDate = (string)($old['entry_date'] ?? $entry['entry_date'] ?? date('Y-m-d'));
$sheetNo = (string)$value('sheet_no', $entry['reference_no'] ?? '');
$checkNo = (string)$value('check_no', '');
$checkDate = (string)$value('check_date', $entryDate);
if (!valid_date($checkDate)) $checkDate = $entryDate;
$payeeName = (string)$value('payee_name', '');
$recipientName = (string)$value('recipient_name', '');

$normaliseArray = static function(mixed $value): array {
    if ($value === null || $value === '') return [];
    return is_array($value) ? array_values($value) : [$value];
};
if (array_key_exists('line_account_id', $old)) {
    $ids = $normaliseArray($old['line_account_id']);
    $debits = $normaliseArray($old['line_debit'] ?? []);
    $credits = $normaliseArray($old['line_credit'] ?? []);
    $descriptions = $normaliseArray($old['line_description'] ?? []);
    $costs = $normaliseArray($old['line_cost_center_id'] ?? []);
    $rowParties = $normaliseArray($old['line_party_id'] ?? []);
    $lineRows = [];
    foreach ($ids as $i => $accountId) {
        $lineRows[] = [
            'account_id' => (string)$accountId,
            'debit' => (string)($debits[$i] ?? ''),
            'credit' => (string)($credits[$i] ?? ''),
            'description' => (string)($descriptions[$i] ?? ''),
            'cost_center_id' => (string)($costs[$i] ?? ''),
            'party_id' => (string)($rowParties[$i] ?? ''),
        ];
    }
}
if (!$lineRows) {
    $lineRows = [
        ['account_id'=>'','debit'=>'','credit'=>'','description'=>(string)($entry['description'] ?? ''),'cost_center_id'=>'','party_id'=>''],
        ['account_id'=>'','debit'=>'','credit'=>'','description'=>(string)($entry['description'] ?? ''),'cost_center_id'=>'','party_id'=>''],
    ];
}

$accountOptions = static function(array $rows, string $selected=''): string {
    $html = '<option value="">— اختر أي حساب قابل للترحيل —</option>';
    foreach ($rows as $a) {
        $sel = $selected === (string)$a['id'] ? ' selected' : '';
        $html .= '<option value="'.e((string)$a['id']).'"'.$sel
            .' data-code="'.e((string)$a['code']).'"'
            .' data-name="'.e((string)$a['name_ar']).'"'
            .' data-parent-code="'.e((string)($a['parent_code'] ?: $a['code'])).'"'
            .' data-parent-name="'.e((string)($a['parent_name'] ?: $a['name_ar'])).'">'
            .e((string)$a['code'].' — '.(string)$a['name_ar']).'</option>';
    }
    return $html;
};
$costOptions = static function(array $rows, string $selected=''): string {
    $html = '<option value="">— بدون مركز كلفة —</option>';
    foreach ($rows as $a) {
        $sel = $selected === (string)$a['id'] ? ' selected' : '';
        $html .= '<option value="'.e((string)$a['id']).'"'.$sel.' data-code="'.e((string)$a['code']).'">'.e((string)$a['code'].' — '.(string)$a['name_ar']).'</option>';
    }
    return $html;
};
$partyOptions = static function(array $rows, string $selected=''): string {
    $html = '<option value="">— بدون جهة —</option>';
    foreach ($rows as $a) {
        $sel = $selected === (string)$a['id'] ? ' selected' : '';
        $html .= '<option value="'.e((string)$a['id']).'"'.$sel.' data-name="'.e((string)$a['name_ar']).'">'.e(($a['code'] ? $a['code'].' — ' : '').$a['name_ar']).'</option>';
    }
    return $html;
};

$initialDebit = 0.0;
$initialCredit = 0.0;
foreach ($lineRows as $r) {
    $initialDebit += (float)($r['debit'] ?: 0);
    $initialCredit += (float)($r['credit'] ?: 0);
}
$initialVoucherAmount = max($initialDebit, $initialCredit);

$GLOBALS['fixed_print_template'] = 'payment-voucher';
render_header($entry ? 'تعديل سند' : 'سند قبض / صرف', 'cash_voucher');
page_heading(
    $entry ? 'تعديل '.(string)$entry['voucher_no'] : 'إضافة مستند صرف / قبض',
    'المستند عام: يمكن اختيار أي حساب قابل للترحيل في المدين أو الدائن، ويمكن تقسيم أي طرف على أكثر من حساب.'
);
?>
<form method="post" id="paymentVoucherForm">
<input type="hidden" name="action" value="voucher_save">
<input type="hidden" name="id" value="<?=e((string)($entry['id'] ?? ''))?>">
<input type="hidden" name="version_no" value="<?=e((string)($entry['version_no'] ?? ''))?>">
<input type="hidden" name="reference_no" id="voucherReferenceNo" value="<?=e($sheetNo)?>">
<?=csrf_field()?>

<div class="payment-voucher-tools no-print">
    <div class="field"><label>نوع السند</label><select name="source_type" id="paymentVoucherType"><option value="payment" <?=$source==='payment'?'selected':''?>>مستند صرف</option><option value="receipt" <?=$source==='receipt'?'selected':''?>>سند قبض</option></select></div>
    <div class="field"><label>المعيار المرتبط</label><select name="origin_standard"><option value="">— عام —</option><?php foreach($standards as $st):?><option value="<?=e((string)$st['code'])?>" <?=($entry['origin_standard']??'')===$st['code']?'selected':''?>><?=e((string)$st['code'].' — '.(string)$st['title_ar'])?></option><?php endforeach;?></select></div>
    <div class="field"><label>بند التدفق النقدي</label><select name="cash_flow_line_code"><option value="">تصنيف تلقائي</option><?php foreach($cashDefs as $code=>$def):?><option value="<?=e((string)$code)?>"><?=e((string)$def[2].' — '.(string)$def[3])?></option><?php endforeach;?></select></div>
    <button type="button" class="btn btn-outline print-btn">معاينة الطباعة</button>
</div>

<section class="official-payment-voucher" id="officialPaymentVoucher" aria-label="مستند صرف">
    <header class="opv-company"><?=e((string)(company()['name_ar'] ?? ''))?></header>
    <div class="opv-top-grid">
        <div class="opv-box opv-money-box">
            <label><span>المبلغ:</span><input class="num opv-editable-total" name="amount" id="paymentAmount" inputmode="decimal" value="<?=e($initialVoucherAmount > 0 ? (string)$initialVoucherAmount : '')?>" placeholder="يحتسب تلقائياً" readonly></label>
            <label><span>رقم الصك:</span><input name="check_no" value="<?=e($checkNo)?>"></label>
            <?php $checkDateTime = strtotime($checkDate) ?: (strtotime($entryDate) ?: time()); ?>
            <label><span>تاريخ الصك:</span><span class="doc-date-field opv-check-date-field"><input type="text" class="doc-date-part doc-date-day" inputmode="numeric" maxlength="2" placeholder="يوم" value="<?=e(date('d',$checkDateTime))?>" autocomplete="off"><span class="doc-date-sep">/</span><input type="text" class="doc-date-part doc-date-month" inputmode="numeric" maxlength="2" placeholder="شهر" value="<?=e(date('m',$checkDateTime))?>" autocomplete="off"><span class="doc-date-sep">/</span><input type="text" class="doc-date-part doc-date-year" inputmode="numeric" maxlength="4" placeholder="سنة" value="<?=e(date('Y',$checkDateTime))?>" autocomplete="off"><input type="hidden" class="doc-date-value" name="check_date" value="<?=e($checkDate)?>"></span></label>
        </div>
        <div class="opv-center-head">
            <div class="opv-title" id="paymentVoucherTitle"><?=$source==='payment'?'مستند صرف':'سند قبض'?></div>
            <label class="opv-payee"><span id="paymentPayeeLabel"><?=$source==='payment'?'المدفوع له:':'المستلم منه:'?></span><input name="payee_name" id="paymentPayeeName" value="<?=e($payeeName)?>" required></label>
        </div>
        <div class="opv-box opv-document-box">
            <label><span>اسم الدائرة:</span><input value="<?=e((string)(company()['name_ar'] ?? ''))?>" readonly></label>
            <label><span>رقم المستند:</span><input value="<?=e((string)($entry['voucher_no'] ?? 'ينشأ تلقائياً'))?>" readonly></label>
            <?php $cvDateTime = strtotime($entryDate) ?: time(); ?><label><span>تاريخ المستند:</span><span class="doc-date-field"><input type="text" class="doc-date-part doc-date-day" inputmode="numeric" maxlength="2" placeholder="يوم" value="<?=e(date('d',$cvDateTime))?>" autocomplete="off" required><span class="doc-date-sep">/</span><input type="text" class="doc-date-part doc-date-month" inputmode="numeric" maxlength="2" placeholder="شهر" value="<?=e(date('m',$cvDateTime))?>" autocomplete="off" required><span class="doc-date-sep">/</span><input type="text" class="doc-date-part doc-date-year" inputmode="numeric" maxlength="4" placeholder="سنة" value="<?=e(date('Y',$cvDateTime))?>" autocomplete="off" required><input type="hidden" class="doc-date-value" name="entry_date" value="<?=e($entryDate)?>"></span></label>
            <label><span>رقم صحيفة السند:</span><input name="sheet_no" id="paymentSheetNo" value="<?=e($sheetNo)?>"></label>
        </div>
    </div>

    <div class="opv-table-wrap">
    <table class="opv-table" id="officialPaymentTable">
        <colgroup>
            <col class="opv-fils"><col class="opv-dinar"><col class="opv-fils"><col class="opv-dinar">
            <col class="opv-account"><col class="opv-guide"><col class="opv-guide"><col class="opv-guide">
            <col class="opv-cost"><col class="opv-cost"><col class="opv-cost"><col class="opv-cost"><col class="opv-cost">
        </colgroup>
        <thead>
            <tr><th colspan="2">مبلغ المدين</th><th colspan="2">مبلغ الدائن</th><th rowspan="2">اسم الحساب وتفاصيله</th><th colspan="3">رقم الدليل المحاسبي</th><th colspan="5">مراكز الكلف</th></tr>
            <tr><th>ف</th><th>د</th><th>ف</th><th>د</th><th>3</th><th>4</th><th>5</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th></tr>
        </thead>
        <tbody id="paymentVoucherRows">
            <?php foreach ($lineRows as $row): ?>
            <tr class="opv-account-row opv-general-row">
                <td class="opv-debit-fils"><span class="opv-debit-fils-print"></span></td>
                <td class="opv-debit-dinar num"><span class="opv-debit-print opv-line-amount-print"></span><span class="opv-amount-editor"><input name="line_debit[]" class="opv-line-debit opv-direct-amount no-print" inputmode="decimal" value="<?=e((string)$row['debit'])?>" placeholder="مدين"></span></td>
                <td class="opv-credit-fils"><span class="opv-credit-fils-print"></span></td>
                <td class="opv-credit-dinar num"><span class="opv-credit-print opv-line-amount-print"></span><span class="opv-amount-editor"><input name="line_credit[]" class="opv-line-credit opv-direct-amount no-print" inputmode="decimal" value="<?=e((string)$row['credit'])?>" placeholder="دائن"></span></td>
                <td class="opv-account-cell">
                    <div class="opv-account-print"></div>
                    <div class="opv-account-controls no-print">
                        <input class="opv-account-code" inputmode="numeric" placeholder="رقم الحساب">
                        <select name="line_account_id[]" class="opv-line-account" required><?=$accountOptions($accounts,(string)$row['account_id'])?></select>
                    </div>
                    <div class="opv-row-extra no-print">
                        <label>مركز الكلفة<select name="line_cost_center_id[]" class="opv-row-cost-center"><?=$costOptions($ccs,(string)$row['cost_center_id'])?></select></label>
                        <label>الجهة<select name="line_party_id[]" class="opv-row-party"><?=$partyOptions($parties,(string)$row['party_id'])?></select></label>
                        <button type="button" class="opv-remove-row" title="حذف الصف" aria-label="حذف الصف">×</button>
                    </div>
                    <textarea name="line_description[]" class="opv-line-description" required placeholder="تفاصيل العملية"><?=e((string)$row['description'])?></textarea>
                </td>
                <td class="opv-code opv-code-3"></td><td class="opv-code opv-code-4"></td><td class="opv-code opv-code-5"></td>
                <td class="opv-cc-digit" data-pos="0"></td><td class="opv-cc-digit" data-pos="1"></td><td class="opv-cc-digit" data-pos="2"></td><td class="opv-cc-digit" data-pos="3"></td><td class="opv-cc-digit" data-pos="4"></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr class="opv-total-row"><td></td><td id="opvTotalDebit" class="num"></td><td></td><td id="opvTotalCredit" class="num"></td><td colspan="9" id="opvAmountWords" data-currency="<?=e((string)(company()['currency_name_ar'] ?? 'دينار عراقي'))?>"></td></tr>
        </tfoot>
    </table>
    </div>

    <div class="opv-row-actions no-print">
        <button type="button" class="btn btn-outline" id="addPaymentVoucherRow">+ إضافة حساب / صف</button>
        <small>يمكن تقسيم المدين أو الدائن إلى عدة حسابات؛ مثال: مدين 10,000,000 مقابل دائن 8,000,000 + 2,000,000.</small>
    </div>

    <div class="opv-signatures">
        <?php foreach ([
            'organizer' => ['المنظم', (string)(user()['full_name'] ?? '')],
            'accountant' => ['المحاسب', ''],
            'auditor' => ['المدقق', ''],
            'accounts_manager' => ['مدير الحسابات', ''],
            'general_manager' => ['المدير العام', ''],
        ] as $sigKey => $sig):
            $sigValue = (string)($old['signature_' . $sigKey] ?? setting_get('voucher_sign_' . $sigKey, $sig[1]));
        ?>
            <div><strong><?=e($sig[0])?></strong><input class="voucher-sign-input" name="signature_<?=e($sigKey)?>" value="<?=e($sigValue)?>" autocomplete="off" placeholder="الاسم"></div>
        <?php endforeach;?>
    </div>
    <div class="opv-receipt-ack">
        <div>إني الموقع أدناه استلمت من <span class="opv-line"></span></div>
        <div>الصك المرقم <span class="opv-line"></span></div>
        <label>اسم المستلم: <input name="recipient_name" value="<?=e($recipientName)?>"></label>
        <div class="opv-receipt-sign">التوقيع: <span class="opv-line"></span></div>
    </div>
</section>

<template id="paymentVoucherRowTemplate">
<tr class="opv-account-row opv-general-row">
    <td class="opv-debit-fils"><span class="opv-debit-fils-print"></span></td>
    <td class="opv-debit-dinar num"><span class="opv-debit-print opv-line-amount-print"></span><span class="opv-amount-editor"><input name="line_debit[]" class="opv-line-debit opv-direct-amount no-print" inputmode="decimal" placeholder="مدين"></span></td>
    <td class="opv-credit-fils"><span class="opv-credit-fils-print"></span></td>
    <td class="opv-credit-dinar num"><span class="opv-credit-print opv-line-amount-print"></span><span class="opv-amount-editor"><input name="line_credit[]" class="opv-line-credit opv-direct-amount no-print" inputmode="decimal" placeholder="دائن"></span></td>
    <td class="opv-account-cell">
        <div class="opv-account-print"></div>
        <div class="opv-account-controls no-print">
            <input class="opv-account-code" inputmode="numeric" placeholder="رقم الحساب">
            <select name="line_account_id[]" class="opv-line-account" required><?=$accountOptions($accounts,'')?></select>
        </div>
        <div class="opv-row-extra no-print">
            <label>مركز الكلفة<select name="line_cost_center_id[]" class="opv-row-cost-center"><?=$costOptions($ccs,'')?></select></label>
            <label>الجهة<select name="line_party_id[]" class="opv-row-party"><?=$partyOptions($parties,'')?></select></label>
            <button type="button" class="opv-remove-row" title="حذف الصف" aria-label="حذف الصف">×</button>
        </div>
        <textarea name="line_description[]" class="opv-line-description" required placeholder="تفاصيل العملية"></textarea>
    </td>
    <td class="opv-code opv-code-3"></td><td class="opv-code opv-code-4"></td><td class="opv-code opv-code-5"></td>
    <td class="opv-cc-digit" data-pos="0"></td><td class="opv-cc-digit" data-pos="1"></td><td class="opv-cc-digit" data-pos="2"></td><td class="opv-cc-digit" data-pos="3"></td><td class="opv-cc-digit" data-pos="4"></td>
</tr>
</template>

<div class="payment-voucher-actions no-print">
    <input type="hidden" name="currency_code" value="<?=e((string)(company()['currency_code'] ?? 'IQD'))?>"><input type="hidden" name="exchange_rate" value="1"><input type="hidden" name="foreign_amount" value="0"><input type="hidden" name="equity_movement_type" value="none">
    <button class="btn btn-light" name="submit_mode" value="draft">حفظ كمسودة</button>
    <button class="btn btn-primary" name="submit_mode" value="post" data-confirm="حفظ السند وترحيله؟">حفظ وترحيل</button>
    <a class="btn btn-outline" href="<?=e($entry?url('journal_view',['id'=>$entry['id']]):url('journal_list'))?>">إلغاء</a>
</div>
</form>

<script>
(() => {
  const form = document.getElementById('paymentVoucherForm');
  if (!form) return;
  const type = document.getElementById('paymentVoucherType');
  const amount = document.getElementById('paymentAmount');
  const title = document.getElementById('paymentVoucherTitle');
  const payeeLabel = document.getElementById('paymentPayeeLabel');
  const payee = document.getElementById('paymentPayeeName');
  const sheet = document.getElementById('paymentSheetNo');
  const reference = document.getElementById('voucherReferenceNo');
  const rowsBody = document.getElementById('paymentVoucherRows');
  const addButton = document.getElementById('addPaymentVoucherRow');
  const template = document.getElementById('paymentVoucherRowTemplate');
  const MAX_ROWS = 20;
  const parseAmount = (v) => Number.parseFloat(String(v || '').replace(/[٬,\s]/g,'').replace('٫','.')) || 0;
  const formatAmount = (v) => v.toLocaleString('en-US',{maximumFractionDigits:3});
  const splitAmount = (v) => {
    const value = Math.max(0, parseAmount(v));
    const dinar = Math.floor(value);
    let fils = Math.round((value - dinar) * 1000);
    if (fils >= 1000) fils = 0;
    return {dinar, fils: fils > 0 ? String(fils).padStart(3,'0') : ''};
  };
  const under1000 = (n) => { const u=['','واحد','اثنان','ثلاثة','أربعة','خمسة','ستة','سبعة','ثمانية','تسعة','عشرة','أحد عشر','اثنا عشر','ثلاثة عشر','أربعة عشر','خمسة عشر','ستة عشر','سبعة عشر','ثمانية عشر','تسعة عشر']; const t={20:'عشرون',30:'ثلاثون',40:'أربعون',50:'خمسون',60:'ستون',70:'سبعون',80:'ثمانون',90:'تسعون'}; const h=['','مائة','مائتان','ثلاثمائة','أربعمائة','خمسمائة','ستمائة','سبعمائة','ثمانمائة','تسعمائة']; const p=[]; if(n>=100){p.push(h[Math.floor(n/100)]);n%=100;} if(n){if(n<20)p.push(u[n]);else{const x=n%10;p.push(x?u[x]+' و'+t[n-x]:t[n]);}} return p.join(' و'); };
  const words = (n) => { n=Math.floor(Math.abs(n)); if(!n)return 'صفر'; const scales=[[1e9,'مليار','ملياران','مليارات'],[1e6,'مليون','مليونان','ملايين'],[1e3,'ألف','ألفان','آلاف']]; const p=[]; for(const [v,a,b,c] of scales){if(n>=v){const q=Math.floor(n/v);n%=v;p.push(q===1?a:q===2?b:q<=10?under1000(q)+' '+c:under1000(q)+' '+a);}} if(n)p.push(under1000(n)); return p.join(' و'); };
  const placeCode = (row, code) => { row.querySelectorAll('.opv-code').forEach(x=>x.textContent=''); const digits=String(code||'').replace(/\D/g,''); const level=digits.length<=3?3:(digits.length===4?4:5); const cell=row.querySelector('.opv-code-'+level); if(cell)cell.textContent=code||''; };
  const updateCostDigits = (row) => { const select=row.querySelector('.opv-row-cost-center'); if(!select)return; const code=select.selectedOptions[0]?.dataset.code||''; const digits=String(code).replace(/\D/g,'').slice(-5).padStart(5,''); row.querySelectorAll('.opv-cc-digit').forEach((cell,i)=>cell.textContent=digits[i]||''); };
  const bindAccountPair = (row, select, code) => {
    const apply=()=>{const o=select.selectedOptions[0]; const valid=o&&o.value; code.value=valid?(o.dataset.code||''):''; row.querySelector('.opv-account-print').textContent=valid?((o.dataset.parentName&&o.dataset.parentName!==o.dataset.name?o.dataset.parentName+' / ':'')+(o.dataset.name||'')):''; placeCode(row,valid?(o.dataset.code||''):''); code.setCustomValidity('');};
    const find=(force)=>{const v=code.value.trim(), opts=Array.from(select.options); const exact=opts.find(o=>o.dataset.code===v); const pref=opts.filter(o=>(o.dataset.code||'').startsWith(v)); const match=exact||(force&&pref.length===1?pref[0]:null); if(match){select.value=match.value;apply();}else if(!v){select.value='';apply();}else if(force){code.setCustomValidity('رقم الحساب غير موجود في الدليل.');code.reportValidity();}};
    select.addEventListener('change',apply); code.addEventListener('input',()=>find(false)); code.addEventListener('change',()=>find(true)); code.addEventListener('blur',()=>find(true)); apply();
  };
  const update = () => {
    const payment=type.value==='payment';
    title.textContent=payment?'مستند صرف':'سند قبض';
    payeeLabel.textContent=payment?'المدفوع له:':'المستلم منه:';
    let totalDebit=0, totalCredit=0;
    rowsBody.querySelectorAll('.opv-general-row').forEach(row=>{
      const debit=parseAmount(row.querySelector('.opv-line-debit')?.value);
      const credit=parseAmount(row.querySelector('.opv-line-credit')?.value);
      totalDebit += debit; totalCredit += credit;
      const d=splitAmount(debit), c=splitAmount(credit);
      const dp=row.querySelector('.opv-debit-print'), df=row.querySelector('.opv-debit-fils-print');
      const cp=row.querySelector('.opv-credit-print'), cf=row.querySelector('.opv-credit-fils-print');
      if(dp)dp.textContent=debit>0?formatAmount(d.dinar):'';
      if(df)df.textContent=d.fils;
      if(cp)cp.textContent=credit>0?formatAmount(c.dinar):'';
      if(cf)cf.textContent=c.fils;
    });
    const total=Math.max(totalDebit,totalCredit);
    if (document.activeElement !== amount) amount.value=total>0?String(total):'';
    document.getElementById('opvTotalDebit').textContent=totalDebit>0?formatAmount(totalDebit):'';
    document.getElementById('opvTotalCredit').textContent=totalCredit>0?formatAmount(totalCredit):'';
    const wordsCell=document.getElementById('opvAmountWords'), currency=wordsCell.dataset.currency||'دينار عراقي';
    const balanced=Math.abs(totalDebit-totalCredit)<0.0005 && totalDebit>0;
    wordsCell.textContent=(balanced?'المجموع فقط ':'غير متوازن — الفرق '+formatAmount(Math.abs(totalDebit-totalCredit))+' | المجموع ')+words(total)+' '+currency+' لا غير';
    wordsCell.classList.toggle('opv-unbalanced',!balanced);
    const count=rowsBody.querySelectorAll('.opv-general-row').length;
    rowsBody.querySelectorAll('.opv-remove-row').forEach(btn=>btn.disabled=count<=2);
    addButton.disabled=count>=MAX_ROWS;
  };
  const bindRow = (row) => {
    const select=row.querySelector('.opv-line-account'), code=row.querySelector('.opv-account-code');
    bindAccountPair(row,select,code);
    const debit=row.querySelector('.opv-line-debit'), credit=row.querySelector('.opv-line-credit');
    debit.addEventListener('input',()=>{if(parseAmount(debit.value)>0)credit.value='';update();});
    credit.addEventListener('input',()=>{if(parseAmount(credit.value)>0)debit.value='';update();});
    const cc=row.querySelector('.opv-row-cost-center'); cc.addEventListener('change',()=>updateCostDigits(row)); updateCostDigits(row);
    row.querySelector('.opv-row-party').addEventListener('change',event=>{const name=event.target.selectedOptions[0]?.dataset.name||'';if(name&&!payee.value.trim())payee.value=name;});
    row.querySelector('.opv-remove-row').addEventListener('click',()=>{if(rowsBody.querySelectorAll('.opv-general-row').length<=2)return;row.remove();update();});
  };
  rowsBody.querySelectorAll('.opv-general-row').forEach(bindRow);
  addButton.addEventListener('click',()=>{
    if(rowsBody.querySelectorAll('.opv-general-row').length>=MAX_ROWS)return;
    const row=template.content.firstElementChild.cloneNode(true);
    rowsBody.appendChild(row);
    bindRow(row);
    update();
    row.querySelector('.opv-account-code').focus();
  });
  type.addEventListener('change',update);
  sheet.addEventListener('input',()=>reference.value=sheet.value);
  form.addEventListener('submit',(event)=>{
    let d=0,c=0,used=0;
    rowsBody.querySelectorAll('.opv-general-row').forEach(row=>{
      const account=row.querySelector('.opv-line-account')?.value||'';
      const debit=parseAmount(row.querySelector('.opv-line-debit')?.value);
      const credit=parseAmount(row.querySelector('.opv-line-credit')?.value);
      if(account||debit>0||credit>0)used++;
      d+=debit;c+=credit;
    });
    if(used<2 || d<=0 || c<=0 || Math.abs(d-c)>=0.0005){
      event.preventDefault();
      alert('يجب إدخال قيد متوازن: إجمالي المدين يساوي إجمالي الدائن، مع حسابين على الأقل.');
    }
  });
  update();
})();
</script>
<?php render_footer(); ?>
