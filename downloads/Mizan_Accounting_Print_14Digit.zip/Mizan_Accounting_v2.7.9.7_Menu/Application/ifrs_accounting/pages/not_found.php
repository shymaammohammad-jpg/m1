<?php
declare(strict_types=1);render_header('الصفحة غير موجودة','');page_heading('الصفحة غير موجودة','تعذر العثور على الصفحة المطلوبة.');?><div class="card empty"><a class="btn btn-primary" href="<?=e(url('dashboard'))?>">العودة إلى لوحة المؤشرات</a></div><?php render_footer(); ?>
