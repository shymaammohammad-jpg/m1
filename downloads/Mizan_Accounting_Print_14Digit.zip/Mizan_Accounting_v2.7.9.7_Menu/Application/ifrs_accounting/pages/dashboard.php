<?php
declare(strict_types=1);
$today = date('Y-m-d');
$period = fiscal_period_for($today);
if (!$period) {
    $stmt = db()->prepare('SELECT * FROM fiscal_periods WHERE company_id=? ORDER BY end_date DESC LIMIT 1');
    $stmt->execute([company_id()]);
    $period = $stmt->fetch() ?: null;
}
$from = $period['start_date'] ?? date('Y-01-01');
$to = $period['end_date'] ?? date('Y-12-31');
$stmt = db()->prepare("SELECT status,COUNT(*) n FROM journal_entries WHERE company_id=? GROUP BY status");
$stmt->execute([company_id()]);
$statusCounts = ['draft'=>0,'posted'=>0,'reversed'=>0];
foreach ($stmt->fetchAll() as $row) $statusCounts[$row['status']] = (int)$row['n'];
$stmt = db()->prepare('SELECT COUNT(*) FROM accounts WHERE company_id=? AND is_active=1');
$stmt->execute([company_id()]); $accountCount=(int)$stmt->fetchColumn();
$stmt = db()->prepare('SELECT COUNT(*) FROM parties WHERE company_id=? AND is_active=1');
$stmt->execute([company_id()]); $partyCount=(int)$stmt->fetchColumn();
$profit = period_profit($from, min($today,$to));
$balances = report_balances(min($today,$to));
$assets=$liabilities=$equity=0.0;
foreach($balances as $row){$raw=(float)$row['debit']-(float)$row['credit'];if($row['account_type']==='asset')$assets+=$raw;elseif($row['account_type']==='contra_asset')$assets-=-$raw;elseif($row['account_type']==='liability')$liabilities+=-$raw;elseif($row['account_type']==='equity')$equity+=-$raw;}
$stmt = db()->prepare("SELECT je.id,je.voucher_no,je.entry_date,je.description,je.source_type,je.status,COALESCE(SUM(jl.debit),0) total
                       FROM journal_entries je LEFT JOIN journal_lines jl ON jl.journal_entry_id=je.id
                       WHERE je.company_id=? GROUP BY je.id ORDER BY je.id DESC LIMIT 8");
$stmt->execute([company_id()]); $recent=$stmt->fetchAll();
render_header('لوحة المؤشرات','dashboard');
page_heading('لوحة المؤشرات','ملخص فوري للحركة المحاسبية والوضع المالي ضمن الفترة الحالية.');
?>
<div class="grid grid-4" style="margin-bottom:18px">
  <div class="stat-card"><span class="label">المستندات المرحلة</span><strong class="value"><?=number_format($statusCounts['posted']+$statusCounts['reversed'])?></strong><span class="note">المسودات: <?=number_format($statusCounts['draft'])?></span></div>
  <div class="stat-card"><span class="label">الأصول حتى اليوم</span><strong class="value"><?=money($assets)?></strong><span class="note"><?=e(company()['currency_code']??'')?></span></div>
  <div class="stat-card"><span class="label">صافي نتيجة الفترة</span><strong class="value <?=$profit>=0?'positive':'negative'?>"><?=money($profit)?></strong><span class="note"><?=e(doc_date($from))?> — <?=e(doc_date(min($today,$to)))?></span></div>
  <div class="stat-card"><span class="label">دليل الحسابات</span><strong class="value"><?=number_format($accountCount)?></strong><span class="note">الجهات الفعالة: <?=number_format($partyCount)?></span></div>
</div>
<div class="card" style="margin-bottom:18px">
  <h3 class="card-title">وصول سريع</h3>
  <div class="quick-links">
    <a class="quick-link" href="<?=e(url('journal_new',['source'=>'opening']))?>"><?=icon('journal')?><span>إضافة قيد افتتاحي</span></a>
    <a class="quick-link" href="<?=e(url('journal_new'))?>"><?=icon('journal')?><span>إضافة قيد يومي</span></a>
    <a class="quick-link" href="<?=e(url('cash_voucher',['type'=>'payment']))?>"><?=icon('cash')?><span>إنشاء سند صرف</span></a>
    <a class="quick-link" href="<?=e(url('trial_balance_balances'))?>"><?=icon('report')?><span>ميزان المراجعة قبل/بعد الغلق</span></a>
    <a class="quick-link" href="<?=e(url('compliance_dashboard'))?>"><?=icon('health')?><span>لوحة المطابقة</span></a>
    <a class="quick-link" href="<?=e(url('financial_package'))?>"><?=icon('report')?><span>الحزمة المالية</span></a>
  </div>
</div>
<div class="grid grid-2">
  <div class="card">
    <h3 class="card-title">ملخص المركز المالي</h3>
    <div class="health-item"><span>إجمالي الأصول</span><strong><?=money($assets)?></strong></div>
    <div class="health-item"><span>إجمالي الالتزامات</span><strong><?=money($liabilities)?></strong></div>
    <div class="health-item"><span>حقوق الملكية المسجلة</span><strong><?=money($equity)?></strong></div>
    <div class="health-item"><span>النتيجة غير المقفلة</span><strong class="<?=$profit>=0?'positive':'negative'?>"><?=money($profit)?></strong></div>
  </div>
  <div class="card">
    <h3 class="card-title">آخر المستندات</h3>
    <?php if(!$recent):?><div class="empty">لا توجد مستندات حتى الآن.</div><?php endif;?>
    <?php foreach($recent as $row):?>
      <div class="backup-card"><div><a href="<?=e(url('journal_view',['id'=>$row['id']]))?>"><strong><?=e($row['voucher_no'])?></strong></a><div class="small muted"><?=e(doc_date($row['entry_date']))?> • <?=e(source_label($row['source_type']))?> • <?=e(mb_strimwidth($row['description'],0,48,'…'))?></div></div><div class="text-center"><?=status_badge($row['status'])?><div class="small num" style="margin-top:5px"><?=money($row['total'])?></div></div></div>
    <?php endforeach;?>
  </div>
</div>
<?php render_footer(); ?>
