<?php
declare(strict_types=1);

$licenseStatus = license_status(true);
$isInternal = user() !== null;
$payload = is_array($licenseStatus['payload'] ?? null) ? $licenseStatus['payload'] : [];

if ($isInternal) {
    render_header('الترخيص والتفعيل', 'license');
    page_heading('الترخيص والتفعيل', 'عرض رقم الجهاز، حالة الترخيص السنوي، وتجديد التفعيل.');
} else {
    render_public_header('تفعيل نظام الميزان المحاسبي');
}
?>
<div class="license-shell <?= $isInternal ? 'license-shell-internal' : '' ?>">
    <?php if (!$isInternal): ?>
        <div class="license-brand-head">
            <img src="assets/branding/app_icon.png" alt="شعار نظام الميزان المحاسبي">
            <div><h1>نظام الميزان المحاسبي</h1><p>التفعيل السنوي الآمن للجهاز</p></div>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['activated']) && (string)$_GET['activated'] === '1'): ?>
        <div class="alert alert-success">تم تفعيل النظام بنجاح وحفظ الترخيص على هذا الجهاز.</div>
    <?php endif; ?>
    <?php if (!empty($licenseError)): ?><div class="alert alert-danger"><?= e($licenseError) ?></div><?php endif; ?>

    <div class="license-grid">
        <section class="card license-status-card <?= $licenseStatus['valid'] ? 'license-valid' : 'license-invalid' ?>">
            <div class="license-status-icon"><?= $licenseStatus['valid'] ? '✓' : '!' ?></div>
            <h2><?= $licenseStatus['valid'] ? 'الترخيص فعال' : 'النظام يحتاج إلى تفعيل' ?></h2>
            <p><?= e((string)$licenseStatus['reason']) ?></p>
            <?php if ($licenseStatus['valid']): ?>
                <dl class="license-details">
                    <div><dt>رقم الترخيص</dt><dd><?= e((string)($payload['license_id'] ?? '')) ?></dd></div>
                    <div><dt>الجهة المرخصة</dt><dd><?= e((string)($payload['organization'] ?? $payload['customer_name'] ?? '')) ?></dd></div>
                    <div><dt>بداية الترخيص</dt><dd><?= e((string)($licenseStatus['valid_from'] ?? '')) ?></dd></div>
                    <div><dt>نهاية الترخيص</dt><dd><?= e((string)($licenseStatus['expires_at'] ?? '')) ?></dd></div>
                    <div><dt>الأيام المتبقية</dt><dd><?= e((string)($licenseStatus['days_remaining'] ?? '')) ?> يوم</dd></div>
                </dl>
            <?php endif; ?>
        </section>

        <section class="card license-machine-card">
            <h2>رقم الجهاز</h2>
            <p>أرسل هذا الرقم إلى المبرمج لإصدار ترخيص سنوي خاص بهذا الجهاز.</p>
            <div class="machine-code-box" id="machineCodeText"><?= e((string)$licenseStatus['machine_code']) ?></div>
            <button type="button" class="btn btn-outline" id="copyMachineCode">نسخ رقم الجهاز</button>
            <div class="developer-contact-box">
                <strong>المبرمج: م. أرشد حميد حسن</strong>
                <span>واتساب: 07735882844</span>
            </div>
        </section>
    </div>

    <section class="card license-activation-card">
        <h2><?= $licenseStatus['valid'] ? 'تجديد أو استبدال الترخيص' : 'إدخال رقم الترخيص' ?></h2>
        <form method="post" enctype="multipart/form-data" action="<?= e(url('license')) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="license_action" value="activate">
            <div class="field">
                <label>رقم License</label>
                <textarea name="license_key" rows="7" placeholder="BAL1...." spellcheck="false"></textarea>
                <small>الصق الرقم الصادر من أداة إنشاء الترخيص، أو اختر ملف License أدناه.</small>
            </div>
            <div class="field">
                <label>استيراد ملف الترخيص</label>
                <input type="file" name="license_file" accept=".license,.lic,.txt,text/plain">
            </div>
            <button class="btn btn-primary" type="submit">تفعيل النظام وحفظ الترخيص</button>
        </form>
    </section>

    <?php if ($licenseStatus['valid']): ?>
        <div class="license-actions">
            <a class="btn btn-primary" href="<?= e(user() ? url('dashboard') : url('login')) ?>"><?= user() ? 'العودة إلى لوحة المؤشرات' : 'الانتقال إلى تسجيل الدخول' ?></a>
        </div>
    <?php endif; ?>
</div>
<script>
(function(){
  var btn=document.getElementById('copyMachineCode');
  if(!btn)return;
  btn.addEventListener('click',function(){
    var value=document.getElementById('machineCodeText').textContent.trim();
    if(navigator.clipboard){navigator.clipboard.writeText(value).then(function(){btn.textContent='تم النسخ';});}
    else{window.prompt('انسخ رقم الجهاز:',value);}
  });
})();
</script>
<?php
if ($isInternal) {
    render_footer();
} else {
    render_public_footer();
}
?>
