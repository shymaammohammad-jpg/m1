<?php
declare(strict_types=1);

$monthNames = [
    1 => 'كانون الثاني',
    2 => 'شباط',
    3 => 'آذار',
    4 => 'نيسان',
    5 => 'أيار',
    6 => 'حزيران',
    7 => 'تموز',
    8 => 'آب',
    9 => 'أيلول',
    10 => 'تشرين الأول',
    11 => 'تشرين الثاني',
    12 => 'كانون الأول',
];

// توافق مع الروابط القديمة from/to: نشتق الشهر والسنة منها عند عدم تمرير month/year.
$legacyFrom = (string)($_GET['from'] ?? '');
$legacyTo = (string)($_GET['to'] ?? '');
$defaultYear = (int)date('Y');
$defaultMonth = (int)date('n');
$legacyDate = $legacyTo !== '' && valid_date($legacyTo) ? $legacyTo : ($legacyFrom !== '' && valid_date($legacyFrom) ? $legacyFrom : '');
if ($legacyDate !== '') {
    $legacyTs = strtotime($legacyDate);
    if ($legacyTs !== false) {
        $defaultYear = (int)date('Y', $legacyTs);
        $defaultMonth = (int)date('n', $legacyTs);
    }
}
$selectedYear = isset($_GET['year']) ? (int)$_GET['year'] : $defaultYear;
$selectedMonth = isset($_GET['month']) ? (int)$_GET['month'] : $defaultMonth;
if ($selectedYear < 2000 || $selectedYear > 2100) $selectedYear = (int)date('Y');
if ($selectedMonth < 1 || $selectedMonth > 12) $selectedMonth = (int)date('n');
$monthStart = new DateTimeImmutable(sprintf('%04d-%02d-01', $selectedYear, $selectedMonth));
$from = $monthStart->format('Y-m-d');
$to = $monthStart->modify('last day of this month')->format('Y-m-d');
$selectedMonthName = $monthNames[$selectedMonth];
$periodLabel = $selectedMonthName . ' ' . $selectedYear;

$yearStmt = db()->prepare('SELECT DISTINCT YEAR(entry_date) AS y FROM journal_entries WHERE company_id=? ORDER BY y DESC');
$yearStmt->execute([company_id()]);
$availableYears = [];
foreach ($yearStmt->fetchAll() as $yearRow) {
    $y = (int)($yearRow['y'] ?? 0);
    if ($y >= 2000 && $y <= 2100) $availableYears[$y] = true;
}
$availableYears[$selectedYear] = true;
$availableYears[(int)date('Y')] = true;
$availableYears = array_keys($availableYears);
rsort($availableYears, SORT_NUMERIC);

$basis = (string)($_GET['basis'] ?? 'closing');
$closingState = (string)($_GET['closing_state'] ?? 'before');
$showZero = isset($_GET['show_zero']) && (string)$_GET['show_zero'] === '1';

if (!in_array($basis, ['closing', 'period'], true)) {
    $basis = 'closing';
}
if (!in_array($closingState, ['before', 'after'], true)) {
    $closingState = 'before';
}
$closingFilter = '';
$closingFilterParams = [];
if ($closingState === 'before') {
    // استبعاد غلق الفترة الحالية فقط مع إبقاء غلق الفترات السابقة جزءاً من الرصيد المرحل.
    $closingFilter = " AND NOT (je.entry_date BETWEEN ? AND ? AND (je.source_type='closing'"
        . " OR (je.source_type='reversal' AND EXISTS (SELECT 1 FROM journal_entries original_closing"
        . " WHERE original_closing.id=je.reversal_of AND original_closing.source_type='closing'))))";
    $closingFilterParams = [$from, $to];
}

/**
 * ميزان مراجعة بالأرصدة وفق النموذج الهرمي الظاهر في المستندات الورقية:
 * - المستويات 2، 3، 4، 5 لكل منها عمود مدين وعمود دائن.
 * - أرصدة الحسابات التفصيلية تتجمع صعوداً إلى الحسابات الأب.
 * - الحسابات الأعمق من المستوى الخامس تظهر ضمن رصيد أصلها في المستوى الخامس.
 */
$stmt = db()->prepare(
    'SELECT a.id,a.code,a.name_ar,a.parent_id,a.level_no,a.normal_balance,a.is_postable,a.is_active,
            COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jl.debit-jl.credit ELSE 0 END),0) AS direct_raw
     FROM accounts a
     LEFT JOIN journal_lines jl ON jl.account_id=a.id
     LEFT JOIN journal_entries je ON je.id=jl.journal_entry_id
          AND je.company_id=a.company_id
          AND ' . posted_status_condition('je') . '
          AND je.entry_date ' . ($basis === 'period' ? 'BETWEEN ? AND ?' : '<= ?') . $closingFilter . '
     WHERE a.company_id=? AND a.is_active=1
     GROUP BY a.id,a.code,a.name_ar,a.parent_id,a.level_no,a.normal_balance,a.is_postable,a.is_active'
);
$params = $basis === 'period' ? [$from, $to] : [$to];
array_push($params, ...$closingFilterParams);
$params[] = company_id();
$stmt->execute($params);
$accounts = $stmt->fetchAll();

$byId = [];
$rawById = [];
foreach ($accounts as $account) {
    $id = (int)$account['id'];
    $account['id'] = $id;
    $account['parent_id'] = $account['parent_id'] !== null ? (int)$account['parent_id'] : null;
    $account['level_no'] = (int)$account['level_no'];
    $byId[$id] = $account;
    $rawById[$id] = (float)$account['direct_raw'];
}

// تجميع الأرصدة من الحسابات الأعمق إلى الحسابات الأب من دون الاعتماد على CTE لضمان التوافق مع XAMPP/MariaDB.
$idsByDepth = array_keys($byId);
usort($idsByDepth, static function (int $a, int $b) use ($byId): int {
    $levelCompare = ((int)$byId[$b]['level_no']) <=> ((int)$byId[$a]['level_no']);
    return $levelCompare !== 0 ? $levelCompare : strnatcmp((string)$byId[$b]['code'], (string)$byId[$a]['code']);
});
foreach ($idsByDepth as $id) {
    $parentId = $byId[$id]['parent_id'];
    if ($parentId !== null && isset($rawById[$parentId])) {
        $rawById[$parentId] += $rawById[$id];
    }
}

$rows = [];
foreach ($byId as $id => $account) {
    $level = (int)$account['level_no'];
    if ($level < 2 || $level > 5) {
        continue;
    }
    $raw = (float)($rawById[$id] ?? 0.0);
    if (!$showZero && abs($raw) < 0.0005) {
        continue;
    }
    $rows[] = $account + [
        'raw' => $raw,
        'debit_balance' => max($raw, 0.0),
        'credit_balance' => max(-$raw, 0.0),
    ];
}
// ترتيب شجري سابق للترتيب الرقمي: يظهر الحساب الأب أولاً، ثم جميع فروعه
// مستوىً بعد مستوى، قبل الانتقال إلى الحساب الشقيق التالي. مثال:
// 11 ثم 111 ثم 1116 ثم 13، وليس 11 ثم 13 ثم 111.
$hierarchyPathCache = [];
$hierarchyPath = static function (int $accountId) use (&$hierarchyPathCache, $byId): array {
    if (isset($hierarchyPathCache[$accountId])) {
        return $hierarchyPathCache[$accountId];
    }

    $path = [];
    $visited = [];
    $currentId = $accountId;
    while (isset($byId[$currentId]) && !isset($visited[$currentId])) {
        $visited[$currentId] = true;
        array_unshift($path, (string)$byId[$currentId]['code']);
        $parentId = $byId[$currentId]['parent_id'];
        if ($parentId === null || !isset($byId[$parentId])) {
            break;
        }
        $currentId = (int)$parentId;
    }

    return $hierarchyPathCache[$accountId] = $path;
};

usort($rows, static function (array $a, array $b) use ($hierarchyPath): int {
    $pathA = $hierarchyPath((int)$a['id']);
    $pathB = $hierarchyPath((int)$b['id']);
    $limit = min(count($pathA), count($pathB));

    for ($i = 0; $i < $limit; $i++) {
        // المقارنة النصية مقصودة هنا؛ لأن رموز الدليل هرمية متسلسلة.
        $comparison = strcmp($pathA[$i], $pathB[$i]);
        if ($comparison !== 0) {
            return $comparison;
        }
    }

    // إذا كان أحد المسارين بادئة للآخر، يظهر الحساب الأب قبل الابن.
    $lengthComparison = count($pathA) <=> count($pathB);
    if ($lengthComparison !== 0) {
        return $lengthComparison;
    }

    return strcmp((string)$a['code'], (string)$b['code']);
});

$totals = [];
foreach ([2, 3, 4, 5] as $level) {
    $totals[$level] = ['debit' => 0.0, 'credit' => 0.0];
}
foreach ($rows as $row) {
    $level = (int)$row['level_no'];
    $totals[$level]['debit'] += (float)$row['debit_balance'];
    $totals[$level]['credit'] += (float)$row['credit_balance'];
}

function tb_balance_display(float $value): string
{
    return abs($value) < 0.0005 ? '' : money($value);
}

if ((string)($_GET['format'] ?? '') === 'csv') {
    require_role(['admin', 'accountant', 'viewer']);
    $filename = 'trial_balance_balances_' . $closingState . '_' . $selectedYear . '_' . str_pad((string)$selectedMonth, 2, '0', STR_PAD_LEFT) . '.csv';
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('X-Content-Type-Options: nosniff');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'wb');
    fputcsv($out, ['المستوى 2 مدين','المستوى 2 دائن','المستوى 3 مدين','المستوى 3 دائن','المستوى 4 مدين','المستوى 4 دائن','المستوى 5 مدين','المستوى 5 دائن','اسم الحساب','دليل 2','دليل 3','دليل 4','دليل 5']);
    foreach ($rows as $row) {
        $level = (int)$row['level_no'];
        $csv = [];
        foreach ([2,3,4,5] as $columnLevel) {
            $csv[] = $level === $columnLevel ? (float)$row['debit_balance'] : '';
            $csv[] = $level === $columnLevel ? (float)$row['credit_balance'] : '';
        }
        $csv[] = (string)$row['name_ar'];
        foreach ([2,3,4,5] as $columnLevel) {
            $csv[] = $level === $columnLevel ? (string)$row['code'] : '';
        }
        fputcsv($out, $csv);
    }
    $totalRow = [];
    foreach ([2,3,4,5] as $level) {
        $totalRow[] = $totals[$level]['debit'];
        $totalRow[] = $totals[$level]['credit'];
    }
    $totalRow[] = 'المجموع';
    array_push($totalRow, '', '', '', '');
    fputcsv($out, $totalRow);
    fclose($out);
    exit;
}

$stateLabel = $closingState === 'after' ? 'بعد الغلق' : 'قبل الغلق';
$stmtClosing = db()->prepare("SELECT COUNT(*) FROM journal_entries WHERE company_id=? AND source_type='closing' AND status='posted' AND entry_date BETWEEN ? AND ?");
$stmtClosing->execute([company_id(), $from, $to]);
$hasPostedClosing = (int)$stmtClosing->fetchColumn() > 0;
render_header('ميزان المراجعة بالأرصدة '.$stateLabel, 'trial_balance_balances');
page_heading(
    'ميزان المراجعة بالأرصدة '.$stateLabel,
    $closingState === 'after' ? 'الأرصدة بعد تضمين قيد الغلق المرحّل.' : 'الأرصدة قبل الغلق مع استبعاد قيود الغلق وآثار عكسها.'
);
$exportUrl = url('trial_balance_balances', [
    'year' => $selectedYear,
    'month' => $selectedMonth,
    'basis' => $basis,
    'closing_state' => $closingState,
    'show_zero' => $showZero ? '1' : '0',
    'format' => 'csv',
]);
$professionalPrintUrl = url('trial_balance_balances', [
    'year' => $selectedYear,
    'month' => $selectedMonth,
    'basis' => $basis,
    'closing_state' => $closingState,
    'show_zero' => $showZero ? '1' : '0',
    'print_view' => '1',
]);
?>
<form class="filters no-print">
    <input type="hidden" name="page" value="trial_balance_balances">
    <div class="field" style="min-width:170px"><label>الشهر</label><select name="month"><?php foreach ($monthNames as $monthNo => $monthName): ?><option value="<?=e((string)$monthNo)?>" <?=$selectedMonth === $monthNo ? 'selected' : ''?>><?=e($monthName)?></option><?php endforeach; ?></select></div>
    <div class="field" style="min-width:120px"><label>السنة</label><select name="year"><?php foreach ($availableYears as $year): ?><option value="<?=e((string)$year)?>" <?=$selectedYear === (int)$year ? 'selected' : ''?>><?=e((string)$year)?></option><?php endforeach; ?></select></div>
    <div class="field" style="min-width:240px"><label>أساس الأرصدة</label><select name="basis"><option value="closing" <?= $basis === 'closing' ? 'selected' : '' ?>>الرصيد الختامي حتى نهاية الشهر المختار</option><option value="period" <?= $basis === 'period' ? 'selected' : '' ?>>صافي حركة الشهر المختار فقط</option></select></div>
    <div class="field" style="min-width:230px"><label>حالة ميزان المراجعة</label><select name="closing_state"><option value="before" <?= $closingState === 'before' ? 'selected' : '' ?>>ميزان المراجعة قبل الغلق</option><option value="after" <?= $closingState === 'after' ? 'selected' : '' ?>>ميزان المراجعة بعد الغلق</option></select></div>
    <label class="check-inline"><input type="checkbox" name="show_zero" value="1" <?= $showZero ? 'checked' : '' ?>> إظهار الحسابات ذات الرصيد الصفري</label>
    <button class="btn btn-primary">عرض</button>
    <a class="btn btn-primary" target="_blank" rel="noopener" href="<?=e($professionalPrintUrl)?>">طباعة احترافية</a>
    <button type="button" class="btn btn-outline print-btn">طباعة سريعة</button>
    <button type="button" class="btn btn-outline excel-export-btn">تصدير Excel</button>
</form>
<div class="trial-balance-state-tabs no-print">
    <a class="btn <?= $closingState === 'before' ? 'btn-primary' : 'btn-outline' ?>" href="<?=e(url('trial_balance_balances',['year'=>$selectedYear,'month'=>$selectedMonth,'basis'=>$basis,'closing_state'=>'before','show_zero'=>$showZero?'1':'0']))?>">قبل الغلق</a>
    <a class="btn <?= $closingState === 'after' ? 'btn-primary' : 'btn-outline' ?>" href="<?=e(url('trial_balance_balances',['year'=>$selectedYear,'month'=>$selectedMonth,'basis'=>$basis,'closing_state'=>'after','show_zero'=>$showZero?'1':'0']))?>">بعد الغلق</a>
</div>
<?php if ($closingState === 'after' && !$hasPostedClosing): ?><div class="alert alert-warning">لا يوجد قيد غلق مرحّل ضمن الشهر المحدد؛ لذلك قد تتطابق أرقام «بعد الغلق» مع «قبل الغلق».</div><?php endif; ?>

<div class="card balance-trial-card">
    <div class="report-head balance-report-head">
        <h2><?= e((string)(company()['name_ar'] ?? '')) ?></h2>
        <h2>ميزان المراجعة بالأرصدة <?= e($stateLabel) ?></h2>
        <p>شهر <?= e($selectedMonthName) ?> / <?= e((string)$selectedYear) ?></p>
        <small><?= $basis === 'closing' ? 'الأرصدة الختامية للقيود المرحلة حتى نهاية الشهر المختار' : 'صافي حركات القيود المرحلة ضمن الشهر المحدد' ?> — <?= e($stateLabel) ?></small>
    </div>
    <div class="table-wrap balance-trial-wrap" style="box-shadow:none">
        <table class="balance-trial-table">
            <thead>
                <tr>
                    <?php foreach ([2,3,4,5] as $level): ?>
                        <th colspan="2" class="balance-level-head">المستوى <?= $level ?></th>
                    <?php endforeach; ?>
                    <th rowspan="2" class="balance-account-name">اسم الحساب</th>
                    <th colspan="4" class="balance-guide-head">الدليل المحاسبي</th>
                </tr>
                <tr>
                    <?php foreach ([2,3,4,5] as $level): ?>
                        <th>مدين</th><th>دائن</th>
                    <?php endforeach; ?>
                    <?php foreach ([2,3,4,5] as $level): ?><th class="balance-code-head"><?= $level ?></th><?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (!$rows): ?>
                    <tr><td colspan="13" class="empty">لا توجد أرصدة ضمن المعايير المحددة.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $row): $rowLevel = (int)$row['level_no']; ?>
                        <tr class="balance-level-row balance-level-<?= $rowLevel ?>">
                            <?php foreach ([2,3,4,5] as $level): ?>
                                <td class="num balance-amount"><?= $rowLevel === $level ? e(tb_balance_display((float)$row['debit_balance'])) : '' ?></td>
                                <td class="num balance-amount"><?= $rowLevel === $level ? e(tb_balance_display((float)$row['credit_balance'])) : '' ?></td>
                            <?php endforeach; ?>
                            <td class="balance-account-cell level-indent-<?= $rowLevel ?>"><?= e((string)$row['name_ar']) ?></td>
                            <?php foreach ([2,3,4,5] as $level): ?>
                                <td class="balance-code-cell"><?= $rowLevel === $level ? '<span class="code">' . e((string)$row['code']) . '</span>' : '' ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="balance-grand-total">
                        <?php foreach ([2,3,4,5] as $level): ?>
                            <td class="num"><?= e(money($totals[$level]['debit'])) ?></td>
                            <td class="num"><?= e(money($totals[$level]['credit'])) ?></td>
                        <?php endforeach; ?>
                        <td>المجموع</td><td colspan="4"></td>
                    </tr>
                    <tr class="balance-difference-row no-print">
                        <?php foreach ([2,3,4,5] as $level): $difference = $totals[$level]['debit'] - $totals[$level]['credit']; ?>
                            <td colspan="2" class="<?= abs($difference) < .0005 ? 'balanced' : 'unbalanced' ?>">فرق <?= $level ?>: <?= e(money($difference)) ?></td>
                        <?php endforeach; ?>
                        <td colspan="5">تُراجع الفروق في المستوى الذي لا يتوازن، وقد تنتج عن توقف بعض فروع الدليل عند مستوى أعلى من الخامس.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="balance-signatures">
        <div><span>المنظم</span><i></i></div>
        <div><span>المحاسب</span><i></i></div>
        <div><span>المدقق</span><i></i></div>
        <div><span>مدير الحسابات</span><i></i></div>
        <div><span>رئيس الدائرة</span><i></i></div>
    </div>
</div>
<div class="programmer-print">المبرمج: م. أرشد حميد حسن • واتساب: 07735882844</div>
<?php render_footer(); ?>
