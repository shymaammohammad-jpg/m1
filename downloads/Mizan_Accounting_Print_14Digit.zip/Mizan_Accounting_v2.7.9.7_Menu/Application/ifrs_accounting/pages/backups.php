<?php
declare(strict_types=1);
require_role('admin');
$files = list_backup_files();
$uploadLimit = backup_restore_upload_limit();
render_header('النسخ الاحتياطية والاستعادة', 'backups');
page_heading(
    'النسخ الاحتياطية والاستعادة',
    'إنشاء نسخ SQL وتنزيلها أو استعادتها للمؤسسة الحالية فقط. لكل مؤسسة مجلد نسخ احتياطية مستقل.'
);
?>
<div class="grid grid-2" style="margin-bottom:18px">
    <form method="post" class="card">
        <input type="hidden" name="action" value="backup_create"><?= csrf_field() ?>
        <h3 class="card-title">إنشاء نسخة جديدة</h3>
        <p class="muted small">يحفظ النظام نسخة SQL كاملة داخل مجلد محمي، ثم يمكنك تنزيلها إلى جهاز آخر.</p>
        <button class="btn btn-primary" data-confirm="إنشاء نسخة احتياطية كاملة الآن؟">إنشاء نسخة احتياطية</button>
    </form>
    <div class="card">
        <h3 class="card-title">سياسة موصى بها</h3>
        <div class="step-list">
            <div>نسخة يومية أثناء الإدخال الكثيف.</div>
            <div>نسخة قبل تعديل القيود المرحلة أو إغلاق الفترة.</div>
            <div>حفظ نسخة خارج جهاز XAMPP.</div>
            <div>ينشئ النظام نسخة وقائية تلقائياً قبل كل استعادة.</div>
        </div>
    </div>
</div>

<div class="card backup-restore-card" style="margin-bottom:18px">
    <h3 class="card-title">استيراد نسخة احتياطية من الجهاز</h3>
    <div class="alert alert-warning">
        الاستعادة تستبدل قاعدة بيانات المؤسسة الحالية بالكامل. النسخ الجديدة تحمل هوية المؤسسة، ويمنع النظام استعادة نسخة مؤسسة أخرى بالخطأ. يتحقق النظام من الملف في قاعدة مؤقتة أولاً ثم ينشئ نسخة وقائية تلقائياً.
    </div>
    <form method="post" enctype="multipart/form-data" class="restore-form">
        <input type="hidden" name="action" value="backup_restore_upload"><?= csrf_field() ?>
        <input type="hidden" name="MAX_FILE_SIZE" value="<?= e((string)$uploadLimit) ?>">
        <div class="field restore-file-field">
            <label>ملف النسخة الاحتياطية SQL</label>
            <input type="file" name="backup_file" accept=".sql,text/plain,application/sql" required>
            <small>الحد الأقصى المسموح: <?= e(format_bytes($uploadLimit)) ?></small>
        </div>
        <div class="field">
            <label>كلمة مرور مدير النظام</label>
            <input type="password" name="admin_password" autocomplete="current-password" required>
        </div>
        <div class="field">
            <label>اكتب كلمة «استعادة» للتأكيد</label>
            <input name="restore_confirmation" autocomplete="off" placeholder="استعادة" required>
        </div>
        <button class="btn btn-danger" data-confirm="سيتم استبدال قاعدة البيانات الحالية بعد إنشاء نسخة وقائية. هل تريد المتابعة؟">رفع الملف واستعادة البيانات</button>
    </form>
</div>

<div class="card">
    <h3 class="card-title">النسخ المحفوظة داخل النظام</h3>
    <?php if (!$files): ?><div class="empty">لا توجد نسخ احتياطية بعد.</div><?php endif; ?>
    <?php foreach ($files as $file): ?>
        <div class="backup-card backup-card-expanded">
            <div>
                <strong class="code"><?= e($file['filename']) ?></strong>
                <div class="small muted"><?= e($file['modified_at']) ?> • <?= e(format_bytes((int)$file['size'])) ?></div>
            </div>
            <div class="row-actions">
                <a class="btn btn-sm btn-outline" href="<?= e(url('backup_download', ['file' => $file['filename']])) ?>">تنزيل</a>
                <details class="restore-details">
                    <summary class="btn btn-sm btn-warning">استعادة</summary>
                    <form method="post" class="restore-inline-form">
                        <input type="hidden" name="action" value="backup_restore_saved">
                        <input type="hidden" name="filename" value="<?= e($file['filename']) ?>"><?= csrf_field() ?>
                        <div class="field"><label>كلمة مرور المدير</label><input type="password" name="admin_password" autocomplete="current-password" required></div>
                        <div class="field"><label>اكتب «استعادة»</label><input name="restore_confirmation" placeholder="استعادة" autocomplete="off" required></div>
                        <button class="btn btn-sm btn-danger" data-confirm="سيتم استبدال قاعدة البيانات الحالية بهذه النسخة بعد إنشاء نسخة وقائية. هل أنت متأكد؟">تنفيذ الاستعادة</button>
                    </form>
                </details>
                <form method="post">
                    <input type="hidden" name="action" value="backup_delete">
                    <input type="hidden" name="filename" value="<?= e($file['filename']) ?>"><?= csrf_field() ?>
                    <button class="btn btn-sm btn-danger" data-confirm="حذف النسخة الاحتياطية من الخادم؟">حذف</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?php render_footer(); ?>
