@echo off
setlocal
set "APP_URL=http://localhost/ifrs_accounting/"
set "XAMPP=C:\xampp"

if exist "%XAMPP%\apache_start.bat" start "Apache" /min "%XAMPP%\apache_start.bat"
if exist "%XAMPP%\mysql_start.bat" start "MySQL" /min "%XAMPP%\mysql_start.bat"

timeout /t 6 /nobreak >nul
start "" "%APP_URL%"
endlocal
