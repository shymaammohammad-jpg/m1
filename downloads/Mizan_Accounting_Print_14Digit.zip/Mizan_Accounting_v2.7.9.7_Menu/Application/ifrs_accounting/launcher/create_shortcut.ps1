param(
    [Parameter(Mandatory=$true)][string]$LauncherPath,
    [Parameter(Mandatory=$false)][string]$IconPath = ''
)
$ErrorActionPreference = 'Stop'

# The shortcut points at cmd.exe running the launcher script, so no executable
# is shipped or installed and Windows Defender has nothing to flag.
if (-not (Test-Path -LiteralPath $LauncherPath)) {
    throw "Mizan launcher script not found: $LauncherPath"
}

$launcher = (Resolve-Path -LiteralPath $LauncherPath).Path
$workingDirectory = Split-Path -Parent $launcher
$comspec = Join-Path $env:SystemRoot 'System32\cmd.exe'
if (-not (Test-Path -LiteralPath $comspec)) { $comspec = 'cmd.exe' }

if ([string]::IsNullOrWhiteSpace($IconPath) -or -not (Test-Path -LiteralPath $IconPath)) {
    $IconPath = $comspec
}

$targets = New-Object System.Collections.Generic.List[string]
$publicDesktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
$userDesktop = [Environment]::GetFolderPath('Desktop')
$commonPrograms = [Environment]::GetFolderPath('CommonPrograms')
$userPrograms = [Environment]::GetFolderPath('Programs')

if ($publicDesktop) { $targets.Add((Join-Path $publicDesktop 'نظام الميزان المحاسبي.lnk')) }
if ($userDesktop) { $targets.Add((Join-Path $userDesktop 'نظام الميزان المحاسبي.lnk')) }
if ($commonPrograms) { $targets.Add((Join-Path $commonPrograms 'نظام الميزان المحاسبي.lnk')) }
if ($userPrograms) { $targets.Add((Join-Path $userPrograms 'نظام الميزان المحاسبي.lnk')) }

$ws = New-Object -ComObject WScript.Shell
$created = 0
foreach ($shortcutPath in ($targets | Select-Object -Unique)) {
    try {
        if (Test-Path -LiteralPath $shortcutPath) {
            Remove-Item -LiteralPath $shortcutPath -Force -ErrorAction SilentlyContinue
        }
        $shortcut = $ws.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $comspec
        $shortcut.Arguments = '/d /c ""' + $launcher + '""'
        $shortcut.WorkingDirectory = $workingDirectory
        $shortcut.IconLocation = $IconPath + ',0'
        $shortcut.WindowStyle = 7
        $shortcut.Description = 'نظام الميزان المحاسبي 2.7.9.7'
        $shortcut.Save()
        if (Test-Path -LiteralPath $shortcutPath) { $created++ }
    } catch {
        # Continue so a restricted public desktop does not prevent user-desktop creation.
    }
}

if ($created -lt 1) {
    throw 'No desktop or Start Menu shortcut could be created.'
}
