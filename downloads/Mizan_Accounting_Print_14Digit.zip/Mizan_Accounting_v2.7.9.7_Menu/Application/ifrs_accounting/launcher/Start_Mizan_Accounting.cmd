@echo off
setlocal EnableExtensions
chcp 65001 >NUL
set "APP_URL=http://localhost/ifrs_accounting/"
set "XAMPP_PATH="

rem Prefer the exact XAMPP path saved by the installer when this launcher is in Program Files.
if exist "%~dp0XamppPath.txt" (
  set /p "XAMPP_PATH="<"%~dp0XamppPath.txt"
)

rem When launched from the application folder, derive C:\xampp-style path from launcher location.
if not defined XAMPP_PATH (
  set "XAMPP_PATH=%~dp0..\..\.."
  for %%I in ("%XAMPP_PATH%") do set "XAMPP_PATH=%%~fI"
)

rem Fallback scan for common XAMPP installations.
if not exist "%XAMPP_PATH%\xampp-control.exe" (
  set "XAMPP_PATH="
  for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
    if not defined XAMPP_PATH if exist "%%D:\xampp\xampp-control.exe" set "XAMPP_PATH=%%D:\xampp"
  )
)

if not exist "%XAMPP_PATH%\xampp-control.exe" (
  echo.
  echo XAMPP was not found.
  echo Start XAMPP manually, then open:
  echo %APP_URL%
  echo.
  pause
  exit /b 1
)

tasklist /FI "IMAGENAME eq httpd.exe" 2>NUL | find /I "httpd.exe" >NUL
if errorlevel 1 if exist "%XAMPP_PATH%\apache_start.bat" start "Apache" /min "%XAMPP_PATH%\apache_start.bat"

tasklist /FI "IMAGENAME eq mysqld.exe" 2>NUL | find /I "mysqld.exe" >NUL
if errorlevel 1 if exist "%XAMPP_PATH%\mysql_start.bat" start "MySQL" /min "%XAMPP_PATH%\mysql_start.bat"

timeout /t 5 /nobreak >NUL
start "" "%APP_URL%"
endlocal
