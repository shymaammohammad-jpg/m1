@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >NUL
color 1F
title Mizan Accounting Setup 2.7.9.7

echo ===============================================================
echo        Mizan Accounting System 2.7.9.7 - Script Installer (no EXE)
echo ===============================================================
echo.

set "SOURCE=%~dp0Application\ifrs_accounting"
if not exist "%SOURCE%\index.php" (
  echo ERROR: Application files are missing.
  echo Extract the complete ZIP package, then run START_INSTALL.cmd again.
  pause
  exit /b 10
)
if not exist "%SOURCE%\launcher\Start_Mizan_Accounting.cmd" (
  echo ERROR: Start_Mizan_Accounting.cmd is missing from the package.
  pause
  exit /b 13
)

rem ---------------------------------------------------------------
rem Administrator check. Installing under Program Files needs it;
rem without it we fall back to a per-user folder that needs no rights.
rem ---------------------------------------------------------------
set "IS_ADMIN=0"
net session >NUL 2>&1 && set "IS_ADMIN=1"

if "%IS_ADMIN%"=="0" if /I not "%~1"=="/user" (
  echo Requesting administrator permission...
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "try { Start-Process -FilePath '%~f0' -WorkingDirectory '%~dp0' -Verb RunAs -ErrorAction Stop; exit 0 } catch { exit 1 }"
  if not errorlevel 1 exit /b 0
  echo.
  echo Administrator permission was not granted.
  echo Continuing with a per-user installation instead.
  echo.
)

set "XAMPP_PATH="
for %%D in (C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (
  if not defined XAMPP_PATH if exist "%%D:\xampp\xampp-control.exe" set "XAMPP_PATH=%%D:\xampp"
)

if not defined XAMPP_PATH (
  echo XAMPP was not detected automatically.
  set /p "XAMPP_PATH=Enter the XAMPP folder, for example C:\xampp: "
)

if not exist "%XAMPP_PATH%\xampp-control.exe" (
  echo ERROR: xampp-control.exe was not found in:
  echo %XAMPP_PATH%
  pause
  exit /b 11
)

set "TARGET=%XAMPP_PATH%\htdocs\ifrs_accounting"
set "BACKUP=%XAMPP_PATH%\htdocs\ifrs_accounting_backup_before_2.7.9.1_%RANDOM%"
set "PRESERVE=%TEMP%\MizanPreserve_%RANDOM%"
if "%IS_ADMIN%"=="1" (
  set "PROGRAM_DIR=%ProgramFiles%\Mizan Accounting"
) else (
  set "PROGRAM_DIR=%LOCALAPPDATA%\Mizan Accounting"
)
set "PROGRAM_LAUNCHER=%PROGRAM_DIR%\Start_Mizan_Accounting.cmd"
set "PROGRAM_ICON=%PROGRAM_DIR%\Mizan_Accounting_Icon.ico"
mkdir "%PRESERVE%" >NUL 2>&1

if exist "%TARGET%\index.php" (
  echo Creating a safety backup...
  robocopy "%TARGET%" "%BACKUP%" /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS >NUL
  if exist "%TARGET%\config.php" copy /Y "%TARGET%\config.php" "%PRESERVE%\config.php" >NUL
  if exist "%TARGET%\storage" robocopy "%TARGET%\storage" "%PRESERVE%\storage" /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS >NUL
)

if not exist "%TARGET%" mkdir "%TARGET%"
echo Copying application files...
robocopy "%SOURCE%" "%TARGET%" /E /COPY:DAT /R:2 /W:1 /NFL /NDL /NJH /NJS >NUL
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo ERROR: File copy failed. Robocopy code: %RC%
  pause
  exit /b 12
)

if exist "%PRESERVE%\config.php" copy /Y "%PRESERVE%\config.php" "%TARGET%\config.php" >NUL
if exist "%PRESERVE%\storage" robocopy "%PRESERVE%\storage" "%TARGET%\storage" /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS >NUL
rmdir /S /Q "%PRESERVE%" >NUL 2>&1

rem Install the launcher script in Program Files. No EXE is deployed, so
rem Windows Defender has nothing to quarantine.
if not exist "!PROGRAM_DIR!" mkdir "!PROGRAM_DIR!" >NUL 2>&1
copy /Y "%SOURCE%\launcher\Start_Mizan_Accounting.cmd" "!PROGRAM_LAUNCHER!" >NUL 2>&1
if errorlevel 1 (
  echo Could not write to: !PROGRAM_DIR!
  echo Falling back to a per-user folder that needs no administrator rights.
  set "PROGRAM_DIR=%LOCALAPPDATA%\Mizan Accounting"
  set "PROGRAM_LAUNCHER=%LOCALAPPDATA%\Mizan Accounting\Start_Mizan_Accounting.cmd"
  set "PROGRAM_ICON=%LOCALAPPDATA%\Mizan Accounting\Mizan_Accounting_Icon.ico"
  if not exist "!PROGRAM_DIR!" mkdir "!PROGRAM_DIR!" >NUL 2>&1
  copy /Y "%SOURCE%\launcher\Start_Mizan_Accounting.cmd" "!PROGRAM_LAUNCHER!" >NUL 2>&1
  if errorlevel 1 (
    echo ERROR: Could not install the launcher in either location.
    echo You can still use the system at: http://localhost/ifrs_accounting/
    pause
    exit /b 14
  )
)
copy /Y "%SOURCE%\launcher\app_icon.ico" "!PROGRAM_ICON!" >NUL 2>&1
>"!PROGRAM_DIR!\XamppPath.txt" echo %XAMPP_PATH%

rem Remove the old EXE launcher left by earlier versions, if present.
if exist "!PROGRAM_DIR!\MizanAccounting.exe" del /F /Q "!PROGRAM_DIR!\MizanAccounting.exe" >NUL 2>&1
if exist "%ProgramFiles%\Mizan Accounting\MizanAccounting.exe" del /F /Q "%ProgramFiles%\Mizan Accounting\MizanAccounting.exe" >NUL 2>&1

if not exist "!PROGRAM_LAUNCHER!" (
  echo ERROR: The installed launcher could not be verified.
  pause
  exit /b 15
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create_Mizan_Shortcut.ps1" -LauncherPath "!PROGRAM_LAUNCHER!" -IconPath "!PROGRAM_ICON!"
if errorlevel 1 (
  echo WARNING: The desktop shortcut could not be created automatically.
  echo You can start the program from:
  echo !PROGRAM_LAUNCHER!
)

>"%TARGET%\INSTALLATION_2.7.9.1_CLEAN.txt" echo Installed from corrected EXE package v2.7.9.1 on %DATE% %TIME%
>"!PROGRAM_DIR!\INSTALL_LOCATION.txt" (
  echo Mizan Accounting 2.7.9.7
  echo Launcher: !PROGRAM_LAUNCHER!
  echo Web application: %TARGET%
  echo XAMPP: %XAMPP_PATH%
)

echo.
echo Installation completed successfully.
echo Program launcher: !PROGRAM_LAUNCHER!
echo Application folder: %TARGET%
echo Backup folder: %BACKUP%
echo.

if exist "%XAMPP_PATH%\apache_start.bat" start "Apache" /min "%XAMPP_PATH%\apache_start.bat"
if exist "%XAMPP_PATH%\mysql_start.bat" start "MySQL" /min "%XAMPP_PATH%\mysql_start.bat"
timeout /t 5 /nobreak >NUL
start "" "http://localhost/ifrs_accounting/"

pause
endlocal
