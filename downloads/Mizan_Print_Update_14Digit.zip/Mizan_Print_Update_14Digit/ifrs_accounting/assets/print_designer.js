(() => {
  'use strict';

  const panel = document.getElementById('printDesignerPanel');
  const overlay = document.getElementById('printDesignerOverlay');
  const openButton = document.getElementById('printDesignerOpen');
  if (!panel || !overlay || !openButton) return;

  const root = document.documentElement;
  const body = document.body;
  const pageName = new URLSearchParams(window.location.search).get('page') || 'dashboard';
  const detectedTemplate = String(body.dataset.printTemplate || '').trim();
  const templateFromPage = ({
    journal_new: 'journal-voucher', cash_voucher: 'payment-voucher', ledger: 'ledger', bank_reconciliation: 'bank-reconciliation', general_journal_assistant: 'assistant-journal',
  })[pageName] || '';
  const fixedTemplate = detectedTemplate || templateFromPage || (
    document.querySelector('.official-payment-voucher') ? 'payment-voucher' :
    document.querySelector('.excel-voucher-sheet') ? 'journal-voucher' :
    document.querySelector('.excel-ledger-sheet') ? 'ledger' :
    document.querySelector('.bank-reconciliation-sheet') ? 'bank-reconciliation' :
    document.querySelector('.assistant-journal-sheet') ? 'assistant-journal' : ''
  );
  const fixedPresets = {
    'journal-voucher': { pageSize:'A4', orientation:'portrait', margins:[7,7,7,7], fontSize:11, titleSize:16, tableFontSize:10.5, tableHeaderSize:12, lineHeight:1.12, scale:100, namedPage:'journalVoucherPage', sheet:'.excel-voucher-sheet' },
    'payment-voucher': { pageSize:'A4', orientation:'landscape', margins:[7,7,7,7], fontSize:10.5, titleSize:15, tableFontSize:9.5, tableHeaderSize:10, lineHeight:1.08, scale:100, namedPage:'paymentVoucherPage', sheet:'.official-payment-voucher' },
    'ledger': { pageSize:'A4', orientation:'landscape', margins:[8,8,8,8], fontSize:11, titleSize:16, tableFontSize:10.5, tableHeaderSize:11.5, lineHeight:1.1, scale:100, namedPage:'ledgerPage', sheet:'.excel-ledger-sheet' },
    'bank-reconciliation': { pageSize:'A4', orientation:'landscape', margins:[7,7,7,7], fontSize:10.5, titleSize:13, tableFontSize:9.5, tableHeaderSize:10, lineHeight:1.05, scale:100, namedPage:'bankReconciliationPage', sheet:'.bank-reconciliation-sheet' },
    'assistant-journal': { pageSize:'A3', orientation:'landscape', margins:[7,7,7,7], fontSize:7.5, titleSize:14, tableFontSize:7.5, tableHeaderSize:7.5, lineHeight:1, scale:100, namedPage:'assistantJournalPage', sheet:'.assistant-journal-sheet' },
  };
  const fixedPreset = fixedPresets[fixedTemplate] || null;
  const hasFixedPrintForm = Boolean(fixedPreset);
  if (hasFixedPrintForm) body.classList.add('fixed-print-form', 'fixed-print-controls');
  const storagePrefix = hasFixedPrintForm ? 'ifrs-print-designer-v2791-fixed' : 'ifrs-print-designer-v2791';
  const globalKey = `${storagePrefix}:global`;
  const pageKey = `${storagePrefix}:page:${pageName}`;
  const tableKey = `${storagePrefix}:tables:${pageName}`;

  const controls = Object.fromEntries(
    Array.from(panel.querySelectorAll('[data-print-setting]')).map((input) => [input.dataset.printSetting, input])
  );

  if (hasFixedPrintForm) {
    panel.querySelector('.pd-help')?.setAttribute('data-fixed-form', fixedTemplate);
    const heading = panel.querySelector('.pd-panel-head p');
    if (heading) heading.textContent = 'ضبط آمن للنموذج الرسمي: الخط، الحجم، الورق، الهوامش، المقياس والإزاحة';
  }

  const wideRegister = ['general_journal', 'trial_balance_balances'].includes(pageName);
  const defaults = {
    pageSize: fixedPreset?.pageSize || (wideRegister ? 'A3' : 'A4'),
    orientation: fixedPreset?.orientation || (wideRegister || document.querySelector('.content table')?.scrollWidth > 1000 ? 'landscape' : 'portrait'),
    marginTop: fixedPreset?.margins?.[0] ?? 7,
    marginRight: fixedPreset?.margins?.[1] ?? 7,
    marginBottom: fixedPreset?.margins?.[2] ?? 7,
    marginLeft: fixedPreset?.margins?.[3] ?? 7,
    fontFamily: 'Cairo',
    fontSize: fixedPreset?.fontSize ?? 11,
    lineHeight: fixedPreset?.lineHeight ?? 1.25,
    titleSize: fixedPreset?.titleSize ?? 18,
    tableFontSize: fixedPreset?.tableFontSize ?? 9,
    tableHeaderSize: fixedPreset?.tableHeaderSize ?? 9,
    cellPaddingX: 4,
    cellPaddingY: 3,
    rowMinHeight: 24,
    scale: fixedPreset?.scale ?? 100,
    offsetX: 0,
    offsetY: 0,
    centerContent: true,
    showReportHeader: true,
    showFooter: hasFixedPrintForm ? false : true,
    repeatTableHeader: true,
    printBackground: true,
  };

  const safeParse = (value, fallback = {}) => {
    try {
      const parsed = JSON.parse(value || '');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : fallback;
    } catch (_) {
      return fallback;
    }
  };

  const clamp = (value, min, max, fallback) => {
    const number = Number(value);
    return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
  };

  const sanitizeSettings = (raw) => ({
    pageSize: ['A4', 'A3', 'Letter', 'Legal'].includes(raw.pageSize) ? raw.pageSize : defaults.pageSize,
    orientation: ['portrait', 'landscape'].includes(raw.orientation) ? raw.orientation : defaults.orientation,
    marginTop: clamp(raw.marginTop, 0, 50, defaults.marginTop),
    marginRight: clamp(raw.marginRight, 0, 50, defaults.marginRight),
    marginBottom: clamp(raw.marginBottom, 0, 50, defaults.marginBottom),
    marginLeft: clamp(raw.marginLeft, 0, 50, defaults.marginLeft),
    fontFamily: String(raw.fontFamily || defaults.fontFamily).slice(0, 80),
    fontSize: clamp(raw.fontSize, 7, 28, defaults.fontSize),
    lineHeight: clamp(raw.lineHeight, 0.8, 3, defaults.lineHeight),
    titleSize: clamp(raw.titleSize, 10, 40, defaults.titleSize),
    tableFontSize: clamp(raw.tableFontSize, 5, 24, defaults.tableFontSize),
    tableHeaderSize: clamp(raw.tableHeaderSize, 5, 24, defaults.tableHeaderSize),
    cellPaddingX: clamp(raw.cellPaddingX, 0, 30, defaults.cellPaddingX),
    cellPaddingY: clamp(raw.cellPaddingY, 0, 30, defaults.cellPaddingY),
    rowMinHeight: clamp(raw.rowMinHeight, 10, 120, defaults.rowMinHeight),
    scale: clamp(raw.scale, 40, 150, defaults.scale),
    offsetX: clamp(raw.offsetX, -25, 25, defaults.offsetX),
    offsetY: clamp(raw.offsetY, -25, 25, defaults.offsetY),
    centerContent: raw.centerContent !== false,
    showReportHeader: raw.showReportHeader !== false,
    showFooter: raw.showFooter !== false,
    repeatTableHeader: raw.repeatTableHeader !== false,
    printBackground: raw.printBackground !== false,
  });

  let settings = sanitizeSettings({
    ...defaults,
    ...safeParse(localStorage.getItem(globalKey)),
    ...safeParse(localStorage.getItem(pageKey)),
  });

  let resizeMode = false;
  let tableLayouts = safeParse(localStorage.getItem(tableKey));
  let activeDrag = null;

  const dynamicStyle = document.createElement('style');
  dynamicStyle.id = 'ifrsDynamicPrintStyle';
  document.head.appendChild(dynamicStyle);

  const cssFont = (name) => `'${String(name).replace(/[\\']/g, '')}', Tahoma, Arial, sans-serif`;

  const updateRangeLabels = () => {
    panel.querySelectorAll('[data-range-output]').forEach((output) => {
      const input = controls[output.dataset.rangeOutput];
      if (!input) return;
      const suffix = output.dataset.suffix || '';
      output.textContent = `${input.value}${suffix}`;
    });
  };

  const readControls = () => {
    const raw = {};
    Object.entries(controls).forEach(([key, input]) => {
      raw[key] = input.type === 'checkbox' ? input.checked : input.value;
    });
    return sanitizeSettings(raw);
  };

  const writeControls = () => {
    Object.entries(controls).forEach(([key, input]) => {
      if (!(key in settings)) return;
      if (input.type === 'checkbox') input.checked = Boolean(settings[key]);
      else input.value = String(settings[key]);
    });
    updateRangeLabels();
  };

  const applySettings = (preview = panel.classList.contains('open')) => {
    settings = sanitizeSettings(settings);
    root.style.setProperty('--pd-font-family', cssFont(settings.fontFamily));
    root.style.setProperty('--pd-font-size', `${settings.fontSize}px`);
    root.style.setProperty('--pd-line-height', String(settings.lineHeight));
    root.style.setProperty('--pd-title-size', `${settings.titleSize}px`);
    root.style.setProperty('--pd-table-font-size', `${settings.tableFontSize}px`);
    root.style.setProperty('--pd-table-header-size', `${settings.tableHeaderSize}px`);
    root.style.setProperty('--pd-cell-padding-x', `${settings.cellPaddingX}px`);
    root.style.setProperty('--pd-cell-padding-y', `${settings.cellPaddingY}px`);
    root.style.setProperty('--pd-row-min-height', `${settings.rowMinHeight}px`);
    root.style.setProperty('--pd-scale', String(settings.scale / 100));
    root.style.setProperty('--pd-offset-x-mm', `${settings.offsetX}mm`);
    root.style.setProperty('--pd-offset-y-mm', `${settings.offsetY}mm`);
    if (hasFixedPrintForm) {
      root.style.setProperty('--pd-fixed-font-factor', String(settings.fontSize / fixedPreset.fontSize));
      root.style.setProperty('--pd-fixed-title-factor', String(settings.titleSize / fixedPreset.titleSize));
      root.style.setProperty('--pd-fixed-table-factor', String(settings.tableFontSize / fixedPreset.tableFontSize));
      root.style.setProperty('--pd-fixed-header-factor', String(settings.tableHeaderSize / fixedPreset.tableHeaderSize));
    }

    body.classList.toggle('print-preview-active', Boolean(preview));
    body.classList.toggle('pd-hide-report-header', !settings.showReportHeader);
    body.classList.toggle('pd-show-footer', settings.showFooter);
    body.classList.toggle('pd-repeat-table-header', settings.repeatTableHeader);
    body.classList.toggle('pd-print-background', settings.printBackground);
    body.classList.toggle('pd-center-content', settings.centerContent);

    const pageSize = `${settings.pageSize} ${settings.orientation}`;
    const pageRule = hasFixedPrintForm ? `@page ${fixedPreset.namedPage}` : '@page';
    const scaleRule = hasFixedPrintForm
      ? `${fixedPreset.sheet} { zoom: ${settings.scale / 100}; position: relative; left: ${settings.offsetX}mm; top: ${settings.offsetY}mm; }`
      : `.content { zoom: ${settings.scale / 100}; }`;
    dynamicStyle.textContent = `
      ${pageRule} {
        size: ${pageSize};
        margin: ${settings.marginTop}mm ${settings.marginRight}mm ${settings.marginBottom}mm ${settings.marginLeft}mm;
      }
      @media print {
        html, body { font-family: ${cssFont(settings.fontFamily)} !important; font-size: ${settings.fontSize}px !important; line-height: ${settings.lineHeight} !important; }
        ${scaleRule}
      }
    `;
    const printOptions = {
      pageSize: settings.pageSize,
      orientation: settings.orientation,
      margins: [settings.marginTop, settings.marginRight, settings.marginBottom, settings.marginLeft],
    };
    window.MizanPrecisionPrintOptions = printOptions;
    body.dataset.printPaper = printOptions.pageSize;
    body.dataset.printOrientation = printOptions.orientation;
    body.dataset.printMargins = JSON.stringify(printOptions.margins);
    window.MizanPrecisionPrint?.schedule(printOptions);
  };

  const open = () => {
    writeControls();
    panel.hidden = false;
    overlay.hidden = false;
    requestAnimationFrame(() => {
      panel.classList.add('open');
      overlay.classList.add('open');
      panel.setAttribute('aria-hidden', 'false');
      applySettings(true);
    });
  };

  const close = () => {
    panel.classList.remove('open');
    overlay.classList.remove('open');
    panel.setAttribute('aria-hidden', 'true');
    body.classList.remove('print-preview-active');
    setTimeout(() => {
      panel.hidden = true;
      overlay.hidden = true;
    }, 180);
  };

  const savePage = () => {
    settings = readControls();
    localStorage.setItem(pageKey, JSON.stringify(settings));
    applySettings(true);
    showStatus('تم حفظ إعدادات الطباعة لهذه الصفحة.');
  };

  const saveGlobal = () => {
    settings = readControls();
    localStorage.setItem(globalKey, JSON.stringify(settings));
    applySettings(true);
    showStatus('تم اعتماد الإعدادات افتراضياً لجميع الصفحات.');
  };

  const resetSettings = () => {
    localStorage.removeItem(pageKey);
    settings = sanitizeSettings({ ...defaults, ...safeParse(localStorage.getItem(globalKey)) });
    writeControls();
    applySettings(true);
    showStatus('تمت إعادة إعدادات هذه الصفحة إلى القيم الافتراضية.');
  };

  const showStatus = (message, isError = false) => {
    const status = document.getElementById('printDesignerStatus');
    if (!status) return;
    status.textContent = message;
    status.classList.toggle('error', isError);
    status.classList.add('show');
    clearTimeout(showStatus.timer);
    showStatus.timer = setTimeout(() => status.classList.remove('show'), 2600);
  };

  const tableId = (table, index) => {
    if (table.dataset.printDesignerKey) return table.dataset.printDesignerKey;
    const base = table.id || table.dataset.excelSheet || Array.from(table.classList).filter((c) => !c.startsWith('pd-')).slice(0, 2).join('-') || 'table';
    table.dataset.printDesignerKey = `${index}-${base}`.replace(/[^a-zA-Z0-9_-]/g, '_');
    return table.dataset.printDesignerKey;
  };

  const logicalColumnCount = (table) => {
    let max = 0;
    Array.from(table.rows).forEach((row) => {
      const count = Array.from(row.cells).reduce((sum, cell) => sum + Math.max(1, Number(cell.colSpan || 1)), 0);
      max = Math.max(max, count);
    });
    return max;
  };

  const ensureColgroup = (table, count) => {
    let colgroup = table.querySelector(':scope > colgroup.pd-colgroup');
    if (!colgroup) {
      colgroup = document.createElement('colgroup');
      colgroup.className = 'pd-colgroup';
      table.insertBefore(colgroup, table.firstChild);
    }
    while (colgroup.children.length < count) colgroup.appendChild(document.createElement('col'));
    while (colgroup.children.length > count) colgroup.lastElementChild?.remove();
    return colgroup;
  };

  const headerCellMap = (table) => {
    const head = table.tHead;
    if (!head || !head.rows.length) return [];
    const grid = [];
    const mapped = [];
    Array.from(head.rows).forEach((row, rowIndex) => {
      grid[rowIndex] ||= [];
      let colIndex = 0;
      Array.from(row.cells).forEach((cell) => {
        while (grid[rowIndex][colIndex]) colIndex++;
        const rowSpan = Math.max(1, Number(cell.rowSpan || 1));
        const colSpan = Math.max(1, Number(cell.colSpan || 1));
        for (let rr = rowIndex; rr < rowIndex + rowSpan; rr++) {
          grid[rr] ||= [];
          for (let cc = colIndex; cc < colIndex + colSpan; cc++) grid[rr][cc] = cell;
        }
        if (rowIndex + rowSpan >= head.rows.length) mapped.push({ cell, start: colIndex, span: colSpan });
        colIndex += colSpan;
      });
    });
    return mapped;
  };

  const initializeColumnWidths = (table, colgroup, count) => {
    const cols = Array.from(colgroup.children);
    const hasWidths = cols.some((col) => parseFloat(col.style.width) > 0);
    if (hasWidths) return;
    const tableRect = table.getBoundingClientRect();
    const defaultWidth = Math.max(55, tableRect.width / Math.max(1, count));
    cols.forEach((col) => { col.style.width = `${Math.round(defaultWidth)}px`; });
    headerCellMap(table).forEach(({ cell, start, span }) => {
      const width = Math.max(40, cell.getBoundingClientRect().width / span);
      for (let i = start; i < start + span; i++) {
        if (cols[i]) cols[i].style.width = `${Math.round(width)}px`;
      }
    });
  };

  const saveTableLayouts = () => localStorage.setItem(tableKey, JSON.stringify(tableLayouts));

  const captureTableLayout = (table) => {
    const key = table.dataset.printDesignerKey;
    const cols = Array.from(table.querySelectorAll(':scope > colgroup.pd-colgroup > col')).map((col) => Math.round(parseFloat(col.style.width) || 0));
    const rows = Array.from(table.rows).map((row) => Math.round(parseFloat(row.style.height) || 0));
    tableLayouts[key] = { cols, rows };
    saveTableLayouts();
  };

  const restoreTableLayout = (table) => {
    const layout = tableLayouts[table.dataset.printDesignerKey];
    if (!layout) return;
    const cols = Array.from(table.querySelectorAll(':scope > colgroup.pd-colgroup > col'));
    (layout.cols || []).forEach((width, index) => {
      if (cols[index] && Number(width) > 0) cols[index].style.width = `${Number(width)}px`;
    });
    Array.from(table.rows).forEach((row, index) => {
      const height = Number(layout.rows?.[index] || 0);
      if (height > 0) row.style.height = `${height}px`;
    });
  };

  const createColumnHandle = (table, mapping) => {
    const { cell, start, span } = mapping;
    if (cell.querySelector(':scope > .pd-col-resizer')) return;
    cell.classList.add('pd-resize-anchor');
    const handle = document.createElement('span');
    handle.className = 'pd-col-resizer no-print';
    handle.title = 'اسحب لتغيير عرض العمود';
    handle.setAttribute('role', 'separator');
    handle.setAttribute('aria-orientation', 'vertical');
    handle.innerHTML = '<span aria-hidden="true">⋮</span>';
    handle.addEventListener('pointerdown', (event) => {
      if (!resizeMode || event.button !== 0) return;
      event.preventDefault();
      event.stopPropagation();
      const cols = Array.from(table.querySelectorAll(':scope > colgroup.pd-colgroup > col'));
      const startWidths = [];
      for (let i = start; i < start + span; i++) startWidths.push(parseFloat(cols[i]?.style.width) || 70);
      activeDrag = { type: 'column', table, cols, start, span, startX: event.clientX, startWidths };
      body.classList.add('pd-dragging-column');
      handle.setPointerCapture?.(event.pointerId);
    });
    cell.appendChild(handle);
  };

  const createRowHandle = (table, row, rowIndex) => {
    const cell = Array.from(row.cells).find((candidate) => getComputedStyle(candidate).display !== 'none');
    if (!cell || cell.querySelector(':scope > .pd-row-resizer')) return;
    cell.classList.add('pd-resize-anchor');
    const handle = document.createElement('span');
    handle.className = 'pd-row-resizer no-print';
    handle.title = 'اسحب لتغيير ارتفاع الصف';
    handle.setAttribute('role', 'separator');
    handle.setAttribute('aria-orientation', 'horizontal');
    handle.innerHTML = '<span aria-hidden="true">⋯</span>';
    handle.addEventListener('pointerdown', (event) => {
      if (!resizeMode || event.button !== 0) return;
      event.preventDefault();
      event.stopPropagation();
      activeDrag = {
        type: 'row', table, row, rowIndex, startY: event.clientY,
        startHeight: Math.max(row.getBoundingClientRect().height, parseFloat(row.style.height) || 0),
      };
      body.classList.add('pd-dragging-row');
      handle.setPointerCapture?.(event.pointerId);
    });
    cell.appendChild(handle);
  };

  const makeResizable = (table, index) => {
    if (table.classList.contains('no-print-resize')) return;
    const count = logicalColumnCount(table);
    if (!count) return;
    table.classList.add('pd-resizable-table');
    table.dataset.printDesignerKey = tableId(table, index);
    const colgroup = ensureColgroup(table, count);
    initializeColumnWidths(table, colgroup, count);
    restoreTableLayout(table);
    headerCellMap(table).forEach((mapping) => createColumnHandle(table, mapping));
    Array.from(table.rows).forEach((row, rowIndex) => createRowHandle(table, row, rowIndex));
  };

  const initializeTables = () => {
    if (hasFixedPrintForm) return;
    Array.from(document.querySelectorAll('.content table:not(.no-print-resize)')).forEach(makeResizable);
  };

  const pointerMove = (event) => {
    if (!activeDrag) return;
    if (activeDrag.type === 'column') {
      const direction = getComputedStyle(activeDrag.table).direction;
      const delta = direction === 'rtl' ? activeDrag.startX - event.clientX : event.clientX - activeDrag.startX;
      const startTotal = activeDrag.startWidths.reduce((sum, width) => sum + width, 0);
      const newTotal = Math.max(activeDrag.span * 36, startTotal + delta);
      const factor = newTotal / startTotal;
      activeDrag.startWidths.forEach((width, offset) => {
        const col = activeDrag.cols[activeDrag.start + offset];
        if (col) col.style.width = `${Math.max(36, Math.round(width * factor))}px`;
      });
      activeDrag.table.style.width = `${Array.from(activeDrag.cols).reduce((sum, col) => sum + (parseFloat(col.style.width) || 0), 0)}px`;
    } else if (activeDrag.type === 'row') {
      const height = Math.max(14, Math.round(activeDrag.startHeight + event.clientY - activeDrag.startY));
      activeDrag.row.style.height = `${height}px`;
    }
  };

  const pointerUp = () => {
    if (!activeDrag) return;
    captureTableLayout(activeDrag.table);
    activeDrag = null;
    body.classList.remove('pd-dragging-column', 'pd-dragging-row');
  };

  const toggleResizeMode = (force) => {
    resizeMode = typeof force === 'boolean' ? force : !resizeMode;
    body.classList.toggle('print-resize-mode', resizeMode);
    const button = document.getElementById('pdResizeToggle');
    if (button) {
      button.classList.toggle('active', resizeMode);
      button.textContent = resizeMode ? 'إنهاء وضع السحب' : 'تفعيل سحب الأعمدة والصفوف';
    }
    if (resizeMode) {
      initializeTables();
      showStatus('اسحب أيقونة العمود أفقياً أو أيقونة الصف عمودياً.');
    }
  };

  const resetTableSizes = () => {
    if (!window.confirm('هل تريد حذف جميع أحجام الأعمدة والصفوف المحفوظة لهذه الصفحة؟')) return;
    tableLayouts = {};
    localStorage.removeItem(tableKey);
    document.querySelectorAll('.content table.pd-resizable-table').forEach((table) => {
      table.style.removeProperty('width');
      table.querySelectorAll(':scope > colgroup.pd-colgroup > col').forEach((col) => col.style.removeProperty('width'));
      Array.from(table.rows).forEach((row) => row.style.removeProperty('height'));
      initializeColumnWidths(table, table.querySelector(':scope > colgroup.pd-colgroup'), logicalColumnCount(table));
    });
    showStatus('تمت إعادة أحجام الجداول.');
  };

  const fitTables = () => {
    document.querySelectorAll('.content table.pd-resizable-table').forEach((table) => {
      const wrapper = table.closest('.table-wrap') || table.parentElement;
      const available = Math.max(420, wrapper?.clientWidth || document.querySelector('.content')?.clientWidth || window.innerWidth - 80);
      const cols = Array.from(table.querySelectorAll(':scope > colgroup.pd-colgroup > col'));
      const current = cols.reduce((sum, col) => sum + (parseFloat(col.style.width) || 70), 0);
      if (!current) return;
      const ratio = Math.min(1, available / current);
      cols.forEach((col) => {
        const width = parseFloat(col.style.width) || 70;
        col.style.width = `${Math.max(36, Math.floor(width * ratio))}px`;
      });
      table.style.width = `${cols.reduce((sum, col) => sum + (parseFloat(col.style.width) || 0), 0)}px`;
      captureTableLayout(table);
    });
    showStatus('تم ملاءمة الجداول مع عرض مساحة التقرير الحالية.');
  };

  const printNow = () => {
    settings = readControls();
    applySettings(false);
    close();
    const doPrint = () => requestAnimationFrame(() => {
      window.MizanPrecisionPrint?.prepare(window.MizanPrecisionPrintOptions);
      window.print();
    });
    if (document.fonts?.ready) document.fonts.ready.then(doPrint);
    else doPrint();
  };

  openButton.addEventListener('click', open);
  overlay.addEventListener('click', close);
  document.getElementById('printDesignerClose')?.addEventListener('click', close);
  document.getElementById('pdApply')?.addEventListener('click', () => {
    settings = readControls();
    applySettings(true);
    showStatus('تم تطبيق الإعدادات على المعاينة.');
  });
  document.getElementById('pdSavePage')?.addEventListener('click', savePage);
  document.getElementById('pdSaveGlobal')?.addEventListener('click', saveGlobal);
  document.getElementById('pdReset')?.addEventListener('click', resetSettings);
  document.getElementById('pdPrint')?.addEventListener('click', printNow);
  document.getElementById('pdResizeToggle')?.addEventListener('click', () => toggleResizeMode());
  document.getElementById('pdResetTables')?.addEventListener('click', resetTableSizes);
  document.getElementById('pdFitTables')?.addEventListener('click', fitTables);

  panel.addEventListener('input', (event) => {
    if (!event.target.matches('[data-print-setting]')) return;
    settings = readControls();
    updateRangeLabels();
    applySettings(true);
  });
  panel.addEventListener('change', (event) => {
    if (!event.target.matches('[data-print-setting]')) return;
    settings = readControls();
    applySettings(true);
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && panel.classList.contains('open')) close();
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'p') {
      event.preventDefault();
      open();
    }
  });
  document.addEventListener('pointermove', pointerMove);
  document.addEventListener('pointerup', pointerUp);
  document.addEventListener('pointercancel', pointerUp);
  window.addEventListener('beforeprint', () => {
    applySettings(false);
    window.MizanPrecisionPrint?.prepare(window.MizanPrecisionPrintOptions);
  });
  window.addEventListener('afterprint', () => {
    body.classList.remove('print-preview-active');
    window.MizanPrecisionPrint?.restore();
  });

  const observer = new MutationObserver(() => {
    clearTimeout(observer.timer);
    observer.timer = setTimeout(initializeTables, 100);
  });
  const content = document.querySelector('.content');
  if (content) observer.observe(content, { childList: true, subtree: true });

  writeControls();
  applySettings(false);
  initializeTables();

  window.IFRSPrintDesigner = { open, close, print: printNow, apply: applySettings };
})();
