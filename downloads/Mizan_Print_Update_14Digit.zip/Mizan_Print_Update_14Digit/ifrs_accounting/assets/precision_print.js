/* Mizan: lossless financial-cell print layout, 14 integer digits + existing decimals. */
(() => {
  'use strict';
  const ID = 'mizan-precision-print';
  const PX_PER_MM = 96 / 25.4;
  const PAPERS = { A4: [210, 297], A3: [297, 420], Letter: [215.9, 279.4], Legal: [215.9, 355.6] };
  const RESERVE = '\u221299,999,999,999,999.999';
  const body = document.body;
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  let frame = 0;
  let lastOptions = null;
  let preparing = false;
  let result = null;

  function options(raw) {
    const input = raw || window.MizanPrecisionPrintOptions || lastOptions || {};
    const page = body.dataset.page || new URLSearchParams(location.search).get('page') || '';
    const wide = ['general_journal', 'general_journal_assistant', 'trial_balance_balances'].includes(page);
    const pageSize = PAPERS[input.pageSize] ? input.pageSize : body.dataset.printPaper || (wide ? 'A3' : 'A4');
    const orientation = ['portrait', 'landscape'].includes(input.orientation) ? input.orientation : body.dataset.printOrientation || 'landscape';
    const margins = (Array.isArray(input.margins) ? input.margins : [7, 7, 7, 7]).map(n => Math.max(0, Math.min(50, Number(n) || 0)));
    while (margins.length < 4) margins.push(7);
    const dimensions = PAPERS[pageSize] || PAPERS.A4;
    const width = (orientation === 'landscape' ? Math.max(...dimensions) : Math.min(...dimensions)) - margins[1] - margins[3];
    return { pageSize: PAPERS[pageSize] ? pageSize : 'A4', orientation, margins, width: Math.max(40, width) };
  }

  function grid(table) {
    const occupied = [];
    const rows = Array.from(table.rows);
    const entries = [];
    let columns = 0;
    rows.forEach((row, rowIndex) => {
      occupied[rowIndex] ||= [];
      let column = 0;
      Array.from(row.cells).forEach(cell => {
        while (occupied[rowIndex][column]) column++;
        const span = Math.max(1, cell.colSpan);
        const rowSpan = Math.max(1, cell.rowSpan);
        const item = { cell, row, rowIndex, start: column, end: column + span };
        entries.push(item);
        for (let r = rowIndex; r < rowIndex + rowSpan; r++) {
          occupied[r] ||= [];
          for (let c = column; c < column + span; c++) occupied[r][c] = item;
        }
        column += span;
        columns = Math.max(columns, column);
      });
    });
    return { entries, rows, columns };
  }

  function moneyCell(cell) {
    return cell.matches('.num,.br-money,.gj-amount-cell,.gj-side-cell,.aj-side,.aj-diff') ||
      Boolean(cell.querySelector('.opv-line-amount-print,input.num,.mp-input-text.num')) ||
      (cell.closest('.assistant-journal-table') && cell.querySelector('.excel-vertical-number')) ||
      (cell.closest('tfoot') && cell.querySelector('.excel-vertical-number'));
  }

  function amountText(cell) {
    const printValue = cell.querySelector('.opv-line-amount-print,bdi,.excel-vertical-number');
    if (printValue) return printValue.textContent.trim();
    const input = cell.querySelector('input.num');
    if (input) return input.value;
    return cell.textContent.trim();
  }

  function textWidth(text, fontPx, bold = false) {
    context.font = `${bold ? 700 : 400} ${fontPx}px Arial`;
    return context.measureText(text.replace(/[\u2066-\u2069\u200e\u200f]/g, '')).width;
  }

  function configFor(table, data, fontPx) {
    const n = data.columns;
    const numeric = new Set();
    data.entries.forEach(e => {
      if (e.cell.closest('table') === table && e.cell.colSpan === 1 && moneyCell(e.cell) && !e.cell.closest('thead')) numeric.add(e.start);
    });
    const pair = (start, count) => Array.from({ length: Math.ceil(count / 2) }, (_, i) => [start + i * 2, start + i * 2 + 1].filter(c => c < n));
    let fixed = [], groups = [], widths = {}, description = -1;
    let kind = 'generic';
    if (table.matches('.general-journal-table')) {
      kind = 'journal'; fixed = [0, 1, 2, 3, 4, 5]; groups = pair(6, Math.max(0, n - 6));
      widths = { 0: 8, 1: 12, 2: 17, 3: 19, 4: 26 }; description = 4; numeric.add(5);
      groups.flat().forEach(c => numeric.add(c));
    } else if (table.matches('.assistant-journal-table')) {
      kind = 'assistant'; fixed = [0, 1, 2, 3, 4, 5, 6]; groups = pair(7, Math.max(0, n - 7));
      widths = { 0: 11, 1: 11, 2: 11, 3: 9, 4: 25, 5: 9, 6: 9 }; description = 4;
      for (let c = 7; c < n; c++) widths[c] = 9;
    } else if (table.matches('.balance-trial-table') && n === 13) {
      kind = 'balances'; fixed = [8, 9, 10, 11, 12]; groups = pair(0, 8);
      widths = { 8: 42, 9: 7, 10: 7, 11: 7, 12: 7 }; description = 8;
      for (let c = 0; c < 8; c++) numeric.add(c);
    } else if (table.matches('.iraqi-ledger-table') && n === 10) {
      kind = 'ledger'; fixed = [0, 1, 2, 3, 4]; groups = [[5, 6], [7, 8, 9]];
      widths = { 0: 6, 1: 19, 2: 15, 3: 16, 4: 23 }; description = 4;
      for (let c = 5; c < 10; c++) numeric.add(c);
    } else if (table.matches('.data-table') && body.classList.contains('page-trial_balance') && n === 8) {
      kind = 'trial'; fixed = [0, 1]; groups = pair(2, 6); widths = { 0: 15, 1: 42 }; description = 1;
      for (let c = 2; c < 8; c++) numeric.add(c);
    } else if (table.matches('.br-books-table') && n === 4) {
      kind = 'bank-books'; fixed = [0, 2]; groups = [[1, 3]];
      widths = { 0: 25, 2: 25 }; description = -1;
    } else if (table.matches('.br-bank-table') && n === 4) {
      kind = 'bank-statement'; fixed = [0, 1, 2]; groups = [[3]];
      widths = { 0: 7, 1: 7, 2: 40 }; description = 2;
    } else if (table.matches('.excel-voucher-table,.official-payment-voucher-table,.opv-table') || table.closest('.official-payment-voucher,.excel-voucher-sheet')) {
      kind = 'voucher';
      // Dinar/fils columns remain separate; do not reserve fourteen digits for a three-digit fils field.
      for (let c = 0; c < n; c++) widths[c] = c === 4 ? 30 : c < 4 ? (c % 2 ? 35 : 5) : c < 8 ? 8 : 6;
      fixed = Array.from({ length: n }, (_, i) => i); description = Math.min(4, n - 1);
    } else {
      fixed = Array.from({ length: n }, (_, i) => i).filter(c => !numeric.has(c));
      groups = Array.from(numeric).sort((a, b) => a - b).map(c => [c]);
      fixed.forEach(c => { widths[c] = fixed.length > 4 ? 13 : 25; });
      description = fixed.length ? fixed[fixed.length - 1] : -1;
    }
    const reserved = Math.max(textWidth(RESERVE, fontPx), textWidth(RESERVE, fontPx, true)) + 8;
    numeric.forEach(column => {
      if (kind === 'assistant') return;
      let measured = reserved;
      data.entries.forEach(e => {
        if (e.start === column && e.cell.colSpan === 1 && moneyCell(e.cell)) {
          const value = amountText(e.cell);
          if (/[0-9\u0660-\u0669\u06f0-\u06f9]/.test(value)) measured = Math.max(measured, textWidth(value, fontPx, true) + 8);
        }
      });
      widths[column] = measured / PX_PER_MM;
    });
    for (let c = 0; c < n; c++) widths[c] ||= 18;
    return { kind, fixed: fixed.filter(c => c < n), groups, widths, description, numeric, fontPx };
  }

  function bands(config, width) {
    if (!config.groups.length) return [config.fixed];
    const fixedWidth = config.fixed.reduce((sum, c) => sum + config.widths[c], 0);
    const panels = [];
    let pending = [], used = fixedWidth;
    config.groups.forEach(group => {
      const groupWidth = group.reduce((sum, c) => sum + config.widths[c], 0);
      if (pending.length && used + groupWidth > width + .01) {
        panels.push([...config.fixed, ...pending].sort((a, b) => a - b));
        pending = []; used = fixedWidth;
      }
      pending.push(...group); used += groupWidth;
    });
    if (pending.length) panels.push([...config.fixed, ...pending].sort((a, b) => a - b));
    return panels;
  }

  function projectTable(source, data, columns, widths, width) {
    const table = source.cloneNode(false);
    table.removeAttribute('id'); table.removeAttribute('style');
    table.classList.add('mp-table', 'no-print-resize');
    table.dataset.mpColumns = columns.join(',');
    table.style.setProperty('width', `${width}mm`, 'important');
    const group = document.createElement('colgroup');
    columns.forEach(c => {
      const col = document.createElement('col');
      col.style.setProperty('width', `${widths[c]}mm`, 'important'); group.append(col);
    });
    table.append(group);
    Array.from(source.children).forEach(section => {
      if (!['THEAD', 'TBODY', 'TFOOT'].includes(section.tagName)) return;
      const copy = section.cloneNode(false);
      Array.from(section.rows).forEach(row => {
        const copyRow = row.cloneNode(false);
        copyRow.removeAttribute('style');
        copyRow.dataset.mpSourceRow = String(data.rows.indexOf(row));
        data.entries.filter(e => e.row === row).forEach(entry => {
          const kept = columns.filter(c => c >= entry.start && c < entry.end);
          if (!kept.length) return;
          const cell = entry.cell.cloneNode(true);
          cell.colSpan = kept.length;
          cell.style.removeProperty('width'); cell.style.removeProperty('min-width'); cell.style.removeProperty('max-width');
          cell.style.removeProperty('height');
          cell.dataset.mpSourceColumn = String(entry.start);
          copyRow.append(cell);
        });
        if (copyRow.cells.length) copy.append(copyRow);
      });
      table.append(copy);
    });
    return table;
  }

  function cleanClone(source) {
    const clone = source.cloneNode(true);
    const originalControls = Array.from(source.querySelectorAll('input,textarea,select'));
    clone.querySelectorAll('input,textarea,select').forEach((control, index) => {
      const original = originalControls[index];
      if (control.matches('input[type="hidden"],input[type="submit"],input[type="button"],input[type="reset"],input[type="file"],input[type="image"]')) {
        control.remove(); return;
      }
      if (control.closest('.no-print,.opv-amount-editor')) return;
      const text = document.createElement('span');
      text.className = `mp-input-text ${control.className || ''}`;
      text.textContent = control.matches('select') ? original?.selectedOptions?.[0]?.textContent || '' :
        control.type === 'checkbox' ? (original?.checked ? '✓' : '') : original?.value || '';
      control.replaceWith(text);
    });
    clone.querySelectorAll('form').forEach(form => {
      if (!form.querySelector('table,.official-payment-voucher,.excel-voucher-sheet') &&
          !form.closest('.official-payment-voucher,.excel-voucher-sheet')) form.remove();
    });
    clone.classList.remove('content'); clone.classList.add('mp-document');
    clone.querySelectorAll('script,template,button,.no-print,.opv-amount-editor,.pd-col-resizer,.pd-row-resizer,colgroup.pd-colgroup').forEach(n => n.remove());
    clone.querySelectorAll('[id]').forEach(n => n.removeAttribute('id'));
    clone.removeAttribute('id');
    clone.querySelectorAll('table').forEach(t => t.classList.add('no-print-resize'));
    return clone;
  }

  function moneyTargets(table) {
    const targets = [];
    Array.from(table.querySelectorAll('td,th')).forEach(cell => {
      if (cell.closest('table') !== table || !moneyCell(cell) || cell.closest('thead')) return;
      let node = cell.querySelector('.opv-line-amount-print,bdi,.excel-vertical-number,.mp-input-text.num');
      if (!node) {
        node = document.createElement('span');
        while (cell.firstChild) node.append(cell.firstChild);
        cell.append(node);
      }
      node.classList.add('mp-money-value');
      cell.classList.add('mp-money-cell');
      node.setAttribute('dir', 'ltr');
      if (table.classList.contains('assistant-journal-table')) cell.classList.add('mp-rotated-money');
      targets.push({ cell, node, rotated: cell.classList.contains('mp-rotated-money') });
    });
    return targets;
  }

  function fitValues(table, fontPx) {
    const targets = moneyTargets(table);
    if (table.classList.contains('assistant-journal-table')) {
      let height = textWidth(RESERVE, fontPx, true) + 16;
      targets.forEach(({ node }) => { height = Math.max(height, textWidth(node.textContent.trim(), fontPx, true) + 16); });
      table.style.setProperty('--mp-rotated-row-height', `${height}px`);
    }
    const overflow = [];
    targets.forEach(({ cell, node, rotated }) => {
      node.style.setProperty('font-size', `${fontPx}px`, 'important');
      if (!node.textContent.trim()) return;
      const style = getComputedStyle(cell);
      const available = (rotated ? cell.clientHeight - parseFloat(style.paddingTop) - parseFloat(style.paddingBottom) :
        cell.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight)) - 2;
      const needed = textWidth(node.textContent.trim(), fontPx, parseInt(getComputedStyle(node).fontWeight, 10) >= 600);
      const fitted = Math.max(8 * 96 / 72, Math.min(fontPx, fontPx * available / Math.max(1, needed)));
      node.style.setProperty('font-size', `${fitted}px`, 'important');
      const measured = textWidth(node.textContent.trim(), fitted, parseInt(getComputedStyle(node).fontWeight, 10) >= 600);
      if (measured > available + .8) overflow.push({ column: cell.dataset.mpSourceColumn || '', excess: Math.ceil(measured - available) });
    });
    return { count: targets.length, overflow };
  }

  function prepare(raw) {
    if (preparing) return result;
    cancelAnimationFrame(frame); frame = 0;
    const source = document.querySelector('.content');
    if (!source || !source.querySelector('table')) return null;
    preparing = true;
    try {
      lastOptions = options(raw);
      document.getElementById(ID)?.remove();
      const oldStyle = document.getElementById('mizan-precision-page-style');
      oldStyle?.remove();
      const style = document.createElement('style'); style.id = 'mizan-precision-page-style';
      style.textContent = `@page mizanPrecisionPage{size:${lastOptions.pageSize} ${lastOptions.orientation};margin:${lastOptions.margins.map(v => `${v}mm`).join(' ')}}`;
      document.head.append(style);
      const root = document.createElement('main'); root.id = ID;
      root.style.setProperty('--mp-printable-width', `${lastOptions.width}mm`);
      const clone = cleanClone(source); root.append(clone); body.append(root);
      body.classList.add('mp-print-ready');
      result = { ok: true, panels: 0, tables: 0, values: 0, overflow: [], paper: lastOptions };
      const tables = Array.from(clone.querySelectorAll('table')).reverse();
      tables.forEach((table, sourceIndex) => {
        if (!table.isConnected || !table.querySelector('td')) return;
        const data = grid(table);
        if (!data.columns) return;
        const hasAmounts = data.entries.some(e => e.cell.closest('table') === table && moneyCell(e.cell));
        if (!hasAmounts) return;
        result.tables++;
        const parentWidth = table.parentElement.getBoundingClientRect().width / PX_PER_MM;
        // Allow for collapsed outer borders and sub-pixel column rounding.
        const available = Math.min(lastOptions.width, parentWidth > 20 ? parentWidth : lastOptions.width) - .5;
        let fontPx = Math.max(8.5 * 96 / 72, parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--pd-table-font-size')) || 0);
        let config = configFor(table, data, fontPx);
        // Only reduce half a point if one inseparable group would otherwise be wider than the paper.
        const maxGroup = Math.max(0, ...config.groups.map(g => g.reduce((sum, c) => sum + config.widths[c], 0)));
        if (config.fixed.reduce((sum, c) => sum + config.widths[c], 0) + maxGroup > available) {
          fontPx = 8 * 96 / 72; config = configFor(table, data, fontPx);
        }
        const plans = bands(config, available);
        const holder = document.createElement('div'); holder.className = 'mp-table-panels';
        const reportScope = table.closest('.excel-ledger-sheet,.assistant-journal-sheet,.card') || clone;
        const headings = Array.from(reportScope.querySelectorAll('.report-head,.excel-ledger-company,.excel-ledger-title,.excel-ledger-meta,.excel-ledger-account-name,.assistant-journal-company,.assistant-journal-title,.assistant-journal-date-range'));
        const reportTitle = (headings.map(h => h.textContent.trim()).join(' — ') || document.title).replace(/\s+/g, ' ').trim();
        plans.forEach((columns, index) => {
          const section = document.createElement('section'); section.className = 'mp-panel';
          section.dataset.mpSourceTable = String(sourceIndex); section.dataset.mpPanel = String(index);
          const label = document.createElement('p'); label.className = 'mp-panel-label';
          label.textContent = plans.length > 1 ? `مجموعة الأعمدة ${index + 1} من ${plans.length} — ${reportTitle}` : '';
          if (plans.length > 1) {
            section.append(label);
            const note = document.createElement('p'); note.className = 'mp-panel-note';
            note.textContent = 'بيانات المستند ومبلغ المعاملة مكررة للمطابقة بين مجموعات الأعمدة؛ لا تُجمع مرة أخرى.';
            section.append(note);
          }
          const widths = { ...config.widths };
          const used = columns.reduce((sum, c) => sum + widths[c], 0);
          if (used > available + .05) {
            // Large user margins can make even one group physically impossible.
            // Preserve every value and flag this selection instead of clipping it.
            result.overflow.push({ reason: 'paper-too-narrow', table: sourceIndex });
          } else if (columns.length) {
            const extra = available - used;
            if (config.kind === 'bank-books') config.fixed.forEach(c => { widths[c] += extra / config.fixed.length; });
            else if (columns.includes(config.description)) widths[config.description] += extra;
            else columns.forEach(c => { widths[c] += extra / columns.length; });
          }
          const copy = projectTable(table, data, columns, widths, Math.max(available, used));
          copy.dataset.mpKind = config.kind;
          if (copy.tHead) {
            const row = copy.tHead.insertRow(0); const cell = document.createElement('th');
            cell.colSpan = columns.length; cell.className = 'mp-repeat-title';
            cell.textContent = `${reportTitle}${plans.length > 1 ? ` — مجموعة ${index + 1}/${plans.length}` : ''}`;
            row.append(cell);
          }
          section.append(copy); holder.append(section); result.panels++;
        });
        table.replaceWith(holder);
        holder.querySelectorAll('table.mp-table').forEach(copy => {
          const fitted = fitValues(copy, fontPx); result.values += fitted.count; result.overflow.push(...fitted.overflow);
        });
      });
      result.ok = result.overflow.length === 0;
      root.dataset.mpOverflow = String(result.overflow.length);
      root.dataset.mpPanels = String(result.panels);
      if (!result.ok) {
        const warning = document.createElement('p'); warning.className = 'mp-layout-warning no-print';
        warning.textContent = 'مساحة الورق المختارة لا تكفي لعرض بعض المبالغ بوضوح. اختر A3 أفقي أو قلّل الهوامش قبل الطباعة.';
        root.prepend(warning);
      }
      return result;
    } finally { preparing = false; }
  }

  function schedule(raw) {
    if (raw) lastOptions = raw;
    cancelAnimationFrame(frame);
    frame = requestAnimationFrame(() => prepare(raw || window.MizanPrecisionPrintOptions || lastOptions));
  }

  function restore() {
    cancelAnimationFrame(frame); frame = 0;
    document.getElementById(ID)?.remove();
    document.getElementById('mizan-precision-page-style')?.remove();
    body.classList.remove('mp-print-ready');
    if (body.classList.contains('professional-print-mode')) schedule(lastOptions);
  }

  window.MizanPrecisionPrint = { prepare, schedule, restore, getResult: () => result };
  window.addEventListener('beforeprint', () => prepare(window.MizanPrecisionPrintOptions || lastOptions));
  window.addEventListener('afterprint', restore);
  const init = () => {
    if (body.classList.contains('professional-print-mode')) {
      schedule(window.MizanPrecisionPrintOptions);
      document.fonts?.ready.then(() => schedule(window.MizanPrecisionPrintOptions));
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
