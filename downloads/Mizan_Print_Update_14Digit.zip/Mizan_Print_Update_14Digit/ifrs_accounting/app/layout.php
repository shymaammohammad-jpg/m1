<?php
declare(strict_types=1);
require_once __DIR__ . '/core.php';

function icon(string $name): string
{
    $icons = [
        'dashboard' => '<path d="M4 13h6V4H4v9Zm0 7h6v-4H4v4Zm10 0h6v-9h-6v9Zm0-16v4h6V4h-6Z"/>',
        'journal' => '<path d="M6 3h12a2 2 0 0 1 2 2v16H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm2 5h8M8 12h8M8 16h5"/>',
        'cash' => '<path d="M3 6h18v12H3V6Zm4 6h.01M17 12h.01M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"/>',
        'accounts' => '<path d="M4 5h16M4 12h16M4 19h16M8 3v4M15 10v4M11 17v4"/>',
        'party' => '<path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM4 21a8 8 0 0 1 16 0"/>',
        'report' => '<path d="M5 3h14v18H5V3Zm3 13v-4m4 4V8m4 8v-6"/>',
        'period' => '<path d="M3 6h18v15H3V6Zm4-3v6m10-6v6M3 11h18"/>',
        'closing' => '<path d="M5 4h14v16H5V4Zm3 4h8m-8 4h8m-8 4h5M18 2v4"/>',
        'users' => '<path d="M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm7 10v-2a5 5 0 0 0-5-5H7a5 5 0 0 0-5 5v2m15-10 2 2 4-4"/>',
        'settings' => '<path d="M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm0-6v3m0 14v3M2 12h3m14 0h3M4.9 4.9 7 7m10 10 2.1 2.1m0-14.2L17 7M7 17l-2.1 2.1"/>',
        'audit' => '<path d="M5 3h14v18H5V3Zm3 5h8m-8 4h8m-8 4h5"/>',
        'backup' => '<path d="M12 3v12m0 0-4-4m4 4 4-4M4 18v3h16v-3"/>',
        'health' => '<path d="M3 12h4l2-5 4 10 2-5h6"/>',
        'assistant' => '<path d="M12 3a7 7 0 0 0-7 7v2a4 4 0 0 0 4 4h1v3l4-3h1a4 4 0 0 0 4-4v-2a7 7 0 0 0-7-7Zm-3 7h.01M12 10h.01M15 10h.01"/>',
        'license' => '<path d="M7 14a5 5 0 1 1 4.7-6.7L22 7v4h-3v3h-3v3h-4.3A5 5 0 0 1 7 14Zm0-2h.01"/>',
        'print' => '<path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v7H6v-7Zm11-2h.01"/>',
        'balance' => '<path d="M12 4v16M8 20h8M5 7h14M7 7l-3 6h6l-3-6Zm10 0-3 6h6l-3-6Z"/>',
        'ledger' => '<path d="M4 4h13a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3V4Zm0 13a3 3 0 0 1 3-3h13M9 8h7"/>',
        'shield' => '<path d="M12 3l8 3v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6l8-3Zm-3 9 2 2 4-4"/>',
        'folder' => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
        'vault' => '<path d="M4 4h16v16H4V4Zm8 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8Zm0 0v-1m0 10v1m4-5h1M7 12H6"/>',
    ];
    $path = $icons[$name] ?? $icons['report'];
    return '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
}

function page_heading(string $title, string $subtitle = '', string $actions = ''): void
{
    echo '<div class="page-heading"><div><h1>' . e($title) . '</h1>';
    if ($subtitle !== '') {
        echo '<p>' . e($subtitle) . '</p>';
    }
    echo '</div>';
    if ($actions !== '') {
        echo '<div class="page-actions">' . $actions . '</div>';
    }
    echo '</div>';
}

function render_header(string $title, string $active = 'dashboard'): void
{
    $professionalPrint = isset($_GET['print_view']) && (string)$_GET['print_view'] === '1'
        && in_array($active, ['ledger','general_journal','trial_balance','trial_balance_balances'], true);
    if ($professionalPrint) {
        require_role(['admin','accountant','viewer']);
        $GLOBALS['mizan_professional_print_mode'] = true;
        $GLOBALS['mizan_professional_print_page'] = $active;
        $company = company();
        $paperSize = in_array($active, ['general_journal','trial_balance','trial_balance_balances'], true) ? 'A3' : 'A4';
        $orientation = 'landscape';
        $paper = $paperSize . ' ' . $orientation;
        $GLOBALS['mizan_professional_print_default_paper'] = $paper;
        $backParams = $_GET;
        unset($backParams['print_view']);
        $backPage = (string)($backParams['page'] ?? $active);
        unset($backParams['page']);
        $backUrl = url($backPage, $backParams);
        ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light">
<title><?= e($title) ?> | الطباعة الاحترافية</title>
<link rel="icon" href="assets/branding/app_icon.ico" sizes="any">
<link rel="stylesheet" href="assets/app.css?v=2.7.9.7-journal-tb-monthly-r2">
<link rel="stylesheet" href="assets/professional_print.css?v=2.7.9.7-journal-tb-monthly-r2">
<style id="ppPageStyle">@page{size:<?= e($paper) ?>;margin:9mm 8mm 10mm 8mm}</style>
<link rel="stylesheet" href="assets/precision_print.css?v=2.7.9.7-print-14digit-r1">
</head>
<body class="professional-print-mode page-<?= e($active) ?>" data-page="<?= e($active) ?>">
<div class="professional-print-toolbar no-print">
    <div><strong>مركز الطباعة الاحترافية</strong><small id="ppPaperSummary" data-company="<?= e((string)($company['name_ar'] ?? '')) ?>"><?= e((string)($company['name_ar'] ?? '')) ?> • <?= e($paperSize) ?> • أفقي</small></div>
    <div class="professional-print-actions">
        <label class="pp-paper-label">حجم الورق <select id="ppPaperSizeSelect"><option value="A4" <?= $paperSize === 'A4' ? 'selected' : '' ?>>A4</option><option value="A3" <?= $paperSize === 'A3' ? 'selected' : '' ?>>A3</option></select></label>
        <label class="pp-paper-label">الاتجاه <select id="ppOrientationSelect"><option value="portrait">عمودي</option><option value="landscape" selected>أفقي</option></select></label>
        <a class="pp-btn" href="<?= e($backUrl) ?>">العودة للتقرير</a>
        <button class="pp-btn pp-primary" type="button" onclick="window.print()">طباعة / حفظ PDF</button>
        <button class="pp-btn" type="button" onclick="window.close()">إغلاق</button>
    </div>
</div>
<main class="professional-print-canvas">
<section class="content professional-print-content">
        <?php
        return;
    }

    $u = user();
    $company = company();
    $role = (string)($u['role'] ?? 'viewer');
    $groups = [
        'الرئيسية' => [
            ['dashboard', 'لوحة المؤشرات', 'dashboard'],
        ],
        'القيود والمستندات' => [
            ['journal_new', 'قيد يومية جديد', 'journal'],
            ['journal_list', 'سجل القيود اليومية', 'journal'],
            ['cash_voucher', 'مستندات القبض والصرف', 'cash'],
        ],
        'السجلات' => [
            ['general_journal', 'سجل اليومية العامة', 'journal'],
            ['general_journal_assistant', 'اليومية العامة المساعد', 'journal'],
            ['ledger', 'سجل الأستاذ العام', 'report'],
            ['bank_reconciliation', 'شهادة مطابقة البنك', 'report'],
            ['fixed_assets', 'سجل الأصول الثابتة', 'accounts'],
            ['inventory', 'سجل المخزون', 'accounts'],
            ['ifrs_registers', 'السجلات التخصصية', 'journal'],
            ['cash_flow_register', 'سجل تصنيف التدفقات النقدية', 'cash'],
        ],
        'الموازين' => [
            ['trial_balance_balances', 'ميزان المراجعة بالأرصدة — قبل/بعد الغلق', 'report'],
            ['trial_balance', 'ميزان المراجعة بالحركات — قبل/بعد الغلق', 'report'],
        ],
        'الحسابات الختامية' => [
            ['financial_position', 'قائمة المركز المالي', 'report'],
            ['income_statement', 'قائمة الدخل الشامل', 'report'],
            ['cash_flow', 'قائمة التدفقات النقدية', 'report'],
            ['equity_changes', 'التغيرات في حقوق الملكية', 'report'],
            ['analytical_schedules', 'الكشوفات التحليلية', 'report'],
            ['financial_package', 'الحسابات الختامية / الحزمة الكاملة', 'report'],
            ['closing', 'مساعد الإقفال', 'closing'],
        ],
        'البيانات الأساسية' => [
            ['accounts', 'دليل الحسابات', 'accounts'],
            ['parties', 'العملاء والموردون', 'party'],
            ['cost_centers', 'مراكز الكلفة', 'accounts'],
            ['periods', 'الفترات المالية', 'period'],
        ],
        'الامتثال والمعايير' => [
            ['compliance_dashboard', 'لوحة المطابقة', 'health'],
            ['ifrs_transition', 'التحول لأول مرة IFRS 1', 'closing'],
            ['accounting_policies', 'السياسات المحاسبية', 'settings'],
            ['disclosures', 'الإيضاحات والإفصاحات', 'report'],
            ['standards_library', 'مكتبة المعايير', 'audit'],
            ['report_settings', 'إعدادات مطابقة التقارير', 'settings'],
        ],
        'المساعدة الذكية' => [
            ['smart_assistant', 'المساعد المحاسبي الذكي', 'assistant'],
        ],
    ];
    if ($role === 'admin') {
        $groups['الإدارة والرقابة'] = [
            ['institutions', 'إدارة المؤسسات وقواعد البيانات', 'accounts'],
            ['users', 'المستخدمون', 'users'],
            ['settings', 'إعدادات المنشأة', 'settings'],
            ['backups', 'النسخ الاحتياطية', 'backup'],
            ['audit', 'سجل التدقيق', 'audit'],
            ['diagnostics', 'فحص النظام', 'health'],
            ['license', 'الترخيص والتفعيل', 'license'],
        ];
    }
    $groupIcons = [
        'الرئيسية' => 'dashboard',
        'القيود والمستندات' => 'journal',
        'السجلات' => 'ledger',
        'الموازين' => 'balance',
        'الحسابات الختامية' => 'closing',
        'البيانات الأساسية' => 'folder',
        'الامتثال والمعايير' => 'shield',
        'المساعدة الذكية' => 'assistant',
        'الإدارة والرقابة' => 'vault',
    ];

    ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<meta name="color-scheme" content="light">
<title><?= e($title) ?> | <?= e((string)app_config('app_name')) ?></title>
<link rel="icon" href="assets/branding/app_icon.ico" sizes="any">
<link rel="apple-touch-icon" href="assets/branding/app_icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/app.css?v=2.7.9.7-journal-tb-monthly-r2">
<link rel="stylesheet" href="assets/precision_print.css?v=2.7.9.7-print-14digit-r1">
</head>
<?php
$routePage = preg_replace('/[^a-z0-9_-]+/i', '-', (string)($_GET['page'] ?? $active));
$fixedPrintTemplate = preg_replace('/[^a-z0-9_-]+/i', '-', (string)($GLOBALS['fixed_print_template'] ?? ''));
$bodyClass = 'page-' . $routePage . ($fixedPrintTemplate !== '' ? ' fixed-print-form print-' . $fixedPrintTemplate : '');
?>
<body class="<?= e($bodyClass) ?>" data-page="<?= e($routePage) ?>" data-print-template="<?= e($fixedPrintTemplate) ?>">
<div class="app-shell">
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <img class="brand-logo" src="assets/branding/brand_icon.png" alt="شعار نظام الميزان المحاسبي">
        <div><strong>نظام الميزان المحاسبي</strong><small>الإصدار 2.7.9.7</small></div>
    </div>
    <div class="company-mini"><strong><?= e($company['name_ar'] ?? '') ?></strong><small>قاعدة بيانات مستقلة</small></div>
    <div class="nav-tools" aria-label="أدوات القائمة">
        <label class="nav-search" for="navMenuSearch">
            <span class="nav-search-icon" aria-hidden="true">⌕</span>
            <input type="search" id="navMenuSearch" placeholder="ابحث في القوائم..." autocomplete="off">
            <button type="button" id="navMenuClear" class="nav-search-clear" aria-label="مسح البحث" hidden>×</button>
        </label>
        <div class="nav-tool-actions">
            <button type="button" id="navExpandAll" class="nav-tool-btn">عرض الكل</button>
            <button type="button" id="navCollapseAll" class="nav-tool-btn">طي الكل</button>
        </div>
    </div>
    <nav class="nav-scroll nav-modern-menu" aria-label="القائمة الرئيسية" id="modernSidebarMenu">
        <?php foreach ($groups as $groupIndex => $items): ?>
            <?php
                $groupName = is_string($groupIndex) ? $groupIndex : '';
                $groupOpen = false;
                foreach ($items as $item) { if ($active === $item[0]) { $groupOpen = true; break; } }
                $groupId = 'nav-group-' . md5($groupName);
                $groupIcon = $groupIcons[$groupName] ?? 'report';
            ?>
            <section class="nav-modern-group <?= $groupOpen ? 'is-open has-active' : '' ?>" data-nav-group="<?= e($groupId) ?>" data-default-open="<?= $groupOpen ? '1' : '0' ?>">
                <button type="button" class="nav-modern-trigger" aria-expanded="<?= $groupOpen ? 'true' : 'false' ?>" aria-controls="<?= e($groupId) ?>">
                    <span class="nav-modern-group-icon"><?= icon($groupIcon) ?></span>
                    <span class="nav-modern-group-copy">
                        <strong><?= e($groupName) ?></strong>
                    </span>
                    <span class="nav-modern-chevron" aria-hidden="true">⌄</span>
                </button>
                <div class="nav-modern-panel" id="<?= e($groupId) ?>">
                    <ul class="nav-modern-items">
                        <?php foreach ($items as [$page, $label, $ico]): ?>
                            <li class="nav-modern-item" data-nav-label="<?= e(mb_strtolower($label . ' ' . $groupName)) ?>">
                                <a class="nav-link <?= $active === $page ? 'active' : '' ?>" href="<?= e(url($page)) ?>">
                                    <span class="nav-item-icon"><?= icon($ico) ?></span>
                                    <span class="nav-item-label"><?= e($label) ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </section>
        <?php endforeach; ?>
        <div class="nav-empty-state" id="navEmptyState" hidden>لا توجد نتيجة مطابقة في القوائم.</div>
    </nav>
    <div class="sidebar-credit"><strong>م. أرشد حميد حسن</strong><small>واتساب 07735882844</small></div>
</aside>
<main class="main-area">
<header class="topbar">
    <button class="menu-btn" type="button" id="menuBtn" aria-label="فتح القائمة">☰</button>
    <div class="topbar-title"><?= e($title) ?></div>
    <div class="institution-topbar no-print">
        <span class="institution-topbar-name"><?= e((string)($_SESSION['institution_name'] ?? ($company['name_ar'] ?? ''))) ?></span>
        <a class="institution-switch-link" href="index.php?page=institution_switch" title="الانتقال إلى قاعدة بيانات مؤسسة أخرى">تبديل المؤسسة</a>
    </div>
    <?php $headerLicense = license_status(); if ($headerLicense['valid']): ?>
        <a class="license-header-badge <?= (int)($headerLicense['days_remaining'] ?? 999) <= 30 ? 'license-soon' : '' ?>" href="<?= e(url('license')) ?>" title="عرض حالة الترخيص">مرخص حتى <?= e((string)($headerLicense['expires_at'] ?? '')) ?></a>
    <?php endif; ?>
    <div class="topbar-print-tools no-print"><button type="button" class="print-designer-top-btn" id="printDesignerOpen" title="التحكم الكامل بالطباعة"><?= icon('print') ?><span>إعداد الطباعة</span></button></div>
    <div class="user-menu">
        <div class="user-avatar"><?= e(mb_substr((string)($u['full_name'] ?? 'م'), 0, 1)) ?></div>
        <div class="user-meta"><strong><?= e($u['full_name'] ?? '') ?></strong><small><?= e(['admin'=>'مدير النظام','accountant'=>'محاسب','viewer'=>'مستعرض'][$role] ?? '') ?></small></div>
        <a class="logout-link" href="<?= e(url('logout')) ?>">خروج</a>
    </div>
</header>
<section class="content">
<?php foreach (pull_flashes() as $flash): ?>
    <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endforeach; ?>
<?php
}

function render_footer(): void
{
    if (!empty($GLOBALS['mizan_professional_print_mode'])) {
        ?>
</section>
</main>
<div class="professional-print-screen-note no-print">يتم توزيع السجل الطويل تلقائياً على صفحات متعددة، ويتكرر رأس الجدول في كل صفحة.</div>
<script>
(() => {
  const sizeSelect = document.getElementById('ppPaperSizeSelect');
  const orientationSelect = document.getElementById('ppOrientationSelect');
  const style = document.getElementById('ppPageStyle');
  const summary = document.getElementById('ppPaperSummary');
  const applyPaper = () => {
    if (!sizeSelect || !orientationSelect || !style) return;
    const size = sizeSelect.value;
    const orientation = orientationSelect.value;
    document.body.dataset.printPaper = size;
    document.body.dataset.printOrientation = orientation;
    document.body.dataset.printMargins = JSON.stringify([9, 8, 10, 8]);
    window.MizanPrecisionPrintOptions = { pageSize: size, orientation, margins: [9, 8, 10, 8] };
    style.textContent = '@page{size:' + size + ' ' + orientation + ';margin:9mm 8mm 10mm 8mm}';
    if (summary) {
      const companyText = summary.dataset.company || '';
      summary.textContent = companyText + ' • ' + size + ' • ' + (orientation === 'portrait' ? 'عمودي' : 'أفقي');
    }
    window.MizanPrecisionPrint?.prepare(window.MizanPrecisionPrintOptions);
  };
  sizeSelect?.addEventListener('change', applyPaper);
  orientationSelect?.addEventListener('change', applyPaper);
  applyPaper();
})();
</script>
<script src="assets/precision_print.js?v=2.7.9.7-print-14digit-r1"></script>
</body>
</html>
        <?php
        return;
    }
    ?>
</section>
<footer class="app-footer">
    <span>نظام الميزان المحاسبي وفق معايير التقارير المالية الدولية</span>
    <span class="programmer-credit">المبرمج: م. أرشد حميد حسن • واتساب: 07735882844</span>
</footer>
</main>
</div>
<a class="assistant-fab no-print" href="<?= e(url('smart_assistant')) ?>" title="فتح المساعد المحاسبي الذكي" aria-label="فتح المساعد المحاسبي الذكي"><?= icon('assistant') ?><span>المساعد الذكي</span></a>
<div class="print-designer-overlay no-print" id="printDesignerOverlay" hidden></div>
<aside class="print-designer-panel no-print" id="printDesignerPanel" aria-hidden="true" hidden>
  <div class="pd-panel-head">
    <div><h2>مُصمم الطباعة</h2><p>تحكم بالورق والهوامش والخط والمقياس والإزاحة قبل الطباعة</p></div>
    <button type="button" class="pd-close" id="printDesignerClose" aria-label="إغلاق">×</button>
  </div>
  <div class="pd-panel-body">
    <section class="pd-section">
      <h3>الصفحة والهوامش</h3>
      <div class="pd-grid">
        <div class="pd-field"><label>حجم الورق</label><select data-print-setting="pageSize"><option value="A4">A4</option><option value="A3">A3</option><option value="Letter">Letter</option><option value="Legal">Legal</option></select></div>
        <div class="pd-field"><label>الاتجاه</label><select data-print-setting="orientation"><option value="portrait">عمودي</option><option value="landscape">أفقي</option></select></div>
        <div class="pd-field"><label>الهامش العلوي (ملم)</label><input type="number" min="0" max="50" step="1" data-print-setting="marginTop"></div>
        <div class="pd-field"><label>الهامش السفلي (ملم)</label><input type="number" min="0" max="50" step="1" data-print-setting="marginBottom"></div>
        <div class="pd-field"><label>الهامش الأيمن (ملم)</label><input type="number" min="0" max="50" step="1" data-print-setting="marginRight"></div>
        <div class="pd-field"><label>الهامش الأيسر (ملم)</label><input type="number" min="0" max="50" step="1" data-print-setting="marginLeft"></div>
        <div class="pd-field pd-field-wide"><label>مقياس المحتوى</label><div class="pd-range-line"><input type="range" min="40" max="150" step="1" data-print-setting="scale"><span class="pd-range-output" data-range-output="scale" data-suffix="%"></span></div></div>
        <div class="pd-field pd-fixed-only"><label>الإزاحة الأفقية (ملم)</label><input type="number" min="-25" max="25" step="0.5" data-print-setting="offsetX"></div>
        <div class="pd-field pd-fixed-only"><label>الإزاحة العمودية (ملم)</label><input type="number" min="-25" max="25" step="0.5" data-print-setting="offsetY"></div>
        <div class="pd-field pd-field-wide pd-fixed-only"><label class="pd-check"><input type="checkbox" data-print-setting="centerContent"> توسيط النموذج داخل مساحة الطباعة</label></div>
      </div>
    </section>
    <section class="pd-section">
      <h3>الخطوط وتباعد الأسطر</h3>
      <div class="pd-grid">
        <div class="pd-field pd-field-wide"><label>نوع الخط</label><select data-print-setting="fontFamily"><option value="Cairo">Cairo — موصى به</option><option value="Tahoma">Tahoma</option><option value="Segoe UI">Segoe UI</option><option value="Arial">Arial</option><option value="Traditional Arabic">Traditional Arabic</option><option value="Times New Roman">Times New Roman</option><option value="Calibri">Calibri</option></select></div>
        <div class="pd-field"><label>حجم الخط العام</label><input type="number" min="7" max="28" step="0.5" data-print-setting="fontSize"></div>
        <div class="pd-field"><label>حجم عناوين التقرير</label><input type="number" min="10" max="40" step="1" data-print-setting="titleSize"></div>
        <div class="pd-field pd-field-wide"><label>تباعد الأسطر</label><div class="pd-range-line"><input type="range" min="0.8" max="3" step="0.05" data-print-setting="lineHeight"><span class="pd-range-output" data-range-output="lineHeight"></span></div></div>
      </div>
    </section>
    <section class="pd-section">
      <h3>تنسيق الجداول</h3>
      <div class="pd-grid">
        <div class="pd-field"><label>حجم خط الجدول</label><input type="number" min="5" max="24" step="0.5" data-print-setting="tableFontSize"></div>
        <div class="pd-field"><label>حجم خط رأس الجدول</label><input type="number" min="5" max="24" step="0.5" data-print-setting="tableHeaderSize"></div>
        <div class="pd-field"><label>المسافة الأفقية داخل الخلية</label><input type="number" min="0" max="30" step="1" data-print-setting="cellPaddingX"></div>
        <div class="pd-field"><label>المسافة العمودية داخل الخلية</label><input type="number" min="0" max="30" step="1" data-print-setting="cellPaddingY"></div>
        <div class="pd-field pd-field-wide"><label>الحد الأدنى لارتفاع الصف</label><div class="pd-range-line"><input type="range" min="10" max="120" step="1" data-print-setting="rowMinHeight"><span class="pd-range-output" data-range-output="rowMinHeight" data-suffix=" px"></span></div></div>
      </div>
      <div class="pd-table-tools">
        <button type="button" class="pd-tool-btn" id="pdResizeToggle">تفعيل سحب الأعمدة والصفوف</button>
        <button type="button" class="pd-tool-btn" id="pdFitTables">ملاءمة الجداول للعرض</button>
        <button type="button" class="pd-tool-btn" id="pdResetTables">إعادة أحجام الجداول</button>
      </div>
      <p class="pd-help">عند تفعيل وضع السحب تظهر أيقونة ذهبية على حافة كل عمود وأسفل كل صف. اسحب أفقياً لتغيير عرض العمود وعمودياً لتغيير ارتفاع الصف.</p>
    </section>
    <section class="pd-section">
      <h3>عناصر الطباعة</h3>
      <div class="pd-checks">
        <label class="pd-check"><input type="checkbox" data-print-setting="showReportHeader"> إظهار عنوان التقرير</label>
        <label class="pd-check"><input type="checkbox" data-print-setting="showFooter"> إظهار تذييل النظام واسم المبرمج</label>
        <label class="pd-check"><input type="checkbox" data-print-setting="repeatTableHeader"> تكرار رأس الجدول في كل صفحة</label>
        <label class="pd-check"><input type="checkbox" data-print-setting="printBackground"> طباعة ألوان وخلفيات الجداول</label>
      </div>
    </section>
  </div>
  <div class="pd-status" id="printDesignerStatus"></div>
  <div class="pd-panel-actions">
    <button type="button" class="btn btn-outline" id="pdApply">تطبيق ومعاينة</button>
    <button type="button" class="btn btn-outline" id="pdReset">إعادة الافتراضي</button>
    <button type="button" class="btn btn-light" id="pdSavePage">حفظ لهذه الصفحة</button>
    <button type="button" class="btn btn-light" id="pdSaveGlobal">اعتماد لجميع الصفحات</button>
    <button type="button" class="btn pd-print-primary" id="pdPrint">طباعة الآن</button>
  </div>
</aside>
<div class="toast" id="toast" role="status"></div>
<script src="assets/app.js?v=2.7.9.7-pro-print-r1"></script>
<script src="assets/print_designer.js?v=2.7.9.7-print-14digit-r1"></script>
<script src="assets/precision_print.js?v=2.7.9.7-print-14digit-r1"></script>
</body>
</html>
<?php
}

function render_public_header(string $title): void
{
    ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?></title>
<link rel="icon" href="assets/branding/app_icon.ico" sizes="any">
<link rel="apple-touch-icon" href="assets/branding/app_icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/app.css?v=2.7.9.7-journal-tb-monthly-r2">
</head>
<body class="public-body">
<?php
}

function render_public_footer(): void
{
    ?>
<div class="public-credit">المبرمج<br><strong>م. أرشد حميد حسن</strong><br><span>واتساب: 07735882844</span></div>
<script src="assets/app.js?v=2.7.9.7-pro-print-r1"></script>
</body></html>
<?php
}
