"""Government contract audit workspace."""
